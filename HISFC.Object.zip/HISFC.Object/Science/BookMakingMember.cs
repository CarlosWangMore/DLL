using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Science
{
    /// <summary>
    /// Neusoft.HISFC.Object.Science.BookMakingMember<br></br>
    /// [��������:������Ա��Ϣʵ�� ]<br></br>
    /// [�� �� ��: �·�]<br></br>
    /// [����ʱ��: 2008-05-21]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��='yyyy-mm-dd'
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class BookMakingMember : Neusoft.NFC.Object.NeuObject, Neusoft.HISFC.Object.Base.IValid
    {
        
        #region ����

        /// <summary>
        /// ְ��,��,����,������,��ί
        /// </summary>
        private Neusoft.NFC.Object.NeuObject responsibility = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��Ч��
        /// </summary>
        private bool isValid = true;

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private HRM.HRMEmployee hRMEmployee = new Neusoft.HISFC.Object.HRM.HRMEmployee();

        /// <summary>
        /// ����������Ϣ
        /// </summary>
        private Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private BookMaking bookMaking = new BookMaking();

        #endregion 

        #region ����

        /// <summary>
        /// ְ��,��,����,������,��ί
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Responsibility
        {
            get
            {
                return this.responsibility;
            }
            set
            {
                this.responsibility = value;
            }
        }

        /// <summary>
        /// ��Ч��
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.isValid;
            }
            set
            {
                this.isValid = value;
            }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public HRM.HRMEmployee HRMEmployee
        {
            get
            {
                return this.hRMEmployee;
            }
            set
            {
                this.hRMEmployee = value;
            }
        }

        /// <summary>
        /// ����������Ϣ
        /// </summary>
        public Base.OperEnvironment OperInfo
        {
            get
            {
                return this.operInfo;
            }
            set
            {
                this.operInfo = value;
            }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public BookMaking BookMaking
        {
            get
            {
                return this.bookMaking;
            }
            set
            {
                this.bookMaking = value;
            }
        }

        #endregion

        #region ����

        public new BookMakingMember Clone()
        {
            BookMakingMember member = base.Clone() as BookMakingMember;

            member.HRMEmployee = this.HRMEmployee.Clone();
            member.OperInfo = this.OperInfo.Clone();
            member.BookMaking = this.BookMaking.Clone();
            member.Responsibility = this.Responsibility.Clone();

            return member;
        }

        #endregion 
    }
}
