﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 组套实体类
    /// 由于组套与病历内容高度重合，考虑到组套加载与病历加载代码可复用，因此组套实体
    /// 继承门诊病历实体，但由于采用不同的表进行存储，因此数据访问层将各自独立。
    /// </summary>
    public class OmrTemplate : OmrRecord
    {
        private string owner;
        private string type;
        private string groupId;

        /// <summary>
        /// 拥有者
        /// </summary>
        public string Owner
        {
            get { return owner; }
            set { owner = value; }
        }

        /// <summary>
        /// 类型
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        /// <summary>
        /// 组ID
        /// </summary>
        public string GroupId
        {
            get { return groupId; }
            set { groupId = value; }
        }
    }
}
