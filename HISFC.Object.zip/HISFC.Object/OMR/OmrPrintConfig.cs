﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Neusoft.HISFC.Object.OMR
{
    public class OmrPrintConfig : Neusoft.NFC.Object.NeuObject
    {
        private string id;
        private string leftMargin;
        private string topMargin;
        private string lineHeight;
        private string font;
        private string integrateArg;
        private int hospitalNameLeft;
        private int recordLeft;
        private int signLeft;
        private int hospitalNameSize;
        private int recordSize;
        private int topMarginOdd; //奇数页上边距
        private int topMarginEven; //偶数页上边距
        private string hospitalName;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public int LeftMargin
        {
            get
            {
                int result = 0;
                Int32.TryParse(leftMargin, out result);

                return result; 
            }
            set
            {
                leftMargin = value.ToString();
            }
        }

        public string TopMargin
        {
            set
            {
                topMargin = value;
                string[] topMarginList = topMargin.Split('|');
                topMarginOdd = int.Parse(topMarginList[0]);
                topMarginEven = int.Parse(topMarginList[1]);
            }
        }

        public int LineHeight
        {
            get
            {
                int result = 0;
                Int32.TryParse(lineHeight, out result);

                return result;
            }
            set
            {
                lineHeight = value.ToString();
            }
        }

        public Font Font
        {
            get
            {
                Font result = GetDefaultFont();

                string[] fontResult = font.Split('|');

                if (fontResult.Length >= 2)
                {
                    int fontSize = 0;
                    if (Int32.TryParse(fontResult[1], out fontSize) && fontSize != 0)
                    {
                        try
                        {
                            result = new Font(fontResult[0], fontSize);
                        }
                        catch
                        {
                            //Nothing
                        }
                    }
                }

                return result; 
            }
            //set { font = value; }
        }

        public void SetFont(string fontString)
        {
            this.font = fontString;
        }

        public string IntegrateArg
        {
            get { return integrateArg; }
            set
            { 
                integrateArg = value;

                string[] integrateArgList = integrateArg.Split('|');
                hospitalNameLeft = int.Parse(integrateArgList[0]);
                recordLeft = int.Parse(integrateArgList[1]);
                signLeft = int.Parse(integrateArgList[2]);
                hospitalNameSize = int.Parse(integrateArgList[3]);
                recordSize = int.Parse(integrateArgList[4]);
            }
        }

        public int HospitalNameLeft
        {
            get { return hospitalNameLeft; }
        }

        public int RecordLeft
        {
            get { return recordLeft; }
        }

        public int SignLeft
        {
            get { return signLeft; }
        }

        public int HospitalNameSize
        {
            get { return hospitalNameSize; }
        }

        public int RecordSize
        {
            get { return recordSize; }
        }

        public int TopMarginOdd
        {
            get { return topMarginOdd; }
        }

        public int TopMarginEven
        {
            get { return topMarginEven; }
        }

        public string HospitalName
        {
            get { return hospitalName; }
            set { hospitalName = value; }
        }

        private Font GetDefaultFont()
        {
            return new Font("宋体", 12);
        }
    }
}
