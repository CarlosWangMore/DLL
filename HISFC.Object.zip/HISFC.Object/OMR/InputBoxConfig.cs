﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 模板输入框的配置实体
    /// name使用基类Name
    /// </summary>
    public class InputBoxConfig : Neusoft.NFC.Object.NeuObject
    {
        private string dllName;
        private string controlName;
        private string systemCode;
        private string systemName;
        private byte[] data;
        private string isAuto;

        /// <summary>
        /// dll名称
        /// </summary>
        public string DllName
        {
            get { return dllName; }
            set { dllName = value; }
        }

        /// <summary>
        /// 控件名称
        /// </summary>
        public string ControlName
        {
            get { return controlName; }
            set { controlName = value; }
        }

        /// <summary>
        /// 系统ID
        /// </summary>
        public string SystemCode
        {
            get { return systemCode; }
            set { systemCode = value; }
        }

        /// <summary>
        /// 系统名称
        /// </summary>
        public string SystemName
        {
            get { return systemName; }
            set { systemName = value; }
        }

        /// <summary>
        /// 辅助输入内容
        /// </summary>
        public byte[] Data
        {
            get { return data; }
            set { data = value; }
        }

        /// <summary>
        /// 是否为自动生成dll。"1"是，"0"否。
        /// 自动生成dll为用户维护输入项，非自动生成dll为开发人员维护
        /// </summary>
        public string IsAuto
        {
            get { return isAuto; }
            set { isAuto = value; }
        }
    }
}
