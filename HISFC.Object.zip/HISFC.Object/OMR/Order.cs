﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 处方类
    /// </summary>
    public class Order : Neusoft.NFC.Object.NeuObject
    {
        private string clinicCode;
        private string recordId;
        private string itemName; //药品名称
        private string specs; //规格
        private string onceDose; //剂量
        private string itemUnit; //数量

        /// add by shenwei 2015-1-6 {AEF90EB9-B22B-4b73-8AB1-80C1EA2B83D6}
        private string usageName;//用法
        private string frequencyName;//频次
        /// add end

        public string ClinicCode
        {
            get { return clinicCode; }
            set { clinicCode = value; }
        }

        public string RecordId
        {
            get { return recordId; }
            set { recordId = value; }
        }

        /// <summary>
        /// 药品名称
        /// </summary>
        public string ItemName
        {
            get { return itemName; }
            set { itemName = value; }
        }

        /// <summary>
        /// 规格
        /// </summary>
        public string Specs
        {
            get { return specs; }
            set { specs = value; }
        }

        /// <summary>
        /// 剂量
        /// </summary>
        public string OnceDose
        {
            get { return onceDose; }
            set { onceDose = value; }
        }

        /// <summary>
        /// 数量
        /// </summary>
        public string ItemUnit
        {
            get { return itemUnit; }
            set { itemUnit = value; }
        }

        /// <summary>
        /// 用法
        /// </summary>
        public string UsageName
        {
            get { return usageName; }
            set { usageName = value; }
        }

        /// <summary>
        /// 频次
        /// </summary>
        public string FrequencyName
        {
            get { return frequencyName; }
            set { frequencyName = value; }
        }

        public string OrderString
        {
            get
            {
                /// modified by shenwei 2015-1-6 {AEF90EB9-B22B-4b73-8AB1-80C1EA2B83D6}
                return string.Format("[{0}  {1}  {2}  {3}  {4}  {5}] ", ItemName, Specs, OnceDose, ItemUnit, UsageName, frequencyName);
            }
        }
    }
}
