﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 门诊病历检查项目实体
    /// 使用基类ID作为流水号,MEMO作为备注
    /// </summary>
    public class OmrSurveyData : Neusoft.NFC.Object.NeuObject
    {
        private string omrId;
        private string clinicCode;
        private string cardId;
        private string patientName;
        private string nodeName;
        private string nodeValue;
        private DateTime operDate;
        private DateTime surveyDate;
        private string operCode;
        private string unit;


       

        /// <summary>
        /// 病历ID
        /// </summary>
        public string OmrId
        {
            get { return omrId; }
            set { omrId = value; }
        }

        /// <summary>
        /// 挂号流水号
        /// </summary>
        public string ClinicCode
        {
            get { return clinicCode; }
            set { clinicCode = value; }
        }

        /// <summary>
        /// 卡号
        /// </summary>
        public string CardId
        {
            get { return cardId; }
            set { cardId = value; }
        }

        /// <summary>
        /// 患者姓名
        /// </summary>
        public string PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }

        /// <summary>
        /// 结点名称
        /// </summary>
        public string NodeName
        {
            get { return nodeName; }
            set { nodeName = value; }
        }

        /// <summary>
        /// 结点值
        /// </summary>
        public string NodeValue
        {
            get { return nodeValue; }
            set { nodeValue = value; }
        }

        /// <summary>
        /// 检查时间
        /// </summary>
        public DateTime SurveyDate
        {
            get { return surveyDate; }
            set { surveyDate = value; }
        }

        /// <summary>
        /// 操作时间
        /// </summary>
        public DateTime OperDate
        {
            get { return operDate; }
            set { operDate = value; }
        }

        /// <summary>
        /// 操作者ID
        /// </summary>
        public string OperCode
        {
            get { return operCode; }
            set { operCode = value; }
        }

        /// <summary>
        /// 单位
        /// </summary>
        public string Unit
        {
            get { return unit; }
            set { unit = value; }
        }
    }
}
