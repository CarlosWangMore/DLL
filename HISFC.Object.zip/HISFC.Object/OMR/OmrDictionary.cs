﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 门诊病历字典实体类
    /// 使用基类ID作为流水号,NAME作为字典名称
    /// </summary>
    public class OmrDictionary : Neusoft.NFC.Object.NeuObject
    {
        private string type;
        private string pyCode;
        private string unit;

        /// <summary>
        /// 类型
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        /// <summary>
        /// 拼音码
        /// </summary>
        public string PyCode
        {
            get { return pyCode; }
            set { pyCode = value; }
        }

        /// <summary>
        /// 默认单位
        /// </summary>
        public string Unit
        {
            get { return unit; }
            set { unit = value; }
        }
    }
}
