﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 特殊符号实体类
    /// 使用基类ID作为流水号
    /// </summary>
    public class Symbol : Neusoft.NFC.Object.NeuObject
    {
        private string symbolText;
        private string status;
        private string type;
        private string key;

        /// <summary>
        /// 主键ID
        /// </summary>
        public string Key
        {
            get { return key; }
            set { key = value;}
        }
        /// <summary>
        /// 符号值
        /// </summary>
        public string SymbolText
        {
            get { return symbolText; }
            set { symbolText = value; }
        }

        /// <summary>
        /// 状态
        /// </summary>
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        /// <summary>
        /// 类型
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
    }
}
