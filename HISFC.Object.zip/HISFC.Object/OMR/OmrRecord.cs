﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 门诊病历实体类
    /// 使用基类ID作为流水号
    /// </summary>
    public class OmrRecord : Neusoft.NFC.Object.NeuObject
    {
        private string clinicCode;
        private string cardId;
        private string patientName;
        private DateTime createDate;
        private string createOperCode;
        private string createOperName;
        private DateTime saveDate;
        private string saveOperCode;
        private string saveOperName;
        private string archiveDate;
        private string archiveOperCode;
        private string status;
        private string chiefComplaint;
        private string presentIllness;
        private string pastMedicalHistory;
        private string ballergicHistory;
        private string physicalSign;
        private string accessoryExamination;
        private string handlingSuggestion;
        private string deptCode;
        private string deptName;
        private string printFlag;
        private List<OmrSurveyData> survey;

        /// <summary>
        /// 所属科室编码
        /// </summary>
        public string DeptCode
        {
            get { return deptCode; }
            set { deptCode = value; }
        }

        /// <summary>
        /// 所属科室名称
        /// </summary>
        public string DeptName
        {
            get { return deptName; }
            set { deptName = value; }
        }

        /// <summary>
        /// 打印状态
        /// </summary>
        public string PrintFlag
        {
            get { return printFlag; }
            set { printFlag = value; }
        }

        /// <summary>
        /// 挂号流水号
        /// </summary>
        public string ClinicCode
        {
            get { return clinicCode; }
            set { clinicCode = value; }
        }

        /// <summary>
        /// 卡号
        /// </summary>
        public string CardId
        {
            get { return cardId; }
            set { cardId = value; }
        }

        /// <summary>
        /// 患者姓名
        /// </summary>
        public string PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }

        /// <summary>
        /// 病历创建时间
        /// </summary>
        public DateTime CreateDate
        {
            get { return createDate; }
            set { createDate = value; }
        }

        /// <summary>
        /// 创建者ID
        /// </summary>
        public string CreateOperCode
        {
            get { return createOperCode; }
            set { createOperCode = value; }
        }

        /// <summary>
        /// 创建者姓名
        /// </summary>
        public string CreateOperName
        {
            get { return createOperName; }
            set { createOperName = value; }
        }

        /// <summary>
        /// 保存时间
        /// </summary>
        public DateTime SaveDate
        {
            get { return saveDate; }
            set { saveDate = value; }
        }
  
        /// <summary>
        /// 保存者ID
        /// </summary>
        public string SaveOperCode
        {
            get { return saveOperCode; }
            set { saveOperCode = value; }
        }

        /// <summary>
        /// 保存者姓名
        /// </summary>
        public string SaveOperName
        {
            get { return saveOperName; }
            set { saveOperName = value; }
        }

        /// <summary>
        /// 归档时间
        /// </summary>
        public string ArchiveDate
        {
            get { return archiveDate; }
            set { archiveDate = value; }
        }

        /// <summary>
        /// 归档者ID
        /// </summary>
        public string ArchiveOperCode
        {
            get { return archiveOperCode; }
            set { archiveOperCode = value; }
        }

        /// <summary>
        /// 状态 
        /// </summary>
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        /// <summary>
        /// 主诉
        /// </summary>
        public string ChiefComplaint
        {
            get { return chiefComplaint; }
            set { chiefComplaint = value; }
        }

        /// <summary>
        /// 现病史
        /// </summary>
        public string PresentIllness
        {
            get { return presentIllness; }
            set { presentIllness = value; }
        }

        /// <summary>
        /// 既往史
        /// </summary>
        public string PastMedicalHistory
        {
            get { return pastMedicalHistory; }
            set { pastMedicalHistory = value; }
        }

        /// <summary>
        /// 过敏史
        /// </summary>
        public string BallergicHistory
        {
            get { return ballergicHistory; }
            set { ballergicHistory = value; }
        }

        /// <summary>
        /// 体征
        /// </summary>
        public string PhysicalSign
        {
            get { return physicalSign; }
            set { physicalSign = value; }
        }

        /// <summary>
        /// 辅助检查
        /// </summary>
        public string AccessoryExamination
        {
            get { return accessoryExamination; }
            set { accessoryExamination = value; }
        }

        /// <summary>
        /// 处理意见
        /// </summary>
        public string HandlingSuggestion
        {
            get { return handlingSuggestion; }
            set { handlingSuggestion = value; }
        }

        /// <summary>
        /// 检查项目
        /// </summary>
        public List<OmrSurveyData> Survey
        {
            get { return survey; }
            set { survey = value; }
        }
    }
}
