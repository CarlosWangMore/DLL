﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    /// <summary>
    /// 打印日志实体类
    /// 使用基类ID作为流水号
    /// </summary>
    public class PrintLog : Neusoft.NFC.Object.NeuObject
    {
        private string omrId;
        private DateTime printDate;
        private string operCode;
        private string operName;
        private string printPosition;

        /// <summary>
        /// 病历ID
        /// </summary>
        public string OmrId
        {
            get { return omrId; }
            set { omrId = value; }
        }

        /// <summary>
        /// 打印时间
        /// </summary>
        public DateTime PrintDate
        {
            get { return printDate; }
            set { printDate = value; }
        }

        /// <summary>
        /// 操作者ID
        /// </summary>
        public string OperCode
        {
            get { return operCode; }
            set { operCode = value; }
        }

        /// <summary>
        /// 操作者姓名
        /// </summary>
        public string OperName
        {
            get { return operName; }
            set { operName = value; }
        }

        /// <summary>
        /// 打印地点
        /// </summary>
        public string PrintPosition
        {
            get { return printPosition; }
            set { printPosition = value; }
        }
    }
}
