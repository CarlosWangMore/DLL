﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.OMR
{
    public class OmrInputSystem : Neusoft.NFC.Object.NeuObject
    {
        private string systemId;
        private string systemName;
        private string status;

        /// <summary>
        /// 系统ID
        /// </summary>
        public string SystemId
        {
            get { return systemId; }
            set { systemId = value; }
        }

        /// <summary>
        /// 系统名称
        /// </summary>
        public string SystemName
        {
            get { return systemName; }
            set { systemName = value; }
        }

        /// <summary>
        /// 状态 0停用，1启用
        /// </summary>
        public string Status
        {
            get { return status; }
            set { status = value; }
        }
    }
}
