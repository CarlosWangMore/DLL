using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Account
{
    public class PatientAccount : Neusoft.HISFC.Object.RADT.PatientInfo
    {

        #region ����
        Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion 

        #region ����
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            set
            {
                oper = value;
            }
            get
            {
                return oper;
            }
        }
        #endregion

        #region ����
        public new PatientAccount Clone()
        {
            PatientAccount patient = base.Clone() as PatientAccount;
            patient.Oper = this.Oper.Clone();
            return patient;
        }

        #endregion
    }
}
