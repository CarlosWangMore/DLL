using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Blood
{
    public class StoreBase : Neusoft.NFC.Object.NeuObject 
    {
        public StoreBase()
        {

        }

        #region ����

        /// <summary>
        /// ��Ѫ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject storeDept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// Ŀ�����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject targetDept = new Neusoft.NFC.Object.NeuObject();

        #endregion

        #region ����

        /// <summary>
        /// ��Ѫ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject StoreDept
        {
            get
            {
                return this.storeDept;
            }
            set
            {
                this.storeDept = value;
            }
        }

        /// <summary>
        /// Ŀ�����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject TargetDept
        {
            get
            {
                return this.targetDept;
            }
            set
            {
                this.targetDept = value;
            }
        }


        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public StoreBase Clone()
        {
            StoreBase cloneStoreBase = base.Clone() as StoreBase;

            cloneStoreBase.StoreDept = this.storeDept.Clone();

            cloneStoreBase.TargetDept = this.targetDept.Clone();

            return cloneStoreBase;
        }

        #endregion
    }
}
