using System;
using System.Collections.Generic;
using Neusoft.NFC.Attribute;
using Neusoft.NFC.Management;

namespace Neusoft.HISFC.Object.Fee
{
    /// <summary>
    /// FeeDrugGF �෽��ϸ����<para></para>
    /// [��������: {11690CD9-EB36-42fa-B73F-BD26D0E06373}]<para></para>
    /// [�� �� ��: �����]<para></para>
    /// [����ʱ��: 2012-11-01 15:40]<para></para>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  /><para></para>
    /// </summary>
    public class FeeDrugGF : Neusoft.NFC.Management.NeuObjectExtra
    {
        /// <summary>
        /// һ�㹹�캯��
        /// </summary>
        public FeeDrugGF()
        {
            objectStatus = ObjectStatus.New;
            base.pkFields = new string[] { "RecipeNo", "SequenceNo", "TransType", "DrugCode" };
        }

        /// <summary>
        /// ����һ��ʵ������¡����ʵ��
        /// </summary>
        public FeeDrugGF(FeeDrugGF argObj)
            : base(argObj)
        {
            base.pkFields = new string[] { "RecipeNo", "SequenceNo", "TransType", "DrugCode" };
        }

        #region ����

        #endregion

        #region ����
        /// <summary>
        /// ���ݿ����
        /// </summary>
        public override string TableName
        {
            get { return "FIN_IPB_MEDICINELIST_GF"; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string ID
        {
            get { return base.ID; }
            set { base.ID = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string Name
        {
            get { return base.Name; }
            set { base.Name = value; }
        }


        private string recipeNo;
        /// <summary>
        /// ������
        /// </summary>
        [DataFieldName("RECIPE_NO"), DataFieldDefault("")]
        public string RecipeNo
        {
            get { return recipeNo; }
            set
            {
                if (!object.Equals(recipeNo, value))
                {
                    if (!modifiedProperty.ContainsKey("RecipeNo"))
                    {
                        modifiedProperty.Add("RecipeNo", recipeNo);
                        this.IsModified = true;
                    }
                    recipeNo = value;
                }
            }
        }

        private int sequenceNo;
        /// <summary>
        /// ��������Ŀ��ˮ��
        /// </summary>
        [DataFieldName("SEQUENCE_NO")]
        public int SequenceNo
        {
            get { return sequenceNo; }
            set
            {
                if (!object.Equals(sequenceNo, value))
                {
                    if (!modifiedProperty.ContainsKey("SequenceNo"))
                    {
                        modifiedProperty.Add("SequenceNo", sequenceNo);
                        this.IsModified = true;
                    }
                    sequenceNo = value;
                }
            }
        }

        private string transType = "1";
        /// <summary>
        /// ��������,1�����ף�2������
        /// </summary>
        [DataFieldName("TRANS_TYPE"), DataFieldDefault("")]
        public string TransType
        {
            get { return transType; }
            set
            {
                if (!object.Equals(transType, value))
                {
                    if (!modifiedProperty.ContainsKey("TransType"))
                    {
                        modifiedProperty.Add("TransType", transType);
                        this.IsModified = true;
                    }
                    transType = value;
                }
            }
        }

        private string inpatientNo;
        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        [DataFieldName("INPATIENT_NO"), DataFieldDefault("")]
        public string InpatientNo
        {
            get { return inpatientNo; }
            set
            {
                if (!object.Equals(inpatientNo, value))
                {
                    if (!modifiedProperty.ContainsKey("InpatientNo"))
                    {
                        modifiedProperty.Add("InpatientNo", inpatientNo);
                        this.IsModified = true;
                    }
                    inpatientNo = value;
                }
            }
        }

        private string drugCode;
        /// <summary>
        /// ҩƷ����
        /// </summary>
        [DataFieldName("DRUG_CODE"), DataFieldDefault("")]
        public string DrugCode
        {
            get { return drugCode; }
            set
            {
                if (!object.Equals(drugCode, value))
                {
                    if (!modifiedProperty.ContainsKey("DrugCode"))
                    {
                        modifiedProperty.Add("DrugCode", drugCode);
                        this.IsModified = true;
                    }
                    drugCode = value;
                }
            }
        }

        private decimal perQty;
        /// <summary>
        /// ÿ����
        /// </summary>
        [DataFieldName("PER_QTY")]
        public decimal PerQty
        {
            get { return perQty; }
            set
            {
                if (!object.Equals(perQty, value))
                {
                    if (!modifiedProperty.ContainsKey("PerQty"))
                    {
                        modifiedProperty.Add("PerQty", perQty);
                        this.IsModified = true;
                    }
                    perQty = value;
                }
            }
        }

        private int packQty;
        /// <summary>
        /// ��װ����
        /// </summary>
        [DataFieldName("PACK_QTY")]
        public int PackQty
        {
            get { return packQty; }
            set
            {
                if (!object.Equals(packQty, value))
                {
                    if (!modifiedProperty.ContainsKey("PackQty"))
                    {
                        modifiedProperty.Add("PackQty", packQty);
                        this.IsModified = true;
                    }
                    packQty = value;
                }
            }
        }

        private decimal price;
        /// <summary>
        /// ��װ�۸�
        /// </summary>
        [DataFieldName("PRICE")]
        public decimal Price
        {
            get { return price; }
            set
            {
                if (!object.Equals(price, value))
                {
                    if (!modifiedProperty.ContainsKey("Price"))
                    {
                        modifiedProperty.Add("Price", price);
                        this.IsModified = true;
                    }
                    price = value;
                }
            }
        }

        private decimal totQty;
        /// <summary>
        /// ������
        /// </summary>
        [DataFieldName("TOT_QTY")]
        public decimal TotQty
        {
            get { return totQty; }
            set
            {
                if (!object.Equals(totQty, value))
                {
                    if (!modifiedProperty.ContainsKey("TotQty"))
                    {
                        modifiedProperty.Add("TotQty", totQty);
                        this.IsModified = true;
                    }
                    totQty = value;
                }
            }
        }

        private decimal totCost;
        /// <summary>
        /// �ܽ��
        /// </summary>
        [DataFieldName("TOT_COST")]
        public decimal TotCost
        {
            get { return totCost; }
            set
            {
                if (!object.Equals(totCost, value))
                {
                    if (!modifiedProperty.ContainsKey("TotCost"))
                    {
                        modifiedProperty.Add("TotCost", totCost);
                        this.IsModified = true;
                    }
                    totCost = value;
                }
            }
        }

        #endregion

        #region ����
        /// <summary>
        /// ǳ����¡
        /// </summary>
        public new FeeDrugGF Clone()
        {
            // TODO:  ���� FeeDrugGF.Clone ʵ��
            FeeDrugGF obj = base.Clone() as FeeDrugGF;

            return obj;
        }

        public List<FeeDrugGF> SelectData(string recipeNo, int sequenceNo, int transType)
        {
            string sql = "Select * from " + TableName + " Where RECIPE_NO='{0}' And SEQUENCE_NO='{1}' And TRANS_TYPE={2}";
            sql = string.Format(sql, recipeNo, sequenceNo, transType);
            if (dbManger.ExecQuery(sql) >= 0)
            {
                if (dbManger.ExecQuery(sql) < 0)
                {
                    this.Err = dbManger.Err;
                    return null;
                }
                List<FeeDrugGF> l = new List<FeeDrugGF>();
                while (dbManger.Reader.Read())
                {
                    FeeDrugGF f = new FeeDrugGF();
                    NFC.Function.Convert.ToObject(dbManger.Reader, f);
                    f.ResetStatus();
                    l.Add(f);
                }
                return l;
            }

            return null;
        }
        #endregion

    }

}