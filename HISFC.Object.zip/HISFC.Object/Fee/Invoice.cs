using System;
using Neusoft.HISFC.Object.Base;
using Neusoft.NFC.Object;
using Neusoft.HISFC.Object.RADT;

namespace Neusoft.HISFC.Object.Fee
{
	/// <summary>
	/// Invoice<br></br>
	/// [��������: ��Ʊ��]<br></br>
	/// [�� �� ��: ����]<br></br>
	/// [����ʱ��: 2006-09-01]<br></br>
	/// <�޸ļ�¼
	///		�޸���=''
	///		�޸�ʱ��='yyyy-mm-dd'
	///		�޸�Ŀ��=''
	///		�޸�����=''
	///  />
	/// </summary>
	public class Invoice : NeuObject
	{

		#region ����
		
		/// <summary>
		/// ��Ʊ����
		/// </summary>
        
		//private InvoiceTypeEnumService enumInvoiceType = new InvoiceTypeEnumService();

        private NeuObject invoiceType = new NeuObject();


		
		/// <summary>
		/// ��Ч״̬
		/// </summary>
		private string validState;
		
		/// <summary>
		/// ��÷�Ʊ�Ĳ���Ա��Ϣ
		/// </summary>
		private Employee acceptOper = new Employee();
		
		/// <summary>
		/// ��ȡʱ��
		/// </summary>
		private DateTime acceptTime;
		
		/// <summary>
		/// ��Ʊ��ʼ��
		/// </summary>
		private string beginNO;
		
		/// <summary>
		/// ��Ʊ��ֹ��
		/// </summary>
		private string endNO;
		
		/// <summary>
		/// ��ǰʹ�ú�
		/// </summary>
		private string usedNO;
	
		/// <summary>
		/// ��Ʊ��Ŀ
		/// </summary>
		private int qty;

		/// <summary>
		/// �Ƿ���
		/// </summary>
		private bool isPublic;


        /// <summary>
        /// ��Ʊ��ʼ�ַ�  {826A12F1-2A31-49a5-83E9-F01D9E6C7E2D}
        /// </summary>
        private string beginLetter = string.Empty;

		#endregion

		#region ����
		
		/// <summary>
		/// ��Ʊ����
		/// </summary>
        
        //public InvoiceTypeEnumService Type
        //{
        //    get
        //    {
        //        return this.enumInvoiceType;
        //    }
        //    set
        //    {
        //        this.enumInvoiceType = value;
        //    }
        //}
        public NeuObject Type
        {
            set
            {
                this.invoiceType = value;
            }
            get
            {
                return this.invoiceType;
            }
            
        }
            


		/// <summary>
		/// ��Ч״̬
		/// </summary>
		public string ValidState
		{
			get
			{
				return this.validState;
			}
			set
			{
				this.validState = value;
			}
		}
		
		/// <summary>
		/// ��÷�Ʊ�Ĳ���Ա
		/// </summary>
		public Employee AcceptOper
		{
			get
			{
				return this.acceptOper;
			}
			set
			{
				this.acceptOper = value;
			}
		}
		
		/// <summary>
		/// ��ȡʱ��
		/// </summary>
		public DateTime AcceptTime
		{
			get
			{
				return this.acceptTime;
			}
			set
			{
				this.acceptTime = value;
			}
		}
		
		/// <summary>
		/// ��Ʊ��ʼ��
		/// </summary>
		public string BeginNO
		{
			get
			{
				return this.beginNO;
			}
			set
			{
				//this.beginNO = value.PadLeft(12, '0');
                this.beginNO = value;
			}
		
		}
		
		/// <summary>
		/// ��Ʊ��ֹ��
		/// </summary>
		public string EndNO
		{
			get
			{
				return this.endNO;
			}
			set
			{
				//this.endNO = value.PadLeft(12, '0');
                this.endNO = value;
			}
		
		}

		/// <summary>
		/// ��ǰʹ�ú�
		/// </summary>
		public string UsedNO
		{
			get
			{
				return this.usedNO;
			}
			set
			{
                //this.usedNO = value.PadLeft(12, '0');
                this.usedNO = value;
			}
		}

		/// <summary>
		/// ��Ʊ��Ŀ
		/// </summary>
		public int Qty
		{
			get
			{
				return this.qty;
			}
			set
			{
				this.qty = value;
			}
		}

		/// <summary>
		/// �Ƿ���
		/// </summary>
		public bool IsPublic
		{
			get
			{
				return this.isPublic;
			}
			set
			{
				this.isPublic = value;
			}
		}

        /// <summary>
        /// ��Ʊ��ʼ�ַ�{826A12F1-2A31-49a5-83E9-F01D9E6C7E2D}
        /// </summary>
        public string BeginLetter
        {
            get
            {
                return beginLetter;
            }
            set
            {
                beginLetter = value;
            }
        }
		#endregion
		
		#region ʧЧ����
		
		/// <summary>
		/// ��Ʊ״̬ 
		/// </summary>
		//public Neusoft.NFC.Object.NeuObject State = new Neusoft.NFC.Object.NeuObject();
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��ValidState����", true)]
		public int State; //1  0  -1
		
		//[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��AcceptOper����", true)]
		//public Neusoft.HISFC.Object.RADT.Person User= new Neusoft.HISFC.Object.RADT.Person();

		/// <summary>
		/// ��ȡʱ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ������AcceptTime", true)]
		public DateTime HadInvoiceTime;
		
		string startCode;
		/// <summary>
		/// ��Ʊ��ʼ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��BegionNO����", true)]
		public string StartCode
		{
			get{ return this.startCode; }
			set{ this.startCode = value.PadLeft(12,'0'); }
		}
		string endCode;
		/// <summary>
		/// ��Ʊ��ֹ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��EndNO����", true)]
		public string EndCode
		{
			get{ return this.endCode; }
			set{ this.endCode = value.PadLeft(12,'0'); }
		}
		string userCode;
		/// <summary>
		/// ��ǰʹ�ú�
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��UsedNO����", true)]
		public string UsedCode
		{
			get{ return this.userCode; }
			set{ this.userCode = value.PadLeft(12,'0'); }
		}

		/// <summary>
		/// ��Ʊ��Ŀ
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��Qty����", true)]
		public int Numbers;


		/// <summary>
		/// �Ƿ���  IS_PUB
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ֹͣʹ��,ʹ��IsPublic����", true)]
		public bool IsGroup;

		#endregion

		#region ����

		#region ��¡

		/// <summary>
		/// ��¡
		/// </summary>
		/// <returns>��ǰ�����ʵ������</returns>
		public new Invoice Clone()
		{
			Invoice invoice = base.Clone() as Invoice;

			invoice.AcceptOper = this.AcceptOper.Clone();
			invoice.Type = this.Type.Clone();
            //invoice.InvoiceType = this.InvoiceType.Clone();
			return invoice;
		}

		#endregion

		#endregion
	}
}
