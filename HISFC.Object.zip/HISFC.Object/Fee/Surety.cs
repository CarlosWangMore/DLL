using System;
using System.Collections.Generic;
using System.Text;
using Neusoft.NFC.Object;

namespace Neusoft.HISFC.Object.Fee
{
    public class Surety : Neusoft.NFC.Object.NeuObject
    {
        #region  ����

        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        private string patientNO = string.Empty;

        /// <summary>
        /// ����
        /// </summary>
        private NeuObject dept = new NeuObject();

        /// <summary>
        /// ������
        /// </summary>
        private NeuObject suretyPerson = new NeuObject();

        /// <summary>
        /// ������
        /// </summary>
        private NeuObject applyPerson = new NeuObject();
        
        /// <summary>
        /// �������
        /// </summary>
        private decimal suretyCost = 0m;
        
        /// <summary>
        /// ��ע
        /// </summary>
        private string mark;
        
        /// <summary>
        /// ��������
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();
        
        /// ��������
        /// </summary>
        //private SuretyTypeEnumService suretyType = new SuretyTypeEnumService();
        private Neusoft.NFC.Object.NeuObject suretyType = new NeuObject();
        #endregion

        #region ����

        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        public string PatientNO
        {
            get
            {
                return patientNO;
            }
            set
            {
                patientNO = value;
            }

        }

        /// <summary>
        /// ����
        /// </summary>
        public NeuObject Dept
        {
            get
            {
                return dept;
            }
            set
            {
                dept = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public NeuObject SuretyPerson
        {
            get
            {
                return suretyPerson;
            }
            set
            {
                suretyPerson = value;
            }

        }
        /// <summary>
        /// ������
        /// </summary>
        public NeuObject ApplyPerson
        {
            get
            {
                return applyPerson;
            }
            set
            {
                applyPerson = value;
            }
        }
        /// <summary>
        /// �������
        /// </summary>
        public decimal SuretyCost
        {
            get
            {
                return suretyCost;
            }
            set
            {
                suretyCost = value;
            }
        }
        /// <summary>
        /// ��ע
        /// </summary>
        public string Mark
        {
            get
            {
                return mark;
            }
            set
            {
                mark = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return oper;
            }
            set
            {
                oper = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        //public SuretyTypeEnumService SuretyType
        //{
        //    get
        //    {
        //        return suretyType;
        //    }
        //    set
        //    {
        //        suretyType = value;
        //    }
        //}
        public Neusoft.NFC.Object.NeuObject SuretyType
        {
            get
            {
                return suretyType;
            }
            set
            {
                suretyType = value;
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new Surety Clone()
        {
            Surety obj = base.Clone() as Surety;
           // obj.SuretyType = this.SuretyType.Clone() as SuretyTypeEnumService;
            obj.SuretyPerson = this.SuretyPerson.Clone();
            obj.Oper = this.Oper.Clone();
            obj.ApplyPerson = this.ApplyPerson.Clone();
            obj.SuretyType = this.SuretyType.Clone();
            return obj;
        }
        #endregion
    }
}
