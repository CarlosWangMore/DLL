using System;

namespace Neusoft.HISFC.Object.Fee.Outpatient
{
	/// <summary>
	/// Balance<br></br>
	/// [��������: ��������� ID:����������ˮ�� Name:��������]<br></br>
	/// [�� �� ��: ����]<br></br>
	/// [����ʱ��: 2006-09-06]<br></br>
	/// <�޸ļ�¼
	///		�޸���=''
	///		�޸�ʱ��='yyyy-mm-dd'
	///		�޸�Ŀ��=''
	///		�޸�����=''
	///  />
	/// </summary>
	public class Balance : BalanceBase 
	{
		#region ����

        public Balance() 
        {
            this.Patient = new Neusoft.HISFC.Object.Registration.Register();  
        }

		/// <summary>
		/// �Һ�����
		/// </summary>
		private DateTime regTime;
		
		/// <summary>
		/// ����־ 0�������/1�������/2������� 
		/// </summary>
		private string examineFlag;
		
		/// <summary>
		/// ��Ʊ��ţ�һ�ν���������ŷ�Ʊ��combNO
		/// </summary>
		private string combNO;
		
		/// <summary>
		/// ��Ʊ�ϵĴ�ӡ��
		/// </summary>
		private string printedInvoiceNO;
		
		/// <summary>
		/// ��ҩ������Ϣ
		/// </summary>
		private string drugWindowsNO;
		
		/// <summary>
		/// �ս��ʶ��
		/// </summary>
		private string balanceID;
        //{6D309EC1-0953-445d-8CD6-C635E739916B}
        /// <summary>
        /// ����Ա��½����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject logindept = new Neusoft.NFC.Object.NeuObject();
        /// <summary>
        /// ����ҽԺ���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject hospital = new Neusoft.NFC.Object.NeuObject();
        ////{6D309EC1-0953-445d-8CD6-C635E739916B}
		#endregion

		#region ����
		
		/// <summary>
		/// �Һ�����
		/// </summary>
		public DateTime RegTime
		{
			get
			{
				return this.regTime;
			}
			set
			{
				this.regTime = value;
			}
		}

		/// <summary>
		/// ����־ 0�������/1�������/2������� 
		/// </summary>
		public string ExamineFlag
		{
			get
			{
				return this.examineFlag;
			}
			set
			{
				this.examineFlag = value;
			}
		}
		
		/// <summary>
		/// ��Ʊ��ţ�һ�ν���������ŷ�Ʊ��combNO
		/// </summary>
		public string CombNO
		{
			get
			{
				return this.combNO;
			}
			set
			{
				this.combNO = value;
			}
		}
		
		/// <summary>
		/// ��Ʊ�ϵĴ�ӡ��
		/// </summary>
		public string PrintedInvoiceNO
		{
			get
			{
				return this.printedInvoiceNO;
			}
			set
			{
				this.printedInvoiceNO = value;
			}
		}
		
		/// <summary>
		/// ��ҩ������Ϣ
		/// </summary>
		public string DrugWindowsNO
		{
			get
			{
				return this.drugWindowsNO;
			}
			set
			{
				this.drugWindowsNO = value;
			}
		}

		/// <summary>
		/// �ս��ʶ��
		/// </summary>
		public string BalanceID
		{
			get
			{
				return this.balanceID;
			}
			set
			{
				this.balanceID = value;
			}
		}
        //{6D309EC1-0953-445d-8CD6-C635E739916B}
        /// <summary>
        /// ����Ա��½����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Logindept
        {
            get { return logindept; }
            set { logindept = value; }
        }
        /// <summary>
        /// ����ҽԺ���
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Hospital
        {
            get { return hospital; }
            set { hospital = value; }
        }
        ////{6D309EC1-0953-445d-8CD6-C635E739916B}
		#endregion

		#region ����
		
		#region ��¡
		
		/// <summary>
		/// ��¡
		/// </summary>
		/// <returns>���ص�ǰ����ʵ��</returns>
		public new Balance Clone()
		{
			return base.Clone() as Balance;
		} 

		#endregion

		#endregion
		
		#region ���ñ���,����

		private string cardNo;//���߾��￨��
		/// <summary>
		/// ���߾��￨��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����,�Ѿ��̳�Patinet.PID.CardNO", true)]
		public string CardNo 
		{
			get
			{
				return cardNo;
			}
			set
			{
				cardNo = value;
			}
		}

		private DateTime regDate;
		/// <summary>
		/// �Һ�����
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����,RegTime����", true)]
		public DateTime RegDate
		{
			get
			{
				return regDate;
			}
			set
			{
				regDate = value;
			}
		}
		private string patientName = "";
		/// <summary>
		/// ��������
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����,Base.Name", true)]
		public string PatientName 
		{
			get
			{
				return patientName;
			}
			set
			{
				patientName = value;
			}
		}
		private Neusoft.HISFC.Object.Base.PayKind payKind = new Neusoft.HISFC.Object.Base.PayKind();
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����,�Ѿ��̳�this.Patient.Pact.PayKind", true)]
		public Neusoft.HISFC.Object.Base.PayKind PayKind 
		{
			get
			{
				return payKind;
				
			}
			set
			{
				payKind = value;
			}
		}

		private Neusoft.NFC.Object.NeuObject pactUnit = new Neusoft.NFC.Object.NeuObject();
		/// <summary>
		/// ��ͬ��λ
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����,�Ѿ��̳�this.Patient.Pact", true)]
		public Neusoft.NFC.Object.NeuObject PactUnit 
		{
			get
			{
				return pactUnit;
			}
			set
			{
				pactUnit = value;
			}
		}

		private Neusoft.NFC.Object.NeuObject medicalType = new Neusoft.NFC.Object.NeuObject();
		/// <summary>
		/// ҽ�����
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("should use Pact property",true)]
		public Neusoft.NFC.Object.NeuObject MedicalType
		{
			get
			{
				return medicalType;
			}
			set
			{
				medicalType = value;
			}
		}
		
		private DateTime balanceDate;
		/// <summary>
		/// ��������
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("BalanceOper.OperTime",true)]
		public DateTime BalanceDate 
		{
			get
			{
				return balanceDate;
			}
			set
			{
				balanceDate = value;
			}
		}
		private Neusoft.NFC.Object.NeuObject balanceOper = new Neusoft.NFC.Object.NeuObject();

		
		private Neusoft.HISFC.Object.Base.CancelTypes cancelFlag;
		//private bool isCancel = false;
		/// <summary>
		/// ���ϱ�־
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("CancelType",true)]
		public Neusoft.HISFC.Object.Base.CancelTypes CancelFlag
		{
			get
			{
				return cancelFlag;
			}
			set
			{
				cancelFlag = value;
			}
		}

		private string cancelInvoice = "";
		/// <summary>
		/// ����Ʊ�ݺ�
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("canceledInvoiceNO",true)]
		public string CancelInvoice 
		{
			get
			{
				return cancelInvoice;
			}
			set
			{
				cancelInvoice = value;
			}
		}

		private DateTime cancelDate;
		/// <summary>
		/// ����ʱ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("CancelOper.OperTime",true)]
		public DateTime CancelDate 
		{
			get
			{
				return cancelDate;
			}
			set
			{
				cancelDate = value;
			}
		}

		private bool isCheck;
		/// <summary>
		/// �Ƿ�˲�
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("IsAuditing",true)]
		public bool IsCheck 
		{
			get
			{
				return isCheck;
			}
			set
			{
				isCheck = value;
			}
		}

		private Neusoft.NFC.Object.NeuObject checkOper = new Neusoft.NFC.Object.NeuObject() ;
		/// <summary>
		/// �˲���
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("AuditingOper.Oper",true)]
		public Neusoft.NFC.Object.NeuObject CheckOper 
		{
			get
			{
				return checkOper;
			}
			set
			{
				checkOper = value;
			}
		}

		private string checkDate = "";
		/// <summary>
		/// �˲�ʱ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("AuditingOper.OperTime",true)]
		public string CheckDate 
		{
			get
			{
				return checkDate;
			}
			set
			{
				checkDate = value;
			}
		}

		private DateTime dayBalanceDate ;
		/// <summary>
		/// �ս�ʱ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("DayBalanceOper.OperTime",true)]
		public DateTime DayBalanceDate 
		{
			get
			{
				return dayBalanceDate;
			}
			set
			{
				dayBalanceDate = value;
			}
		}
		
		private bool isBalanced;
		/// <summary>
		/// �Ƿ��ս�
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("IsDayBalanced",true)]
		public bool IsBalanced 
		{
			get
			{
				return isBalanced;
			}
			set
			{
				isBalanced = value;
			}
		}
		
		
		private DateTime printDisplayDate;//��Ʊ��ʾ�Ĵ�ӡʱ��
		/// <summary>
		/// ��Ʊ��ʾ��ӡʱ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("PrintTime",true)]
		public DateTime PrintDisplayDate
		{
			get
			{
				return printDisplayDate;
			}
			set
			{
				printDisplayDate = value;
			}
		}
		private string clinicNO;//�Һ���ˮ��
		/// <summary>
		/// �Һ���ˮ��
		/// </summary>
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("Base.ID",true)]
		public string ClinicNO
		{
			get
			{
				return clinicNO;
			}
			set
			{
				clinicNO = value;
			}
		}
		
		#endregion
	}
}
