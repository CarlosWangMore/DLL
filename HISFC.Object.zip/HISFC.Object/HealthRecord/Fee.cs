using System;


namespace Neusoft.HISFC.Object.HealthRecord
{


    /// <summary>
    /// Fee ��ժҪ˵����ID ����Ա���� Name ����Ա����
    /// </summary>
    public class Fee : Neusoft.NFC.Object.NeuObject
    {
        public Fee()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ˽�б���

        private string inpatientNO;
        private Neusoft.NFC.Object.NeuObject myDeptInfo = new Neusoft.NFC.Object.NeuObject();
        private Neusoft.NFC.Object.NeuObject myMainOutICD = new Neusoft.NFC.Object.NeuObject();
        private decimal totCost;
        private DateTime outDate;
        private DateTime operDate;
        private Neusoft.NFC.Object.NeuObject myFeeInfo = new Neusoft.NFC.Object.NeuObject();
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion

        #region ����

        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        public string InpatientNO
        {
            get
            {
                return inpatientNO;
            }
            set
            {

                inpatientNO = value;
            }
        }

        /// <summary>
        /// ������Ϣ(�Ƿ�Ҫ���ǻ���ת�����) ID ���ұ��� Name ��������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject DeptInfo
        {
            get
            {
                return myDeptInfo;
            }
            set
            {
                myDeptInfo = value;
            }
        }
        /// <summary>
        /// ��Ժ�������Ϣ ID �������Ϣ Name �������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject MainOutICD
        {
            get
            {
                return myMainOutICD;
            }
            set
            {
                myMainOutICD = value;
            }
        }
        /// <summary>
        /// ���
        /// </summary>
        public decimal TotCost
        {
            get
            {
                return totCost;
            }
            set
            {
                totCost = value;
            }
        }
        /// <summary>
        /// ��Ժ����
        /// </summary>
        public DateTime OutDate
        {
            get
            {
                return outDate;
            }
            set
            {
                outDate = value;
            }
        }
        /// <summary>
        /// ����Ա��
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }
        /// <summary>
        /// ������Ϣ ID ���ô������ Name ���ô�������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject FeeInfo
        {
            get
            {
                return myFeeInfo;
            }
            set
            {
                myFeeInfo = value;
            }
        }

        #endregion

        #region ���ú���


        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns>Case.Fee</returns>
        public new Fee Clone()
        {
            Fee FeeClone = base.MemberwiseClone() as Fee;

            FeeClone.FeeInfo = this.FeeInfo.Clone();
            FeeClone.DeptInfo = this.DeptInfo.Clone();
            FeeClone.MainOutICD = this.MainOutICD.Clone();
            FeeClone.operInfo = operInfo.Clone();

            return FeeClone;
        }

        #endregion

        #region ����
        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� OperInfo.OperTime ����", true)]
        public DateTime OperDate
        {
            get
            {
                return operDate;
            }
            set
            {
                operDate = value;
            }
        }
        #endregion
    }
}
