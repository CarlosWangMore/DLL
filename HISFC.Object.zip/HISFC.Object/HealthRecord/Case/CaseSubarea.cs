using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord.Case
{
    /// <summary>
    /// [��������: ������������վά��]<br></br>
    /// [�� �� ��: ��ΰ��]<br></br>
    /// [����ʱ��: 2007/09/13]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class CaseSubarea : Neusoft.NFC.Object.NeuObject
    {
        public CaseSubarea()
        {
        }

        private Neusoft.NFC.Object.NeuObject subArea = new Neusoft.NFC.Object.NeuObject();

        private Neusoft.NFC.Object.NeuObject nurseStation = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject SubArea
        {
            get
            {
                return this.subArea;
            }
            set
            {
                this.subArea = value;
            }
        }


        /// <summary>
        /// ����վ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject NurseStation
        {
            get
            {
                return this.nurseStation;
            }
            set
            {
                this.nurseStation = value;
            }
        }

        /// <summary>
        /// �����¶���
        /// </summary>
        /// <returns></returns>
        public new CaseSubarea Clone()
        {
            CaseSubarea cb = base.Clone() as CaseSubarea;

            cb.subArea = this.subArea.Clone();
            cb.nurseStation = this.nurseStation.Clone();

            return cb;
        }
    }
}
