using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord.Case
{
    /// <summary>
    /// ���Ĳ���ҵ������
    /// </summary>
    public enum EnumLendType
    {
        /// <summary>
        /// ����
        /// </summary>
        Lend = 0,
        /// <summary>
        /// ����
        /// </summary>
        Refer = 1
    }


}
