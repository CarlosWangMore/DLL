using System;
using Neusoft.NFC.Object;


namespace Neusoft.HISFC.Object.HealthRecord
{
    /// <summary>
    /// Base<br></br>
    /// [��������:����������Ϣ�Ǽ�]<br></br>
    /// [�� �� ��: �ſ���]<br></br>
    /// [����ʱ��: 2007-04-2]<br></br>
    /// <�޸ļ�¼ 
    ///		�޸���='������' 
    ///		�޸�ʱ��='2009-10-28' 
    ///		�޸�Ŀ��='����'
    ///		�޸�����='ҽ�Ƹ��ʽ��ҽ�����Ѻ�'
    ///  />
    /// </summary>
    public class Base //: Neusoft.NFC.Object.NeuObject
    {
        public Base()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ˽�б���
        private string caseNO = "";
        /// <summary>
        /// ������ 
        /// </summary>
        private System.String nomen;
        /// <summary>
        /// ���䵥λ
        /// </summary>
        private System.String ageUnit; 
        /// <summary>
        /// ת��ҽԺ
        /// </summary>
        private System.String comeFrom;
        /// <summary>
        /// ��Ժ��Դ
        /// </summary>
        private System.String inAvenue;
        /// <summary>
        ///��Ժ״̬
        /// </summary>
        private System.String inCircs;
        /// <summary>
        /// �������
        /// </summary>
        private System.DateTime diagDate;
        /// <summary>
        /// ��������
        /// </summary>
        private System.DateTime operationDate;
        /// <summary>
        /// ȷ������
        /// </summary>
        private System.Int32 diagDays;
        /// <summary>
        /// סԺ����
        /// </summary>
        private System.Int32 inHospitalDays;
        /// <summary>
        /// ��������
        /// </summary>
        private System.DateTime deadDate;
        /// <summary>
        /// ����ԭ��
        /// </summary>
        private System.String deadReason;
        /// <summary>
        /// �Ƿ�ʬ��
        /// </summary>
        private System.String cadaverCheck;

        /// <summary>
        /// ʬ����
        /// </summary>
        private System.String cadaverCheckId;

        /// <summary>
        /// ��������
        /// </summary>
        private System.String deadKind;
        /// <summary>
        /// ���ʺ�
        /// </summary>
        private System.String bodyAnotomize;
        /// <summary>
        /// �Ҹα��濹ԭ�����ԡ����ԡ�δ���� 
        /// </summary>
        private System.String hbsag;
        /// <summary>
        /// ���β������壨���ԡ����ԡ�δ����
        /// </summary>
        private System.String hcvAb;
        /// <summary>
        /// �������������ȱ�ݲ������壨���ԡ����ԡ�δ����
        /// </summary>
        private System.String hivAb;
        /// <summary>
        /// �ż���Ժ����
        /// </summary>
        private System.String cePi;
        /// <summary>
        /// ���Ժ����
        /// </summary>
        private System.String piPo;
        /// <summary>
        /// ��ǰ�����
        /// </summary>
        private System.String opbOpa;
        /// <summary>
        /// �ٴ�X�����
        /// </summary>
        private System.String clX;
        /// <summary>
        /// �ٴ�CT����
        /// </summary>
        private System.String clCt;
        /// <summary>
        /// �ٴ�MRI����
        /// </summary>
        private System.String clMri;
        /// <summary>
        /// �ٴ���������
        /// </summary>
        private System.String clPa;
        /// <summary>
        /// ���䲡������
        /// </summary>
        private System.String fsBl;
        /// <summary>
        /// ���ȴ���
        /// </summary>
        private System.Int32 salvTimes;
        /// <summary>
        /// �ɹ�����
        /// </summary>
        private System.Int32 succTimes;
        /// <summary>
        /// /ʾ�̿���
        /// </summary>
        private System.String techSerc;
        /// <summary>
        /// �Ƿ�����
        /// </summary>
        private System.String visiStat;
        /// <summary>
        /// �������
        /// </summary>
        private System.DateTime visiPeriod;
        /// <summary>
        /// Ժ�ʻ������
        /// </summary>
        private System.Int32 inconNum;
        /// <summary>
        /// Զ�̻������
        /// </summary>
        private System.Int32 outconNum;
        /// <summary>
        /// ҩ�����
        /// </summary>
        private System.String anaphyFlag;
        private System.DateTime coutDate;
        /// <summary>
        /// ��������
        /// </summary>
        private System.String mrQual;
        /// <summary>
        /// �ϸ񲡰�
        /// </summary>
        private System.String mrElig; 
        /// <summary>
        ///  ���ʱ��
        /// </summary>
        private System.DateTime checkDate;
        /// <summary>
        /// ���������������ơ���顢���Ϊ��Ժ��һ����Ŀ
        /// </summary>
        private System.String ynFirst;
        /// <summary>
        /// RhѪ��(������)
        /// </summary>
        private System.String rhBlood;
        /// <summary>
        /// ��Ѫ��Ӧ���С��ޣ�
        /// </summary>
        private System.String reactionBlood;
        /// <summary>
        /// ��ϸ����
        /// </summary>
        private System.String bloodRed;
        /// <summary>
        /// ѪС����
        /// </summary>
        private System.String bloodPlatelet;
        /// <summary>
        /// Ѫ����
        /// </summary>
        private System.String bloodPlasma;
        /// <summary>
        /// ȫѪ��
        /// </summary>
        private System.String bloodWhole;
        /// <summary>
        /// ������Ѫ��
        /// </summary>
        private System.String bloodOther;
        /// <summary>
        ///  X���
        /// </summary>
        private System.String xNumb;
        /// <summary>
        /// CT��
        /// </summary>
        private System.String ctNumb;
        /// <summary>
        /// MRI��
        /// </summary>
        private System.String mriNumb;
        /// <summary>
        /// ������
        /// </summary>
        private System.String pathNumb;
        /// <summary>
        /// DSA��
        /// </summary>
        private System.String dsaNumb;
        /// <summary>
        /// PET��
        /// </summary>
        private System.String petNumb;
        /// <summary>
        ///  ECT��
        /// </summary>
        private System.String ectNumb;
        /// <summary>
        /// X�ߴ���
        /// </summary>
        private System.Int32 xQty;
        /// <summary>
        /// CT����
        /// </summary>
        private System.Int32 ctQty;
        /// <summary>
        ///  MR����
        /// </summary>
        private System.Int32 mrQty;
        /// <summary>
        /// DSA����
        /// </summary>
        private System.Int32 dsaQty;
        /// <summary>
        ///  PET����
        /// </summary>
        private System.Int32 petQty;
        /// <summary>
        /// ECT����
        /// </summary>
        private System.Int32 ectQty;
        /// <summary>
        /// �鵵�����
        /// </summary>
        private System.String barCode;
        /// <summary>
        /// lendStus
        /// </summary>
        private System.String lendStat;
        /// <summary>
        /// ����״̬1�����ʼ�/2�ǼǱ���/3����/4�������ʼ�/5��Ч
        /// </summary>
        private System.String caseStat;
        /// <summary>
        /// s������� ��������
        /// </summary>
        private string visiPeriWeek;
        /// <summary>
        /// s������� ��������
        /// </summary>
        private string visiPeriMonth;
        /// <summary>
        /// s������� ��������
        /// </summary>
        private string visiPeriYear;
        /// <summary>
        /// I������ʱ��(��)  
        /// </summary>
        private decimal iNus;
        /// <summary>
        /// II������ʱ��(��)  
        /// </summary>
        private decimal iiNus;
        /// <summary>
        /// III������ʱ��(��)    
        /// </summary>
        private decimal iiiNus;
        /// <summary>
        /// ��֢�໤ʱ��( Сʱ)     
        /// </summary>          
        private decimal strictnessNus;
        /// <summary>
        /// �ؼ�����ʱ��(Сʱ) 
        /// </summary>
        private decimal superNus;
        /// <summary>
        /// ���⻤��(��)  
        /// </summary>
        private decimal specalNus;
        /// <summary>
        /// �Ƿ񵥲���
        /// </summary>
        private string disease30;
        /// <summary>
        /// �Ƿ��Զ�¼�벡��
        /// </summary>
        private string isHandCraft;
        /// <summary>
        /// �Ƿ��в���֢
        /// </summary>
        private string syndromeFlag;
        /// <summary>
        /// ������������Ա 
        /// </summary>
        private NeuObject operationCodingOper = new NeuObject();
        /// <summary>
        /// ��Ժ����
        /// </summary>
        private Neusoft.HISFC.Object.RADT.Location inDept = new Neusoft.HISFC.Object.RADT.Location();
        /// <summary>
        /// ����ҩ������
        /// </summary>
        private NeuObject firstAnaphyPharmacy = new NeuObject();
        /// <summary>
        /// ����ҩ������
        /// </summary>
        private NeuObject secondAnaphyPharmacy = new NeuObject();
        /// <summary>
        /// ��Ժ����
        /// </summary>
        private Neusoft.HISFC.Object.RADT.Location outDept = new Neusoft.HISFC.Object.RADT.Location();
        /// <summary>
        /// �������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject clinicDiag = new NeuObject();

        /// <summary>
        /// ��Ժ���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject inHospitalDiag = new NeuObject();
        /// <summary>
        /// ��Ժ���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject outDiag = new NeuObject();

        /// <summary>
        /// ��һ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject firstOperation = new NeuObject();

        /// <summary>
        /// ����ҽʦ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject firstOperationDoc = new NeuObject();
        ///// <summary>
        ///// ������
        ///// </summary>
        //private Neusoft.HISFC.Object.RADT.Kin kin = new Neusoft.HISFC.Object.RADT.Kin();
        //private Neusoft.HISFC.Object.RADT.PVisit pVisit = new Neusoft.HISFC.Object.RADT.PVisit();
        /// <summary>
        /// ����ҽ��
        /// </summary>
        private Neusoft.NFC.Object.NeuObject clinicDoc = new NeuObject();
        private Neusoft.HISFC.Object.RADT.PatientInfo patientInfo = new Neusoft.HISFC.Object.RADT.PatientInfo();
        /// <summary>
        /// ����ҽ��
        /// </summary>
        private NeuObject refresherDoc = new NeuObject();
        /// <summary>
        /// �о���ʵϰҽʦ����
        /// </summary>
        private NeuObject graduateDoc = new NeuObject();
        /// <summary>
        /// ����Ա
        /// </summary>
        private NeuObject codingOper = new NeuObject();
        /// <summary>
        /// �ʿ�ҽ��
        /// </summary>
        private NeuObject qcDoc = new NeuObject();
        /// <summary>
        /// �ʿػ�ʿ
        /// </summary>
        private NeuObject qcNucd = new NeuObject();

        /// <summary>
        /// ����Ա 
        /// </summary>
        private Neusoft.NFC.Object.NeuObject packupOper = new NeuObject();
        /// <summary>
        /// ����Ա��
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// Ժ�ڸ�Ⱦ��λ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject infectionPosition = new NeuObject();

        /// <summary>
        /// ��Ժ��ʽ
        /// </summary>
        private string out_type;
        /// <summary>
        /// ��������
        /// </summary>
        private string cure_type;
        /// <summary>
        /// ������ҩ�Ƽ�
        /// </summary>
        private string use_cha_med;
        /// <summary>
        /// ���ȷ�ʽ
        /// </summary>
        private string save_type;
        /// <summary>
        /// �Ƿ����Σ�ء�
        /// </summary>
        private string ever_sickintodeath;
        /// <summary>
        /// �Ƿ���ּ�֢
        /// </summary>
        private string ever_firstaid;
        /// <summary>
        /// �Ƿ�����������
        /// </summary>
        private string ever_difficulty;
        /// <summary>
        /// ��Һ��Ӧ
        /// </summary>
        private string reaction_liquid;


        ///
        ///��������ʵ��
        ///

        /// <summary>
        /// EP��Ⱦ
        /// </summary>
        private string ep_infection;
        /// <summary>
        /// �Ƿ������¼��
        /// </summary>
        private string dep_master;
        /// <summary>
        /// ���䷽ʽ
        /// </summary>
        private string birth_type;
        /// <summary>
        /// Ӥ�����
        /// </summary>
        private string baby_condition;
        /// <summary>
        /// ��������
        /// </summary>
        private string perineum_broken;
        /// <summary>
        /// �촯���
        /// </summary>
        private string decubitus_condition;
        /// <summary>
        /// ��Һ���
        /// </summary>
        private string trans_condition;
        /// <summary>
        /// ��Ѫ���
        /// </summary>
        private string transblood_conditon;
        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime birth_time;

        #region ���� lvxl@neusoft.com 2009-10-28 {256C018D-BB48-4525-A6B4-92674D3332C7}
        /// <summary>
        /// ҽ�Ƹ��ʽ
        /// </summary>
        private string pay_kind;
        /// <summary>
        /// ҽ�����Ѻ�
        /// </summary>
        private string mcard_NO;
        /// <summary>
        /// ���ˡ��ж����ⲿԭ��
        /// </summary>
        private string poisoning_Reason;
        //��Ժ����
        private string in_nursestation;
        /// <summary>
        /// ת�Ʋ���
        /// </summary>
        private string change_nursestation;
        /// <summary>
        /// ��Ժ����
        /// </summary>
        private string out_nursestation;
        /// <summary>
        /// ���䷽ʽ2
        /// </summary>
        private string birth_type2;
        /// <summary>
        /// ������
        /// </summary>
        private string baby2_condition;
        /// <summary>
        /// ʾ�̲���
        /// </summary>
        private string example_case;
        #endregion

        #region �Ϻ���ұ���� add by changw {FA03206E-72B2-4ce8-850D-E9B35129E853}

        /// <summary>
        /// �����Ѫ��
        /// </summary>
        private string birth_blood;

        /// <summary>
        /// ����������ɸ��
        /// </summary>
        private string babydesease_check;

        /// <summary>
        /// ����÷��ɸ��(1��0��)
        /// </summary>
        private string rsmd_check;

        /// <summary>
        /// �Ƿ��в�����������(1��0��)
        /// </summary>
        private string ycfdead_report;

        /// <summary>
        /// �Ƿ���������������(1��0��)
        /// </summary>
        private string babydead_report;
        /// <summary>
        /// �Ƿ���������(1��0��)
        /// </summary>
        private string cancer_report;
        #endregion
        

        #endregion

        //{7D094A18-0FC9-4e8b-A8E6-901E55D4C20C}

        #region ����

        

        //public Neusoft.HISFC.Object.RADT.PVisit PVisit
        //{
        //    get
        //    {
        //        return pVisit;
        //    }
        //    set
        //    {
        //        pVisit = value;
        //    }
        //}

        /// <summary>
        /// ����Ա��
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }

        /// <summary>
        /// �Ƿ��в���֢
        /// </summary>
        public string SyndromeFlag
        {
            get
            {
                return syndromeFlag;
            }
            set
            {
                syndromeFlag = value;
            }
        }

        /// <summary>
        /// ������������Ա 
        /// </summary>
        public NeuObject OperationCoding
        {
            get
            {
                return operationCodingOper;
            }
            set
            {
                operationCodingOper = value;
            }
        }

        /// <summary>
        /// ����ҽ��
        /// </summary>
        public NeuObject ClinicDoc
        {
            get
            {
                return clinicDoc;
            }
            set
            {
                clinicDoc = value;
            }
        }

        ///// <summary>
        ///// ������ϵ�� 
        ///// </summary>
        //public Neusoft.HISFC.Object.RADT.Kin Kin
        //{
        //    get
        //    {
        //        return kin;
        //    }
        //    set
        //    {
        //        kin = value;
        //    }
        //}

        /// <summary>
        /// ��Ժ����
        /// </summary>
        public Neusoft.HISFC.Object.RADT.Location InDept
        {
            get
            {
                return inDept;
            }
            set
            {
                inDept = value;
            }
        }

        /// <summary>
        /// ��Ժ����
        /// </summary>
        public Neusoft.HISFC.Object.RADT.Location OutDept
        {
            get
            {
                return outDept;
            }
            set
            {
                outDept = value;
            }
        }

        /// <summary>
        /// �������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject ClinicDiag
        {
            get
            {
                return clinicDiag;
            }
            set
            {
                clinicDiag = value;
            }
        }

        /// <summary>
        /// ��Ժ���
        /// </summary>
        public Neusoft.NFC.Object.NeuObject InHospitalDiag
        {
            get
            {
                return inHospitalDiag;
            }
            set
            {
                inHospitalDiag = value;
            }
        }

        /// <summary>
        /// ��Ժ���
        /// </summary>
        public Neusoft.NFC.Object.NeuObject OutDiag
        {
            get
            {
                return outDiag;
            }
            set
            {
                outDiag = value;
            }
        }

        /// <summary>
        /// ��һ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject FirstOperation
        {
            get
            {
                return firstOperation;
            }
            set
            {
                firstOperation = value;
            }
        }

        /// <summary>
        /// ����ҽʦ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject FirstOperationDoc
        {
            get
            {
                return firstOperationDoc;
            }
            set
            {
                firstOperationDoc = value;
            }
        }

        /// <summary>
        /// Ժ�ڸ�Ⱦ����
        /// </summary>
        public int InfectionNum;

        /// <summary>
        /// �ֹ�¼�벡����־
        /// </summary>
        public string IsHandCraft
        {
            get
            {
                if (isHandCraft == null)
                {
                    isHandCraft = "";
                }
                return isHandCraft;
            }
            set
            {
                isHandCraft = value;
            }
        }

        /// <summary>
        /// �Ƿ񵥲���
        /// </summary>
        public string Disease30
        {
            get
            {
                return disease30;
            }
            set
            {
                disease30 = value;
            }
        }

        /// <summary>
        /// ����Ա 
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PackupMan
        {
            get
            {
                return packupOper;
            }
            set
            {
                packupOper = value;
            }
        }

        /// <summary>
        /// ���⻤��
        /// </summary>
        public decimal SpecalNus
        {
            get
            {
                return specalNus;
            }
            set
            {
                specalNus = value;
            }
        }

        /// <summary>
        /// �ؼ�����ʱ��
        /// </summary>
        public decimal SuperNus
        {
            get
            {
                return superNus;
            }
            set
            {
                superNus = value;
            }
        }

        /// <summary>
        /// ��֢�໤ʱ��
        /// </summary>
        public decimal StrictNuss
        {
            get
            {
                return strictnessNus;
            }
            set
            {
                strictnessNus = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public decimal IIINus
        {
            get
            {
                return iiiNus;
            }
            set
            {
                iiiNus = value;
            }
        }

        /// <summary>
        /// ��������ʱ��
        /// </summary>
        public decimal IINus
        {
            get
            {
                return iiNus;
            }
            set
            {
                iiNus = value;
            }
        }

        /// <summary>
        /// һ������ʱ��
        /// </summary>
        public decimal INus
        {
            get
            {
                return iNus;
            }
            set
            {
                iNus = value;
            }
        }

        /// <summary>
        /// s������� ��������
        /// </summary>
        public string VisiPeriodYear
        {
            get
            {
                if (visiPeriYear == null)
                {
                    visiPeriYear = "";
                }
                return visiPeriYear;
            }
            set
            {
                visiPeriYear = value;
            }
        }

        /// <summary>
        /// s������� ��������
        /// </summary>
        public string VisiPeriodMonth
        {
            get
            {
                return visiPeriMonth;
            }
            set
            {
                visiPeriMonth = value;
            }
        }

        /// <summary>
        /// s������� ��������
        /// </summary>
        public string VisiPeriodWeek
        {
            get
            {
                return visiPeriWeek;
            }
            set
            {
                visiPeriWeek = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public System.String Nomen
        {
            get
            {
                return this.nomen;
            }
            set
            {
                this.nomen = value;
            }
        }

        /// <summary>
        /// ���䵥λ
        /// </summary>
        public System.String AgeUnit
        {
            get
            {
                return this.ageUnit;
            }
            set
            {
                this.ageUnit = value;
            }
        }

        /// <summary>
        /// ת��ҽԺ
        /// </summary>
        public System.String ComeFrom
        {
            get
            {
                return this.comeFrom;
            }
            set
            {
                this.comeFrom = value;
            }
        }

        /// <summary>
        /// ��Ժ��Դ
        /// </summary>
        public System.String InAvenue
        {
            get
            {
                return this.inAvenue;
            }
            set
            {
                this.inAvenue = value;
            }
        }

        /// <summary>
        /// ��Ժ״̬
        /// </summary>
        public System.String InCircs
        {
            get
            {
                return this.inCircs;
            }
            set
            {
                this.inCircs = value;
            }
        }

        /// <summary>
        /// ȷ������
        /// </summary>
        public System.DateTime DiagDate
        {
            get
            {
                return this.diagDate;
            }
            set
            {
                this.diagDate = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public System.DateTime OperationDate
        {
            get
            {
                return this.operationDate;
            }
            set
            {
                this.operationDate = value;
            }
        }

        /// <summary>
        /// ȷ������
        /// </summary>
        public System.Int32 DiagDays
        {
            get
            {
                return this.diagDays;
            }
            set
            {
                this.diagDays = value;
            }
        }

        /// <summary>
        /// סԺ����
        /// </summary>
        public System.Int32 InHospitalDays
        {
            get
            {
                return this.inHospitalDays;
            }
            set
            {
                this.inHospitalDays = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public System.DateTime DeadDate
        {
            get
            {
                return this.deadDate;
            }
            set
            {
                this.deadDate = value;
            }
        }

        /// <summary>
        /// ����ԭ��
        /// </summary>
        public System.String DeadReason
        {
            get
            {
                return this.deadReason;
            }
            set
            {
                this.deadReason = value;
            }
        }

        /// <summary>
        /// ʬ��
        /// </summary>
        public System.String CadaverCheck
        {
            get
            {
                return this.cadaverCheck;
            }
            set
            {
                this.cadaverCheck = value;
            }
        }

        /// <summary>
        /// ʬ����
        /// </summary>
        public System.String CadaverCheckID
        {
            get
            {
                return this.cadaverCheckId;
            }
            set
            {
                this.cadaverCheckId = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public System.String DeadKind
        {
            get
            {
                return this.deadKind;
            }
            set
            {
                this.deadKind = value;
            }
        }

        /// <summary>
        /// ʬ����ʺ�
        /// </summary>
        public System.String BodyAnotomize
        {
            get
            {
                return this.bodyAnotomize;
            }
            set
            {
                this.bodyAnotomize = value;
            }
        }

        /// <summary>
        /// �Ҹα��濹ԭ�����ԡ����ԡ�δ����
        /// </summary>
        public System.String Hbsag
        {
            get
            {
                return this.hbsag;
            }
            set
            {
                this.hbsag = value;
            }
        }

        /// <summary>
        /// ���β������壨���ԡ����ԡ�δ����
        /// </summary>
        public System.String HcvAb
        {
            get
            {
                return this.hcvAb;
            }
            set
            {
                this.hcvAb = value;
            }
        }

        /// <summary>
        /// �������������ȱ�ݲ������壨���ԡ����ԡ�δ����
        /// </summary>
        public System.String HivAb
        {
            get
            {
                return this.hivAb;
            }
            set
            {
                this.hivAb = value;
            }
        }

        /// <summary>
        /// �ż���Ժ����
        /// </summary>
        public System.String CePi
        {
            get
            {
                return this.cePi;
            }
            set
            {
                this.cePi = value;
            }
        }

        /// <summary>
        /// ���Ժ����
        /// </summary>
        public System.String PiPo
        {
            get
            {
                return this.piPo;
            }
            set
            {
                this.piPo = value;
            }
        }

        /// <summary>
        /// ��ǰ�����
        /// </summary>
        public System.String OpbOpa
        {
            get
            {
                return this.opbOpa;
            }
            set
            {
                this.opbOpa = value;
            }
        }

        /// <summary>
        /// �ٴ�X�����
        /// </summary>
        public System.String ClX
        {
            get
            {
                return this.clX;
            }
            set
            {
                this.clX = value;
            }
        }

        /// <summary>
        /// �ٴ�CT����
        /// </summary>
        public System.String ClCt
        {
            get
            {
                return this.clCt;
            }
            set
            {
                this.clCt = value;
            }
        }

        /// <summary>
        /// �ٴ�MRI����
        /// </summary>
        public System.String ClMri
        {
            get
            {
                return this.clMri;
            }
            set
            {
                this.clMri = value;
            }
        }

        /// <summary>
        /// �ٴ���������
        /// </summary>
        public System.String ClPa
        {
            get
            {
                return this.clPa;
            }
            set
            {
                this.clPa = value;
            }
        }

        /// <summary>
        /// ���䲡������
        /// </summary>
        public System.String FsBl
        {
            get
            {
                return this.fsBl;
            }
            set
            {
                this.fsBl = value;
            }
        }

        /// <summary>
        /// ���ȴ���
        /// </summary>
        public System.Int32 SalvTimes
        {
            get
            {
                return this.salvTimes;
            }
            set
            {
                this.salvTimes = value;
            }
        }

        /// <summary>
        /// �ɹ�����
        /// </summary>
        public System.Int32 SuccTimes
        {
            get
            {
                return this.succTimes;
            }
            set
            {
                this.succTimes = value;
            }
        }

        /// <summary>
        /// ʾ�̿���
        /// </summary>
        public System.String TechSerc
        {
            get
            {
                return this.techSerc;
            }
            set
            {
                this.techSerc = value;
            }
        }

        /// <summary>
        /// �Ƿ�����
        /// </summary>
        public System.String VisiStat
        {
            get
            {
                return this.visiStat;
            }
            set
            {
                this.visiStat = value;
            }
        }

        /// <summary>
        /// �������
        /// </summary>
        public System.DateTime VisiPeriod
        {
            get
            {
                return this.visiPeriod;
            }
            set
            {
                this.visiPeriod = value;
            }
        }

        /// <summary>
        /// Ժ�ʻ������
        /// </summary>
        public System.Int32 InconNum
        {
            get
            {
                return this.inconNum;
            }
            set
            {
                this.inconNum = value;
            }
        }

        /// <summary>
        /// Զ�̻������
        /// </summary>
        public System.Int32 OutconNum
        {
            get
            {
                return this.outconNum;
            }
            set
            {
                this.outconNum = value;
            }
        }

        /// <summary>
        /// ҩ�����
        /// </summary>
        public System.String AnaphyFlag
        {
            get
            {
                return this.anaphyFlag;
            }
            set
            {
                this.anaphyFlag = value;
            }
        }

        /// <summary>
        /// ���ĺ��Ժ����
        /// </summary>
        public System.DateTime CoutDate
        {
            get
            {
                return this.coutDate;
            }
            set
            {
                this.coutDate = value;
            }
        }

        /// <summary>
        /// ����ҩ��1
        /// </summary>
        public NeuObject FirstAnaphyPharmacy
        {
            get
            {
                return this.firstAnaphyPharmacy;
            }
            set
            {
                this.firstAnaphyPharmacy = value;
            }
        }

        /// <summary>
        /// ����ҩ��2
        /// </summary>
        public NeuObject SecondAnaphyPharmacy
        {
            get
            {
                return this.secondAnaphyPharmacy;
            }
            set
            {
                this.secondAnaphyPharmacy = value;
            }
        }
        /// <summary>
        /// ����ҽʦ����
        /// </summary>
        public NeuObject RefresherDoc
        {
            get
            {
                return this.refresherDoc;
            }
            set
            {
                this.refresherDoc = value;
            }
        }

        /// <summary>
        /// �о���ʵϰҽʦ����
        /// </summary>
        public NeuObject GraduateDoc
        {
            get
            {
                return this.graduateDoc;
            }
            set
            {
                this.graduateDoc = value;
            }
        }

        /// <summary>
        /// ����Ա����
        /// </summary>
        public NeuObject CodingOper
        {
            get
            {
                return this.codingOper;
            }
            set
            {
                this.codingOper = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public System.String MrQuality
        {
            get
            {
                return this.mrQual;
            }
            set
            {
                this.mrQual = value;
            }
        }

        /// <summary>
        /// �ϸ񲡰�
        /// </summary>
        public System.String MrEligible
        {
            get
            {
                return this.mrElig;
            }
            set
            {
                this.mrElig = value;
            }
        }

        /// <summary>
        /// �ʿ�ҽʦ
        /// </summary>
        public NeuObject QcDoc
        {
            get
            {
                return this.qcDoc;
            }
            set
            {
                this.qcDoc = value;
            }
        }

        /// <summary>
        /// �ʿػ�ʿ����
        /// </summary>
        public NeuObject QcNurse
        {
            get
            {
                return this.qcNucd;
            }
            set
            {
                this.qcNucd = value;
            }
        }

        /// <summary>
        /// ���ʱ��
        /// </summary>
        public System.DateTime CheckDate
        {
            get
            {
                return this.checkDate;
            }
            set
            {
                this.checkDate = value;
            }
        }

        /// <summary>
        /// ���������������ơ���顢���Ϊ��Ժ��һ����Ŀ
        /// </summary>
        public System.String YnFirst
        {
            get
            {
                return this.ynFirst;
            }
            set
            {
                this.ynFirst = value;
            }
        }

        /// <summary>
        /// RhѪ��(������)
        /// </summary>
        public System.String RhBlood
        {
            get
            {
                return this.rhBlood;
            }
            set
            {
                this.rhBlood = value;
            }
        }

        /// <summary>
        /// ��Ѫ��Ӧ���С��ޣ�
        /// </summary>
        public System.String ReactionBlood
        {
            get
            {
                return this.reactionBlood;
            }
            set
            {
                this.reactionBlood = value;
            }
        }

        /// <summary>
        /// ��ϸ����
        /// </summary>
        public System.String BloodRed
        {
            get
            {
                return this.bloodRed;
            }
            set
            {
                this.bloodRed = value;
            }
        }

        /// <summary>
        /// ѪС����
        /// </summary>
        public System.String BloodPlatelet
        {
            get
            {
                return this.bloodPlatelet;
            }
            set
            {
                this.bloodPlatelet = value;
            }
        }

        /// <summary>
        /// Ѫ����
        /// </summary>
        public System.String BloodPlasma
        {
            get
            {
                return this.bloodPlasma;
            }
            set
            {
                this.bloodPlasma = value;
            }
        }

        /// <summary>
        /// ȫѪ��
        /// </summary>
        public System.String BloodWhole
        {
            get
            {
                return this.bloodWhole;
            }
            set
            {
                this.bloodWhole = value;
            }
        }

        /// <summary>
        /// ������Ѫ��
        /// </summary>
        public System.String BloodOther
        {
            get
            {
                return this.bloodOther;
            }
            set
            {
                this.bloodOther = value;
            }
        }

        /// <summary>
        /// X���
        /// </summary>
        public System.String XNum
        {
            get
            {
                return this.xNumb;
            }
            set
            {
                this.xNumb = value;
            }
        }

        /// <summary>
        /// CT��
        /// </summary>
        public System.String CtNum
        {
            get
            {
                return this.ctNumb;
            }
            set
            {
                this.ctNumb = value;
            }
        }

        /// <summary>
        /// MRI��
        /// </summary>
        public System.String MriNum
        {
            get
            {
                return this.mriNumb;
            }
            set
            {
                this.mriNumb = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public System.String PathNum
        {
            get
            {
                return this.pathNumb;
            }
            set
            {
                this.pathNumb = value;
            }
        }

        /// <summary>
        /// DSA��
        /// </summary>
        public System.String DsaNum
        {
            get
            {
                return this.dsaNumb;
            }
            set
            {
                this.dsaNumb = value;
            }
        }

        /// <summary>
        /// PET��
        /// </summary>
        public System.String PetNum
        {
            get
            {
                return this.petNumb;
            }
            set
            {
                this.petNumb = value;
            }
        }

        /// <summary>
        /// ECT��
        /// </summary>
        public System.String EctNum
        {
            get
            {
                return this.ectNumb;
            }
            set
            {
                this.ectNumb = value;
            }
        }

        /// <summary>
        /// X�ߴ���
        /// </summary>
        public System.Int32 XQty
        {
            get
            {
                return this.xQty;
            }
            set
            {
                this.xQty = value;
            }
        }

        /// <summary>
        /// CT����
        /// </summary>
        public System.Int32 CTQty
        {
            get
            {
                return this.ctQty;
            }
            set
            {
                this.ctQty = value;
            }
        }

        /// <summary>
        /// MR����
        /// </summary>
        public System.Int32 MRQty
        {
            get
            {
                return this.mrQty;
            }
            set
            {
                this.mrQty = value;
            }
        }

        /// <summary>
        /// DSA����
        /// </summary>
        public System.Int32 DSAQty
        {
            get
            {
                return this.dsaQty;
            }
            set
            {
                this.dsaQty = value;
            }
        }

        /// <summary>
        /// PET����
        /// </summary>
        public System.Int32 PetQty
        {
            get
            {
                return this.petQty;
            }
            set
            {
                this.petQty = value;
            }
        }

        /// <summary>
        /// ECT����
        /// </summary>
        public System.Int32 EctQty
        {
            get
            {
                return this.ectQty;
            }
            set
            {
                this.ectQty = value;
            }
        }

        /// <summary>
        /// �鵵�����
        /// </summary>
        public System.String BarCode
        {
            get
            {
                return this.barCode;
            }
            set
            {
                this.barCode = value;
            }
        }

        /// <summary>
        /// ��������״̬(O��� I�ڼ�)
        /// </summary>
        public System.String LendStat
        {
            get
            {
                return this.lendStat;
            }
            set
            {
                this.lendStat = value;
            }
        }

        /// <summary>
        /// ����״̬1�����ʼ�/2�ǼǱ���/3����/4�������ʼ�/5��Ч
        /// </summary>
        public System.String CaseStat
        {
            get
            {
                return this.caseStat;
            }
            set
            {
                this.caseStat = value;
            }
        }
        /// <summary>
        /// ���߻�������
        /// </summary>
        public Neusoft.HISFC.Object.RADT.PatientInfo PatientInfo
        {
            get
            {
                return this.patientInfo;
            }
            set
            {
                this.patientInfo = value;
            }
        }
        /// <summary>
        /// ������
        /// </summary>
        public string CaseNO
        {
            get
            {
                return caseNO;
            }
            set
            {
                caseNO = value;
            }
        }
        /// <summary>
        /// Ժ�ڸ�Ⱦ��λ
        /// </summary>
        public NeuObject InfectionPosition
        {
            get
            {
                return this.infectionPosition;
            }
            set
            {
                this.infectionPosition = value;
            }
        }


        /// <summary>
        /// ��Ժ��ʽ
        /// </summary>
        public string Out_Type
        {
            get
            {
                return this.out_type;
            }
            set
            {
                this.out_type = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string Cure_Type
        {
            get
            {
                return this.cure_type;
            }
            set
            {
                this.cure_type = value;
            }
        }

        /// <summary>
        /// ������ҩ�Ƽ�
        /// </summary>
        public string Use_CHA_Med
        {
            get
            {
                return this.use_cha_med;
            }
            set
            {
                this.use_cha_med = value;
            }
        }
        /// <summary>
        /// ���ȷ�ʽ
        /// </summary>
        public string Save_Type
        {
            get
            {
                return this.save_type;
            }
            set
            {
                this.save_type = value;
            }
        }
        /// <summary>
        /// �Ƿ����Σ�ء�
        /// </summary>
        public string Ever_Sickintodeath
        {
            get
            {
                return this.ever_sickintodeath;
            }
            set
            {
                this.ever_sickintodeath = value;
            }
        }
        /// <summary>
        /// �Ƿ���ּ�֢
        /// </summary>
        public string Ever_Firstaid
        {
            get
            {
                return this.ever_firstaid;
            }
            set
            {
                this.ever_firstaid = value;
            }
        }
        /// <summary>
        /// �Ƿ�����������
        /// </summary>
        public  string Ever_Difficulty
        {
            get
            {
                return this.ever_difficulty;
            }
            set
            {
                this.ever_difficulty = value;
            }
        }
        /// <summary>
        /// ��Һ��Ӧ
        /// </summary>
        public string ReactionLiquid
        {
            get
            {
                return this.reaction_liquid;
            }
            set
            {
                this.reaction_liquid = value;
            }
        }

       
        // ������ʵ��
      
    

        /// <summary>
        /// �Ƿ�EP��Ⱦ��1���� 0����
        /// </summary>
        public System.String EPInfection
        {
            get
            {
                return this.ep_infection;
            }
            set
            {
                this.ep_infection = value;
            }
        }
        /// <summary>
        /// �Ƿ������¼�루1���� 0 ��
        /// </summary>
        public System.String DepMaster
        {
            get
            {
                return this.dep_master;
            }
            set
            {
                this.dep_master = value;
            }
        }
        /// <summary>
        /// ���䷽ʽ��1�������� 2���ʹ��� 3���쳣�� 4�������
        /// </summary>
        public System.String BirthType
        {
            get
            {
                return this.birth_type;
            }
            set
            {
                this.birth_type = value;
            }
        }
        /// <summary>
        /// Ӥ�������1����̥��� 2����̥���� 3��˫̥һ�� 4��˫̥���
        /// </summary>
        public System.String BabyCondition
        {
            get
            {
                return this.baby_condition;
            }
            set
            {
                this.baby_condition = value;
            }
        }
        /// <summary>
        /// �������������1��2��3��
        /// </summary>
        public System.String PerienumBroken
        {
            get
            {
                return this.perineum_broken;
            }
            set
            {
                this.perineum_broken = value;
            }
        }
        /// <summary>
        /// ��Һ�����1���� 0����
        /// </summary>
        public System.String TransConditon
        {
            get
            {
                return this.trans_condition;
            }
            set
            {
                this.trans_condition = value;
            }
        }

        /// <summary>
        /// �촯�����1���� 0����
        /// </summary>
        public System.String DecubitusCondition
        {
            get
            {
                return this.decubitus_condition;
            }
            set
            {
                this.decubitus_condition = value;
            }
        }
        /// <summary>
        /// ��Ѫ�����1���� 0����
        /// </summary>
        public System.String TransBloodCondition
        {
            get
            {
                return this.transblood_conditon;
            }
            set
            {
                this.transblood_conditon = value;
            }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public System.DateTime BirthTime
        {
            get
            {
                return this.birth_time;
            }
            set
            {
                this.birth_time = value;
            }
        }

        #region ���� lvxl@neusoft.com 2009-10-28 {0C498D79-18B3-451a-A596-311EA1E9D868}
        /// <summary>
        /// ҽ�Ƹ��ʽ
        /// </summary>
        public System.String PayKind
        {
            get
            {
                return pay_kind;
            }
            set
            {
                pay_kind = value;
            }
        }
        /// <summary>
        /// ҽ�����Ѻ�
        /// </summary>
        public System.String Mcard_NO
        {
            get
            {
                return mcard_NO;
            }
            set
            {
                mcard_NO = value;
            }
        }
        /// <summary>
        /// ���ˡ��ж����ⲿԭ��
        /// </summary>
        public System.String PoisoningReason
        {
            get
            {
                return poisoning_Reason;
            }
            set
            {
                poisoning_Reason = value;
            }
        }
        /// <summary>
        /// ��Ժ����
        /// </summary>
        public System.String In_NurseStation
        {
            get
            {
                return in_nursestation;
            }
            set
            {
                in_nursestation = value;
            }
        }
        /// <summary>
        /// תԺ����
        /// </summary>
        public System.String Change_NurseStation
        {
            get
            {
                return change_nursestation;
            }
            set
            {
                change_nursestation = value;
            }
        }
        /// <summary>
        /// ��Ժ����
        /// </summary>
        public System.String Out_NurseStation
        {
            get
            {
                return out_nursestation;
            }
            set
            {
                out_nursestation = value;
            }
        }
        /// <summary>
        /// ���䷽ʽ2
        /// </summary>
        public System.String Birth_Type2
        {
            get
            {
                return birth_type;
            }
            set
            {
                birth_type = value;
            }
        }
        /// <summary>
        /// ������
        /// </summary>
        public System.String Baby2_Condition
        {
            get
            {
                return baby2_condition;
            }
            set
            {
                baby2_condition = value;
            }
        }
        /// <summary>
        /// ʾ�̲���
        /// </summary>
        public System.String Example_Case
        {
            get
            {
                return example_case;
            }
            set
            {
                example_case = value;
            }
        }

        #endregion


        #region �Ϻ���ұ���� add by changw {FA03206E-72B2-4ce8-850D-E9B35129E853}
        /// <summary>
        /// �Ƿ���������(1��0��)
        /// </summary>
        public System.String Cancer_Report
        {
            get
            {
                return cancer_report;
            }
            set
            {
                cancer_report = value;
            }
        }

        /// <summary>
        /// �Ƿ���������������(1��0��)
        /// </summary>
        public System.String BabyDead_Report
        {
            get
            {
                return babydead_report;
            }
            set
            { 
                babydead_report = value;
            }
        }

        /// <summary>
        /// �Ƿ��в�����������(1��0��)
        /// </summary>
        public System.String YcfDead_Report
        {
            get
            {
                return ycfdead_report;
            }
            set
            {
                ycfdead_report = value;
            }
        }

        /// <summary>
        /// ����÷��ɸ��(1��0��)
        /// </summary>
        public System.String Rsmd_Check
        {
            get
            {
                return rsmd_check;
            }
            set
            {
                rsmd_check = value;
            }
        }

        /// <summary>
        /// �����Ѫ��
        /// </summary>
        public System.String Birth_Blood
        {
            get 
            { 
                return birth_blood; 
            }
            set 
            { 
                birth_blood = value; 
            }
        }
        /// <summary>
        /// ����������ɸ��
        /// </summary>
        public System.String BabyDesease_Check
        {
            get
            {
                return babydesease_check;
            }
            set 
            {
                babydesease_check = value;
            }
        }



        #endregion

        #endregion

        #region ����
        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns></returns>
        public new Base Clone()
        {
            Base b = base.MemberwiseClone() as Base;
            b.qcDoc = qcDoc.Clone();
            b.qcNucd = qcNucd.Clone();
            b.refresherDoc = refresherDoc.Clone();
            b.graduateDoc = graduateDoc.Clone();
            b.codingOper = codingOper.Clone();
            b.firstAnaphyPharmacy = firstAnaphyPharmacy.Clone();
            b.secondAnaphyPharmacy = secondAnaphyPharmacy.Clone();
            b.clinicDiag = this.clinicDiag.Clone();
            b.inHospitalDiag = this.inHospitalDiag.Clone();
            b.firstOperation = this.firstOperation.Clone();
            b.firstOperationDoc = this.firstOperationDoc.Clone();
            b.outDiag = this.outDiag.Clone();
            b.operInfo = this.operInfo.Clone();
            b.packupOper = this.packupOper.Clone();
            b.clinicDoc = this.clinicDoc.Clone();
            b.inDept = this.inDept.Clone();
            b.outDept = this.outDept.Clone();
            b.patientInfo = this.patientInfo.Clone();
            b.operationCodingOper = operationCodingOper.Clone();
            b.infectionPosition = infectionPosition.Clone();
            return b;
        }
        #endregion

        #region  ����
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ")]
        private System.String operCode;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ")]
        private System.DateTime operDate;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ")]
        private System.String codingName;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ ClinicDoc ����")]
        private System.String clinicDocd;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ ClinicDoc ����")]
        private System.String clinicDonm;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������  ����")]
        private System.String graDocName;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ü̳д���")]
        private System.String linkmanTel;
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ü̳д���")]
        private System.String linkmanAdd;


        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� nationality ���� ")]
        private System.String nationCode;

        /// <summary>
        /// PET����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ PetQty ����", true)]
        public System.Int32 PetTimes
        {
            get
            {
                return this.petQty;
            }
            set
            {
                this.petQty = value;
            }
        }
        /// <summary>
        /// ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� Nationality ���� ", true)]
        public System.String NationCode
        {
            get
            {
                return this.nationCode;
            }
            set
            {
                this.nationCode = value;
            }
        }
        /// <summary>
        /// ��ϵ�绰
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ Kin ����", true)]
        public System.String LinkmanTel
        {
            get
            {
                return this.linkmanTel;
            }
            set
            {
                this.linkmanTel = value;
            }
        }
        /// <summary>
        /// ��ϵ��ַ
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ Kin ����", true)]
        public System.String LinkmanAdd
        {
            get
            {
                return this.linkmanAdd;
            }
            set
            {
                this.linkmanAdd = value;
            }
        }
        /// <summary>
        /// �������ҽ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ ClinicDoc ����", true)]
        public System.String ClinicDocd
        {
            get
            {
                return this.clinicDocd;
            }
            set
            {
                this.clinicDocd = value;
            }
        }
        /// <summary>
        /// �������ҽ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ ClinicDoc ����", true)]
        public System.String ClinicDonm
        {
            get
            {
                return this.clinicDonm;
            }
            set
            {
                this.clinicDonm = value;
            }
        }
        /// <summary>
        /// סԺ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ InHospitalDays ����", true)]
        public System.Int32 PiDays
        {
            get
            {
                return this.inHospitalDays;
            }
            set
            {
                this.inHospitalDays = value;
            }
        }
        /// <summary>
        /// ʬ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ CadaverCheck ����", true)]
        public System.String BodyCheck
        {
            get
            {
                return this.cadaverCheck;
            }
            set
            {
                this.cadaverCheck = value;
            }
        }
        /// <summary>
        /// �������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ VisiPeriod ����", true)]
        public System.DateTime VisiPeri
        {
            get
            {
                return this.visiPeriod;
            }
            set
            {
                this.visiPeriod = value;
            }
        }
        /// <summary>
        /// ����ҩ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ firstAnaphyPharmacy ����", true)]
        public NeuObject AnaphyName1
        {
            get
            {
                return this.firstAnaphyPharmacy;
            }
            set
            {
                this.firstAnaphyPharmacy = value;
            }
        }
        /// <summary>
        /// ����ҩ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ firstAnaphyPharmacy ����", true)]
        public NeuObject AnaphyName2
        {
            get
            {
                return this.firstAnaphyPharmacy;
            }
            set
            {
                this.firstAnaphyPharmacy = value;
            }
        }
        /// <summary>
        /// ����ҽ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ RefresherDoc.Name ����", true)]
        public System.String RefresherDonm
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.refresherDonm = value;
            //}
        }
        /// <summary>
        /// �о���ʵϰҽʦ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ GraduateDoc.Name ����", true)]
        public System.String GraDocName
        {
            get
            {
                return this.graDocName;
            }
            set
            {
                this.graDocName = value;
            }
        }
        /// <summary>
        /// ����Ա����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ CodingOper.Name ����", true)]
        public System.String CodingName
        {
            get
            {
                return this.codingName;
            }
            set
            {
                this.codingName = value;
            }
        }
        /// <summary>
        /// ����Ա����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ CodingOper.Name ����", true)]
        public NeuObject codingCode
        {
            get
            {
                return null;
            }
            set
            {
                //this.codingOper = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ MrQuality ����", true)]
        public System.String MrQual
        {
            get
            {
                return this.mrQual;
            }
            set
            {
                this.mrQual = value;
            }
        }
        /// <summary>
        /// �ϸ񲡰�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ MrEligible ����", true)]
        public System.String MrElig
        {
            get
            {
                return this.mrElig;
            }
            set
            {
                this.mrElig = value;
            }
        }
        /// <summary>
        /// �ʿ�ҽʦ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ QcDocd.Name ����", true)]
        public System.String QcDonm
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.qcDonm = value;
            //}
        }
        /// <summary>
        /// �ʿػ�ʿ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ QcNurse ����", true)]
        public System.String QcNucd
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.qcNucd = value;
            //}
        }
        /// <summary>
        /// �ʿػ�ʿ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ QcNurse.Name ����", true)]
        public System.String QcNunm
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.qcNunm = value;
            //}
        }
        /// <summary>
        /// X�ߴ���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ XQty ����", true)]
        public System.Int32 XTimes
        {
            get
            {
                return this.xQty;
            }
            set
            {
                this.xQty = value;
            }
        }
        /// <summary>
        /// CT����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ CTQty ����", true)]
        public System.Int32 CtTimes
        {
            get
            {
                return this.ctQty;
            }
            set
            {
                this.ctQty = value;
            }
        }
        /// <summary>
        /// MR����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ MRQty ����", true)]
        public System.Int32 MrTimes
        {
            get
            {
                return this.mrQty;
            }
            set
            {
                this.mrQty = value;
            }
        }
        /// <summary>
        /// DSA����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ DSAQty ����", true)]
        public System.Int32 DsaTimes
        {
            get
            {
                return this.dsaQty;
            }
            set
            {
                this.dsaQty = value;
            }
        }
        /// <summary>
        /// ECT����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ EctQty ����", true)]
        public System.Int32 EctTimes
        {
            get
            {
                return this.ectQty;
            }
            set
            {
                this.ectQty = value;
            }
        }
        /// <summary>
        /// ����Ա
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ OperInfo ����", true)]
        public System.String OperCode
        {
            get
            {
                return this.operCode;
            }
            set
            {
                this.operCode = value;
            }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ OperInfo ����", true)]
        public System.DateTime OperDate
        {
            get
            {
                return this.operDate;
            }
            set
            {
                this.operDate = value;
            }
        }
        /// <summary>
        /// ���⻤��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ SpecalNus ����", true)]
        public decimal SPecalNus
        {
            get
            {
                return specalNus;
            }
            set
            {
                specalNus = value;
            }
        }
        /// <summary>
        /// ��������״̬(O��� I�ڼ�)
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ lendStat ����", true)]
        public System.String LendStus
        {
            get
            {
                return this.lendStat;
            }
            set
            {
                this.lendStat = value;
            }
        }
        /// <summary>
        /// ����״̬1�����ʼ�/2�ǼǱ���/3����/4�������ʼ�/5��Ч
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ CaseStat ����", true)]
        public System.String CaseStus
        {
            get
            {
                return this.caseStat;
            }
            set
            {
                this.caseStat = value;
            }
        }
        /// <summary>
        /// ��Ժ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ INDept ����", true)]
        public Neusoft.NFC.Object.NeuObject deptIN = new NeuObject();

        /// <summary>
        /// ��Ժ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ OutDept ����", true)]
        public Neusoft.NFC.Object.NeuObject deptOut = new NeuObject();

        /// <summary>
        /// ʵϰҽʦ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ PVisit.TempDoctor ����", true)]
        public System.String PraDocCode
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.praDocCode = value;
            //}
        }

        /// <summary>
        /// ʵϰҽʦ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������ PVisit.TempDoctor ����", true)]
        public System.String PraDocName
        {
            get
            {
                return null;
            }
            //set
            //{
            //    this.praDocName = value;
            //}
        }
        /// <summary>
        /// ��Ժ���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("������InHospitalDiag����",true)]
        public Neusoft.NFC.Object.NeuObject InhosDiag
        {
            get
            {
                return null;
            }
        }
        #endregion
    }
}
