using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord
{
    /// <summary>
    /// PatientInfo <br></br>
    /// [��������: �ż��﹤���ձ�ʵ��]<br></br>
    /// [�� �� ��: �޷���]<br></br>
    /// [����ʱ��: 2009-11-25]<br></br>
    /// 
    /// <�޸ļ�¼
    /// 
    ///		�޸���=""
    ///		�޸�ʱ��=""
    ///		�޸�Ŀ��=""
    ///		�޸�����=""
    ///  />
    /// </summary>
    public class DayReportOutpatient : Neusoft.NFC.Object.NeuObject
    {
        public DayReportOutpatient()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }
        #region ����
        //���м�¼
        private string hasRecord;       
        //�ձ�����
        private DateTime dateStat;

        
        //����
        private Neusoft.NFC.Object.NeuObject dept = new Neusoft.NFC.Object.NeuObject();

          
        //��������
        private int outpatientNum;   
       
        //��������
        private int emergeryNum;       
        
        //�ϼ�
        private int sumNum;
        //����ϼ�
        private int outpatientSumNum;

       
        //����ϼ�
        private int emergerySumNum;

       
        //��չ�ֶ�
        private string user01;      
        private string user02;
        private string user03;

        
        #endregion

        #region ����
        //���м�¼
        public string HasRecord
        {
            get 
            {
                return hasRecord; 
            }
            set
            {
                hasRecord = value; 
            }
        }
        //�ձ�����
        public DateTime DateStat
        {
            get 
            {
                return dateStat; 
            }
            set
            {
                dateStat = value; 
            }
        }      
        //����
        public Neusoft.NFC.Object.NeuObject Dept
        {
            get 
            {
                return dept; 
            }
            set
            {
                dept = value; 
            }
        }      
        //��������
        public int OutpatientNum
        {
            get 
            {
                return outpatientNum; 
            }
            set
            {
                outpatientNum = value; 
            }
        }
        //��������
        public int EmergeryNum
        {
            get
            {
                return emergeryNum; 
            }
            set
            {
                emergeryNum = value; 
            }
        }
        //�ϼ�
        public int SumNum
        {
            get
            {
                return sumNum; 
            }
            set
            {
                sumNum = value; 
            }
        }
        //����ϼ�����
        public int OutpatientSumNum
        {
            get 
            {
                return outpatientSumNum; 
            }
            set
            {
                outpatientSumNum = value; 
            }
        }
        //����ϼ�����
        public int EmergerySumNum
        {
            
            get
            {
                return emergerySumNum; 
            }
            set
            {
                emergerySumNum = value; 
            }
        }

        //��չ�ֶ�1
        public string User01
        {
            get 
            {
                return user01; 
            }
            set
            {
                user01 = value; 
            }
        }
        //��չ�ֶ�2
        public string User021
        {
            get
            {
                return user02;
            }
            set
            {
                user02 = value;
            }
        }
        //��չ�ֶ�3
        public string User031
        {
            get 
            {
                return user03; 
            }
            set
            {
                user03 = value; 
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new DayReportOutpatient Clone()
        {
            DayReportOutpatient myDayReportOutpatient = base.Clone() as DayReportOutpatient;
           
            return myDayReportOutpatient;
        }
        #endregion
    }
}
