using System;


namespace Neusoft.HISFC.Object.HealthRecord
{


    /// <summary>
    /// Lend ��ժҪ˵������������ʵ�� ID ¼��������Ա���� Name ¼��������Ա����
    /// </summary>
    public class Lend : Neusoft.NFC.Object.NeuObject
    {
        public Lend()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ˽�б���

        private Base caseBase = new Base();
        private Neusoft.NFC.Object.NeuObject employeeInfo = new Neusoft.NFC.Object.NeuObject();
        private Neusoft.NFC.Object.NeuObject employeeDept = new Neusoft.NFC.Object.NeuObject();
        private Neusoft.NFC.Object.NeuObject returnOperInfo = new Neusoft.NFC.Object.NeuObject();
        private string seqNO;
        private DateTime lendDate;
        private DateTime prerDate;
        private string lendKind;
        private string lendStus;
        private DateTime returnDate;
        private string cardNo;
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion

        #region ����
        /// <summary>
        /// �������
        /// </summary>
        public string SeqNO
        {
            get
            {
                return seqNO;
            }
            set
            {
                seqNO = value;
            }
        }
        /// <summary>
        /// ���� 
        /// </summary>
        public string CardNO
        {
            set
            {
                cardNo = value;
            }
            get
            {
                return cardNo;
            }
        }

        /// <summary>
        /// ���˻�����Ϣ
        /// </summary>
        public Base CaseBase
        {
            get
            {
                return caseBase;
            }
            set
            {
                caseBase = value;
            }
        }

        /// <summary>
        /// ��������Ϣ ID �����˱�� Name ����������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject EmployeeInfo
        {
            get
            {
                return employeeInfo;
            }
            set
            {
                employeeInfo = value;
            }
        }

        /// <summary>
        /// ���������ڿ�����Ϣ ID ���ұ�� Name ��������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject EmployeeDept
        {
            get
            {
                return employeeDept;
            }
            set
            {
                employeeDept = value;
            }
        }

        /// <summary>
        /// ��������(����)
        /// </summary>
        public DateTime LendDate
        {
            get
            {
                return lendDate;
            }
            set
            {
                lendDate = value;
            }
        }

        /// <summary>
        /// Ԥ���黹����(����)
        /// </summary>
        public DateTime PrerDate
        {
            get
            {
                return prerDate;
            }
            set
            {
                prerDate = value;
            }
        }

        /// <summary>
        /// ��������(����)
        /// </summary>
        public string LendKind
        {
            get
            {
                return lendKind;
            }
            set
            {
                lendKind = value;
            }
        }

        /// <summary>
        /// ����״̬ 1���/2���� 
        /// </summary>
        public string LendStus
        {
            get
            {
                return lendStus;
            }
            set
            {
                lendStus = value;
            }
        }

        /// <summary>
        ///�黹����Ա��Ϣ ID �黹����Ա���� Name �黹����Ա����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject ReturnOperInfo
        {
            get
            {
                return returnOperInfo;
            }
            set
            {
                returnOperInfo = value;
            }
        }

        /// <summary>
        /// �黹����
        /// </summary>
        public DateTime ReturnDate
        {
            get
            {
                return returnDate;
            }
            set
            {
                returnDate = value;
            }
        }
        /// <summary>
        /// ����Ա��
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }
        #endregion

        #region ���ú���
        public new Lend Clone()
        {
            Lend LendClone = base.MemberwiseClone() as Lend;

            LendClone.caseBase = this.caseBase.Clone();
            LendClone.EmployeeInfo = this.employeeInfo.Clone(); ;
            LendClone.employeeDept = this.employeeDept.Clone();
            LendClone.ReturnOperInfo = this.ReturnOperInfo.Clone();
            LendClone.operInfo = operInfo.Clone();
            return LendClone;
        }
        #endregion

        #region ����
        /// <summary>
        /// ���˻�����Ϣ
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ��CaseBase", true)]
        public Base PatientInfo
        {
            get
            {
                return caseBase;
            }
            set
            {
                caseBase = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ��OperInfo.OperTime", true)]
        public DateTime OperDate
        {
            get
            {
                return System.DateTime.Now;
            }
        }

        /// <summary>
        /// ��������Ϣ ID �����˱�� Name ����������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� EmployeeInfo ����", true)]
        public Neusoft.NFC.Object.NeuObject EmplInfo
        {
            get
            {
                return employeeInfo;
            }
            set
            {
                employeeInfo = value;
            }
        }

        /// <summary>
        /// ���������ڿ�����Ϣ ID ���ұ�� Name ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� EmployeeDept ����", true)]
        public Neusoft.NFC.Object.NeuObject EmplDeptInfo
        {
            get
            {
                return employeeDept;
            }
            set
            {
                employeeDept = value;
            }
        }
        #endregion
    }
}
