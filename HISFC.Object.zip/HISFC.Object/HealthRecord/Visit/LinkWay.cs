﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord.Visit
{
    /// <summary>
    /// LinkWay <br></br>
    /// [功能描述: 联系方式记录]<br></br>
    /// [创 建 者: 赫一阳]<br></br>
    /// [创建时间: 2007-08-16]<br></br>
    /// <修改记录
    ///		修改人=''
    ///		修改时间=''
    ///		修改目的=''
    ///		修改描述=''
    ///  />
    /// </summary>
    public class LinkWay : Case.CaseInfo
    {
        #region 变量

        /// <summary>
        /// 联系方式类别
        /// </summary>
        private HISFC.Object.Base.Const linkWayType = new Neusoft.HISFC.Object.Base.Const();
        
        /// <summary>
        /// 联系方式内容
        /// </summary>
        [Obsolete ("废弃  选择对应的联系方式字段存")]
        private string linkWay = "";

        /// <summary>
        /// 邮政编码
        /// </summary>
        private string zip = "";
        
        /// <summary>
        /// 是否是联系人的联系方式
        /// </summary>
        private bool isLinkMan;
        
        /// <summary>
        /// 联系人
        /// </summary>
        private Neusoft.NFC.Object.NeuObject linkMan = new Neusoft.NFC.Object.NeuObject();
        
        /// <summary>
        /// 联系人与患者的关系
        /// </summary>
        private HISFC.Object.Base.Const relation = new Neusoft.HISFC.Object.Base.Const();

        #region 2007-10-25 ADD BY WANGLI

        /// <summary>
        /// 地址
        /// </summary>
        private string address = "";

        /// <summary>
        /// 电话
        /// </summary>
        private string phone = "";

        /// <summary>
        /// 邮件
        /// </summary>
        private string mail = "";

        /// <summary>
        /// 其它
        /// </summary>
        private string otherLinkway = "";

        #endregion

        /// <summary>
        /// 创建或修改的环境
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment operEnvi = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region 属性
        /// <summary>
        /// 联系方式类别
        /// </summary>
        public HISFC.Object.Base.Const LinkWayType
        {
            get
            {
                return this.linkWayType;
            }
            set
            {
                this.linkWayType = value;
            }
        }

        /// <summary>
        /// 联系方式内容
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("废弃  选择对应的联系方式字段存",true)]
        public string LinkWayContent
        {
            get
            {
                return this.linkWay;
            }
            set
            {
                this.linkWay = value;
            }
        }

        /// <summary>
        /// 邮政编码
        /// </summary>
        public string ZIP
        {
            get
            {
                return this.zip;
            }
            set
            {
                this.zip = value;
            }
        }

        /// <summary>
        /// 是否是联系人的联系方式
        /// </summary>
        public bool IsLinkMan
        {
            get
            {
                return this.isLinkMan;
            }
            set
            {
                this.isLinkMan = value;
            }
        }

        /// <summary>
        /// 联系人
        /// </summary>
        public Neusoft.NFC.Object.NeuObject LinkMan
        {
            get
            {
                return this.linkMan;
            }
            set
            {
                this.linkMan = value;
            }
        }

        /// <summary>
        /// 联系人与患者的关系
        /// </summary>
        public HISFC.Object.Base.Const Relation
        {
            get
            {
                return this.relation;
            }
            set
            {
                this.relation = value;
            }
        }

        /// <summary>
        /// 创建或修改的环境
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperEnvi
        {
            get
            {
                return this.operEnvi;
            }
            set
            {
                this.operEnvi = value;
            }
        }

        #region 2007-10-25 ADD BY WANGLI

        /// <summary>
        /// 地址
        /// </summary>
        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }

        /// <summary>
        /// 电话
        /// </summary>
        public string Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }

        /// <summary>
        /// 邮件
        /// </summary>
        public string Mail
        {
            get
            {
                return this.mail;
            }
            set
            {
                this.mail = value;
            }
        }

        /// <summary>
        /// 其它
        /// </summary>
        public string OtherLinkway
        {
            get
            {
                return this.otherLinkway;
            }
            set
            {
                this.otherLinkway = value;
            }
        }

        #endregion

        #endregion

        #region 方法

        /// <summary>
        /// 克隆
        /// </summary>
        /// <returns>联系方式</returns>
        public new LinkWay Clone()
        {
            LinkWay linkWay = base.Clone() as LinkWay;

            linkWay.LinkWayType = this.LinkWayType.Clone();
            linkWay.LinkMan = this.LinkMan.Clone();
            linkWay.Relation = this.Relation.Clone();
            linkWay.OperEnvi = this.OperEnvi.Clone();
            //linkWay.ZIP = this.ZIP.Clone();

            return linkWay;
        }

        #endregion
    }
}
