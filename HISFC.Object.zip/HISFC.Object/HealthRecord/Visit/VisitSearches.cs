using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord.Visit
{
    /// <summary>
    /// VisitSearches <br></br>
    /// [��������: ��ü�������ʵ��]<br></br>
    /// [�� �� ��: ����]<br></br>
    /// [����ʱ��: 2007-09-10]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class VisitSearches : Case.CaseInfo
    {
        #region ����

        /// <summary>
        /// ���뻷��(����ҽ��,����ʱ��)
        /// </summary>
        private HISFC.Object.Base.OperEnvironment doctorOper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ҽ����ʦ,��ʦ�ĵ绰�����ֶ�User01��
        /// </summary>
        private Neusoft.NFC.Object.NeuObject teacher = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// �������ݣ����֡����ޡ�������Ŀ��
        /// </summary>
        private string searchesContent = "";

        /// <summary>
        /// ԤԼ����ʱ��
        /// </summary>
        private DateTime bookingTime = DateTime.MinValue;
        
        /// <summary>
        /// �Ƿ��շ�
        /// </summary>
        private bool isCharge = false;

        /// <summary>
        /// �շѽ��
        /// </summary>
        private decimal chargeCost = 0m;

        /// <summary>
        /// ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject illType = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����
        /// </summary>
        private decimal years = 0m;

        /// <summary>
        /// ��Ŀ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject items = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����
        /// </summary>
        private string copy = "";

        /// <summary>
        /// ����
        /// </summary>
        private string append = "";

        /// <summary>
        /// ����״̬
        /// </summary>
        private EnumSearchesState searchesState = new EnumSearchesState();

        /// <summary>
        /// ��˻���
        /// </summary>
        private HISFC.Object.Base.OperEnvironment auditingOper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// ��������
        /// </summary>
        private HISFC.Object.Base.OperEnvironment searchesOper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ��Ϣ�Ƴ��������,����浽User01��
        /// </summary>
        private HISFC.Object.Base.OperEnvironment notionOper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// ���뻷��(����ҽ��,����ʱ��)
        /// </summary>
        public HISFC.Object.Base.OperEnvironment DoctorOper
        {
            get 
            {
                return this.doctorOper; 
            }
            set
            { 
                this.doctorOper = value; 
            }
        }

        /// <summary>
        /// ҽ����ʦ,��ʦ�ĵ绰�����ֶ�User01��
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Teacher
        {
            get 
            {
                return this.teacher; 
            }
            set
            {
                this.teacher = value; 
            }
        }

        /// <summary>
        /// �������ݣ����֡����ޡ�������Ŀ��
        /// </summary>
        public string SearchesContent
        {
            get 
            {
                return this.searchesContent; 
            }
            set
            {
                this.searchesContent = value; 
            }
        }

        /// <summary>
        /// ԤԼ����ʱ��
        /// </summary>
        public DateTime BookingTime
        {
            get 
            {
                return this.bookingTime; 
            }
            set
            {
                this.bookingTime = value; 
            }
        }

        /// <summary>
        /// �Ƿ��շ�
        /// </summary>
        public bool IsCharge
        {
            get 
            { 
                return this.isCharge; 
            }
            set 
            {
                this.isCharge = value; 
            }
        }

        /// <summary>
        /// �շѽ��
        /// </summary>
        public decimal ChargeCost
        {
            get 
            { 
                return this.chargeCost; 
            }
            set 
            { 
                this.chargeCost = value; 
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject IllType
        {
            get 
            { 
                return this.illType; 
            }
            set 
            { 
                this.illType = value; 
            }
        }


        /// <summary>
        /// ����
        /// </summary>
        public decimal Years
        {
            get 
            { 
                return this.years; 
            }
            set 
            { 
                this.years = value; 
            }
        }


        /// <summary>
        /// ��Ŀ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Items
        {
            get 
            { 
                return this.items; 
            }
            set 
            { 
                this.items = value; 
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string Copy
        {
            get 
            { 
                return this.copy; 
            }
            set 
            { 
                this.copy = value;
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string Append
        {
            get 
            { 
                return this.append; 
            }
            set 
            { 
                this.append = value;
            }
        }

        /// <summary>
        /// ����״̬
        /// </summary>
        public EnumSearchesState SearchesState
        {
            get 
            { 
                return this.searchesState; 
            }
            set 
            {
                this.searchesState = value; 
            }
        }

        /// <summary>
        /// ��˻���
        /// </summary>
        public HISFC.Object.Base.OperEnvironment AuditingOper
        {
            get 
            { 
                return this.auditingOper; 
            }
            set 
            { 
                this.auditingOper = value; 
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public HISFC.Object.Base.OperEnvironment SearchesOper
        {
            get 
            { 
                return this.searchesOper; 
            }
            set 
            { 
                this.searchesOper = value; 
            }
        }

        /// <summary>
        /// ��Ϣ�Ƴ��������,����浽User01��
        /// </summary>
        public HISFC.Object.Base.OperEnvironment NotionOper
        {
            get 
            { 
                return this.notionOper; 
            }
            set 
            { 
                this.notionOper = value; 
            }
        }

        #endregion

        #region ����

        #region ��¡

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns>��ü�������ʵ��</returns>
        public new VisitSearches Clone()
        {
            VisitSearches visitSearches = base.Clone() as VisitSearches;

            visitSearches.doctorOper = this.DoctorOper.Clone();
            visitSearches.teacher = this.Teacher.Clone();
            visitSearches.auditingOper = this.AuditingOper.Clone();
            visitSearches.searchesOper = this.SearchesOper.Clone();
            visitSearches.notionOper = this.NotionOper.Clone();

            return visitSearches;
        }

        #endregion

        #endregion
    }
}
