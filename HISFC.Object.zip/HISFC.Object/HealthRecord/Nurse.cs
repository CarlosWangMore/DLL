using System;


namespace Neusoft.HISFC.Object.HealthRecord
{


    /// <summary>
    /// Nurse ��ժҪ˵��:�����ȼ���Ϣ	ID ����Ա��� Name ����Ա����
    /// </summary>
    public class Nurse : Neusoft.NFC.Object.NeuObject
    {
        public Nurse()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }
        #region ˽�б���

        private Neusoft.HISFC.Object.RADT.Patient myPatientInfo = new Neusoft.HISFC.Object.RADT.Patient();
        private Neusoft.NFC.Object.NeuObject myNurseInfo = new Neusoft.NFC.Object.NeuObject();
        private int exeNumber;
        private string exeUnit;
        private DateTime operDate;

        #endregion

        #region ����
        /// <summary>
        /// ���߻�����Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.RADT.Patient PatientInfo
        {
            get { return myPatientInfo; }
            set { myPatientInfo = value; }
        }
        /// <summary>
        /// �����ȼ���Ϣ ID �ȼ����� Name �ȼ�����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject NurseInfo
        {
            get { return myNurseInfo; }
            set { myNurseInfo = value; }
        }
        /// <summary>
        /// ִ������
        /// </summary>
        public int ExeNumber
        {
            get { return exeNumber; }
            set { exeNumber = value; }
        }
        /// <summary>
        /// ִ�е�λ
        /// </summary>
        public string ExeUnit
        {
            get { return exeUnit; }
            set { exeUnit = value; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime OperDate
        {
            get { return operDate; }
            set { operDate = value; }
        }

        #endregion

        #region ���к���


        public new Nurse Clone()
        {
            Nurse NurseClone = base.MemberwiseClone() as Nurse;

            NurseClone.PatientInfo = this.PatientInfo.Clone();
            NurseClone.myNurseInfo = this.myNurseInfo.Clone();

            return NurseClone;
        }
        #endregion
    }
}
