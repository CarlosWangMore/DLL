using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.HealthRecord
{
    /// <summary>
    /// PatientInfo <br></br>
    /// [��������: ���﹤���ձ�¼��ʵ��]<br></br>
    /// [�� �� ��: �޷���]<br></br>
    /// [����ʱ��: 2009-11-27]<br></br>
    /// 
    /// <�޸ļ�¼
    /// 
    ///		�޸���=""
    ///		�޸�ʱ��=""
    ///		�޸�Ŀ��=""
    ///		�޸�����=""
    ///  />
    /// </summary>
    public class DayReportEmergency : Neusoft.NFC.Object.NeuObject
    {
        public DayReportEmergency()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ����
        //���м�¼
        private string hasRecord;
        //�ձ�����
        private DateTime dateStat;
        //����
        private Neusoft.NFC.Object.NeuObject dept = new Neusoft.NFC.Object.NeuObject();
        //��������
        private int emergencyNum;
        //�ɹ�����
        private int succeedNum;
        //��Ժ����
        private int outHospitalNum;
        //��������
        private int lcNum;
        //��Һ����
        private int syNum;
        //����Ա��Ϣ
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

       
        //��չ�ֶ�
        private string user01;

        
        #endregion

        #region ����
        //���м�¼
        public string HasRecord
        {
            get
            {
                return hasRecord; 
            }
            set
            {
                hasRecord = value; 
            }
        }
        //�ձ�����
        public DateTime DateStat
        {
            get
            {
                return dateStat; 
            }
            set
            {
                dateStat = value; 
            }
        }
        //����
        public Neusoft.NFC.Object.NeuObject Dept
        {
            get 
            {
                return dept; 
            }
            set
            {
                dept = value; 
            }
        }
        //��������
        public int EmergencyNum
        {
            get
            {
                return emergencyNum; 
            }
            set
            {
                emergencyNum = value; 
            }
        }
        //�ɹ�����
        public int SucceedNum
        {
            get
            {
                return succeedNum; 
            }
            set
            {
                succeedNum = value; 
            }
        }
        //��Ժ����
        public int OutHospitalNum
        {
            get
            {
                return outHospitalNum; 
            }
            set
            {
                outHospitalNum = value; 
            }
        }
        //��������
        public int LcNum
        {
            get
            {
                return lcNum; 
            }
            set
            {
                lcNum = value; 
            }
        }
        //��Һ����
        public int SyNum
        {
            get 
            {
                return syNum; 
            }
            set
            {
                syNum = value; 
            }
        }
        //����Ա��Ϣ
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get 
            {
                return operInfo; 
            }
            set
            {
                operInfo = value; 
            }
        }
        //��չ�ֶ�
        public string User011
        {
            get 
            {
                return user01; 
            }
            set
            {
                user01 = value; 
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new DayReportEmergency Clone()
        {
            DayReportEmergency myDayReportEmergency = base.Clone() as DayReportEmergency;

            return myDayReportEmergency;
        }
        #endregion
    }
}
