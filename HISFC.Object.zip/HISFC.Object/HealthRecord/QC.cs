using System;


namespace Neusoft.HISFC.Object.HealthRecord
{


    /// <summary>
    /// ������������ʵ�塣
    /// �̳�Neusoft.NFC.Object.NeuObject
    /// Neusoft.NFC.Object.NeuObject.ID ����Ա���� Neusoft.NFC.Object.NeuObject.Name ����Ա����
    ///
    /// ����: WangYu 2004-12-04
    /// </summary>
    public class QC : Neusoft.NFC.Object.NeuObject
    {
        public QC()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        //˽���ֶ�
        private string myInpatientNO;
        private Neusoft.NFC.Object.NeuObject myRuleInfo = new Neusoft.NFC.Object.NeuObject();
        private decimal myMark;
        private string myDenyFlag;
        private DateTime myOperDate;
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ����Ա��
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }
        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        public string InpatientNO
        {
            get
            {
                return myInpatientNO;
            }
            set
            {
                myInpatientNO = value;
            }
        }

        /// <summary>
        /// ������Ϣ ID ������� Name ������Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject RuleInfo
        {
            get
            {
                return myRuleInfo;
            }
            set
            {
                myRuleInfo = value;
            }
        }

        /// <summary>
        /// �÷�
        /// </summary>
        public decimal Mark
        {
            get
            {
                return myMark;
            }
            set
            {
                myMark = value;
            }
        }

        /// <summary>
        /// �Ƿ����
        /// </summary>
        public string DenyFlag
        {
            get
            {
                return myDenyFlag;
            }
            set
            {
                myDenyFlag = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public DateTime OperDate
        {
            get
            {
                return myOperDate;
            }
            set
            {
                myOperDate = value;
            }
        }

        public new QC Clone()
        {
            QC QCCLone = base.MemberwiseClone() as QC;

            QCCLone.myRuleInfo = this.myRuleInfo.Clone();

            return QCCLone;
        }

    }
}
