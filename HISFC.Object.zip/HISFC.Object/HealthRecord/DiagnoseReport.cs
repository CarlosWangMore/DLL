using System;


namespace Neusoft.HISFC.Object.HealthRecord
{


    /// <summary>
    /// DiagnoseReport ��ժҪ˵����
    /// ��Ⱦ�����濨��
    /// </summary>
    public class DiagnoseReport : Neusoft.HISFC.Object.RADT.Patient
    {
        public DiagnoseReport()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region  ˽�б���
        //������
        private string reportNO;
        //��������
        private string beginDate;
        //�������
        private string diagnoseDate;
        //��������
        private string deadDate;
        //����״̬
        private string state;
        //��������
        private string diseaseType;
        //��������
        private Neusoft.NFC.Object.NeuObject diseaseName;
        //��������
        private string cureDate;
        //����ȥ��
        private string patientGoing;
        //�Ǽ�ҽ��
        private Neusoft.NFC.Object.NeuObject registerCode;
        //�Ǽǿ���
        private Neusoft.NFC.Object.NeuObject registerDept;
        //�Ǽ�ʱ��
        private string registerDate;
        //�����
        private Neusoft.NFC.Object.NeuObject auditCode;
        //���ʱ��
        private string auditDate;
        //������
        private Neusoft.NFC.Object.NeuObject cancelCode;
        //����ʱ��
        private string cancelDate;
        //���ҽ��
        private Neusoft.NFC.Object.NeuObject diagnoseCode;
        //���Ҳ���Ա
        private Neusoft.NFC.Object.NeuObject deptOperCode;
        //���Ҳ���ʱ��
        private string deptOperDate;
        //סַ����
        private Neusoft.NFC.Object.NeuObject addCode;
        //ְҵ
        private Neusoft.NFC.Object.NeuObject profession;
        //��ϸסֵ
        private Neusoft.NFC.Object.NeuObject addHome;
        #endregion

        #region  ���б���
        //������
        public string ReportNo
        {
            get
            {
                return reportNO;
            }
            set
            {
                reportNO = value;
            }
        }
        //��������
        public string BeginDate
        {
            get
            {
                return beginDate;
            }
            set
            {
                beginDate = value;
            }
        }
        //�������
        public string DiagnoseDate
        {
            get
            {
                return diagnoseDate;
            }
            set
            {
                diagnoseDate = value;
            }
        }
        //��������
        public string DeadDate
        {
            get
            {
                return deadDate;
            }
            set
            {
                deadDate = value;
            }
        }
        //����״̬
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                state = value;
            }
        }
        //��������
        public string DiseaseType
        {
            get
            {
                return diseaseType;
            }
            set
            {
                diseaseType = value;
            }
        }
        //��������
        public Neusoft.NFC.Object.NeuObject DiseaseName
        {
            get
            {
                return diseaseName;
            }
            set
            {
                diseaseName = value;
            }
        }
        //��������
        public string CureDate
        {
            get
            {
                return cureDate;
            }
            set
            {
                cureDate = value;
            }
        }
        //����ȥ��
        public string PatientGoing
        {
            get
            {
                return patientGoing;
            }
            set
            {
                patientGoing = value;
            }
        }
        //�Ǽ�ҽ��
        public Neusoft.NFC.Object.NeuObject RegisterCode
        {
            get
            {
                return registerCode;
            }
            set
            {
                registerCode = value;
            }
        }
        //�Ǽǿ���
        public Neusoft.NFC.Object.NeuObject RegisterDept
        {
            get
            {
                return registerDept;
            }
            set
            {
                registerDept = value;
            }
        }
        //�Ǽ�ʱ��
        public string RegisterDate
        {
            get
            {
                return registerDate;
            }
            set
            {
                registerDate = value;
            }
        }
        //�����
        public Neusoft.NFC.Object.NeuObject AuditCode
        {
            get
            {
                return auditCode;
            }
            set
            {
                auditCode = value;
            }
        }
        //���ʱ��
        public string AuditDate
        {
            get
            {
                return auditDate;
            }
            set
            {
                auditDate = value;
            }
        }
        //������
        public Neusoft.NFC.Object.NeuObject CancelCode
        {
            get
            {
                return cancelCode;
            }
            set
            {
                cancelCode = value;
            }
        }
        //����ʱ��
        public string CancelDate
        {
            get
            {
                return cancelDate;
            }
            set
            {
                cancelDate = value;
            }
        }
        //���ҽ��
        public Neusoft.NFC.Object.NeuObject DiagnoseDoc
        {
            get
            {
                return diagnoseCode;
            }
            set
            {
                diagnoseCode = value;
            }
        }
        //���Ҳ���Ա
        public Neusoft.NFC.Object.NeuObject DeptOper
        {
            get
            {
                return deptOperCode;
            }
            set
            {
                deptOperCode = value;
            }
        }
        //���Ҳ���ʱ��
        public string DeptOperDate
        {
            get
            {
                return deptOperDate;
            }
            set
            {
                deptOperDate = value;
            }
        }
        //סַ����
        public Neusoft.NFC.Object.NeuObject AddCode
        {
            get
            {
                return addCode;
            }
            set
            {
                addCode = value;
            }
        }
        //ְҵ
        public Neusoft.NFC.Object.NeuObject Profession
        {
            get
            {
                return profession;
            }
            set
            {
                profession = value;
            }
        }
        //��ϸסֵ
        public Neusoft.NFC.Object.NeuObject AddHome
        {
            get
            {
                return addHome;
            }
            set
            {
                addHome = value;
            }
        }
        #endregion

        #region ����

        //סԺ��ˮ��
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ���ü̳д���", true)]
        public string inpatientNo = "";
        //��������
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �ü̳д���", true)]
        public string patientName = "";
        //�ҳ�����
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�������ü̳д���", true)]
        public string parentName = "";
        //����Ա
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("��������OperInfo����", true)]
        public string operCode = "";
        //����ʱ��
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("��������OperInfo����", true)]
        public string operDate = "";
        #endregion
    }
}
