using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Pharmacy
{
    /// <summary>
    /// [��������: ҩƷ�Զ����½�ά��]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2007-07]<br></br>
    /// <˵��>
    ///     1��ID�洢��ˮ��
    /// </˵��>
    /// </summary>
    public class MSCustom : Neusoft.NFC.Object.NeuObject
    {
        #region �����

        /// <summary>
        /// ��������
        /// </summary>
        private Neusoft.HISFC.Object.Base.EnumDepartmentType deptType = Neusoft.HISFC.Object.Base.EnumDepartmentType.P;

        /// <summary>
        /// ��Ŀ��Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject customItem = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��Ŀ���
        /// </summary>
        private int itemOrder;

        /// <summary>
        /// ��Ŀ��������
        /// </summary>
        private Neusoft.HISFC.Object.Base.EnumMSCustomType customType = Neusoft.HISFC.Object.Base.EnumMSCustomType.���;

        /// <summary>
        /// ��������
        /// </summary>
        private string typeItem;

        /// <summary>
        /// ��֧���� 1 ���� 2 ֧��
        /// </summary>
        private Neusoft.HISFC.Object.Base.TransTypes trans = Neusoft.HISFC.Object.Base.TransTypes.Positive;

        /// <summary>
        /// �۸�����
        /// </summary>
        private string priceType;

        /// <summary>
        /// ����Ա��Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion

        #region ����

        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.HISFC.Object.Base.EnumDepartmentType DeptType
        {
            get
            {
                return this.deptType;
            }
            set
            {
                this.deptType = value;
            }
        }

        /// <summary>
        /// ��Ŀ��Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject CustomItem
        {
            get
            {
                return this.customItem;
            }
            set
            {
                this.customItem = value;
            }
        }

        /// <summary>
        /// ��Ŀ���
        /// </summary>
        public int ItemOrder
        {
            get
            {
                return this.itemOrder;
            }
            set
            {
                this.itemOrder = value;
            }
        }

        /// <summary>
        /// ��Ŀ��������
        /// </summary>
        public Neusoft.HISFC.Object.Base.EnumMSCustomType CustomType
        {
            get
            {
                return this.customType;
            }
            set
            {
                this.customType = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string TypeItem
        {
            get
            {
                return this.typeItem;
            }
            set
            {
                this.typeItem = value;
            }
        }

        /// <summary>
        /// ��֧���� 1 ���� 2 ֧��
        /// </summary>
        public Neusoft.HISFC.Object.Base.TransTypes Trans
        {
            get
            {
                return this.trans;
            }
            set
            {
                this.trans = value;
            }
        }

        /// <summary>
        /// �۸�����
        /// </summary>
        public string PriceType
        {
            get
            {
                return this.priceType;
            }
            set
            {
                this.priceType = value;
            }
        }

        /// <summary>
        /// ����Ա��Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get            
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }
        #endregion


        #region ����

        public new MSCustom Clone()
        {
            MSCustom ms = base.Clone() as MSCustom;

            ms.customItem = this.customItem.Clone();

            ms.oper = this.oper.Clone();

            return ms;
        }

        #endregion
    }
}
