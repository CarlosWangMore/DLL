using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Pharmacy
{
    /// <summary>
    /// [��������: ҩ������ʵ��for����]<br></br>
    /// [�� �� ��: ţ��Ԫ]<br></br>
    /// [����ʱ��: 2009-10]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=' '
    ///		�޸�ʱ��=' '
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public  class PharmacyFunction:Neusoft.NFC.Object.NeuObject
    {
        #region ����
        /// <summary>
        /// ҩƷ��Ŀʵ��
        /// </summary>
        private Item item = new Item();

        /// <summary>
        /// ҩ������1
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction1 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩ������2
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction2 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩ������3
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction3 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// 4��ҩ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction4 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// 5��ҩ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction5 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����Ա
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

       

        /// <summary>
        /// �÷�
        /// </summary>
        private string usages = string.Empty;

        #endregion

        #region ����
        /// <summary>
        /// ҩƷ��Ŀʵ��
        /// </summary>
        public Item Item
        {
            get { return item; }
            set { item = value; }
        }

        /// <summary>
        /// ҩ������1
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction1
        {
            get { return phyFunction1; }
            set { phyFunction1 = value; }
        }

        /// <summary>
        /// ҩ������2
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction2
        {
            get { return phyFunction2; }
            set { phyFunction2 = value; }
        }

        /// <summary>
        /// ҩ������3
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction3
        {
            get { return phyFunction3; }
            set { phyFunction5 = value; }
        }

        /// <summary>
        /// ҩ������4
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction4
        {
            get { return phyFunction4; }
            set { phyFunction5 = value; }
        }

        /// <summary>
        /// ҩ������5
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction5
        {
            get { return phyFunction5; }
            set { phyFunction5 = value; }
        }
        /// <summary>
        /// ����Ա
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get { return oper; }
            set { oper = value; }
        }

       

        /// <summary>
        /// �÷�
        /// </summary>
        public string Usages
        {
            get { return usages; }
            set { usages = value; }
        }
 
        #endregion

        #region ��¡����

        public new PharmacyFunction Clone()
        {
            PharmacyFunction phymacyFunction = base.Clone() as PharmacyFunction;
            phymacyFunction.Item = this.Item.Clone();
            phymacyFunction.PhyFunction1 = this.PhyFunction1.Clone();
            phymacyFunction.PhyFunction2 = this.PhyFunction2.Clone();
            phymacyFunction.PhyFunction3 = this.PhyFunction3.Clone();
            phymacyFunction.PhyFunction4 = this.PhyFunction4.Clone();
            phymacyFunction.PhyFunction5 = this.PhyFunction5.Clone();
            phymacyFunction.Oper = this.Oper.Clone();
            return phymacyFunction;
        }

        #endregion
    }
}
