using System;
using System.Collections.Generic;
using Neusoft.NFC.Attribute;
using Neusoft.NFC.Management;

namespace Neusoft.HISFC.Object.Pharmacy.Base
{
    /// <summary>
    /// EntPhaInfoExt<para></para>
    /// [��������: ]<para></para>
    /// [�� �� ��: ]<para></para>
    /// [����ʱ��: 2012-11-14 10:19]<para></para>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  /><para></para>
    /// </summary>
    public class EntPhaInfoExt : Neusoft.NFC.Management.NeuObjectExtra
    {
        /// <summary>
        /// һ�㹹�캯��
        /// </summary>
        public EntPhaInfoExt()
        {
            objectStatus = ObjectStatus.New;
        }

        /// <summary>
        /// ����һ��ʵ������¡����ʵ��
        /// </summary>
        public EntPhaInfoExt(EntPhaInfoExt argObj)
            : base(argObj)
        {
        }

        #region ����

        #endregion

        #region ����
        /// <summary>
        /// ���ݿ����
        /// </summary>
        public override string TableName
        {
            get { return "PHA_COM_BASEINFO_EXT"; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string ID
        {
            get { return base.ID; }
            set { base.ID = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string Name
        {
            get { return base.Name; }
            set { base.Name = value; }
        }


        private string drugCode;
        /// <summary>
        /// ҩƷ����
        /// </summary>
        [DataFieldName("DRUG_CODE"), DataFieldDefault("")]
        public string DrugCode
        {
            get { return drugCode; }
            set
            {
                if (!object.Equals(drugCode, value))
                {
                    if (!modifiedProperty.ContainsKey("DrugCode"))
                    {
                        modifiedProperty.Add("DrugCode", drugCode);
                        this.IsModified = true;
                    }
                    drugCode = value;
                }
            }
        }

        private string zySplitFlag;
        /// <summary>
        /// סԺ�Ƿ���Բ��� 1 ���� 0 ������  
        /// </summary>
        [DataFieldName("ZY_SPLIT_FLAG"), DataFieldDefault("")]
        public string ZySplitFlag
        {
            get { return zySplitFlag; }
            set
            {
                if (!object.Equals(zySplitFlag, value))
                {
                    if (!modifiedProperty.ContainsKey("ZySplitFlag"))
                    {
                        modifiedProperty.Add("ZySplitFlag", zySplitFlag);
                        this.IsModified = true;
                    }
                    zySplitFlag = value;
                }
            }
        }

        #endregion

        #region ����
        /// <summary>
        /// ǳ����¡
        /// </summary>
        public new EntPhaInfoExt Clone()
        {
            // TODO:  ���� EntPhaInfoExt.Clone ʵ��
            EntPhaInfoExt obj = base.Clone() as EntPhaInfoExt;

            return obj;
        }
        #endregion

    }

}