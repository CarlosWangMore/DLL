using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Pharmacy
{
    /// <summary>
    /// [��������: ҩƷ�ض�λ����]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2007-11]<br></br>
    /// <˵��>
    ///     1��  ID ȡҩҩ�� Name ȡҩҩ������
    /// </˵��>
    /// </summary>
    public class DrugSpeLocation : Neusoft.NFC.Object.NeuObject
    {
        public DrugSpeLocation()
        {

        }

        #region �����

        /// <summary>
        /// �ض�ҩƷ
        /// </summary>
        private Neusoft.HISFC.Object.Pharmacy.Item item = new Item();

        /// <summary>
        /// ȡҩ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject roomDept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����Ա
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// �ض�ҩƷ
        /// </summary>
        public Neusoft.HISFC.Object.Pharmacy.Item Item
        {
            get            
            {
                return this.item;
            }
            set
            {
                this.item = value;
            }
        }

        /// <summary>
        /// ȡҩ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject RoomDept
        {
            get
            {
                return this.roomDept;
            }
            set
            {
                this.roomDept = value;
            }
        }

        /// <summary>
        /// ����Ա
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }

        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new DrugSpeLocation Clone()
        {
            DrugSpeLocation dr = base.Clone() as DrugSpeLocation;

            dr.item = this.item.Clone();
            dr.roomDept = this.roomDept.Clone();
            dr.oper = this.oper.Clone();

            return dr;
        }

        #endregion
    }
}
