using System;

namespace Neusoft.HISFC.Object.Pharmacy
{
    /// <summary>
    /// [��������: ҩƷ������Ϣ]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2006-09-11]<br></br>
    /// <�޸ļ�¼
    ///		�޸���='������'
    ///		�޸�ʱ��='2009-10-21'
    ///		�޸�Ŀ��='�ӹ�������'
    ///		�޸�����=''
    ///  />
    /// </summary>
    [System.ComponentModel.DisplayName("ҩƷ�ֵ���Ϣ")]
    public class Item : Neusoft.HISFC.Object.Base.Item, Neusoft.HISFC.Object.Base.IValidState
    {
        public Item()
        {
            //this.IsPharmacy = true;
            this.ItemType = Neusoft.HISFC.Object.Base.EnumItemType.Drug;
        }


        #region ����

        /// <summary>
        /// ����������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ��Ŀ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.IMA.NameService nameCollection = new Neusoft.HISFC.Object.IMA.NameService();

        /// <summary>
        /// �۸���Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.IMA.PriceService priceCollection = new Neusoft.HISFC.Object.IMA.PriceService();

        /// <summary>
        /// ��Ʒ��Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Pharmacy.Base.ProductService product = new Neusoft.HISFC.Object.Pharmacy.Base.ProductService();

        /// <summary>
        /// ����Ļ��ʾ
        /// </summary>
        private bool isShow;

        /// <summary>
        /// ��ʾ���� 0 ȫԺ 1 סԺ  2 ����
        /// </summary>
        private string showState;

        /// <summary>
        /// �Ƿ�ͣ��
        /// </summary>
        private bool isStop;

        /// <summary>
        /// �Ƿ�GMP
        /// </summary>
        private bool isGMP;

        /// <summary>
        /// �Ƿ�OTC
        /// </summary>
        private bool isOTC;

        /// <summary>
        /// �Ƿ���ҩ
        /// </summary>
        private bool isNew;

        /// <summary>
        /// �Ƿ�ȱҩ
        /// </summary>
        private bool isLack;

        /// <summary>
        /// �Ƿ���Ҫ����
        /// </summary>
        private bool isAllergy;

        /// <summary>
        /// �Ƿ񸽲�
        /// </summary>
        private bool isSubtbl;

        /// <summary>
        /// �Ƿ��ֹ�����  {9F062119-CA0C-4942-9D0E-F0D870CA1BAA}  add by chenzl 2011-05-12
        /// </summary>
        private bool isUndocFlag;

        /// <summary>
        /// ��Ч�ɷ�
        /// </summary>
        private string ingredient;

        /// <summary>
        /// ��ҩִ�б�׼
        /// </summary>
        private string executeStandard;

        /// <summary>
        /// �б���Ϣ��
        /// </summary>
        private TenderOffer tenderOffer = new TenderOffer();

        /// <summary>
        /// �䶯����
        /// </summary>
        private ItemShiftType shiftType = new ItemShiftType();

        /// <summary>
        /// �䶯ʱ��
        /// </summary>
        private DateTime shiftTime;

        /// <summary>
        /// �䶯ԭ��
        /// </summary>
        private string shiftMark;

        /// <summary>
        /// ��ϵͳҩƷ����
        /// </summary>
        private string oldDrugID;

        /// <summary>
        /// ������� 0 �ɲ��װ��λ 1 ���ܲ��װ��λ
        /// </summary>
        private string splitType = "1";

        /// <summary>
        /// ��������
        /// </summary>
        private string buyType;

        /// <summary>
        /// ��Ч��
        /// </summary>
        private Neusoft.HISFC.Object.Base.EnumValidState validState = Neusoft.HISFC.Object.Base.EnumValidState.Valid;

        /// <summary>
        /// ҩƷҽ�����     
        /// </summary>
        private string ybGrade;

        /// <summary>
        /// ������ҩ�� �Ƿ����ҩ add by chenzl 2012-10-24 {85EDAA64-4BA2-473b-8B6E-7B09D2EDF52B}
        /// </summary>
        private bool isAutoMed;

        public bool IsAutoMed
        {
            get 
            { 
                return isAutoMed; 
            }
            set 
            { 
                isAutoMed = value; 
            }
        }

        #endregion

        #region ҩƷʹ����Ϣ����

        /// <summary>
        /// ��װ��λ
        /// </summary>
        private string packUnit;

        /// <summary>
        /// ��С��λ
        /// </summary>
        private string minUnit;

        /// <summary>
        /// ��������
        /// </summary>
        private decimal baseDose;

        /// <summary>
        /// ������λ
        /// </summary>
        private string doseUnit;

        /// <summary>
        /// һ�μ���
        /// </summary>
        private decimal onceDose;

        /// <summary>
        /// ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject dosageForm = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��� ��ҩ����ҩ��
        /// </summary>
        private Neusoft.NFC.Object.NeuObject type = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩƷ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject quality = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ʹ�÷���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject usage = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// Ƶ��
        /// </summary>
        private Neusoft.HISFC.Object.Order.Frequency frequency = new Neusoft.HISFC.Object.Order.Frequency();

        /// <summary>
        /// ҩ������1
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction1 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩ������2
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction2 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩ������3
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction3 = new Neusoft.NFC.Object.NeuObject();

        #endregion

        #region ҩƷ�ֵ���չ�ֶΣ���չ��ʹ�� ҩƷ������ΪID ��������ҩ�����ã� {AED5267F-9819-46a9-8639-6670BF74CA1B}

        /// <summary>
        /// 4��ҩ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction4 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// 5��ҩ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject phyFunction5 = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// �÷����루֧�ֶ��÷� �ԡ�|��������
        /// </summary>
        private string usages = string.Empty;

        /// <summary>
        ///  ��չ�ֶ�1
        /// </summary>
        private string extend1 = string.Empty;

        /// <summary>
        /// ��չ�ֶ�2
        /// </summary>
        private string extend2 = string.Empty;

        /// <summary>
        /// ��չ�ֶ�3
        /// </summary>
        private string extend3 = string.Empty;

        #endregion

        /// <summary>
        /// ��Ŀ����
        /// </summary>
        public new string ID
        {
            get
            {
                return base.ID;
            }
            set
            {
                base.ID = value;
                this.nameCollection.ID = value;
                this.priceCollection.ID = value;
                this.product.ID = value;
            }
        }


        /// <summary>
        /// ��Ŀ����
        /// </summary>
        [System.ComponentModel.DisplayName("ҩƷ����")]
        [System.ComponentModel.Description("ҩƷ��Ʒ����")]
        public new string Name
        {
            get
            {
                return base.Name;
            }
            set
            {
                base.Name = value;
                this.nameCollection.Name = value;
                this.priceCollection.Name = value;
                this.product.Name = value;
            }
        }


        /// <summary>
        /// ��Ŀ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.IMA.NameService NameCollection
        {
            get
            {
                return this.nameCollection;
            }
            set
            {
                this.nameCollection = value;
            }
        }

        /// <summary>
        /// �۸� (���ۼ�)
        /// </summary>
        public new decimal Price
        {
            get
            {
                if (this.priceCollection.RetailPrice != 0)
                {
                    base.Price = this.priceCollection.RetailPrice;
                    return this.priceCollection.RetailPrice;
                }
                else
                {
                    return base.Price;
                }
            }
            set
            {
                this.priceCollection.RetailPrice = value;
                base.Price = value;
            }
        }

        /// <summary>
        /// ƴ����
        /// </summary>
        [System.ComponentModel.DisplayName("ƴ����")]
        [System.ComponentModel.Description("ҩƷ��Ʒ���Ƶ�ƴ����")]
        public new string SpellCode
        {
            get
            {
                return this.nameCollection.SpellCode;
            }
            set
            {
                base.SpellCode = value;
                this.nameCollection.SpellCode = value;
            }
        }

        /// <summary>
        /// �����
        /// </summary>
        [System.ComponentModel.DisplayName("�����")]
        [System.ComponentModel.Description("ҩƷ��Ʒ���Ƶ������")]
        public new string WBCode
        {
            get
            {
                return this.nameCollection.WBCode;
            }
            set
            {
                base.WBCode = value;
                this.nameCollection.WBCode = value;
            }
        }

        /// <summary>
        /// �Զ�����
        /// </summary>
        [System.ComponentModel.DisplayName("�Զ�����")]
        [System.ComponentModel.Description("ҩƷ��Ʒ���Ƶ��Զ�����")]
        public new string UserCode
        {
            get
            {
                return this.nameCollection.UserCode;
            }
            set
            {
                base.UserCode = value;
                this.nameCollection.UserCode = value;
            }
        }

        /// <summary>
        /// ���ұ���
        /// </summary>
        [System.ComponentModel.DisplayName("���ұ���")]
        [System.ComponentModel.Description("ҩƷ���ұ���")]
        public new string GBCode
        {
            get
            {
                return this.nameCollection.GbCode;
            }
            set
            {
                base.GBCode = value;
                this.nameCollection.GbCode = value;
            }
        }

        /// <summary>
        /// ���ʱ���
        /// </summary>
        [System.ComponentModel.DisplayName("���ʱ���")]
        [System.ComponentModel.Description("ҩƷ���ʱ���")]
        public new string NationCode
        {
            get
            {
                return this.nameCollection.InternationalCode;
            }
            set
            {
                base.NationCode = value;
                this.nameCollection.InternationalCode = value;
            }
        }

        /// <summary>
        /// ��װ��λ
        /// </summary>
        [System.ComponentModel.DisplayName("��װ��λ")]
        [System.ComponentModel.Description("ҩƷ��װ��λ")]
        public string PackUnit
        {
            get
            {
                return this.packUnit;
            }
            set
            {
                this.packUnit = value;
                base.PriceUnit = value;
            }
        }


        /// <summary>
        /// ��С��λ
        /// </summary>
        [System.ComponentModel.DisplayName("��С��λ")]
        [System.ComponentModel.Description("ҩƷ��С��λ")]
        public string MinUnit
        {
            get
            {
                return this.minUnit;
            }
            set
            {
                this.minUnit = value;
            }
        }


        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.DisplayName("��������")]
        [System.ComponentModel.Description("ҩƷ��������")]
        public decimal BaseDose
        {
            get
            {
                return this.baseDose;
            }
            set
            {
                this.baseDose = value;
            }
        }


        /// <summary>
        /// ������λ
        /// </summary>
        [System.ComponentModel.DisplayName("������λ")]
        [System.ComponentModel.Description("ҩƷ������λ")]
        public string DoseUnit
        {
            get
            {
                return this.doseUnit;
            }
            set
            {
                this.doseUnit = value;
            }
        }


        /// <summary>
        /// һ������(����)
        /// </summary>
        [System.ComponentModel.DisplayName("ÿ�μ���")]
        [System.ComponentModel.Description("ҩƷÿ�μ���")]
        public decimal OnceDose
        {
            get
            {
                return this.onceDose;
            }
            set
            {
                this.onceDose = value;
            }
        }


        /// <summary>
        /// ����
        /// </summary>
        [System.ComponentModel.DisplayName("����")]
        [System.ComponentModel.Description("ҩƷ����")]
        public Neusoft.NFC.Object.NeuObject DosageForm
        {
            get
            {
                return this.dosageForm;
            }
            set
            {
                this.dosageForm = value;
            }
        }


        /// <summary>
        /// ��� ��ҩ����ҩ��
        /// </summary>
        [System.ComponentModel.DisplayName("���")]
        [System.ComponentModel.Description("ҩƷ���")]
        public Neusoft.NFC.Object.NeuObject Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }


        /// <summary>
        /// ���� �գ��� 
        /// </summary>
        [System.ComponentModel.DisplayName("����")]
        [System.ComponentModel.Description("ҩƷ����")]
        public Neusoft.NFC.Object.NeuObject Quality
        {
            get
            {
                return this.quality;
            }
            set
            {
                this.quality = value;
            }
        }


        /// <summary>
        /// ʹ�÷���
        /// </summary>
        [System.ComponentModel.DisplayName("ʹ�÷���")]
        [System.ComponentModel.Description("ҩƷʹ�÷���")]
        public Neusoft.NFC.Object.NeuObject Usage
        {
            get
            {
                return this.usage;
            }
            set
            {
                this.usage = value;
            }
        }


        /// <summary>
        /// Ƶ��
        /// </summary>
        [System.ComponentModel.DisplayName("Ƶ��")]
        [System.ComponentModel.Description("ҩƷƵ��")]
        public Neusoft.HISFC.Object.Order.Frequency Frequency
        {
            get
            {
                return this.frequency;
            }
            set
            {
                this.frequency = value;
            }
        }


        /// <summary>
        /// һ��ҩ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction1
        {
            get
            {
                return this.phyFunction1;
            }
            set
            {
                this.phyFunction1 = value;
            }
        }


        /// <summary>
        /// ����ҩ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction2
        {
            get
            {
                return this.phyFunction2;
            }
            set
            {
                this.phyFunction2 = value;
            }
        }


        /// <summary>
        /// ����ҩ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction3
        {
            get
            {
                return this.phyFunction3;
            }
            set
            {
                this.phyFunction3 = value;
            }
        }


        /// <summary>
        /// �۸���Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.IMA.PriceService PriceCollection
        {
            get
            {
                return this.priceCollection;
            }
            set
            {
                this.priceCollection = value;
                base.Price = value.RetailPrice;
            }
        }


        /// <summary>
        /// ��Ʒ��Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Pharmacy.Base.ProductService Product
        {
            get
            {
                return this.product;
            }
            set
            {
                this.product = value;
            }
        }


        /// <summary>
        /// �Ƿ�ͣ��
        /// </summary>
        [System.ComponentModel.DisplayName("�Ƿ�ͣ��")]
        [System.ComponentModel.Description("ҩƷ�Ƿ�ͣ��")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����Բ������ݿ��ڻ�ȡ", false)]
        public bool IsStop
        {
            get
            {
                return this.isStop;
            }
            set
            {
                this.isStop = value;

                if (value)
                {
                    this.validState = Neusoft.HISFC.Object.Base.EnumValidState.Invalid;
                }
                else
                {
                    this.validState = Neusoft.HISFC.Object.Base.EnumValidState.Valid;
                }
            }
        }

        #region IValidState ��Ա

        public new Neusoft.HISFC.Object.Base.EnumValidState ValidState
        {
            get
            {
                return this.validState;
            }
            set
            {
                if (value == Neusoft.HISFC.Object.Base.EnumValidState.Valid)
                {
                    this.isStop = false;
                }
                else
                {
                    this.isStop = true;
                }

                this.validState = value;
            }
        }

        #endregion


        /// <summary>
        /// �Ƿ�GMP
        /// </summary>
        [System.ComponentModel.DisplayName("�Ƿ�GMP")]
        [System.ComponentModel.Description("ҩƷ�Ƿ�GMP")]
        public bool IsGMP
        {
            get
            {
                return this.isGMP;
            }
            set
            {
                this.isGMP = value;
            }
        }


        /// <summary>
        /// �Ƿ�OTC
        /// </summary>
        [System.ComponentModel.DisplayName("�Ƿ�OTC")]
        [System.ComponentModel.Description("ҩƷ�Ƿ�OTC")]
        public bool IsOTC
        {
            get
            {
                return this.isOTC;
            }
            set
            {
                this.isOTC = value;
            }
        }


        /// <summary>
        /// �Ƿ���ҩ
        /// </summary>
        public bool IsNew
        {
            get
            {
                return this.isNew;
            }
            set
            {
                this.isNew = value;
            }
        }


        /// <summary>
        /// �Ƿ�ȱҩ
        /// </summary>
        public bool IsLack
        {
            get
            {
                return this.isLack;
            }
            set
            {
                this.isLack = value;
            }
        }


        /// <summary>
        /// ����Ļ��ʾ
        /// </summary>
        public bool IsShow
        {
            get
            {
                return this.isShow;
            }
            set
            {
                this.isShow = value;
            }
        }


        /// <summary>
        /// ��ʾ���� 0 ȫԺ 1 סԺ  2 ����
        /// </summary>
        public string ShowState
        {
            get
            {
                return this.showState;
            }
            set
            {
                this.showState = value;
            }
        }


        /// <summary>
        /// �Ƿ���Ҫ����
        /// </summary>
        [System.ComponentModel.DisplayName("�Ƿ���Ҫ����")]
        [System.ComponentModel.Description("ҩƷ�Ƿ���Ҫ���� ������ʾҽ��")]
        public bool IsAllergy
        {
            get
            {
                return this.isAllergy;
            }
            set
            {
                this.isAllergy = value;
            }
        }


        /// <summary>
        /// �Ƿ񸽲�
        /// </summary>
        public bool IsSubtbl
        {
            get
            {
                return this.isSubtbl;
            }
            set
            {
                this.isSubtbl = value;
            }
        }

        /// <summary>
        /// �Ƿ��ֹ�����  {9F062119-CA0C-4942-9D0E-F0D870CA1BAA}  add by chenzl 2011-05-12
        /// </summary>
        public bool IsUndocFlag
        {
            get { return isUndocFlag; }
            set { isUndocFlag = value; }
        }

        /// <summary>
        /// ��Ч�ɷ�
        /// </summary>
        public string Ingredient
        {
            get
            {
                return this.ingredient;
            }
            set
            {
                this.ingredient = value;
            }
        }


        /// <summary>
        /// ��ҩִ�б�׼
        /// </summary>
        public string ExecuteStandard
        {
            get
            {
                return this.executeStandard;
            }
            set
            {
                this.executeStandard = value;
            }
        }


        /// <summary>
        /// �б���Ϣ��
        /// </summary>
        public TenderOffer TenderOffer
        {
            get
            {
                return this.tenderOffer;
            }
            set
            {
                this.tenderOffer = value;
            }
        }


        /// <summary>
        /// �䶯����
        /// </summary>
        public ItemShiftType ShiftType
        {
            get
            {
                return this.shiftType;
            }
            set
            {
                this.shiftType = value;
            }
        }


        /// <summary>
        /// �䶯ʱ��
        /// </summary>
        public DateTime ShiftTime
        {
            get
            {
                return this.shiftTime;
            }
            set
            {
                this.shiftTime = value;
            }
        }


        /// <summary>
        /// �䶯ԭ��
        /// </summary>
        public string ShiftMark
        {
            get
            {
                return this.shiftMark;
            }
            set
            {
                this.shiftMark = value;
            }
        }


        /// <summary>
        /// ��ϵͳҩƷ����
        /// </summary>
        public string OldDrugID
        {
            get
            {
                return this.oldDrugID;
            }
            set
            {
                this.oldDrugID = value;
            }
        }


        /// <summary>
        /// ������� 0 �ɲ��װ��λ 1 ���ܲ��װ��λ
        /// </summary>
        [System.ComponentModel.DisplayName("�������")]
        [System.ComponentModel.Description("ҩƷ������� �������Ｐ��Ժ��ҩ��Ч")]
        public string SplitType
        {
            get
            {
                return this.splitType;
            }
            set
            {
                this.splitType = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string BuyType
        {
            get
            {
                return this.buyType;
            }
            set
            {
                this.buyType = value;
            }
        }

        /// <summary>
        /// ҩƷ�ȼ�
        /// </summary>
        [System.ComponentModel.DisplayName("ҩƷ�ȼ�")]
        [System.ComponentModel.Description("ҩƷ�ȼ� ��ҽ��ְ�����")]
        public new string Grade
        {
            get
            {
                return base.Grade;
            }
            set
            {
                base.Grade = value;
            }
        }


        /// <summary>
        /// ����������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }

        #region ҩƷ�ֵ���չ�ֶΣ���չ��ʹ�� ҩƷ������ΪID ��������ҩ�����ã� {AED5267F-9819-46a9-8639-6670BF74CA1B}

        /// <summary>
        /// 4��ҩ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction4
        {
            get
            {
                return this.phyFunction4;
            }
            set
            {
                this.phyFunction4 = value;
            }
        }

        /// <summary>
        /// 5��ҩ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject PhyFunction5
        {
            get
            {
                return this.phyFunction5;
            }
            set
            {
                this.phyFunction5 = value;
            }
        }

        /// <summary>
        /// �÷����루֧�ֶ��÷� �ԡ�|��������
        /// </summary>
        public string Usages
        {
            get
            {
                return this.usages;
            }
            set
            {
                this.usages = value;
            }
        }

        /// <summary>
        ///  ��չ�ֶ�1
        /// </summary>
        public string Extend1
        {
            get
            {
                return this.extend1;
            }
            set
            {
                this.extend1 = value;
            }
        }

        /// <summary>
        /// ��չ�ֶ�2
        /// </summary>
        public string Extend2
        {
            get
            {
                return this.extend2;
            }
            set
            {
                this.extend2 = value;
            }
        }

        /// <summary>
        /// ��չ�ֶ�3
        /// </summary>
        public string Extend3
        {
            get
            {
                return this.extend3;
            }
            set
            {
                this.extend3 = value;
            }
        }

        /// <summary>
        ///ҩƷҽ�����
        /// </summary>
        public new string YbGrade
        {
            get
            {
                return base.YbGrade;
            }
            set
            {
                base.YbGrade = value;
            }
        }
        ///// <summary>
        /////��Ŀ�������
        ///// </summary>
        //public new string Item_Class_Code
        //{
        //    get
        //    {
        //        return base.ItemClassCode;
        //    }
        //    set
        //    {
        //        base.ItemClassCode = value;
        //    }
        //}


        #endregion

        #region ����

        /// <summary>
        /// ������¡
        /// </summary>
        /// <returns>�ɹ����ؿ�¡���Itemʵ�� ʧ�ܷ���null</returns>
        public new Item Clone()
        {
            Item item = base.Clone() as Item;

            item.NameCollection = this.NameCollection.Clone();
            item.DosageForm = this.DosageForm.Clone();
            item.Type = this.Type.Clone();
            item.Quality = this.Quality.Clone();
            item.Usage = this.Usage.Clone();
            item.Frequency = this.Frequency.Clone();
            item.PhyFunction1 = this.PhyFunction1.Clone();
            item.PhyFunction2 = this.PhyFunction2.Clone();
            item.PhyFunction3 = this.PhyFunction3.Clone();
            item.PriceCollection = this.PriceCollection.Clone();
            item.Product = this.Product.Clone();
            item.TenderOffer = this.TenderOffer.Clone();
            item.ShiftType = this.ShiftType.Clone();

            item.PhyFunction4 = this.PhyFunction4.Clone();
            item.PhyFunction5 = this.PhyFunction5.Clone();
            return item;
        }


        #endregion

        #region ��Ч����

        /// <summary>
        /// ���ۼ�
        /// </summary>
        private decimal myRetailPrice;

        /// <summary>
        /// ��ϵͳ����
        /// </summary>
        private string oldDrugCode;

        /// <summary>
        /// ���ʱ��
        /// </summary>
        private DateTime shiftDate;

        /// <summary>
        /// �Ƿ񸽲�
        /// </summary>
        private bool isAppend;

        /// <summary>
        /// ����Ա����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪOper����", true)]
        public string OperCode = "";

        /// <summary>
        /// ����ʱ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪOper����", true)]
        public DateTime OperDate;

        /// <summary>
        /// ҩƷͨ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string RegularName = "";

        /// <summary>
        /// ͨ����������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public Neusoft.HISFC.Object.Base.Spell RegularSpellCode = new Neusoft.HISFC.Object.Base.Spell();

        /// <summary>
        /// ѧ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string FormalName = "";

        /// <summary>
        /// ѧ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public Neusoft.HISFC.Object.Base.Spell FormalSpellCode = new Neusoft.HISFC.Object.Base.Spell();

        /// <summary>
        /// ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string OtherName = "";

        /// <summary>
        /// ������������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public Neusoft.HISFC.Object.Base.Spell OtherSpellCode = new Neusoft.HISFC.Object.Base.Spell();

        /// <summary>
        /// Ӣ����Ʒ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string EnglishName = "";

        /// <summary>
        /// Ӣ��ͨ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string EnglishRegularName = "";

        /// <summary>
        /// Ӣ�ı���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string EnglishOtherName = "";

        /// <summary>
        /// ���ʱ���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string InternationalCode = "";

        /// <summary>
        /// ���ұ���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪNameCollection����", true)]
        public string GbCode = "";

        /// <summary>
        /// ���ۼ�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪPriceCollection����", true)]
        public decimal RetailPrice
        {
            get { return myRetailPrice; }
            set
            {
                this.myRetailPrice = value;
                this.Price = value;
            }
        }


        /// <summary>
        /// ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪPriceCollection����", true)]
        public decimal WholesalePrice;

        /// <summary>
        /// �����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪPriceCollection����", true)]
        public decimal PurchasePrice;

        /// <summary>
        /// ������ۼ�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪPriceCollection����", true)]
        public decimal TopRetailPrice;

        /// <summary>
        /// �۸���ʽ��������Ҷ��ۡ��б궨�۵�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪPriceCollection����", true)]
        public Neusoft.NFC.Object.NeuObject PriceForm = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public Neusoft.NFC.Object.NeuObject Producer = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ���¹�����˾
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public Neusoft.NFC.Object.NeuObject Company = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ������Ϣ
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string ApprovalInfo = "";

        /// <summary>
        /// ע���̱�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string Label = "";

        /// <summary>
        /// ע������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string Caution = "";

        /// <summary>
        /// ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string BarCode = "";

        /// <summary>
        /// ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string ProducingArea = "";

        /// <summary>
        /// ҩƷ���
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string BriefIntroduction = "";

        /// <summary>
        /// ҩƷ˵��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string Manual = "";

        /// <summary>
        /// ҩƷ���ͼƬ
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public System.Drawing.Image Image;

        /// <summary>
        /// �Ƿ�����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public bool IsSelfMade;

        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪProduct����", true)]
        public string StoreCondition = "";

        /// <summary>
        /// ��ϵͳҩƷ����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪOldDrugID", true)]
        public string OldDrugCode
        {
            get
            {
                return this.oldDrugCode;
            }
            set
            {
                this.oldDrugCode = value;
            }
        }


        /// <summary>
        /// �䶯ʱ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪShiftTime", true)]
        public DateTime ShiftDate
        {
            get
            {
                return this.shiftDate;
            }
            set
            {
                this.shiftDate = value;
            }
        }


        /// <summary>
        /// �Ƿ񸽲�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�����ع� ����ΪIsSubtbl", true)]
        public bool IsAppend
        {
            get
            {
                return this.isAppend;
            }
            set
            {
                this.isAppend = value;
            }
        }

        #endregion
    }


    /// <summary>
    /// [��������: ҩƷ�������Ϣ]
    /// [�� �� ��: ������]
    /// [����ʱ��: ��������������������]
    /// {CE055DFC-42E4-410d-A93C-3C9EAD38CE7F}���£٣��ףϣӣˣ٣�������
    /// </summary>
    [System.ComponentModel.DisplayName("ҩƷ�������Ϣ")]
    public class Purchase_Price_Info
    {
        #region ��ʵ��
        /// <summary>
        /// ��Ҫ��ҩƷ��Ϣ����������
        /// </summary>
        public Purchase_Price_Info(Item item)
        {
            this.drug = item;
            this.isAll = true;
            this.oper_date = DateTime.Now;
        }
        /// <summary>
        /// ��ҩƷ��Ϣ�����������
        /// </summary>
        /// <param name="drug_code"></param>
        public Purchase_Price_Info(string drug_code)
        {
            this.drug.ID = drug_code;
            this.isAll = false;
            this.oper_date = DateTime.Now;
        }
        #endregion

        #region ����
        private NFC.Management.DataBaseManger dbMgr = new Neusoft.NFC.Management.DataBaseManger();
        private bool isAll = false;
        private Item drug = new Item();
        private string group_code = string.Empty;
        private string batch_no = string.Empty;
        private decimal purchase_price = decimal.Zero;
        private decimal pack_qty = 1M;
        private string oper_code = NFC.Management.Connection.Operator.ID;
        private DateTime oper_date = DateTime.Now;
        private string user01 = string.Empty;
        private string user02 = string.Empty;
        private string user03 = string.Empty;
        private NFC.Object.NeuObject producer = new Neusoft.NFC.Object.NeuObject();
        #endregion

        #region ����
        /// <summary>
        /// ҩƷ������Ϣ
        /// </summary>
        public Item DrugInfo
        {
            get
            {
                return this.drug;
            }
            set
            {
                this.drug = value;
            }
        }

        /// <summary>
        /// ���κ�
        /// </summary>
        public string GroupCode
        {
            get
            {
                return this.group_code;
            }
            set
            {
                this.group_code = value.Trim();
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string BatchNo
        {
            get
            {
                return this.batch_no;
            }
            set
            {
                this.batch_no = value.Trim();
            }
        }

        /// <summary>
        /// �����
        /// </summary>
        public decimal PurchasePrice
        {
            get
            {
                return this.purchase_price;
            }
            set
            {
                this.purchase_price = value;
            }
        }

        /// <summary>
        /// ����������Ϣ
        /// </summary>
        public NFC.Object.NeuObject Producer
        {
            get
            {
                return this.producer;
            }
            set
            {
                this.producer = value;
            }
        }

        /// <summary>
        /// ��װ����
        /// </summary>
        public decimal PackQty
        {
            get
            {
                return this.pack_qty;
            }
            set
            {
                this.pack_qty = value;
            }
        }

        /// <summary>
        /// ����Ա
        /// </summary>
        public string OperCode
        {
            get
            {
                return this.oper_code;
            }
            set
            {
                this.oper_code = value.Trim();
            }
        }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime OperDate
        {
            get
            {
                return this.oper_date;
            }
            set
            {
                this.oper_date = value;
            }
        }

        /// <summary>
        /// ��־λ
        /// </summary>
        public string User01
        {
            get
            {
                return this.user01;
            }
            set
            {
                this.user01 = value.Trim();
            }
        }

        /// <summary>
        /// ��־λ
        /// </summary>
        public string User02
        {
            get
            {
                return this.user02;
            }
            set
            {
                this.user02 = value.Trim();
            }
        }

        /// <summary>
        /// ��־λ
        /// </summary>
        public string User03
        {
            get
            {
                return this.user03;
            }
            set
            {
                this.user03 = value.Trim();
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��ʾ
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "[" + this.drug.ID + "]" + drug.Name + "(" + this.group_code + "/" + this.batch_no + "->" + this.purchase_price.ToString("f4") + ")";
        }
        /// <summary>
        /// �ж�
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            Purchase_Price_Info xObj = obj as Purchase_Price_Info;
            if (xObj.DrugInfo.ID == this.drug.ID && xObj.GroupCode == this.group_code && xObj.BatchNo == this.batch_no && xObj.PurchasePrice == this.purchase_price)
            {
                return true;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        public new Purchase_Price_Info Clone()
        {
            Purchase_Price_Info pInfo;
            if (this.isAll)
            {
                pInfo = new Purchase_Price_Info(this.drug);
            }
            else
            {
                pInfo = new Purchase_Price_Info(this.drug.ID);
            }
            pInfo.BatchNo = this.batch_no;
            pInfo.GroupCode = this.group_code;
            pInfo.PackQty = this.pack_qty;
            pInfo.PurchasePrice = this.purchase_price;
            return pInfo;
        }
        #endregion
    }
}