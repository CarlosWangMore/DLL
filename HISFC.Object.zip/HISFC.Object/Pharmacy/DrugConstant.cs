using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Pharmacy
{
    /// <summary>
    /// [��������: ҩƷ����������]<br></br>
    /// [�� �� ��: liangjz]<br></br>
    /// [����ʱ��: 2008-01]<br></br>
    /// </summary>
    public class DrugConstant : Neusoft.NFC.Object.NeuObject,Neusoft.HISFC.Object.Base.IValid
    {
        public DrugConstant()
        {

        }

        #region �����

        /// <summary>
        /// �������
        /// </summary>
        private string consType;

        /// <summary>
        /// ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject dept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ҩƷ���
        /// </summary>
        private string drugType;

        /// <summary>
        /// ����Ȩ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject class2Priv = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����Ȩ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject class3Priv = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ������Ŀ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject item = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return oper;
            }
            set
            {
                oper = value;
            }
        }

        /// <summary>
        /// ������Ŀ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Item
        {
            get
            {
                return item;
            }
            set
            {
                item = value;
            }
        }

        /// <summary>
        /// ����Ȩ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Class3Priv
        {
            get
            {
                return class3Priv;
            }
            set
            {
                class3Priv = value;
            }
        }

        /// <summary>
        /// ����Ȩ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Class2Priv
        {
            get
            {
                return class2Priv;
            }
            set
            {
                class2Priv = value;
            }
        }

        /// <summary>
        /// ҩƷ���
        /// </summary>
        public string DrugType
        {
            get
            {
                return drugType;
            }
            set
            {
                drugType = value;
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Dept
        {
            get
            {
                return dept;
            }
            set
            {
                dept = value;
            }
        }

        /// <summary>
        /// �������
        /// </summary>
        public string ConsType
        {
            get
            {
                return consType;
            }
            set
            {
                consType = value;
            }
        }

        #endregion

        #region IValid ��Ա

        /// <summary>
        /// ��Ч��
        /// </summary>
        private bool isValid = true;

        /// <summary>
        /// ��Ч��
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.isValid;
            }
            set
            {
                this.isValid = value;
            }
        }

        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new DrugConstant Clone()
        {
            DrugConstant info = base.Clone() as DrugConstant;

            info.oper = this.oper.Clone();
            info.item = this.item.Clone();
            info.class2Priv = this.class2Priv.Clone();
            info.class3Priv = this.class3Priv.Clone();
            info.dept = this.dept.Clone();

            return info;
        }

        #endregion
    }
}
