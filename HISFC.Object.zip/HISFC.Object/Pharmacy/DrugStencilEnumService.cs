using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Neusoft.HISFC.Object.Pharmacy
{
    public class DrugStencilEnumService : Neusoft.NFC.Object.NeuObject
    {
        static DrugStencilEnumService()
		{
            items[EnumDrugStencil.Check.ToString()] = "�̵�";
            items[EnumDrugStencil.Plan.ToString()] = "�ƻ�";
            items[EnumDrugStencil.Apply.ToString()] = "����";
            items[EnumDrugStencil.Used.ToString()] = "����"; //{670EE382-C26A-4251-BFA5-F165CC1B435C}
		}

        private EnumDrugStencil enumDrugStencil;

		 protected static System.Collections.Hashtable items = new System.Collections.Hashtable();

		protected  System.Collections.Hashtable Items
		{
			get 
			{
				return items;
			}
		}


		protected  Enum EnumItem
		{
			get 
			{
				return enumDrugStencil;
			}
		}


		public new string ID
		{
			get
			{
				if (base.ID == null)
					return string.Empty;
				else
					return base.ID;
			}
			set
			{
				if (value == null)
				{
					base.ID = "";
					base.Name = "";
					return;
				}
				base.ID = value.ToString();
                System.Enum enumTemp = (EnumDrugStencil)Enum.Parse(this.enumDrugStencil.GetType(), base.ID);
				if (items.ContainsKey(base.ID))
                    this.Name = items[base.ID].ToString();
				else
					this.Name = "";
			}
		}

		/// <summary>
		/// �õ���Ŀ�����б�����
		/// </summary>
		/// <param name="items">Enum�ֵ�</param>
		/// <returns>neuObject[]</returns>
		protected static Neusoft.NFC.Object.NeuObject[] GetObjectItems(Hashtable items)
		{
            Neusoft.NFC.Object.NeuObject[] ret = new Neusoft.NFC.Object.NeuObject[items.Count];
			int i=0;
			DictionaryEntry de;
			IEnumerator en = items.GetEnumerator();
			while(en.MoveNext())
			{
				ret[i] = new Neusoft.NFC.Object.NeuObject();
				de = (DictionaryEntry)en.Current;
				ret[i].ID = (de.Key).ToString();
				ret[i].Name = items[de.Key] as string;
				i++;
			}

			return ret;			
		}


		/// <summary>
		/// �����б�
		/// </summary>
		/// <returns>neuobject����</returns>
		public new static System.Collections.ArrayList List()
		{
			return (new System.Collections.ArrayList(GetObjectItems(items)));
		}
    }

    public enum EnumDrugStencil
    {
        /// <summary>
        /// �̵�
        /// </summary>
        Check,
        /// <summary>
        /// �ƻ�
        /// </summary>
        Plan,
        /// <summary>
        /// ����
        /// </summary>
        Apply,
        /// <summary>
        /// ���� {670EE382-C26A-4251-BFA5-F165CC1B435C}
        /// </summary>
        Used
    }
}
