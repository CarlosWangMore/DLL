using System;

namespace Neusoft.HISFC.Object.Nurse
{
    /// <summary>
    /// Inject<br></br>
    /// [��������: ע��ʵ��]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2006-09-01]<br></br>
    /// <�޸ļ�¼
    ///		�޸���='��ΰ��'
    ///		�޸�ʱ��='2007-02-07'
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class Inject : Neusoft.NFC.Object.NeuObject
    {

        #region ����

        /// <summary>
        /// ע��˳��
        /// </summary>
        private System.String orderNO = "";

        /// <summary>
        /// �Ƿ�Ƥ��
        /// </summary>
        private System.String hypotest = "";

        /// <summary>
        /// ִ��ʱ��
        /// </summary>
        private System.DateTime execTime = System.DateTime.MinValue;

        /// <summary>
        /// ��ҩʱ��
        /// </summary>
        private System.DateTime mixTime = System.DateTime.MinValue;
        /// <summary>
        /// ע��ʱ��
        /// </summary>
        private System.DateTime injectTime = System.DateTime.MinValue;

        /// <summary>
        /// ����
        /// </summary>
        private System.Int32 injectSpeed = 0;
        /// <summary>
        /// ����ʱ��
        /// </summary>
        private System.DateTime endTime = System.DateTime.MinValue;
        /// <summary>
        /// ������ʱ��
        /// </summary>
        private System.DateTime sendemcTime = System.DateTime.MinValue;

        /// <summary>
        /// ע����˳��
        /// </summary>
        private System.String injectOrder = "";

        /// <summary>
        /// ���߷�����Ŀ��Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Fee.Outpatient.FeeItemList item = new Neusoft.HISFC.Object.Fee.Outpatient.FeeItemList();

        /// <summary>
        /// ��ҩ����Ϣ36.37
        /// </summary>
        private Neusoft.NFC.Object.NeuObject mixOperInfo = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ע������Ϣ39.40
        /// </summary>
        private Neusoft.NFC.Object.NeuObject injectOperInfo = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��������Ϣ47
        /// </summary>
        private Neusoft.NFC.Object.NeuObject stopOper = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Registration.Register patient = new Neusoft.HISFC.Object.Registration.Register();

        /// <summary>
        /// �Ǽǲ�������
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment booker = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// �Ǽǲ�������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Booker
        {
            get
            {
                return this.booker;
            }
            set
            {
                this.booker = value;
            }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Registration.Register Patient
        {
            get
            {
                return this.patient;
            }
            set
            {
                this.patient = value;
            }
        }

        /// <summary>
        /// ���߷�����Ŀ��Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Fee.Outpatient.FeeItemList Item
        {
            get
            {
                return this.item;
            }
            set
            {
                this.item = value;
            }
        }

        /// <summary>
        /// ��ҩ����Ϣ36.37
        /// </summary>
        public Neusoft.NFC.Object.NeuObject MixOperInfo
        {
            get
            {
                return this.mixOperInfo;
            }
            set
            {
                this.mixOperInfo = value;
            }
        }

        /// <summary>
        /// ÿ��˳���2
        /// </summary>
        public System.String OrderNO
        {
            get
            {
                return this.orderNO;
            }
            set
            {
                this.orderNO = value;
            }
        }

        /// <summary>
        /// �Ƿ�Ƥ��26
        /// </summary>
        public System.String Hypotest
        {
            get
            {
                return this.hypotest;
            }
            set
            {
                this.hypotest = value;
            }
        }

        //{0C880D11-40B2-4e6d-A8D6-9D26DE0A21DC}
        private string _HypotestBack;
        /// <summary>
        /// Ƥ�Խ��
        /// </summary>
        public string HypotestBack
        {
            get { return _HypotestBack; }
            set { _HypotestBack = value; }
        }
        //end {0C880D11-40B2-4e6d-A8D6-9D26DE0A21DC}

        /// <summary>
        /// ִ������33
        /// </summary>
        public System.DateTime ExecTime
        {
            get
            {
                return this.execTime;
            }
            set
            {
                this.execTime = value;
            }
        }

        /// <summary>
        /// ��ҩʱ��38
        /// </summary>
        public System.DateTime MixTime
        {
            get
            {
                return this.mixTime;
            }
            set
            {
                this.mixTime = value;
            }
        }

        /// <summary>
        /// ע������Ϣ39.40
        /// </summary>
        public Neusoft.NFC.Object.NeuObject InjectOperInfo
        {
            get
            {
                return this.injectOperInfo;
            }
            set
            {
                this.injectOperInfo = value;
            }
        }

        /// <summary>
        /// ע��ʱ��
        /// </summary>
        public DateTime InjectTime
        {
            get
            {
                return this.injectTime;
            }
            set
            {
                this.injectTime = value;
            }
        }

        /// <summary>
        /// ����42
        /// </summary>
        public System.Int32 InjectSpeed
        {
            get
            {
                return this.injectSpeed;
            }
            set
            {
                this.injectSpeed = value;
            }
        }

        /// <summary>
        /// ����ʱ��43
        /// </summary>
        public System.DateTime EndTime
        {
            get
            {
                return this.endTime;
            }
            set
            {
                this.endTime = value;
            }
        }

        /// <summary>
        /// �ͼ���ʱ��44
        /// </summary>
        public System.DateTime SendemcTime
        {
            get
            {
                return this.sendemcTime;
            }
            set
            {
                this.sendemcTime = value;
            }
        }


        /// <summary>
        /// ������ע��˳���46
        /// </summary>
        public System.String InjectOrder
        {
            get
            {
                return this.injectOrder;
            }
            set
            {
                this.injectOrder = value;
            }
        }

        /// <summary>
        /// ��������Ϣ47
        /// </summary>
        public Neusoft.NFC.Object.NeuObject StopOper
        {
            get
            {
                return this.stopOper;
            }
            set
            {
                this.stopOper = value;
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns></returns>
        public new Inject Clone()
        {
            Inject inject = base.Clone() as Inject;
            inject.item = this.item.Clone();
            inject.mixOperInfo = this.mixOperInfo.Clone();
            inject.injectOperInfo = this.injectOperInfo.Clone();
            inject.stopOper = this.stopOper.Clone();
            inject.patient = this.patient.Clone();
            inject.booker = this.booker.Clone();
            return inject;
        }
        #endregion

        #region ���ڵ�

        /// <summary>
        /// ��ע
        /// </summary>
        //private System.String myRemark = "";
        /// <summary>
        /// ע��ΨһID��
        /// </summary>
        //private System.String myID = "";
        /// <summary>
        /// ��������
        /// </summary>
        //private System.String patientName = "";	
        /// <summary>
        /// �Ա�
        /// </summary>
        //private System.String mySexCode = "";
        /// <summary>
        /// ����
        /// </summary>
        //private System.DateTime myBirthday = System.DateTime.MinValue;	
        /// <summary>
        /// �Ǽ���
        /// </summary>
        //private System.String myBookerID = "";
        /// <summary>
        /// �Ǽ�ʱ��
        /// </summary>
        //private System.DateTime myRegisterDate = System.DateTime.MinValue;


        /// <summary>
        /// ��������5
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����Register��ĳ�Ա", true)]
        public System.String PatientName
        {
            get
            {
                return null;
            }
            set
            {
            }
        }

        /// <summary>
        /// �Ա�6
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����Register��ĳ�Ա", true)]
        public System.String SexCode
        {
            get
            {
                return null;
            }
            set
            {
            }
        }

        /// <summary>
        /// ��������7
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����Register��ĳ�Ա", true)]
        public System.DateTime Birthday
        {
            get
            {
                return DateTime.MinValue;
            }
            set
            {
            }
        }
        /// <summary>
        /// ��ע45
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�ñ�����Memo�ֶ�", true)]
        public System.String Remark
        {
            get
            {
                return null;
            }
            set
            {
            }
        }
        /// <summary>
        /// ע��ʱ��41
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����InjectTime", true)]
        public System.DateTime InjectDate
        {
            get
            {
                return this.injectTime;
            }
            set
            {
                this.injectTime = value;
            }
        }
        /// <summary>
        /// �Ǽ���34
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����OperEnvironment��Name��Ա", true)]
        public System.String BookerID
        {
            get
            {
                return null;
            }
            set
            {
            }
        }

        /// <summary>
        /// �Ǽ�ʱ��35
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����OperEnvironment��OperTime��Ա", true)]
        public System.DateTime RegisterDate
        {
            get
            {
                return DateTime.MinValue;
            }
            set
            {
            }
        }
        /// <summary>
        /// ��ˮ��1
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("�ñ���ID����", true)]
        public System.String Id
        {
            get
            {
                return null;
            }
            set
            {
            }
        }
        #endregion

    }
}
