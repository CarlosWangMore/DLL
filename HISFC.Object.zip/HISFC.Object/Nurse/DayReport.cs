using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Nurse
{
    public class DayReport : Neusoft.NFC.Object.NeuObject
    {
        public DayReport()
        {

        }

        #region ����
        /// <summary>
        /// �����
        /// </summary>
        private string cardNo;


        /// <summary>
        /// �Ƿ񹬾���
        /// </summary>
        private bool gj_info;


        /// <summary>
        /// �Ƿ񸽼���
        /// </summary>
        private bool fj_info;
        
        /// <summary>
        /// �Ƿ��ӹ���Ĥ��
        /// </summary>
        private bool zgnm_info;

        /// <summary>
        /// ���а���
        /// </summary>
        private bool yxbk_info;

        /// <summary>
        /// ��
        /// </summary>
        private bool d_info;

        /// <summary>
        /// ��
        /// </summary>
        private bool n_info;

        /// <summary>
        /// ������
        /// </summary>
        private bool ln_info;

        /// <summary>
        /// ����Ϣ��
        /// </summary>
        private bool gjxr_info;

        /// <summary>
        /// �ӹ�����
        /// </summary>
        private bool zgjl_info;

        /// <summary>
        /// �ӹ���Ĥ��λ
        /// </summary>
        private bool zgnmyw_info;

        /// <summary>
        /// ��Ѫ
        /// </summary>
        private bool gx_info;

        /// <summary>
        /// �������ۺ�
        /// </summary>
        private bool gnqzh_info;

        /// <summary>
        /// �Ƿ�����
        /// </summary>
        private bool gwy_info;

        /// <summary>
        /// ����Ѫѹ
        /// </summary>
        private bool czxy_info;

        /// <summary>
        /// ����
        /// </summary>
        private bool fz_info;

        /// <summary>
        /// ����
        /// </summary>
        private bool qt;

        /// <summary>
        /// ��չ���1
        /// </summary>
        private bool exct_flag1;

        /// <summary>
        /// ��չ���2
        /// </summary>
        private bool exct_flag2;

        #endregion

        #region ����

        /// <summary>
        /// �����
        /// </summary>
        public string CardNo
        {
            get { return cardNo; }
            set { cardNo = value; }
        }

        /// <summary>
        /// �Ƿ񹬾���
        /// </summary>
        public bool Gj_info
        {
            get { return gj_info; }
            set { gj_info = value; }
        }
        /// <summary>
        /// �Ƿ񸽼���
        /// </summary>
        public bool Fj_info
        {
            get { return fj_info; }
            set { fj_info = value; }
        }
        /// <summary>
        /// �Ƿ��ӹ���Ĥ��
        /// </summary>
        public bool Zgnm_info
        {
            get { return zgnm_info; }
            set { zgnm_info = value; }
        }

        /// <summary>
        /// �Ƿ����а���
        /// </summary>
        public bool Yxbk_info
        {
            get { return yxbk_info; }
            set { yxbk_info = value; }
        }

        /// <summary>
        /// �Ƿ��
        /// </summary>
        public bool D_info
        {
            get { return d_info; }
            set { d_info = value; }
        }

        /// <summary>
        /// �Ƿ���
        /// </summary>
        public bool N_info
        {
            get { return n_info; }
            set { n_info = value; }
        }
        /// <summary>
        /// �Ƿ�������
        /// </summary>
        public bool Ln_info
        {
            get { return ln_info; }
            set { ln_info = value; }
        }

        /// <summary>
        ///�Ƿ񹬾�Ϣ��
        /// </summary>
        public bool Gjxr_info
        {
            get { return gjxr_info; }
            set { gjxr_info = value; }
        }

        /// <summary>
        /// �ӹ�����
        /// </summary>
        public bool Zgjl_info
        {
            get { return zgjl_info; }
            set { zgjl_info = value; }
        }

        /// <summary>
        /// �ӹ���Ļ��λ
        /// </summary>
        public bool Zgnmyw_info
        {
            get { return zgnmyw_info; }
            set { zgnmyw_info = value; }
        }

        /// <summary>
        /// �Ƿ�Ѫ
        /// </summary>
        public bool Gx_info
        {
            get { return gx_info; }
            set { gx_info = value; }
        }

        /// <summary>
        /// �Ƿ�������ۺ�֢
        /// </summary>
        public bool Gnqzh_info
        {
            get { return gnqzh_info; }
            set { gnqzh_info = value; }
        }

        /// <summary>
        /// �Ƿ�����
        /// </summary>
        public bool Gwy_info
        {
            get { return gwy_info; }
            set { gwy_info = value; }
        }
        /// <summary>
        /// ����Ѫѹ
        /// </summary>
        public bool Czxy_info
        {
            get { return czxy_info; }
            set { czxy_info = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public bool Fz_info
        {
            get { return fz_info; }
            set { fz_info = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public bool Qt
        {
            get { return qt; }
            set { qt = value; }
        }
        /// <summary>
        /// ��չ���1
        /// </summary>
        public bool Exct_flag1
        {
            get { return exct_flag1; }
            set { exct_flag1 = value; }
        }

        /// <summary>
        /// ��չ���2
        /// </summary>
        public bool Exct_flag2
        {
            get { return exct_flag2; }
            set { exct_flag2 = value; }
        }
        #endregion

        #region ����

        public new DayReport Clone()
        {
            DayReport obj = base.Clone() as DayReport;
            return obj;
        }
        #endregion


    }
}
