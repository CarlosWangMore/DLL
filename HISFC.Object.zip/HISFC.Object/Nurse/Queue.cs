using System;

namespace Neusoft.HISFC.Object.Nurse
{
	/// <summary>
	/// Queue<br></br>
	/// [��������: �������ʵ��]<br></br>
	/// [�� �� ��: ������]<br></br>
	/// [����ʱ��: 2006-09-01]<br></br>
	/// <�޸ļ�¼
    ///		�޸���='��ΰ��'
	///		�޸�ʱ��='2007-02-07'
	///		�޸�Ŀ��='�����ֶ�,ԭ���Ĳ���'
	///		�޸�����=''
	///  />
	/// </summary>
	public class Queue:Neusoft.NFC.Object.NeuObject
    {
        #region ˽�г�Ա

        /// <summary>
        /// ��������
        /// </summary>
        private DateTime queueTime = DateTime.MinValue;


        /// <summary>
        /// ��ʾ˳��
        /// </summary>
        private int order = 0;


        /// <summary>
        /// �Ƿ���Ч
        /// </summary>
        private bool isValid = false;

        /// <summary>
        /// �����к�������
        /// </summary>
        private int waitingCount = 0;

        /// <summary>
        /// ר�Ҷ��б�־
        /// </summary>
        private string expertFlag = "";

        /// <summary>
        /// ��̨��Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject console = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ���������Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject assignDept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// �������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject noon = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject dept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject room = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����ҽ�� ID, Name, Memo
        /// </summary>
        private Neusoft.NFC.Object.NeuObject doctor = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��������
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }
        /// <summary>
        /// ����ҽ��
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Doctor
        {
            get
            {
                return this.doctor;
            }
            set
            {
                this.doctor = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public DateTime QueueDate
        {
            get
            {
                return this.queueTime;
            }
            set
            {
                this.queueTime = value;
            }
        }
        /// <summary>
        /// �������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Noon
        {
            get
            {
                return this.noon;
            }
            set
            {
                this.noon = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Dept
        {
            get
            {
                return this.dept;
            }
            set
            {
                this.dept = value;
            }
        }
        /// <summary>
        /// ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject SRoom
        {
            get
            {
                return this.room;
            }
            set
            {
                this.room = value;
            }
        }
        /// <summary>
        /// ��ʾ˳��
        /// </summary>
        public int Order
        {
            get
            {
                return this.order;
            }
            set
            {
                this.order = value;
            }
        }
        /// <summary>
        /// �Ƿ���Ч
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.isValid;
            }
            set
            {
                this.isValid = value;
            }
        }


        /// <summary>
        /// ��̨��Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Console
        {
            get
            {
                return this.console;
            }
            set
            {
                this.console = value;
            }
        }
        /// <summary>
        /// ר�Ҷ��б�־
        /// </summary>
        public string ExpertFlag
        {
            get
            {
                return this.expertFlag;
            }
            set
            {
                this.expertFlag = value;
            }
        }
        /// <summary>
        /// ���������Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject AssignDept
        {
            get
            {
                return this.assignDept;
            }
            set
            {
                this.assignDept = value;
            }
        }
        /// <summary>
        /// �����к�������
        /// </summary>
        public int WaitingCount
        {
            get
            {
                return this.waitingCount;
            }
            set
            {
                this.waitingCount = value;
            }
        }


        #endregion

        #region ����

        /// <summary>
        /// ����Ա����
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ʹ��Oper.ID", true)]
        public string OperID
        {
            get
            {
                return this.operID;
            }
            set
            {
                this.operID = value;
            }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("ʹ��Oper.OperTime", true)]
        public DateTime OperDate
        {
            get
            {
                return this.operDate;
            }
            set
            {
                this.operDate = value;
            }
        }

        /// <summary>
        /// ����Ա����
        /// </summary>
        private string operID = "";

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime operDate = DateTime.MinValue;
        #endregion

        #region ����
        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns></returns>
        public new Queue Clone()
        {
            Queue queue = base.Clone() as Queue;
            queue.console = this.console.Clone();
            queue.assignDept = this.assignDept.Clone();
            queue.noon = this.noon.Clone();
            queue.dept = this.dept.Clone();
            queue.room = this.room.Clone();
            queue.doctor = this.doctor.Clone();
            queue.oper = this.oper.Clone();

            return queue;
        }
        #endregion
    }
}