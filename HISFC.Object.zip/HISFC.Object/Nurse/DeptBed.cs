using System;
using System.Collections;

using Neusoft.NFC.Object;
using Neusoft.HISFC.Object.Base;

namespace Neusoft.HISFC.Object.Fee
{
	/// <summary>
    /// DeptBed<br></br>
	/// [��������:���Ҵ�λ��<br></br>
	/// <�޸ļ�¼
	///		�޸���=''
	///		�޸�ʱ��='yyyy-mm-dd'
	///		�޸�Ŀ��=''
	///		�޸�����=''
	///  />
	/// </summary>
	public class DeptBed : NeuObject
    {
        #region ����
        private string nurse_cell_code = "";
        private string dept_code = "";
        private string dept_name = "";
        private int bed_num = 0;
        private string dk_name = "";
        private string valid_state = "";
        private string oper_code = "";
        private DateTime oper_date = System.DateTime.MinValue;
        #endregion

        #region ����
        public string Nurse_cell_code
        {
            get { return nurse_cell_code; }
            set { nurse_cell_code = value; }
        }
        public string Dept_code
        {
            get { return dept_code; }
            set { dept_code = value; }
        }
        public string Dept_name
        {
            get { return dept_name; }
            set { dept_name = value; }
        }
        public int Bed_num
        {
            get { return bed_num; }
            set { bed_num = value; }
        }
        public string Dk_name
        {
            get { return dk_name; }
            set { dk_name = value; }
        }
        public string Valid_state
        {
            get { return valid_state; }
            set { valid_state = value; }
        }
        public string Oper_code
        {
            get { return oper_code; }
            set { oper_code = value; }
        }
        public DateTime Oper_date
        {
            get { return oper_date; }
            set { oper_date = value; }
        }
        #endregion
    }
}
