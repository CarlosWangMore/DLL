using System;
using System.Collections.Generic;
using Neusoft.NFC.Attribute;
using Neusoft.NFC.Management;

namespace Neusoft.HISFC.Object.SIInterface
{
    /// <summary>
    /// SIReturn<para></para>
    /// [��������: ]<para></para>
    /// [�� �� ��: ]<para></para>
    /// User01�����洢������ĩ���¾�ʱ��
    /// [����ʱ��: 2013-05-16 10:39]<para></para>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  /><para></para>
    /// </summary>
    public class SIReturn : Neusoft.NFC.Management.NeuObjectExtra
    {
        /// <summary>
        /// һ�㹹�캯��
        /// </summary>
        public SIReturn()
        {
            objectStatus = ObjectStatus.New;
        }

        /// <summary>
        /// ����һ��ʵ������¡����ʵ��
        /// </summary>
        public SIReturn(SIReturn argObj)
            : base(argObj)
        {
        }

        #region ����

        #endregion

        #region ����
        /// <summary>
        /// ���ݿ����
        /// </summary>
        public override string TableName
        {
            get { return "FIN_SI_RETURN"; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string ID
        {
            get { return base.ID; }
            set { base.ID = value; }
        }

        private int finType;
        /// <summary>
        /// ��������(1�Һ� 2�����շ� 3סԺ�Ǽ� 4סԺ����)
        /// </summary>
        [DataFieldName("FIN_TYPE")]
        public int FinType
        {
            get { return finType; }
            set
            {
                if (!object.Equals(finType, value))
                {
                    if (!modifiedProperty.ContainsKey("FinType"))
                    {
                        modifiedProperty.Add("FinType", finType);
                        this.IsModified = true;
                    }
                    finType = value;
                }
            }
        }

        private string pactCode;
        /// <summary>
        /// ��ͬ��λ����
        /// </summary>
        [DataFieldName("PACT_CODE"), DataFieldDefault("")]
        public string PactCode
        {
            get { return pactCode; }
            set
            {
                if (!object.Equals(pactCode, value))
                {
                    if (!modifiedProperty.ContainsKey("PactCode"))
                    {
                        modifiedProperty.Add("PactCode", pactCode);
                        this.IsModified = true;
                    }
                    pactCode = value;
                }
            }
        }

        /// <summary>
        /// �Һű�(clinic_code)������ˮ��;��������(invoice_seq)��Ʊ��ˮ��;סԺ�ǼǱ�(inpation_no)סԺ��ˮ�ţ�סԺ����ͷ��(invoice_no)��Ʊ����
        /// </summary>
        [DataFieldName("CODE_SEQ"), DataFieldDefault("")]
        public string CodeSeq
        {
            get { return base.ID; }
            set
            {
                if (!object.Equals(base.ID, value))
                {
                    if (!modifiedProperty.ContainsKey("CodeSeq"))
                    {
                        modifiedProperty.Add("CodeSeq", base.ID);
                        this.IsModified = true;
                    }
                    base.ID = value;
                }
            }
        }

        private int transType;
        /// <summary>
        /// ��������,1�����ף�2������
        /// </summary>
        [DataFieldName("TRANS_TYPE")]
        public int TransType
        {
            get { return transType; }
            set
            {
                if (!object.Equals(transType, value))
                {
                    if (!modifiedProperty.ContainsKey("TransType"))
                    {
                        modifiedProperty.Add("TransType", transType);
                        this.IsModified = true;
                    }
                    transType = value;
                }
            }
        }

        private string patientno;
        /// <summary>
        /// ������ˮ��/סԺ��ˮ��
        /// </summary>
        [DataFieldName("PATIENTNO"), DataFieldDefault("")]
        public string Patientno
        {
            get { return patientno; }
            set
            {
                if (!object.Equals(patientno, value))
                {
                    if (!modifiedProperty.ContainsKey("Patientno"))
                    {
                        modifiedProperty.Add("Patientno", patientno);
                        this.IsModified = true;
                    }
                    patientno = value;
                }
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        [DataFieldName("NAME"), DataFieldDefault("")]
        public string Name
        {
            get { return base.Name; }
            set
            {
                if (!object.Equals(base.Name, value))
                {
                    if (!modifiedProperty.ContainsKey("Name"))
                    {
                        modifiedProperty.Add("Name", base.Name);
                        this.IsModified = true;
                    }
                    base.Name = value;
                }
            }
        }

        private string cardNum;
        /// <summary>
        /// ҽ������
        /// </summary>
        [DataFieldName("CARD_NUM"), DataFieldDefault("")]
        public string CardNum
        {
            get { return cardNum; }
            set
            {
                if (!object.Equals(cardNum, value))
                {
                    if (!modifiedProperty.ContainsKey("CardNum"))
                    {
                        modifiedProperty.Add("CardNum", cardNum);
                        this.IsModified = true;
                    }
                    cardNum = value;
                }
            }
        }

        private string cardData;
        /// <summary>
        /// ��������
        /// </summary>
        [DataFieldName("CARD_DATA"), DataFieldDefault("")]
        public string CardData
        {
            get { return cardData; }
            set
            {
                if (!object.Equals(cardData, value))
                {
                    if (!modifiedProperty.ContainsKey("CardData"))
                    {
                        modifiedProperty.Add("CardData", cardData);
                        this.IsModified = true;
                    }
                    cardData = value;
                }
            }
        }

        private DateTime operDate;
        /// <summary>
        /// OPER_DATE
        /// </summary>
        [DataFieldName("OPER_DATE"), DataFieldInsertAbort(true)]
        public DateTime OperDate
        {
            get { return operDate; }
            set
            {
                if (!object.Equals(operDate, value))
                {
                    if (!modifiedProperty.ContainsKey("OperDate"))
                    {
                        modifiedProperty.Add("OperDate", operDate);
                        this.IsModified = true;
                    }
                    operDate = value;
                }
            }
        }

        private string medicalType;
        /// <summary>
        /// ҽ�����
        /// </summary>
        [DataFieldName("MEDICAL_TYPE"), DataFieldDefault("")]
        public string MedicalType
        {
            get { return medicalType; }
            set
            {
                if (!object.Equals(medicalType, value))
                {
                    if (!modifiedProperty.ContainsKey("MedicalType"))
                    {
                        modifiedProperty.Add("MedicalType", medicalType);
                        this.IsModified = true;
                    }
                    medicalType = value;
                }
            }
        }

        private decimal totCost;
        /// <summary>
        /// TOT_COST
        /// </summary>
        [DataFieldName("TOT_COST")]
        public decimal TotCost
        {
            get { return totCost; }
            set
            {
                if (!object.Equals(totCost, value))
                {
                    if (!modifiedProperty.ContainsKey("TotCost"))
                    {
                        modifiedProperty.Add("TotCost", totCost);
                        this.IsModified = true;
                    }
                    totCost = value;
                }
            }
        }

        private decimal payCost;
        /// <summary>
        /// PAY_COST
        /// </summary>
        [DataFieldName("PAY_COST")]
        public decimal PayCost
        {
            get { return payCost; }
            set
            {
                if (!object.Equals(payCost, value))
                {
                    if (!modifiedProperty.ContainsKey("PayCost"))
                    {
                        modifiedProperty.Add("PayCost", payCost);
                        this.IsModified = true;
                    }
                    payCost = value;
                }
            }
        }

        private decimal pubCost;
        /// <summary>
        /// PUB_COST
        /// </summary>
        [DataFieldName("PUB_COST")]
        public decimal PubCost
        {
            get { return pubCost; }
            set
            {
                if (!object.Equals(pubCost, value))
                {
                    if (!modifiedProperty.ContainsKey("PubCost"))
                    {
                        modifiedProperty.Add("PubCost", pubCost);
                        this.IsModified = true;
                    }
                    pubCost = value;
                }
            }
        }

        private decimal ownCost;
        /// <summary>
        /// OWN_COST
        /// </summary>
        [DataFieldName("OWN_COST")]
        public decimal OwnCost
        {
            get { return ownCost; }
            set
            {
                if (!object.Equals(ownCost, value))
                {
                    if (!modifiedProperty.ContainsKey("OwnCost"))
                    {
                        modifiedProperty.Add("OwnCost", ownCost);
                        this.IsModified = true;
                    }
                    ownCost = value;
                }
            }
        }

        private decimal accountBalance;
        /// <summary>
        /// ���
        /// </summary>
        [DataFieldName("ACCOUNT_BALANCE")]
        public decimal AccountBalance
        {
            get { return accountBalance; }
            set
            {
                if (!object.Equals(accountBalance, value))
                {
                    if (!modifiedProperty.ContainsKey("AccountBalance"))
                    {
                        modifiedProperty.Add("AccountBalance", accountBalance);
                        this.IsModified = true;
                    }
                    accountBalance = value;
                }
            }
        }

        private string info1;
        /// <summary>
        /// ��Ա���(����20)
        /// </summary>
        [DataFieldName("INFO1"), DataFieldDefault("")]
        public string PersonType
        {
            get { return info1; }
            set
            {
                if (!object.Equals(info1, value))
                {
                    if (!modifiedProperty.ContainsKey("Info1"))
                    {
                        modifiedProperty.Add("Info1", info1);
                        this.IsModified = true;
                    }
                    info1 = value;
                }
            }
        }

        private string info2;
        /// <summary>
        /// ���˱��(����20)
        /// </summary>
        [DataFieldName("INFO2"), DataFieldDefault("")]
        public string PersonID
        {
            get { return info2; }
            set
            {
                if (!object.Equals(info2, value))
                {
                    if (!modifiedProperty.ContainsKey("Info2"))
                    {
                        modifiedProperty.Add("Info2", info2);
                        this.IsModified = true;
                    }
                    info2 = value;
                }
            }
        }

        private string info3;
        /// <summary>
        /// ������Ϣ(����20)
        /// </summary>
        [DataFieldName("INFO3"), DataFieldDefault("")]
        public string Info3
        {
            get { return info3; }
            set
            {
                if (!object.Equals(info3, value))
                {
                    if (!modifiedProperty.ContainsKey("Info3"))
                    {
                        modifiedProperty.Add("Info3", info3);
                        this.IsModified = true;
                    }
                    info3 = value;
                }
            }
        }

        private string info4;
        /// <summary>
        /// ������Ϣ(����20)
        /// </summary>
        [DataFieldName("INFO4"), DataFieldDefault("")]
        public string Info4
        {
            get { return info4; }
            set
            {
                if (!object.Equals(info4, value))
                {
                    if (!modifiedProperty.ContainsKey("Info4"))
                    {
                        modifiedProperty.Add("Info4", info4);
                        this.IsModified = true;
                    }
                    info4 = value;
                }
            }
        }

        private string info5;
        /// <summary>
        /// ������Ϣ(����20)
        /// </summary>
        [DataFieldName("INFO5"), DataFieldDefault("")]
        public string Info5
        {
            get { return info5; }
            set
            {
                if (!object.Equals(info5, value))
                {
                    if (!modifiedProperty.ContainsKey("Info5"))
                    {
                        modifiedProperty.Add("Info5", info5);
                        this.IsModified = true;
                    }
                    info5 = value;
                }
            }
        }

        private string info6;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO6"), DataFieldDefault("")]
        public string Info6
        {
            get { return info6; }
            set
            {
                if (!object.Equals(info6, value))
                {
                    if (!modifiedProperty.ContainsKey("Info6"))
                    {
                        modifiedProperty.Add("Info6", info6);
                        this.IsModified = true;
                    }
                    info6 = value;
                }
            }
        }

        private string info7;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO7"), DataFieldDefault("")]
        public string Info7
        {
            get { return info7; }
            set
            {
                if (!object.Equals(info7, value))
                {
                    if (!modifiedProperty.ContainsKey("Info7"))
                    {
                        modifiedProperty.Add("Info7", info7);
                        this.IsModified = true;
                    }
                    info7 = value;
                }
            }
        }

        private string info8;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO8"), DataFieldDefault("")]
        public string Info8
        {
            get { return info8; }
            set
            {
                if (!object.Equals(info8, value))
                {
                    if (!modifiedProperty.ContainsKey("Info8"))
                    {
                        modifiedProperty.Add("Info8", info8);
                        this.IsModified = true;
                    }
                    info8 = value;
                }
            }
        }

        private string info9;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO9"), DataFieldDefault("")]
        public string Info9
        {
            get { return info9; }
            set
            {
                if (!object.Equals(info9, value))
                {
                    if (!modifiedProperty.ContainsKey("Info9"))
                    {
                        modifiedProperty.Add("Info9", info9);
                        this.IsModified = true;
                    }
                    info9 = value;
                }
            }
        }

        private string info10;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO10"), DataFieldDefault("")]
        public string Info10
        {
            get { return info10; }
            set
            {
                if (!object.Equals(info10, value))
                {
                    if (!modifiedProperty.ContainsKey("Info10"))
                    {
                        modifiedProperty.Add("Info10", info10);
                        this.IsModified = true;
                    }
                    info10 = value;
                }
            }
        }

        private string info11;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO11"), DataFieldDefault("")]
        public string Info11
        {
            get { return info11; }
            set
            {
                if (!object.Equals(info11, value))
                {
                    if (!modifiedProperty.ContainsKey("Info11"))
                    {
                        modifiedProperty.Add("Info11", info11);
                        this.IsModified = true;
                    }
                    info11 = value;
                }
            }
        }

        private string info12;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO12"), DataFieldDefault("")]
        public string Info12
        {
            get { return info12; }
            set
            {
                if (!object.Equals(info12, value))
                {
                    if (!modifiedProperty.ContainsKey("Info12"))
                    {
                        modifiedProperty.Add("Info12", info12);
                        this.IsModified = true;
                    }
                    info12 = value;
                }
            }
        }

        private string info13;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO13"), DataFieldDefault("")]
        public string Info13
        {
            get { return info13; }
            set
            {
                if (!object.Equals(info13, value))
                {
                    if (!modifiedProperty.ContainsKey("Info13"))
                    {
                        modifiedProperty.Add("Info13", info13);
                        this.IsModified = true;
                    }
                    info13 = value;
                }
            }
        }

        private string info14;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO14"), DataFieldDefault("")]
        public string Info14
        {
            get { return info14; }
            set
            {
                if (!object.Equals(info14, value))
                {
                    if (!modifiedProperty.ContainsKey("Info14"))
                    {
                        modifiedProperty.Add("Info14", info14);
                        this.IsModified = true;
                    }
                    info14 = value;
                }
            }
        }

        private string info15;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO15"), DataFieldDefault("")]
        public string Info15
        {
            get { return info15; }
            set
            {
                if (!object.Equals(info15, value))
                {
                    if (!modifiedProperty.ContainsKey("Info15"))
                    {
                        modifiedProperty.Add("Info15", info15);
                        this.IsModified = true;
                    }
                    info15 = value;
                }
            }
        }

        private string info16;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO16"), DataFieldDefault("")]
        public string Info16
        {
            get { return info16; }
            set
            {
                if (!object.Equals(info16, value))
                {
                    if (!modifiedProperty.ContainsKey("Info16"))
                    {
                        modifiedProperty.Add("Info16", info16);
                        this.IsModified = true;
                    }
                    info16 = value;
                }
            }
        }

        private string info17;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO17"), DataFieldDefault("")]
        public string Info17
        {
            get { return info17; }
            set
            {
                if (!object.Equals(info17, value))
                {
                    if (!modifiedProperty.ContainsKey("Info17"))
                    {
                        modifiedProperty.Add("Info17", info17);
                        this.IsModified = true;
                    }
                    info17 = value;
                }
            }
        }

        private string info18;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO18"), DataFieldDefault("")]
        public string Info18
        {
            get { return info18; }
            set
            {
                if (!object.Equals(info18, value))
                {
                    if (!modifiedProperty.ContainsKey("Info18"))
                    {
                        modifiedProperty.Add("Info18", info18);
                        this.IsModified = true;
                    }
                    info18 = value;
                }
            }
        }

        private string info19;
        /// <summary>
        /// ������Ϣ(����50)
        /// </summary>
        [DataFieldName("INFO19"), DataFieldDefault("")]
        public string Info19
        {
            get { return info19; }
            set
            {
                if (!object.Equals(info19, value))
                {
                    if (!modifiedProperty.ContainsKey("Info19"))
                    {
                        modifiedProperty.Add("Info19", info19);
                        this.IsModified = true;
                    }
                    info19 = value;
                }
            }
        }

        private string info20;
        /// <summary>
        /// INFO20
        /// </summary>
        [DataFieldName("INFO20"), DataFieldDefault("")]
        public string Info20
        {
            get { return info20; }
            set
            {
                if (!object.Equals(info20, value))
                {
                    if (!modifiedProperty.ContainsKey("Info20"))
                    {
                        modifiedProperty.Add("Info20", info20);
                        this.IsModified = true;
                    }
                    info20 = value;
                }
            }
        }

        private string info21;
        /// <summary>
        /// INFO21
        /// </summary>
        [DataFieldName("INFO21"), DataFieldDefault("")]
        public string Info21
        {
            get { return info21; }
            set
            {
                if (!object.Equals(info21, value))
                {
                    if (!modifiedProperty.ContainsKey("Info21"))
                    {
                        modifiedProperty.Add("Info21", info21);
                        this.IsModified = true;
                    }
                    info21 = value;
                }
            }
        }

        private string info22;
        /// <summary>
        /// INFO22
        /// </summary>
        [DataFieldName("INFO22"), DataFieldDefault("")]
        public string Info22
        {
            get { return info22; }
            set
            {
                if (!object.Equals(info22, value))
                {
                    if (!modifiedProperty.ContainsKey("Info22"))
                    {
                        modifiedProperty.Add("Info22", info22);
                        this.IsModified = true;
                    }
                    info22 = value;
                }
            }
        }

        private string info23;
        /// <summary>
        /// INFO23
        /// </summary>
        [DataFieldName("INFO23"), DataFieldDefault("")]
        public string Info23
        {
            get { return info23; }
            set
            {
                if (!object.Equals(info23, value))
                {
                    if (!modifiedProperty.ContainsKey("Info23"))
                    {
                        modifiedProperty.Add("Info23", info23);
                        this.IsModified = true;
                    }
                    info23 = value;
                }
            }
        }

        private string info24;
        /// <summary>
        /// INFO24
        /// </summary>
        [DataFieldName("INFO24"), DataFieldDefault("")]
        public string Info24
        {
            get { return info24; }
            set
            {
                if (!object.Equals(info24, value))
                {
                    if (!modifiedProperty.ContainsKey("Info24"))
                    {
                        modifiedProperty.Add("Info24", info24);
                        this.IsModified = true;
                    }
                    info24 = value;
                }
            }
        }

        private string info25;
        /// <summary>
        /// INFO25
        /// </summary>
        [DataFieldName("INFO25"), DataFieldDefault("")]
        public string Info25
        {
            get { return info25; }
            set
            {
                if (!object.Equals(info25, value))
                {
                    if (!modifiedProperty.ContainsKey("Info25"))
                    {
                        modifiedProperty.Add("Info25", info25);
                        this.IsModified = true;
                    }
                    info25 = value;
                }
            }
        }

        private string info26;
        /// <summary>
        /// INFO26
        /// </summary>
        [DataFieldName("INFO26"), DataFieldDefault("")]
        public string Info26
        {
            get { return info26; }
            set
            {
                if (!object.Equals(info26, value))
                {
                    if (!modifiedProperty.ContainsKey("Info26"))
                    {
                        modifiedProperty.Add("Info26", info26);
                        this.IsModified = true;
                    }
                    info26 = value;
                }
            }
        }

        private string info27;
        /// <summary>
        /// INFO27
        /// </summary>
        [DataFieldName("INFO27"), DataFieldDefault("")]
        public string Info27
        {
            get { return info27; }
            set
            {
                if (!object.Equals(info27, value))
                {
                    if (!modifiedProperty.ContainsKey("Info27"))
                    {
                        modifiedProperty.Add("Info27", info27);
                        this.IsModified = true;
                    }
                    info27 = value;
                }
            }
        }

        private string info28;
        /// <summary>
        /// INFO28
        /// </summary>
        [DataFieldName("INFO28"), DataFieldDefault("")]
        public string Info28
        {
            get { return info28; }
            set
            {
                if (!object.Equals(info28, value))
                {
                    if (!modifiedProperty.ContainsKey("Info28"))
                    {
                        modifiedProperty.Add("Info28", info28);
                        this.IsModified = true;
                    }
                    info28 = value;
                }
            }
        }

        private string info29;
        /// <summary>
        /// INFO29
        /// </summary>
        [DataFieldName("INFO29"), DataFieldDefault("")]
        public string Info29
        {
            get { return info29; }
            set
            {
                if (!object.Equals(info29, value))
                {
                    if (!modifiedProperty.ContainsKey("Info29"))
                    {
                        modifiedProperty.Add("Info29", info29);
                        this.IsModified = true;
                    }
                    info29 = value;
                }
            }
        }

        private string info30;
        /// <summary>
        /// INFO30
        /// </summary>
        [DataFieldName("INFO30"), DataFieldDefault("")]
        public string Info30
        {
            get { return info30; }
            set
            {
                if (!object.Equals(info30, value))
                {
                    if (!modifiedProperty.ContainsKey("Info30"))
                    {
                        modifiedProperty.Add("Info30", info30);
                        this.IsModified = true;
                    }
                    info30 = value;
                }
            }
        }

        private string info31;
        /// <summary>
        /// INFO31
        /// </summary>
        [DataFieldName("INFO31"), DataFieldDefault("")]
        public string Info31
        {
            get { return info31; }
            set
            {
                if (!object.Equals(info31, value))
                {
                    if (!modifiedProperty.ContainsKey("Info31"))
                    {
                        modifiedProperty.Add("Info31", info31);
                        this.IsModified = true;
                    }
                    info31 = value;
                }
            }
        }

        private string info32;
        /// <summary>
        /// INFO32
        /// </summary>
        [DataFieldName("INFO32"), DataFieldDefault("")]
        public string Info32
        {
            get { return info32; }
            set
            {
                if (!object.Equals(info32, value))
                {
                    if (!modifiedProperty.ContainsKey("Info32"))
                    {
                        modifiedProperty.Add("Info32", info32);
                        this.IsModified = true;
                    }
                    info32 = value;
                }
            }
        }

        private string info33;
        /// <summary>
        /// INFO33
        /// </summary>
        [DataFieldName("INFO33"), DataFieldDefault("")]
        public string Info33
        {
            get { return info33; }
            set
            {
                if (!object.Equals(info33, value))
                {
                    if (!modifiedProperty.ContainsKey("Info33"))
                    {
                        modifiedProperty.Add("Info33", info33);
                        this.IsModified = true;
                    }
                    info33 = value;
                }
            }
        }

        private string info34;
        /// <summary>
        /// INFO34
        /// </summary>
        [DataFieldName("INFO34"), DataFieldDefault("")]
        public string Info34
        {
            get { return info34; }
            set
            {
                if (!object.Equals(info34, value))
                {
                    if (!modifiedProperty.ContainsKey("Info34"))
                    {
                        modifiedProperty.Add("Info34", info34);
                        this.IsModified = true;
                    }
                    info34 = value;
                }
            }
        }

        private string info35;
        /// <summary>
        /// INFO35
        /// </summary>
        [DataFieldName("INFO35"), DataFieldDefault("")]
        public string Info35
        {
            get { return info35; }
            set
            {
                if (!object.Equals(info35, value))
                {
                    if (!modifiedProperty.ContainsKey("Info35"))
                    {
                        modifiedProperty.Add("Info35", info35);
                        this.IsModified = true;
                    }
                    info35 = value;
                }
            }
        }

        private string info36;
        /// <summary>
        /// INFO36
        /// </summary>
        [DataFieldName("INFO36"), DataFieldDefault("")]
        public string Info36
        {
            get { return info36; }
            set
            {
                if (!object.Equals(info36, value))
                {
                    if (!modifiedProperty.ContainsKey("Info36"))
                    {
                        modifiedProperty.Add("Info36", info36);
                        this.IsModified = true;
                    }
                    info36 = value;
                }
            }
        }

        private string info37;
        /// <summary>
        /// INFO37
        /// </summary>
        [DataFieldName("INFO37"), DataFieldDefault("")]
        public string Info37
        {
            get { return info37; }
            set
            {
                if (!object.Equals(info37, value))
                {
                    if (!modifiedProperty.ContainsKey("Info37"))
                    {
                        modifiedProperty.Add("Info37", info37);
                        this.IsModified = true;
                    }
                    info37 = value;
                }
            }
        }

        private string info38;
        /// <summary>
        /// INFO38
        /// </summary>
        [DataFieldName("INFO38"), DataFieldDefault("")]
        public string Info38
        {
            get { return info38; }
            set
            {
                if (!object.Equals(info38, value))
                {
                    if (!modifiedProperty.ContainsKey("Info38"))
                    {
                        modifiedProperty.Add("Info38", info38);
                        this.IsModified = true;
                    }
                    info38 = value;
                }
            }
        }

        private string info39;
        /// <summary>
        /// INFO39
        /// </summary>
        [DataFieldName("INFO39"), DataFieldDefault("")]
        public string Info39
        {
            get { return info39; }
            set
            {
                if (!object.Equals(info39, value))
                {
                    if (!modifiedProperty.ContainsKey("Info39"))
                    {
                        modifiedProperty.Add("Info39", info39);
                        this.IsModified = true;
                    }
                    info39 = value;
                }
            }
        }

        private string info40;
        /// <summary>
        /// INFO40
        /// </summary>
        [DataFieldName("INFO40"), DataFieldDefault("")]
        public string Info40
        {
            get { return info40; }
            set
            {
                if (!object.Equals(info40, value))
                {
                    if (!modifiedProperty.ContainsKey("Info40"))
                    {
                        modifiedProperty.Add("Info40", info40);
                        this.IsModified = true;
                    }
                    info40 = value;
                }
            }
        }

        private string info41;
        /// <summary>
        /// INFO41
        /// </summary>
        [DataFieldName("INFO41"), DataFieldDefault("")]
        public string Info41
        {
            get { return info41; }
            set
            {
                if (!object.Equals(info41, value))
                {
                    if (!modifiedProperty.ContainsKey("Info41"))
                    {
                        modifiedProperty.Add("Info41", info41);
                        this.IsModified = true;
                    }
                    info41 = value;
                }
            }
        }

        private string info42;
        /// <summary>
        /// INFO42
        /// </summary>
        [DataFieldName("INFO42"), DataFieldDefault("")]
        public string Info42
        {
            get { return info42; }
            set
            {
                if (!object.Equals(info42, value))
                {
                    if (!modifiedProperty.ContainsKey("Info42"))
                    {
                        modifiedProperty.Add("Info42", info42);
                        this.IsModified = true;
                    }
                    info42 = value;
                }
            }
        }

        private string info43;
        /// <summary>
        /// INFO43
        /// </summary>
        [DataFieldName("INFO43"), DataFieldDefault("")]
        public string Info43
        {
            get { return info43; }
            set
            {
                if (!object.Equals(info43, value))
                {
                    if (!modifiedProperty.ContainsKey("Info43"))
                    {
                        modifiedProperty.Add("Info43", info43);
                        this.IsModified = true;
                    }
                    info43 = value;
                }
            }
        }

        private string info44;
        /// <summary>
        /// INFO44
        /// </summary>
        [DataFieldName("INFO44"), DataFieldDefault("")]
        public string Info44
        {
            get { return info44; }
            set
            {
                if (!object.Equals(info44, value))
                {
                    if (!modifiedProperty.ContainsKey("Info44"))
                    {
                        modifiedProperty.Add("Info44", info44);
                        this.IsModified = true;
                    }
                    info44 = value;
                }
            }
        }

        private string info45;
        /// <summary>
        /// INFO45
        /// </summary>
        [DataFieldName("INFO45"), DataFieldDefault("")]
        public string Info45
        {
            get { return info45; }
            set
            {
                if (!object.Equals(info45, value))
                {
                    if (!modifiedProperty.ContainsKey("Info45"))
                    {
                        modifiedProperty.Add("Info45", info45);
                        this.IsModified = true;
                    }
                    info45 = value;
                }
            }
        }

        private string info46;
        /// <summary>
        /// INFO46
        /// </summary>
        [DataFieldName("INFO46"), DataFieldDefault("")]
        public string Info46
        {
            get { return info46; }
            set
            {
                if (!object.Equals(info46, value))
                {
                    if (!modifiedProperty.ContainsKey("Info46"))
                    {
                        modifiedProperty.Add("Info46", info46);
                        this.IsModified = true;
                    }
                    info46 = value;
                }
            }
        }

        private string info47;
        /// <summary>
        /// INFO47
        /// </summary>
        [DataFieldName("INFO47"), DataFieldDefault("")]
        public string Info47
        {
            get { return info47; }
            set
            {
                if (!object.Equals(info47, value))
                {
                    if (!modifiedProperty.ContainsKey("Info47"))
                    {
                        modifiedProperty.Add("Info47", info47);
                        this.IsModified = true;
                    }
                    info47 = value;
                }
            }
        }

        private string info48;
        /// <summary>
        /// INFO48
        /// </summary>
        [DataFieldName("INFO48"), DataFieldDefault("")]
        public string Info48
        {
            get { return info48; }
            set
            {
                if (!object.Equals(info48, value))
                {
                    if (!modifiedProperty.ContainsKey("Info48"))
                    {
                        modifiedProperty.Add("Info48", info48);
                        this.IsModified = true;
                    }
                    info48 = value;
                }
            }
        }

        private string info49;
        /// <summary>
        /// INFO49
        /// </summary>
        [DataFieldName("INFO49"), DataFieldDefault("")]
        public string Info49
        {
            get { return info49; }
            set
            {
                if (!object.Equals(info49, value))
                {
                    if (!modifiedProperty.ContainsKey("Info49"))
                    {
                        modifiedProperty.Add("Info49", info49);
                        this.IsModified = true;
                    }
                    info49 = value;
                }
            }
        }

        private string info50;
        /// <summary>
        /// ������Ϣ(����2000)
        /// </summary>
        [DataFieldName("INFO50"), DataFieldDefault("")]
        public string Info50
        {
            get { return info50; }
            set
            {
                if (!object.Equals(info50, value))
                {
                    if (!modifiedProperty.ContainsKey("Info50"))
                    {
                        modifiedProperty.Add("Info50", info50);
                        this.IsModified = true;
                    }
                    info50 = value;
                }
            }
        }

        private decimal cost1;
        /// <summary>
        /// COST1
        /// </summary>
        [DataFieldName("COST1")]
        public decimal Cost1
        {
            get { return cost1; }
            set
            {
                if (!object.Equals(cost1, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost1"))
                    {
                        modifiedProperty.Add("Cost1", cost1);
                        this.IsModified = true;
                    }
                    cost1 = value;
                }
            }
        }

        private decimal cost2;
        /// <summary>
        /// COST2
        /// </summary>
        [DataFieldName("COST2")]
        public decimal Cost2
        {
            get { return cost2; }
            set
            {
                if (!object.Equals(cost2, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost2"))
                    {
                        modifiedProperty.Add("Cost2", cost2);
                        this.IsModified = true;
                    }
                    cost2 = value;
                }
            }
        }

        private decimal cost3;
        /// <summary>
        /// COST3
        /// </summary>
        [DataFieldName("COST3")]
        public decimal Cost3
        {
            get { return cost3; }
            set
            {
                if (!object.Equals(cost3, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost3"))
                    {
                        modifiedProperty.Add("Cost3", cost3);
                        this.IsModified = true;
                    }
                    cost3 = value;
                }
            }
        }

        private decimal cost4;
        /// <summary>
        /// COST4
        /// </summary>
        [DataFieldName("COST4")]
        public decimal Cost4
        {
            get { return cost4; }
            set
            {
                if (!object.Equals(cost4, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost4"))
                    {
                        modifiedProperty.Add("Cost4", cost4);
                        this.IsModified = true;
                    }
                    cost4 = value;
                }
            }
        }

        private decimal cost5;
        /// <summary>
        /// COST5
        /// </summary>
        [DataFieldName("COST5")]
        public decimal Cost5
        {
            get { return cost5; }
            set
            {
                if (!object.Equals(cost5, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost5"))
                    {
                        modifiedProperty.Add("Cost5", cost5);
                        this.IsModified = true;
                    }
                    cost5 = value;
                }
            }
        }

        private decimal cost6;
        /// <summary>
        /// COST6
        /// </summary>
        [DataFieldName("COST6")]
        public decimal Cost6
        {
            get { return cost6; }
            set
            {
                if (!object.Equals(cost6, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost6"))
                    {
                        modifiedProperty.Add("Cost6", cost6);
                        this.IsModified = true;
                    }
                    cost6 = value;
                }
            }
        }

        private decimal cost7;
        /// <summary>
        /// COST7
        /// </summary>
        [DataFieldName("COST7")]
        public decimal Cost7
        {
            get { return cost7; }
            set
            {
                if (!object.Equals(cost7, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost7"))
                    {
                        modifiedProperty.Add("Cost7", cost7);
                        this.IsModified = true;
                    }
                    cost7 = value;
                }
            }
        }

        private decimal cost8;
        /// <summary>
        /// COST8
        /// </summary>
        [DataFieldName("COST8")]
        public decimal Cost8
        {
            get { return cost8; }
            set
            {
                if (!object.Equals(cost8, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost8"))
                    {
                        modifiedProperty.Add("Cost8", cost8);
                        this.IsModified = true;
                    }
                    cost8 = value;
                }
            }
        }

        private decimal cost9;
        /// <summary>
        /// COST9
        /// </summary>
        [DataFieldName("COST9")]
        public decimal Cost9
        {
            get { return cost9; }
            set
            {
                if (!object.Equals(cost9, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost9"))
                    {
                        modifiedProperty.Add("Cost9", cost9);
                        this.IsModified = true;
                    }
                    cost9 = value;
                }
            }
        }

        private decimal cost10;
        /// <summary>
        /// COST10
        /// </summary>
        [DataFieldName("COST10")]
        public decimal Cost10
        {
            get { return cost10; }
            set
            {
                if (!object.Equals(cost10, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost10"))
                    {
                        modifiedProperty.Add("Cost10", cost10);
                        this.IsModified = true;
                    }
                    cost10 = value;
                }
            }
        }

        private decimal cost11;
        /// <summary>
        /// COST11
        /// </summary>
        [DataFieldName("COST11")]
        public decimal Cost11
        {
            get { return cost11; }
            set
            {
                if (!object.Equals(cost11, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost11"))
                    {
                        modifiedProperty.Add("Cost11", cost11);
                        this.IsModified = true;
                    }
                    cost11 = value;
                }
            }
        }

        private decimal cost12;
        /// <summary>
        /// COST12
        /// </summary>
        [DataFieldName("COST12")]
        public decimal Cost12
        {
            get { return cost12; }
            set
            {
                if (!object.Equals(cost12, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost12"))
                    {
                        modifiedProperty.Add("Cost12", cost12);
                        this.IsModified = true;
                    }
                    cost12 = value;
                }
            }
        }

        private decimal cost13;
        /// <summary>
        /// COST13
        /// </summary>
        [DataFieldName("COST13")]
        public decimal Cost13
        {
            get { return cost13; }
            set
            {
                if (!object.Equals(cost13, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost13"))
                    {
                        modifiedProperty.Add("Cost13", cost13);
                        this.IsModified = true;
                    }
                    cost13 = value;
                }
            }
        }

        private decimal cost14;
        /// <summary>
        /// COST14
        /// </summary>
        [DataFieldName("COST14")]
        public decimal Cost14
        {
            get { return cost14; }
            set
            {
                if (!object.Equals(cost14, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost14"))
                    {
                        modifiedProperty.Add("Cost14", cost14);
                        this.IsModified = true;
                    }
                    cost14 = value;
                }
            }
        }

        private decimal cost15;
        /// <summary>
        /// COST15
        /// </summary>
        [DataFieldName("COST15")]
        public decimal Cost15
        {
            get { return cost15; }
            set
            {
                if (!object.Equals(cost15, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost15"))
                    {
                        modifiedProperty.Add("Cost15", cost15);
                        this.IsModified = true;
                    }
                    cost15 = value;
                }
            }
        }

        private decimal cost16;
        /// <summary>
        /// COST16
        /// </summary>
        [DataFieldName("COST16")]
        public decimal Cost16
        {
            get { return cost16; }
            set
            {
                if (!object.Equals(cost16, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost16"))
                    {
                        modifiedProperty.Add("Cost16", cost16);
                        this.IsModified = true;
                    }
                    cost16 = value;
                }
            }
        }

        private decimal cost17;
        /// <summary>
        /// COST17
        /// </summary>
        [DataFieldName("COST17")]
        public decimal Cost17
        {
            get { return cost17; }
            set
            {
                if (!object.Equals(cost17, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost17"))
                    {
                        modifiedProperty.Add("Cost17", cost17);
                        this.IsModified = true;
                    }
                    cost17 = value;
                }
            }
        }

        private decimal cost18;
        /// <summary>
        /// COST18
        /// </summary>
        [DataFieldName("COST18")]
        public decimal Cost18
        {
            get { return cost18; }
            set
            {
                if (!object.Equals(cost18, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost18"))
                    {
                        modifiedProperty.Add("Cost18", cost18);
                        this.IsModified = true;
                    }
                    cost18 = value;
                }
            }
        }

        private decimal cost19;
        /// <summary>
        /// COST19
        /// </summary>
        [DataFieldName("COST19")]
        public decimal Cost19
        {
            get { return cost19; }
            set
            {
                if (!object.Equals(cost19, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost19"))
                    {
                        modifiedProperty.Add("Cost19", cost19);
                        this.IsModified = true;
                    }
                    cost19 = value;
                }
            }
        }

        private decimal cost20;
        /// <summary>
        /// COST20
        /// </summary>
        [DataFieldName("COST20")]
        public decimal Cost20
        {
            get { return cost20; }
            set
            {
                if (!object.Equals(cost20, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost20"))
                    {
                        modifiedProperty.Add("Cost20", cost20);
                        this.IsModified = true;
                    }
                    cost20 = value;
                }
            }
        }

        private decimal cost21;
        /// <summary>
        /// COST21
        /// </summary>
        [DataFieldName("COST21")]
        public decimal Cost21
        {
            get { return cost21; }
            set
            {
                if (!object.Equals(cost21, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost21"))
                    {
                        modifiedProperty.Add("Cost21", cost21);
                        this.IsModified = true;
                    }
                    cost21 = value;
                }
            }
        }

        private decimal cost22;
        /// <summary>
        /// COST22
        /// </summary>
        [DataFieldName("COST22")]
        public decimal Cost22
        {
            get { return cost22; }
            set
            {
                if (!object.Equals(cost22, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost22"))
                    {
                        modifiedProperty.Add("Cost22", cost22);
                        this.IsModified = true;
                    }
                    cost22 = value;
                }
            }
        }

        private decimal cost23;
        /// <summary>
        /// COST23
        /// </summary>
        [DataFieldName("COST23")]
        public decimal Cost23
        {
            get { return cost23; }
            set
            {
                if (!object.Equals(cost23, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost23"))
                    {
                        modifiedProperty.Add("Cost23", cost23);
                        this.IsModified = true;
                    }
                    cost23 = value;
                }
            }
        }

        private decimal cost24;
        /// <summary>
        /// COST24
        /// </summary>
        [DataFieldName("COST24")]
        public decimal Cost24
        {
            get { return cost24; }
            set
            {
                if (!object.Equals(cost24, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost24"))
                    {
                        modifiedProperty.Add("Cost24", cost24);
                        this.IsModified = true;
                    }
                    cost24 = value;
                }
            }
        }

        private decimal cost25;
        /// <summary>
        /// COST25
        /// </summary>
        [DataFieldName("COST25")]
        public decimal Cost25
        {
            get { return cost25; }
            set
            {
                if (!object.Equals(cost25, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost25"))
                    {
                        modifiedProperty.Add("Cost25", cost25);
                        this.IsModified = true;
                    }
                    cost25 = value;
                }
            }
        }

        private decimal cost26;
        /// <summary>
        /// COST26
        /// </summary>
        [DataFieldName("COST26")]
        public decimal Cost26
        {
            get { return cost26; }
            set
            {
                if (!object.Equals(cost26, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost26"))
                    {
                        modifiedProperty.Add("Cost26", cost26);
                        this.IsModified = true;
                    }
                    cost26 = value;
                }
            }
        }

        private decimal cost27;
        /// <summary>
        /// COST27
        /// </summary>
        [DataFieldName("COST27")]
        public decimal Cost27
        {
            get { return cost27; }
            set
            {
                if (!object.Equals(cost27, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost27"))
                    {
                        modifiedProperty.Add("Cost27", cost27);
                        this.IsModified = true;
                    }
                    cost27 = value;
                }
            }
        }

        private decimal cost28;
        /// <summary>
        /// COST28
        /// </summary>
        [DataFieldName("COST28")]
        public decimal Cost28
        {
            get { return cost28; }
            set
            {
                if (!object.Equals(cost28, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost28"))
                    {
                        modifiedProperty.Add("Cost28", cost28);
                        this.IsModified = true;
                    }
                    cost28 = value;
                }
            }
        }

        private decimal cost29;
        /// <summary>
        /// COST29
        /// </summary>
        [DataFieldName("COST29")]
        public decimal Cost29
        {
            get { return cost29; }
            set
            {
                if (!object.Equals(cost29, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost29"))
                    {
                        modifiedProperty.Add("Cost29", cost29);
                        this.IsModified = true;
                    }
                    cost29 = value;
                }
            }
        }

        private decimal cost30;
        /// <summary>
        /// COST30
        /// </summary>
        [DataFieldName("COST30")]
        public decimal Cost30
        {
            get { return cost30; }
            set
            {
                if (!object.Equals(cost30, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost30"))
                    {
                        modifiedProperty.Add("Cost30", cost30);
                        this.IsModified = true;
                    }
                    cost30 = value;
                }
            }
        }

        private decimal cost31;
        /// <summary>
        /// COST31
        /// </summary>
        [DataFieldName("COST31")]
        public decimal Cost31
        {
            get { return cost31; }
            set
            {
                if (!object.Equals(cost31, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost31"))
                    {
                        modifiedProperty.Add("Cost31", cost31);
                        this.IsModified = true;
                    }
                    cost31 = value;
                }
            }
        }

        private decimal cost32;
        /// <summary>
        /// COST32
        /// </summary>
        [DataFieldName("COST32")]
        public decimal Cost32
        {
            get { return cost32; }
            set
            {
                if (!object.Equals(cost32, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost32"))
                    {
                        modifiedProperty.Add("Cost32", cost32);
                        this.IsModified = true;
                    }
                    cost32 = value;
                }
            }
        }

        private decimal cost33;
        /// <summary>
        /// COST33
        /// </summary>
        [DataFieldName("COST33")]
        public decimal Cost33
        {
            get { return cost33; }
            set
            {
                if (!object.Equals(cost33, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost33"))
                    {
                        modifiedProperty.Add("Cost33", cost33);
                        this.IsModified = true;
                    }
                    cost33 = value;
                }
            }
        }

        private decimal cost34;
        /// <summary>
        /// COST34
        /// </summary>
        [DataFieldName("COST34")]
        public decimal Cost34
        {
            get { return cost34; }
            set
            {
                if (!object.Equals(cost34, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost34"))
                    {
                        modifiedProperty.Add("Cost34", cost34);
                        this.IsModified = true;
                    }
                    cost34 = value;
                }
            }
        }

        private decimal cost35;
        /// <summary>
        /// COST35
        /// </summary>
        [DataFieldName("COST35")]
        public decimal Cost35
        {
            get { return cost35; }
            set
            {
                if (!object.Equals(cost35, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost35"))
                    {
                        modifiedProperty.Add("Cost35", cost35);
                        this.IsModified = true;
                    }
                    cost35 = value;
                }
            }
        }

        private decimal cost36;
        /// <summary>
        /// COST36
        /// </summary>
        [DataFieldName("COST36")]
        public decimal Cost36
        {
            get { return cost36; }
            set
            {
                if (!object.Equals(cost36, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost36"))
                    {
                        modifiedProperty.Add("Cost36", cost36);
                        this.IsModified = true;
                    }
                    cost36 = value;
                }
            }
        }

        private decimal cost37;
        /// <summary>
        /// COST37
        /// </summary>
        [DataFieldName("COST37")]
        public decimal Cost37
        {
            get { return cost37; }
            set
            {
                if (!object.Equals(cost37, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost37"))
                    {
                        modifiedProperty.Add("Cost37", cost37);
                        this.IsModified = true;
                    }
                    cost37 = value;
                }
            }
        }

        private decimal cost38;
        /// <summary>
        /// COST38
        /// </summary>
        [DataFieldName("COST38")]
        public decimal Cost38
        {
            get { return cost38; }
            set
            {
                if (!object.Equals(cost38, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost38"))
                    {
                        modifiedProperty.Add("Cost38", cost38);
                        this.IsModified = true;
                    }
                    cost38 = value;
                }
            }
        }

        private decimal cost39;
        /// <summary>
        /// COST39
        /// </summary>
        [DataFieldName("COST39")]
        public decimal Cost39
        {
            get { return cost39; }
            set
            {
                if (!object.Equals(cost39, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost39"))
                    {
                        modifiedProperty.Add("Cost39", cost39);
                        this.IsModified = true;
                    }
                    cost39 = value;
                }
            }
        }

        private decimal cost40;
        /// <summary>
        /// COST40
        /// </summary>
        [DataFieldName("COST40")]
        public decimal Cost40
        {
            get { return cost40; }
            set
            {
                if (!object.Equals(cost40, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost40"))
                    {
                        modifiedProperty.Add("Cost40", cost40);
                        this.IsModified = true;
                    }
                    cost40 = value;
                }
            }
        }

        private decimal cost41;
        /// <summary>
        /// COST41
        /// </summary>
        [DataFieldName("COST41")]
        public decimal Cost41
        {
            get { return cost41; }
            set
            {
                if (!object.Equals(cost41, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost41"))
                    {
                        modifiedProperty.Add("Cost41", cost41);
                        this.IsModified = true;
                    }
                    cost41 = value;
                }
            }
        }

        private decimal cost42;
        /// <summary>
        /// COST42
        /// </summary>
        [DataFieldName("COST42")]
        public decimal Cost42
        {
            get { return cost42; }
            set
            {
                if (!object.Equals(cost42, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost42"))
                    {
                        modifiedProperty.Add("Cost42", cost42);
                        this.IsModified = true;
                    }
                    cost42 = value;
                }
            }
        }

        private decimal cost43;
        /// <summary>
        /// COST43
        /// </summary>
        [DataFieldName("COST43")]
        public decimal Cost43
        {
            get { return cost43; }
            set
            {
                if (!object.Equals(cost43, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost43"))
                    {
                        modifiedProperty.Add("Cost43", cost43);
                        this.IsModified = true;
                    }
                    cost43 = value;
                }
            }
        }

        private decimal cost44;
        /// <summary>
        /// COST44
        /// </summary>
        [DataFieldName("COST44")]
        public decimal Cost44
        {
            get { return cost44; }
            set
            {
                if (!object.Equals(cost44, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost44"))
                    {
                        modifiedProperty.Add("Cost44", cost44);
                        this.IsModified = true;
                    }
                    cost44 = value;
                }
            }
        }

        private decimal cost45;
        /// <summary>
        /// COST45
        /// </summary>
        [DataFieldName("COST45")]
        public decimal Cost45
        {
            get { return cost45; }
            set
            {
                if (!object.Equals(cost45, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost45"))
                    {
                        modifiedProperty.Add("Cost45", cost45);
                        this.IsModified = true;
                    }
                    cost45 = value;
                }
            }
        }

        private decimal cost46;
        /// <summary>
        /// COST46
        /// </summary>
        [DataFieldName("COST46")]
        public decimal Cost46
        {
            get { return cost46; }
            set
            {
                if (!object.Equals(cost46, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost46"))
                    {
                        modifiedProperty.Add("Cost46", cost46);
                        this.IsModified = true;
                    }
                    cost46 = value;
                }
            }
        }

        private decimal cost47;
        /// <summary>
        /// COST47
        /// </summary>
        [DataFieldName("COST47")]
        public decimal Cost47
        {
            get { return cost47; }
            set
            {
                if (!object.Equals(cost47, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost47"))
                    {
                        modifiedProperty.Add("Cost47", cost47);
                        this.IsModified = true;
                    }
                    cost47 = value;
                }
            }
        }

        private decimal cost48;
        /// <summary>
        /// COST48
        /// </summary>
        [DataFieldName("COST48")]
        public decimal Cost48
        {
            get { return cost48; }
            set
            {
                if (!object.Equals(cost48, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost48"))
                    {
                        modifiedProperty.Add("Cost48", cost48);
                        this.IsModified = true;
                    }
                    cost48 = value;
                }
            }
        }

        private decimal cost49;
        /// <summary>
        /// COST49
        /// </summary>
        [DataFieldName("COST49")]
        public decimal Cost49
        {
            get { return cost49; }
            set
            {
                if (!object.Equals(cost49, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost49"))
                    {
                        modifiedProperty.Add("Cost49", cost49);
                        this.IsModified = true;
                    }
                    cost49 = value;
                }
            }
        }

        private decimal cost50;
        /// <summary>
        /// COST50
        /// </summary>
        [DataFieldName("COST50")]
        public decimal Cost50
        {
            get { return cost50; }
            set
            {
                if (!object.Equals(cost50, value))
                {
                    if (!modifiedProperty.ContainsKey("Cost50"))
                    {
                        modifiedProperty.Add("Cost50", cost50);
                        this.IsModified = true;
                    }
                    cost50 = value;
                }
            }
        }

        private string nSiRet1;
        /// <summary>
        /// ����������
        /// </summary>
        [DataFieldName("N_SI_RET1"), DataFieldDefault("")]
        public string NSiRet1
        {
            get { return nSiRet1; }
            set
            {
                if (!object.Equals(nSiRet1, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet1"))
                    {
                        modifiedProperty.Add("NSiRet1", nSiRet1);
                        this.IsModified = true;
                    }
                    nSiRet1 = value;
                }
            }
        }

        private string nSiRet2;
        /// <summary>
        /// ��λ���
        /// </summary>
        [DataFieldName("N_SI_RET2"), DataFieldDefault("")]
        public string NSiRet2
        {
            get { return nSiRet2; }
            set
            {
                if (!object.Equals(nSiRet2, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet2"))
                    {
                        modifiedProperty.Add("NSiRet2", nSiRet2);
                        this.IsModified = true;
                    }
                    nSiRet2 = value;
                }
            }
        }

        private string nSiRet3;
        /// <summary>
        /// ���˱��
        /// </summary>
        [DataFieldName("N_SI_RET3"), DataFieldDefault("")]
        public string NSiRet3
        {
            get { return nSiRet3; }
            set
            {
                if (!object.Equals(nSiRet3, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet3"))
                    {
                        modifiedProperty.Add("NSiRet3", nSiRet3);
                        this.IsModified = true;
                    }
                    nSiRet3 = value;
                }
            }
        }

        private string nSiRet4;
        /// <summary>
        /// סԺ��ˮ��(������ˮ��)
        /// </summary>
        [DataFieldName("N_SI_RET4"), DataFieldDefault("")]
        public string NSiRet4
        {
            get { return nSiRet4; }
            set
            {
                if (!object.Equals(nSiRet4, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet4"))
                    {
                        modifiedProperty.Add("NSiRet4", nSiRet4);
                        this.IsModified = true;
                    }
                    nSiRet4 = value;
                }
            }
        }

        private string nSiRet5;
        /// <summary>
        /// ҽ�����
        /// </summary>
        [DataFieldName("N_SI_RET5"), DataFieldDefault("")]
        public string NSiRet5
        {
            get { return nSiRet5; }
            set
            {
                if (!object.Equals(nSiRet5, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet5"))
                    {
                        modifiedProperty.Add("NSiRet5", nSiRet5);
                        this.IsModified = true;
                    }
                    nSiRet5 = value;
                }
            }
        }

        private string nSiRet6;
        /// <summary>
        /// ҽ����Ա���
        /// </summary>
        [DataFieldName("N_SI_RET6"), DataFieldDefault("")]
        public string NSiRet6
        {
            get { return nSiRet6; }
            set
            {
                if (!object.Equals(nSiRet6, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet6"))
                    {
                        modifiedProperty.Add("NSiRet6", nSiRet6);
                        this.IsModified = true;
                    }
                    nSiRet6 = value;
                }
            }
        }

        private string nSiRet7;
        /// <summary>
        /// ��Ա״̬
        /// </summary>
        [DataFieldName("N_SI_RET7"), DataFieldDefault("")]
        public string NSiRet7
        {
            get { return nSiRet7; }
            set
            {
                if (!object.Equals(nSiRet7, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet7"))
                    {
                        modifiedProperty.Add("NSiRet7", nSiRet7);
                        this.IsModified = true;
                    }
                    nSiRet7 = value;
                }
            }
        }

        private string nSiRet8;
        /// <summary>
        /// ��������
        /// </summary>
        [DataFieldName("N_SI_RET8"), DataFieldDefault("")]
        public string NSiRet8
        {
            get { return nSiRet8; }
            set
            {
                if (!object.Equals(nSiRet8, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet8"))
                    {
                        modifiedProperty.Add("NSiRet8", nSiRet8);
                        this.IsModified = true;
                    }
                    nSiRet8 = value;
                }
            }
        }

        private string nSiRet9;
        /// <summary>
        /// ���ܹ���Ա��־
        /// </summary>
        [DataFieldName("N_SI_RET9"), DataFieldDefault("")]
        public string NSiRet9
        {
            get { return nSiRet9; }
            set
            {
                if (!object.Equals(nSiRet9, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet9"))
                    {
                        modifiedProperty.Add("NSiRet9", nSiRet9);
                        this.IsModified = true;
                    }
                    nSiRet9 = value;
                }
            }
        }

        private string nSiRet10;
        /// <summary>
        /// ��������
        /// </summary>
        [DataFieldName("N_SI_RET10"), DataFieldDefault("")]
        public string NSiRet10
        {
            get { return nSiRet10; }
            set
            {
                if (!object.Equals(nSiRet10, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet10"))
                    {
                        modifiedProperty.Add("NSiRet10", nSiRet10);
                        this.IsModified = true;
                    }
                    nSiRet10 = value;
                }
            }
        }

        private string nSiRet11;
        /// <summary>
        /// ���ݺ�
        /// </summary>
        [DataFieldName("N_SI_RET11"), DataFieldDefault("")]
        public string NSiRet11
        {
            get { return nSiRet11; }
            set
            {
                if (!object.Equals(nSiRet11, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet11"))
                    {
                        modifiedProperty.Add("NSiRet11", nSiRet11);
                        this.IsModified = true;
                    }
                    nSiRet11 = value;
                }
            }
        }

        private string nSiRet12;
        /// <summary>
        /// ��������
        /// </summary>
        [DataFieldName("N_SI_RET12"), DataFieldDefault("")]
        public string NSiRet12
        {
            get { return nSiRet12; }
            set
            {
                if (!object.Equals(nSiRet12, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet12"))
                    {
                        modifiedProperty.Add("NSiRet12", nSiRet12);
                        this.IsModified = true;
                    }
                    nSiRet12 = value;
                }
            }
        }

        private string nSiRet13;
        /// <summary>
        /// �ɵ��ݺ�
        /// </summary>
        [DataFieldName("N_SI_RET13"), DataFieldDefault("")]
        public string NSiRet13
        {
            get { return nSiRet13; }
            set
            {
                if (!object.Equals(nSiRet13, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet13"))
                    {
                        modifiedProperty.Add("NSiRet13", nSiRet13);
                        this.IsModified = true;
                    }
                    nSiRet13 = value;
                }
            }
        }

        private string nSiRet14;
        /// <summary>
        /// ������־
        /// </summary>
        [DataFieldName("N_SI_RET14"), DataFieldDefault("")]
        public string NSiRet14
        {
            get { return nSiRet14; }
            set
            {
                if (!object.Equals(nSiRet14, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet14"))
                    {
                        modifiedProperty.Add("NSiRet14", nSiRet14);
                        this.IsModified = true;
                    }
                    nSiRet14 = value;
                }
            }
        }

        private string nSiRet15;
        /// <summary>
        /// ҽ������
        /// </summary>
        [DataFieldName("N_SI_RET15"), DataFieldDefault("")]
        public string NSiRet15
        {
            get { return nSiRet15; }
            set
            {
                if (!object.Equals(nSiRet15, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet15"))
                    {
                        modifiedProperty.Add("NSiRet15", nSiRet15);
                        this.IsModified = true;
                    }
                    nSiRet15 = value;
                }
            }
        }

        private string nSiRet16;
        /// <summary>
        /// �ϴ��ʻ����
        /// </summary>
        [DataFieldName("N_SI_RET16"), DataFieldDefault("")]
        public string NSiRet16
        {
            get { return nSiRet16; }
            set
            {
                if (!object.Equals(nSiRet16, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet16"))
                    {
                        modifiedProperty.Add("NSiRet16", nSiRet16);
                        this.IsModified = true;
                    }
                    nSiRet16 = value;
                }
            }
        }

        private string nSiRet17;
        /// <summary>
        /// �����ʻ�֧��
        /// </summary>
        [DataFieldName("N_SI_RET17"), DataFieldDefault("")]
        public string NSiRet17
        {
            get { return nSiRet17; }
            set
            {
                if (!object.Equals(nSiRet17, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet17"))
                    {
                        modifiedProperty.Add("NSiRet17", nSiRet17);
                        this.IsModified = true;
                    }
                    nSiRet17 = value;
                }
            }
        }

        private string nSiRet18;
        /// <summary>
        /// ͳ��֧�����
        /// </summary>
        [DataFieldName("N_SI_RET18"), DataFieldDefault("")]
        public string NSiRet18
        {
            get { return nSiRet18; }
            set
            {
                if (!object.Equals(nSiRet18, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet18"))
                    {
                        modifiedProperty.Add("NSiRet18", nSiRet18);
                        this.IsModified = true;
                    }
                    nSiRet18 = value;
                }
            }
        }

        private string nSiRet19;
        /// <summary>
        /// ����Ա����֧��
        /// </summary>
        [DataFieldName("N_SI_RET19"), DataFieldDefault("")]
        public string NSiRet19
        {
            get { return nSiRet19; }
            set
            {
                if (!object.Equals(nSiRet19, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet19"))
                    {
                        modifiedProperty.Add("NSiRet19", nSiRet19);
                        this.IsModified = true;
                    }
                    nSiRet19 = value;
                }
            }
        }

        private string nSiRet20;
        /// <summary>
        /// ��ҵ�������֧��
        /// </summary>
        [DataFieldName("N_SI_RET20"), DataFieldDefault("")]
        public string NSiRet20
        {
            get { return nSiRet20; }
            set
            {
                if (!object.Equals(nSiRet20, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet20"))
                    {
                        modifiedProperty.Add("NSiRet20", nSiRet20);
                        this.IsModified = true;
                    }
                    nSiRet20 = value;
                }
            }
        }

        private string nSiRet21;
        /// <summary>
        /// ���ݻ���֧��
        /// </summary>
        [DataFieldName("N_SI_RET21"), DataFieldDefault("")]
        public string NSiRet21
        {
            get { return nSiRet21; }
            set
            {
                if (!object.Equals(nSiRet21, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet21"))
                    {
                        modifiedProperty.Add("NSiRet21", nSiRet21);
                        this.IsModified = true;
                    }
                    nSiRet21 = value;
                }
            }
        }

        private string nSiRet22;
        /// <summary>
        /// ���Ҳл���֧��
        /// </summary>
        [DataFieldName("N_SI_RET22"), DataFieldDefault("")]
        public string NSiRet22
        {
            get { return nSiRet22; }
            set
            {
                if (!object.Equals(nSiRet22, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet22"))
                    {
                        modifiedProperty.Add("NSiRet22", nSiRet22);
                        this.IsModified = true;
                    }
                    nSiRet22 = value;
                }
            }
        }

        private string nSiRet23;
        /// <summary>
        /// �󲡾�������֧��
        /// </summary>
        [DataFieldName("N_SI_RET23"), DataFieldDefault("")]
        public string NSiRet23
        {
            get { return nSiRet23; }
            set
            {
                if (!object.Equals(nSiRet23, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet23"))
                    {
                        modifiedProperty.Add("NSiRet23", nSiRet23);
                        this.IsModified = true;
                    }
                    nSiRet23 = value;
                }
            }
        }

        private string nSiRet24;
        /// <summary>
        /// ҽ�Ʒ��ܶ�
        /// </summary>
        [DataFieldName("N_SI_RET24"), DataFieldDefault("")]
        public string NSiRet24
        {
            get { return nSiRet24; }
            set
            {
                if (!object.Equals(nSiRet24, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet24"))
                    {
                        modifiedProperty.Add("NSiRet24", nSiRet24);
                        this.IsModified = true;
                    }
                    nSiRet24 = value;
                }
            }
        }

        private string nSiRet25;
        /// <summary>
        /// �Էѷ���
        /// </summary>
        [DataFieldName("N_SI_RET25"), DataFieldDefault("")]
        public string NSiRet25
        {
            get { return nSiRet25; }
            set
            {
                if (!object.Equals(nSiRet25, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet25"))
                    {
                        modifiedProperty.Add("NSiRet25", nSiRet25);
                        this.IsModified = true;
                    }
                    nSiRet25 = value;
                }
            }
        }

        private string nSiRet26;
        /// <summary>
        /// ������������
        /// </summary>
        [DataFieldName("N_SI_RET26"), DataFieldDefault("")]
        public string NSiRet26
        {
            get { return nSiRet26; }
            set
            {
                if (!object.Equals(nSiRet26, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet26"))
                    {
                        modifiedProperty.Add("NSiRet26", nSiRet26);
                        this.IsModified = true;
                    }
                    nSiRet26 = value;
                }
            }
        }

        private string nSiRet27;
        /// <summary>
        /// ����ҽ�Ʊ����𸶱�׼�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET27"), DataFieldDefault("")]
        public string NSiRet27
        {
            get { return nSiRet27; }
            set
            {
                if (!object.Equals(nSiRet27, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet27"))
                    {
                        modifiedProperty.Add("NSiRet27", nSiRet27);
                        this.IsModified = true;
                    }
                    nSiRet27 = value;
                }
            }
        }

        private string nSiRet28;
        /// <summary>
        /// ���ⶥ���Ը�
        /// </summary>
        [DataFieldName("N_SI_RET28"), DataFieldDefault("")]
        public string NSiRet28
        {
            get { return nSiRet28; }
            set
            {
                if (!object.Equals(nSiRet28, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet28"))
                    {
                        modifiedProperty.Add("NSiRet28", nSiRet28);
                        this.IsModified = true;
                    }
                    nSiRet28 = value;
                }
            }
        }

        private string nSiRet29;
        /// <summary>
        /// ����Ա�����𸶱�׼�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET29"), DataFieldDefault("")]
        public string NSiRet29
        {
            get { return nSiRet29; }
            set
            {
                if (!object.Equals(nSiRet29, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet29"))
                    {
                        modifiedProperty.Add("NSiRet29", nSiRet29);
                        this.IsModified = true;
                    }
                    nSiRet29 = value;
                }
            }
        }

        private string nSiRet30;
        /// <summary>
        /// ����ͳ��ֶ��Ը�
        /// </summary>
        [DataFieldName("N_SI_RET30"), DataFieldDefault("")]
        public string NSiRet30
        {
            get { return nSiRet30; }
            set
            {
                if (!object.Equals(nSiRet30, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet30"))
                    {
                        modifiedProperty.Add("NSiRet30", nSiRet30);
                        this.IsModified = true;
                    }
                    nSiRet30 = value;
                }
            }
        }

        private string nSiRet31;
        /// <summary>
        /// ������־
        /// </summary>
        [DataFieldName("N_SI_RET31"), DataFieldDefault("")]
        public string NSiRet31
        {
            get { return nSiRet31; }
            set
            {
                if (!object.Equals(nSiRet31, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet31"))
                    {
                        modifiedProperty.Add("NSiRet31", nSiRet31);
                        this.IsModified = true;
                    }
                    nSiRet31 = value;
                }
            }
        }

        private string nSiRet32;
        /// <summary>
        /// ��Ʊ���
        /// </summary>
        [DataFieldName("N_SI_RET32"), DataFieldDefault("")]
        public string NSiRet32
        {
            get { return nSiRet32; }
            set
            {
                if (!object.Equals(nSiRet32, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet32"))
                    {
                        modifiedProperty.Add("NSiRet32", nSiRet32);
                        this.IsModified = true;
                    }
                    nSiRet32 = value;
                }
            }
        }

        private string nSiRet33;
        /// <summary>
        /// ���շ�(ҽ������)������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET33"), DataFieldDefault("")]
        public string NSiRet33
        {
            get { return nSiRet33; }
            set
            {
                if (!object.Equals(nSiRet33, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet33"))
                    {
                        modifiedProperty.Add("NSiRet33", nSiRet33);
                        this.IsModified = true;
                    }
                    nSiRet33 = value;
                }
            }
        }

        private string nSiRet34;
        /// <summary>
        /// ���ͷ�(ҽ�ƻ���)������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET34"), DataFieldDefault("")]
        public string NSiRet34
        {
            get { return nSiRet34; }
            set
            {
                if (!object.Equals(nSiRet34, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet34"))
                    {
                        modifiedProperty.Add("NSiRet34", nSiRet34);
                        this.IsModified = true;
                    }
                    nSiRet34 = value;
                }
            }
        }

        private string nSiRet35;
        /// <summary>
        /// ҵ�����ں�
        /// </summary>
        [DataFieldName("N_SI_RET35"), DataFieldDefault("")]
        public string NSiRet35
        {
            get { return nSiRet35; }
            set
            {
                if (!object.Equals(nSiRet35, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet35"))
                    {
                        modifiedProperty.Add("NSiRet35", nSiRet35);
                        this.IsModified = true;
                    }
                    nSiRet35 = value;
                }
            }
        }

        private string nSiRet36;
        /// <summary>
        /// ���ͷ�(ҽ�ƻ���)������������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET36"), DataFieldDefault("")]
        public string NSiRet36
        {
            get { return nSiRet36; }
            set
            {
                if (!object.Equals(nSiRet36, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet36"))
                    {
                        modifiedProperty.Add("NSiRet36", nSiRet36);
                        this.IsModified = true;
                    }
                    nSiRet36 = value;
                }
            }
        }

        private string nSiRet37;
        /// <summary>
        /// ���շ�(ҽ������)������������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET37"), DataFieldDefault("")]
        public string NSiRet37
        {
            get { return nSiRet37; }
            set
            {
                if (!object.Equals(nSiRet37, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet37"))
                    {
                        modifiedProperty.Add("NSiRet37", nSiRet37);
                        this.IsModified = true;
                    }
                    nSiRet37 = value;
                }
            }
        }

        private string nSiRet38;
        /// <summary>
        /// ���շ�(ҽ������)����������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET38"), DataFieldDefault("")]
        public string NSiRet38
        {
            get { return nSiRet38; }
            set
            {
                if (!object.Equals(nSiRet38, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet38"))
                    {
                        modifiedProperty.Add("NSiRet38", nSiRet38);
                        this.IsModified = true;
                    }
                    nSiRet38 = value;
                }
            }
        }

        private string nSiRet39;
        /// <summary>
        /// ���ͷ�(ҽ�ƻ���)����������ˮ��
        /// </summary>
        [DataFieldName("N_SI_RET39"), DataFieldDefault("")]
        public string NSiRet39
        {
            get { return nSiRet39; }
            set
            {
                if (!object.Equals(nSiRet39, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet39"))
                    {
                        modifiedProperty.Add("NSiRet39", nSiRet39);
                        this.IsModified = true;
                    }
                    nSiRet39 = value;
                }
            }
        }

        private string nSiRet40;
        /// <summary>
        /// ����ͳ��ֶ�1�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET40"), DataFieldDefault("")]
        public string NSiRet40
        {
            get { return nSiRet40; }
            set
            {
                if (!object.Equals(nSiRet40, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet40"))
                    {
                        modifiedProperty.Add("NSiRet40", nSiRet40);
                        this.IsModified = true;
                    }
                    nSiRet40 = value;
                }
            }
        }

        private string nSiRet41;
        /// <summary>
        /// ����ͳ��ֶ�2�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET41"), DataFieldDefault("")]
        public string NSiRet41
        {
            get { return nSiRet41; }
            set
            {
                if (!object.Equals(nSiRet41, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet41"))
                    {
                        modifiedProperty.Add("NSiRet41", nSiRet41);
                        this.IsModified = true;
                    }
                    nSiRet41 = value;
                }
            }
        }

        private string nSiRet42;
        /// <summary>
        /// ����ͳ��ֶ�3�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET42"), DataFieldDefault("")]
        public string NSiRet42
        {
            get { return nSiRet42; }
            set
            {
                if (!object.Equals(nSiRet42, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet42"))
                    {
                        modifiedProperty.Add("NSiRet42", nSiRet42);
                        this.IsModified = true;
                    }
                    nSiRet42 = value;
                }
            }
        }

        private string nSiRet43;
        /// <summary>
        /// ����ͳ��ֶ�4�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET43"), DataFieldDefault("")]
        public string NSiRet43
        {
            get { return nSiRet43; }
            set
            {
                if (!object.Equals(nSiRet43, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet43"))
                    {
                        modifiedProperty.Add("NSiRet43", nSiRet43);
                        this.IsModified = true;
                    }
                    nSiRet43 = value;
                }
            }
        }

        private string nSiRet44;
        /// <summary>
        /// ����ͳ��ֶ�5�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET44"), DataFieldDefault("")]
        public string NSiRet44
        {
            get { return nSiRet44; }
            set
            {
                if (!object.Equals(nSiRet44, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet44"))
                    {
                        modifiedProperty.Add("NSiRet44", nSiRet44);
                        this.IsModified = true;
                    }
                    nSiRet44 = value;
                }
            }
        }

        private string nSiRet45;
        /// <summary>
        /// ����ͳ��ֶ�1�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET45"), DataFieldDefault("")]
        public string NSiRet45
        {
            get { return nSiRet45; }
            set
            {
                if (!object.Equals(nSiRet45, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet45"))
                    {
                        modifiedProperty.Add("NSiRet45", nSiRet45);
                        this.IsModified = true;
                    }
                    nSiRet45 = value;
                }
            }
        }

        private string nSiRet46;
        /// <summary>
        /// ����ͳ��ֶ�2�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET46"), DataFieldDefault("")]
        public string NSiRet46
        {
            get { return nSiRet46; }
            set
            {
                if (!object.Equals(nSiRet46, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet46"))
                    {
                        modifiedProperty.Add("NSiRet46", nSiRet46);
                        this.IsModified = true;
                    }
                    nSiRet46 = value;
                }
            }
        }

        private string nSiRet47;
        /// <summary>
        /// ����ͳ��ֶ�3�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET47"), DataFieldDefault("")]
        public string NSiRet47
        {
            get { return nSiRet47; }
            set
            {
                if (!object.Equals(nSiRet47, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet47"))
                    {
                        modifiedProperty.Add("NSiRet47", nSiRet47);
                        this.IsModified = true;
                    }
                    nSiRet47 = value;
                }
            }
        }

        private string nSiRet48;
        /// <summary>
        /// ����ͳ��ֶ�4�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET48"), DataFieldDefault("")]
        public string NSiRet48
        {
            get { return nSiRet48; }
            set
            {
                if (!object.Equals(nSiRet48, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet48"))
                    {
                        modifiedProperty.Add("NSiRet48", nSiRet48);
                        this.IsModified = true;
                    }
                    nSiRet48 = value;
                }
            }
        }

        private string nSiRet49;
        /// <summary>
        /// ����ͳ��ֶ�5�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET49"), DataFieldDefault("")]
        public string NSiRet49
        {
            get { return nSiRet49; }
            set
            {
                if (!object.Equals(nSiRet49, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet49"))
                    {
                        modifiedProperty.Add("NSiRet49", nSiRet49);
                        this.IsModified = true;
                    }
                    nSiRet49 = value;
                }
            }
        }

        private string nSiRet50;
        /// <summary>
        /// �������Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET50"), DataFieldDefault("")]
        public string NSiRet50
        {
            get { return nSiRet50; }
            set
            {
                if (!object.Equals(nSiRet50, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet50"))
                    {
                        modifiedProperty.Add("NSiRet50", nSiRet50);
                        this.IsModified = true;
                    }
                    nSiRet50 = value;
                }
            }
        }

        private string nSiRet51;
        /// <summary>
        /// �ֽ�֧��
        /// </summary>
        [DataFieldName("N_SI_RET51"), DataFieldDefault("")]
        public string NSiRet51
        {
            get { return nSiRet51; }
            set
            {
                if (!object.Equals(nSiRet51, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet51"))
                    {
                        modifiedProperty.Add("NSiRet51", nSiRet51);
                        this.IsModified = true;
                    }
                    nSiRet51 = value;
                }
            }
        }

        private string nSiRet52;
        /// <summary>
        /// ����ͳ��ֶ�1���
        /// </summary>
        [DataFieldName("N_SI_RET52"), DataFieldDefault("")]
        public string NSiRet52
        {
            get { return nSiRet52; }
            set
            {
                if (!object.Equals(nSiRet52, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet52"))
                    {
                        modifiedProperty.Add("NSiRet52", nSiRet52);
                        this.IsModified = true;
                    }
                    nSiRet52 = value;
                }
            }
        }

        private string nSiRet53;
        /// <summary>
        /// ����ͳ��ֶ�2���
        /// </summary>
        [DataFieldName("N_SI_RET53"), DataFieldDefault("")]
        public string NSiRet53
        {
            get { return nSiRet53; }
            set
            {
                if (!object.Equals(nSiRet53, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet53"))
                    {
                        modifiedProperty.Add("NSiRet53", nSiRet53);
                        this.IsModified = true;
                    }
                    nSiRet53 = value;
                }
            }
        }

        private string nSiRet54;
        /// <summary>
        /// ����ͳ��ֶ�3���
        /// </summary>
        [DataFieldName("N_SI_RET54"), DataFieldDefault("")]
        public string NSiRet54
        {
            get { return nSiRet54; }
            set
            {
                if (!object.Equals(nSiRet54, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet54"))
                    {
                        modifiedProperty.Add("NSiRet54", nSiRet54);
                        this.IsModified = true;
                    }
                    nSiRet54 = value;
                }
            }
        }

        private string nSiRet55;
        /// <summary>
        /// ����ͳ��ֶ�4���
        /// </summary>
        [DataFieldName("N_SI_RET55"), DataFieldDefault("")]
        public string NSiRet55
        {
            get { return nSiRet55; }
            set
            {
                if (!object.Equals(nSiRet55, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet55"))
                    {
                        modifiedProperty.Add("NSiRet55", nSiRet55);
                        this.IsModified = true;
                    }
                    nSiRet55 = value;
                }
            }
        }

        private string nSiRet56;
        /// <summary>
        /// ����ͳ��ֶ�5���
        /// </summary>
        [DataFieldName("N_SI_RET56"), DataFieldDefault("")]
        public string NSiRet56
        {
            get { return nSiRet56; }
            set
            {
                if (!object.Equals(nSiRet56, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet56"))
                    {
                        modifiedProperty.Add("NSiRet56", nSiRet56);
                        this.IsModified = true;
                    }
                    nSiRet56 = value;
                }
            }
        }

        private string nSiRet57;
        /// <summary>
        /// ����󲡾������
        /// </summary>
        [DataFieldName("N_SI_RET57"), DataFieldDefault("")]
        public string NSiRet57
        {
            get { return nSiRet57; }
            set
            {
                if (!object.Equals(nSiRet57, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet57"))
                    {
                        modifiedProperty.Add("NSiRet57", nSiRet57);
                        this.IsModified = true;
                    }
                    nSiRet57 = value;
                }
            }
        }

        private string nSiRet58;
        /// <summary>
        /// �����󲡾������
        /// </summary>
        [DataFieldName("N_SI_RET58"), DataFieldDefault("")]
        public string NSiRet58
        {
            get { return nSiRet58; }
            set
            {
                if (!object.Equals(nSiRet58, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet58"))
                    {
                        modifiedProperty.Add("NSiRet58", nSiRet58);
                        this.IsModified = true;
                    }
                    nSiRet58 = value;
                }
            }
        }

        private string nSiRet59;
        /// <summary>
        /// ����������Ա��������֧��
        /// </summary>
        [DataFieldName("N_SI_RET59"), DataFieldDefault("")]
        public string NSiRet59
        {
            get { return nSiRet59; }
            set
            {
                if (!object.Equals(nSiRet59, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet59"))
                    {
                        modifiedProperty.Add("NSiRet59", nSiRet59);
                        this.IsModified = true;
                    }
                    nSiRet59 = value;
                }
            }
        }

        private string nSiRet60;
        /// <summary>
        /// ��ؽ�����Ϣ��־
        /// </summary>
        [DataFieldName("N_SI_RET60"), DataFieldDefault("")]
        public string NSiRet60
        {
            get { return nSiRet60; }
            set
            {
                if (!object.Equals(nSiRet60, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet60"))
                    {
                        modifiedProperty.Add("NSiRet60", nSiRet60);
                        this.IsModified = true;
                    }
                    nSiRet60 = value;
                }
            }
        }

        private string nSiRet61;
        /// <summary>
        /// ����󲡾����ֶ�1���
        /// </summary>
        [DataFieldName("N_SI_RET61"), DataFieldDefault("")]
        public string NSiRet61
        {
            get { return nSiRet61; }
            set
            {
                if (!object.Equals(nSiRet61, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet61"))
                    {
                        modifiedProperty.Add("NSiRet61", nSiRet61);
                        this.IsModified = true;
                    }
                    nSiRet61 = value;
                }
            }
        }

        private string nSiRet62;
        /// <summary>
        /// ����󲡾����ֶ�2���
        /// </summary>
        [DataFieldName("N_SI_RET62"), DataFieldDefault("")]
        public string NSiRet62
        {
            get { return nSiRet62; }
            set
            {
                if (!object.Equals(nSiRet62, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet62"))
                    {
                        modifiedProperty.Add("NSiRet62", nSiRet62);
                        this.IsModified = true;
                    }
                    nSiRet62 = value;
                }
            }
        }

        private string nSiRet63;
        /// <summary>
        /// �󲡾����ֶ�1�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET63"), DataFieldDefault("")]
        public string NSiRet63
        {
            get { return nSiRet63; }
            set
            {
                if (!object.Equals(nSiRet63, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet63"))
                    {
                        modifiedProperty.Add("NSiRet63", nSiRet63);
                        this.IsModified = true;
                    }
                    nSiRet63 = value;
                }
            }
        }

        private string nSiRet64;
        /// <summary>
        /// �󲡾����ֶ�2�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET64"), DataFieldDefault("")]
        public string NSiRet64
        {
            get { return nSiRet64; }
            set
            {
                if (!object.Equals(nSiRet64, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet64"))
                    {
                        modifiedProperty.Add("NSiRet64", nSiRet64);
                        this.IsModified = true;
                    }
                    nSiRet64 = value;
                }
            }
        }

        private string nSiRet65;
        /// <summary>
        /// �󲡾����ֶ�1�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET65"), DataFieldDefault("")]
        public string NSiRet65
        {
            get { return nSiRet65; }
            set
            {
                if (!object.Equals(nSiRet65, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet65"))
                    {
                        modifiedProperty.Add("NSiRet65", nSiRet65);
                        this.IsModified = true;
                    }
                    nSiRet65 = value;
                }
            }
        }

        private string nSiRet66;
        /// <summary>
        /// �󲡾����ֶ�2�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET66"), DataFieldDefault("")]
        public string NSiRet66
        {
            get { return nSiRet66; }
            set
            {
                if (!object.Equals(nSiRet66, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet66"))
                    {
                        modifiedProperty.Add("NSiRet66", nSiRet66);
                        this.IsModified = true;
                    }
                    nSiRet66 = value;
                }
            }
        }

        private string nSiRet67;
        /// <summary>
        /// ����ҽ����Χ20�����Ϸ���
        /// </summary>
        [DataFieldName("N_SI_RET67"), DataFieldDefault("")]
        public string NSiRet67
        {
            get { return nSiRet67; }
            set
            {
                if (!object.Equals(nSiRet67, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet67"))
                    {
                        modifiedProperty.Add("NSiRet67", nSiRet67);
                        this.IsModified = true;
                    }
                    nSiRet67 = value;
                }
            }
        }

        private string nSiRet68;
        /// <summary>
        /// ����ҽ����Χ20�������Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET68"), DataFieldDefault("")]
        public string NSiRet68
        {
            get { return nSiRet68; }
            set
            {
                if (!object.Equals(nSiRet68, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet68"))
                    {
                        modifiedProperty.Add("NSiRet68", nSiRet68);
                        this.IsModified = true;
                    }
                    nSiRet68 = value;
                }
            }
        }

        private string nSiRet69;
        /// <summary>
        /// �����ڲ���
        /// </summary>
        [DataFieldName("N_SI_RET69"), DataFieldDefault("")]
        public string NSiRet69
        {
            get { return nSiRet69; }
            set
            {
                if (!object.Equals(nSiRet69, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet69"))
                    {
                        modifiedProperty.Add("NSiRet69", nSiRet69);
                        this.IsModified = true;
                    }
                    nSiRet69 = value;
                }
            }
        }

        private string nSiRet70;
        /// <summary>
        /// һ����Ӫ����
        /// </summary>
        [DataFieldName("N_SI_RET70"), DataFieldDefault("")]
        public string NSiRet70
        {
            get { return nSiRet70; }
            set
            {
                if (!object.Equals(nSiRet70, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet70"))
                    {
                        modifiedProperty.Add("NSiRet70", nSiRet70);
                        this.IsModified = true;
                    }
                    nSiRet70 = value;
                }
            }
        }

        private string nSiRet71;
        /// <summary>
        /// ������Ӫ����
        /// </summary>
        [DataFieldName("N_SI_RET71"), DataFieldDefault("")]
        public string NSiRet71
        {
            get { return nSiRet71; }
            set
            {
                if (!object.Equals(nSiRet71, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet71"))
                    {
                        modifiedProperty.Add("NSiRet71", nSiRet71);
                        this.IsModified = true;
                    }
                    nSiRet71 = value;
                }
            }
        }

        private string info51;
        /// <summary>
        /// INFO51
        /// </summary>
        [DataFieldName("INFO51"), DataFieldDefault("")]
        public string Info51
        {
            get { return info51; }
            set
            {
                if (!object.Equals(info51, value))
                {
                    if (!modifiedProperty.ContainsKey("Info51"))
                    {
                        modifiedProperty.Add("Info51", info51);
                        this.IsModified = true;
                    }
                    info51 = value;
                }
            }
        }

        private string info52;
        /// <summary>
        /// INFO52
        /// </summary>
        [DataFieldName("INFO52"), DataFieldDefault("")]
        public string Info52
        {
            get { return info52; }
            set
            {
                if (!object.Equals(info52, value))
                {
                    if (!modifiedProperty.ContainsKey("Info52"))
                    {
                        modifiedProperty.Add("Info52", info52);
                        this.IsModified = true;
                    }
                    info52 = value;
                }
            }
        }

        private string info53;
        /// <summary>
        /// INFO53
        /// </summary>
        [DataFieldName("INFO53"), DataFieldDefault("")]
        public string Info53
        {
            get { return info53; }
            set
            {
                if (!object.Equals(info53, value))
                {
                    if (!modifiedProperty.ContainsKey("Info53"))
                    {
                        modifiedProperty.Add("Info53", info53);
                        this.IsModified = true;
                    }
                    info53 = value;
                }
            }
        }

        private string info54;
        /// <summary>
        /// INFO54
        /// </summary>
        [DataFieldName("INFO54"), DataFieldDefault("")]
        public string Info54
        {
            get { return info54; }
            set
            {
                if (!object.Equals(info54, value))
                {
                    if (!modifiedProperty.ContainsKey("Info54"))
                    {
                        modifiedProperty.Add("Info54", info54);
                        this.IsModified = true;
                    }
                    info54 = value;
                }
            }
        }

        private string info55;
        /// <summary>
        /// INFO55
        /// </summary>
        [DataFieldName("INFO55"), DataFieldDefault("")]
        public string Info55
        {
            get { return info55; }
            set
            {
                if (!object.Equals(info55, value))
                {
                    if (!modifiedProperty.ContainsKey("Info55"))
                    {
                        modifiedProperty.Add("Info55", info55);
                        this.IsModified = true;
                    }
                    info55 = value;
                }
            }
        }

        private string info56;
        /// <summary>
        /// INFO56
        /// </summary>
        [DataFieldName("INFO56"), DataFieldDefault("")]
        public string Info56
        {
            get { return info56; }
            set
            {
                if (!object.Equals(info56, value))
                {
                    if (!modifiedProperty.ContainsKey("Info56"))
                    {
                        modifiedProperty.Add("Info56", info56);
                        this.IsModified = true;
                    }
                    info56 = value;
                }
            }
        }

        private string info57;
        /// <summary>
        /// INFO57
        /// </summary>
        [DataFieldName("INFO57"), DataFieldDefault("")]
        public string Info57
        {
            get { return info57; }
            set
            {
                if (!object.Equals(info57, value))
                {
                    if (!modifiedProperty.ContainsKey("Info57"))
                    {
                        modifiedProperty.Add("Info57", info57);
                        this.IsModified = true;
                    }
                    info57 = value;
                }
            }
        }

        private string info58;
        /// <summary>
        /// INFO58
        /// </summary>
        [DataFieldName("INFO58"), DataFieldDefault("")]
        public string Info58
        {
            get { return info58; }
            set
            {
                if (!object.Equals(info58, value))
                {
                    if (!modifiedProperty.ContainsKey("Info58"))
                    {
                        modifiedProperty.Add("Info58", info58);
                        this.IsModified = true;
                    }
                    info58 = value;
                }
            }
        }

        private string info59;
        /// <summary>
        /// INFO59
        /// </summary>
        [DataFieldName("INFO59"), DataFieldDefault("")]
        public string Info59
        {
            get { return info59; }
            set
            {
                if (!object.Equals(info59, value))
                {
                    if (!modifiedProperty.ContainsKey("Info59"))
                    {
                        modifiedProperty.Add("Info59", info59);
                        this.IsModified = true;
                    }
                    info59 = value;
                }
            }
        }

        private string info60;
        /// <summary>
        /// INFO60
        /// </summary>
        [DataFieldName("INFO60"), DataFieldDefault("")]
        public string Info60
        {
            get { return info60; }
            set
            {
                if (!object.Equals(info60, value))
                {
                    if (!modifiedProperty.ContainsKey("Info60"))
                    {
                        modifiedProperty.Add("Info60", info60);
                        this.IsModified = true;
                    }
                    info60 = value;
                }
            }
        }

        private string info61;
        /// <summary>
        /// INFO61
        /// </summary>
        [DataFieldName("INFO61"), DataFieldDefault("")]
        public string Info61
        {
            get { return info61; }
            set
            {
                if (!object.Equals(info61, value))
                {
                    if (!modifiedProperty.ContainsKey("Info61"))
                    {
                        modifiedProperty.Add("Info61", info61);
                        this.IsModified = true;
                    }
                    info61 = value;
                }
            }
        }

        private string info62;
        /// <summary>
        /// INFO62
        /// </summary>
        [DataFieldName("INFO62"), DataFieldDefault("")]
        public string Info62
        {
            get { return info62; }
            set
            {
                if (!object.Equals(info62, value))
                {
                    if (!modifiedProperty.ContainsKey("Info62"))
                    {
                        modifiedProperty.Add("Info62", info62);
                        this.IsModified = true;
                    }
                    info62 = value;
                }
            }
        }

        private string info63;
        /// <summary>
        /// INFO63
        /// </summary>
        [DataFieldName("INFO63"), DataFieldDefault("")]
        public string Info63
        {
            get { return info63; }
            set
            {
                if (!object.Equals(info63, value))
                {
                    if (!modifiedProperty.ContainsKey("Info63"))
                    {
                        modifiedProperty.Add("Info63", info63);
                        this.IsModified = true;
                    }
                    info63 = value;
                }
            }
        }

        private string info64;
        /// <summary>
        /// INFO64
        /// </summary>
        [DataFieldName("INFO64"), DataFieldDefault("")]
        public string Info64
        {
            get { return info64; }
            set
            {
                if (!object.Equals(info64, value))
                {
                    if (!modifiedProperty.ContainsKey("Info64"))
                    {
                        modifiedProperty.Add("Info64", info64);
                        this.IsModified = true;
                    }
                    info64 = value;
                }
            }
        }

        private string info65;
        /// <summary>
        /// INFO65
        /// </summary>
        [DataFieldName("INFO65"), DataFieldDefault("")]
        public string Info65
        {
            get { return info65; }
            set
            {
                if (!object.Equals(info65, value))
                {
                    if (!modifiedProperty.ContainsKey("Info65"))
                    {
                        modifiedProperty.Add("Info65", info65);
                        this.IsModified = true;
                    }
                    info65 = value;
                }
            }
        }

        private string info66;
        /// <summary>
        /// INFO66
        /// </summary>
        [DataFieldName("INFO66"), DataFieldDefault("")]
        public string Info66
        {
            get { return info66; }
            set
            {
                if (!object.Equals(info66, value))
                {
                    if (!modifiedProperty.ContainsKey("Info66"))
                    {
                        modifiedProperty.Add("Info66", info66);
                        this.IsModified = true;
                    }
                    info66 = value;
                }
            }
        }

        private string info67;
        /// <summary>
        /// INFO67
        /// </summary>
        [DataFieldName("INFO67"), DataFieldDefault("")]
        public string Info67
        {
            get { return info67; }
            set
            {
                if (!object.Equals(info67, value))
                {
                    if (!modifiedProperty.ContainsKey("Info67"))
                    {
                        modifiedProperty.Add("Info67", info67);
                        this.IsModified = true;
                    }
                    info67 = value;
                }
            }
        }

        private string info68;
        /// <summary>
        /// INFO68
        /// </summary>
        [DataFieldName("INFO68"), DataFieldDefault("")]
        public string Info68
        {
            get { return info68; }
            set
            {
                if (!object.Equals(info68, value))
                {
                    if (!modifiedProperty.ContainsKey("Info68"))
                    {
                        modifiedProperty.Add("Info68", info68);
                        this.IsModified = true;
                    }
                    info68 = value;
                }
            }
        }

        private string info69;
        /// <summary>
        /// INFO69
        /// </summary>
        [DataFieldName("INFO69"), DataFieldDefault("")]
        public string Info69
        {
            get { return info69; }
            set
            {
                if (!object.Equals(info69, value))
                {
                    if (!modifiedProperty.ContainsKey("Info69"))
                    {
                        modifiedProperty.Add("Info69", info69);
                        this.IsModified = true;
                    }
                    info69 = value;
                }
            }
        }

        private string info70;
        /// <summary>
        /// INFO70
        /// </summary>
        [DataFieldName("INFO70"), DataFieldDefault("")]
        public string Info70
        {
            get { return info70; }
            set
            {
                if (!object.Equals(info70, value))
                {
                    if (!modifiedProperty.ContainsKey("Info70"))
                    {
                        modifiedProperty.Add("Info70", info70);
                        this.IsModified = true;
                    }
                    info70 = value;
                }
            }
        }

        private string operCode;
        /// <summary>
        /// ����Ա
        /// </summary>
        [DataFieldName("OPER_CODE"), DataFieldDefault("")]
        public string OperCode
        {
            get { return operCode; }
            set
            {
                if (!object.Equals(operCode, value))
                {
                    if (!modifiedProperty.ContainsKey("OperCode"))
                    {
                        modifiedProperty.Add("OperCode", operCode);
                        this.IsModified = true;
                    }
                    operCode = value;
                }
            }
        }

        private string validFlag;
        /// <summary>
        /// ��Ч�Ա��
        /// </summary>
        [DataFieldName("VALID_FLAG"), DataFieldDefault("")]
        public string ValidFlag
        {
            get { return validFlag; }
            set
            {
                if (!object.Equals(validFlag, value))
                {
                    if (!modifiedProperty.ContainsKey("ValidFlag"))
                    {
                        modifiedProperty.Add("ValidFlag", validFlag);
                        this.IsModified = true;
                    }
                    validFlag = value;
                }
            }
        }

        private string operName;
        /// <summary>
        /// ����Ա����
        /// </summary>
        [DataFieldName("OPER_NAME"), DataFieldDefault("")]
        public string OperName
        {
            get { return operName; }
            set
            {
                if (!object.Equals(operName, value))
                {
                    if (!modifiedProperty.ContainsKey("OperName"))
                    {
                        modifiedProperty.Add("OperName", operName);
                        this.IsModified = true;
                    }
                    operName = value;
                }
            }
        }

        private string diagCode;
        /// <summary>
        /// ��ϱ���
        /// </summary>
        [DataFieldName("DIAG_CODE"), DataFieldDefault("")]
        public string DiagCode
        {
            get { return diagCode; }
            set
            {
                if (!object.Equals(diagCode, value))
                {
                    if (!modifiedProperty.ContainsKey("DiagCode"))
                    {
                        modifiedProperty.Add("DiagCode", diagCode);
                        this.IsModified = true;
                    }
                    diagCode = value;
                }
            }
        }

        private string diagName;
        /// <summary>
        /// �������
        /// </summary>
        [DataFieldName("DIAG_NAME"), DataFieldDefault("")]
        public string DiagName
        {
            get { return diagName; }
            set
            {
                if (!object.Equals(diagName, value))
                {
                    if (!modifiedProperty.ContainsKey("DiagName"))
                    {
                        modifiedProperty.Add("DiagName", diagName);
                        this.IsModified = true;
                    }
                    diagName = value;
                }
            }
        }

        private string nSiRet72;
        /// <summary>
        /// ����ҽ�Ʒ�֧��
        /// </summary>
        [DataFieldName("N_SI_RET72"), DataFieldDefault("")]
        public string NSiRet72
        {
            get { return nSiRet72; }
            set
            {
                if (!object.Equals(nSiRet72, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet72"))
                    {
                        modifiedProperty.Add("NSiRet72", nSiRet72);
                        this.IsModified = true;
                    }
                    nSiRet72 = value;
                }
            }
        }

        private string nSiRet73;
        /// <summary>
        /// ���˻�ʳ�Ѳ���
        /// </summary>
        [DataFieldName("N_SI_RET73"), DataFieldDefault("")]
        public string NSiRet73
        {
            get { return nSiRet73; }
            set
            {
                if (!object.Equals(nSiRet73, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet73"))
                    {
                        modifiedProperty.Add("NSiRet73", nSiRet73);
                        this.IsModified = true;
                    }
                    nSiRet73 = value;
                }
            }
        }

        private string nSiRet74;
        /// <summary>
        /// ���˸�������֧��
        /// </summary>
        [DataFieldName("N_SI_RET74"), DataFieldDefault("")]
        public string NSiRet74
        {
            get { return nSiRet74; }
            set
            {
                if (!object.Equals(nSiRet74, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet74"))
                    {
                        modifiedProperty.Add("NSiRet74", nSiRet74);
                        this.IsModified = true;
                    }
                    nSiRet74 = value;
                }
            }
        }

        private string nSiRet75;
        /// <summary>
        /// ��������֧��
        /// </summary>
        [DataFieldName("N_SI_RET75"), DataFieldDefault("")]
        public string NSiRet75
        {
            get { return nSiRet75; }
            set
            {
                if (!object.Equals(nSiRet75, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet75"))
                    {
                        modifiedProperty.Add("NSiRet75", nSiRet75);
                        this.IsModified = true;
                    }
                    nSiRet75 = value;
                }
            }
        }

        private string nSiRet76;
        /// <summary>
        /// ��λ�ֵ����
        /// </summary>
        [DataFieldName("N_SI_RET76"), DataFieldDefault("")]
        public string NSiRet76
        {
            get { return nSiRet76; }
            set
            {
                if (!object.Equals(nSiRet76, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet76"))
                    {
                        modifiedProperty.Add("NSiRet76", nSiRet76);
                        this.IsModified = true;
                    }
                    nSiRet76 = value;
                }
            }
        }

        private string nSiRet77;
        /// <summary>
        /// ҽԺ�ֵ����
        /// </summary>
        [DataFieldName("N_SI_RET77"), DataFieldDefault("")]
        public string NSiRet77
        {
            get { return nSiRet77; }
            set
            {
                if (!object.Equals(nSiRet77, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet77"))
                    {
                        modifiedProperty.Add("NSiRet77", nSiRet77);
                        this.IsModified = true;
                    }
                    nSiRet77 = value;
                }
            }
        }

        private string nSiRet78;
        /// <summary>
        /// �������������  
        /// by wwei_neu ̩��ҽ�������µ������ֶ� {DD36466C-98E4-4179-9F0C-04B6FF53E35E} ���ע��
        /// </summary>
        [DataFieldName("N_SI_RET78"), DataFieldDefault("")]
        public string NSiRet78
        {
            get { return nSiRet78; }
            set
            {
                if (!object.Equals(nSiRet78, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet78"))
                    {
                        modifiedProperty.Add("NSiRet78", nSiRet78);
                        this.IsModified = true;
                    }
                    nSiRet78 = value;
                }
            }
        }

        private string nSiRet79;
        /// <summary>
        /// ����ڼ���סԺ  
        /// by wwei_neu ̩��ҽ�������µ������ֶ� {DD36466C-98E4-4179-9F0C-04B6FF53E35E} ���ע��
        /// </summary>
        [DataFieldName("N_SI_RET79"), DataFieldDefault("")]
        public string NSiRet79
        {
            get { return nSiRet79; }
            set
            {
                if (!object.Equals(nSiRet79, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet79"))
                    {
                        modifiedProperty.Add("NSiRet79", nSiRet79);
                        this.IsModified = true;
                    }
                    nSiRet79 = value;
                }
            }
        }

        private string nSiRet80;
        /// <summary>
        /// ǰ���ۼ�  
        /// by wwei_neu ̩��ҽ�������µ������ֶ� {DD36466C-98E4-4179-9F0C-04B6FF53E35E} ���ע��
        /// </summary>
        [DataFieldName("N_SI_RET80"), DataFieldDefault("")]
        public string NSiRet80
        {
            get { return nSiRet80; }
            set
            {
                if (!object.Equals(nSiRet80, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet80"))
                    {
                        modifiedProperty.Add("NSiRet80", nSiRet80);
                        this.IsModified = true;
                    }
                    nSiRet80 = value;
                }
            }
        }
        private string nSiRet81;
        /// <summary>
        /// ����󲡺Ϲ���ø���֧��ǰ���ۼ� add by gq 20140630 {C7681901-719A-4d14-82B2-E60AD783A691}
        /// </summary>
        [DataFieldName("N_SI_RET81"), DataFieldDefault("")]
        public string NSiRet81
        {
            get { return nSiRet81; }
            set
            {
                if (!object.Equals(nSiRet81, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet81"))
                    {
                        modifiedProperty.Add("NSiRet81", nSiRet81);
                        this.IsModified = true;
                    }
                    nSiRet81 = value;
                }
            }
        }

        private string nSiRet82;
        /// <summary>
        /// {716627B2-083B-4b9b-B8C3-3B9C93A3DDB0} ����ͳ�� ���������洢�����ַ��صĽ�� ������20151010
        /// </summary>
        [DataFieldName("N_SI_RET82"), DataFieldDefault("")]
        public string NSiRet82
        {
            get { return nSiRet82; }
            set
            {
                if (!object.Equals(nSiRet82, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet82"))
                    {
                        modifiedProperty.Add("NSiRet82", nSiRet82);
                        this.IsModified = true;
                    }
                    nSiRet82 = value;
                }
            }
        }
        #region {8FBA2B46-8595-4b6f-9AD9-5EE6839AD049} �󲡱���
        private string nSiRet83;
        /// <summary>
        ///����󲡱��շ���
        /// </summary>
        [DataFieldName("N_SI_RET83"), DataFieldDefault("")]
        public string NSiRet83
        {
            get { return nSiRet83; }
            set
            {
                if (!object.Equals(nSiRet83, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet83"))
                    {
                        modifiedProperty.Add("NSiRet83", nSiRet83);
                        this.IsModified = true;
                    }
                    nSiRet83 = value;
                }
            }
        }

        private string nSiRet84;
        /// <summary>
        ///�󲡱���֧�����
        /// </summary>
        [DataFieldName("N_SI_RET84"), DataFieldDefault("")]
        public string NSiRet84
        {
            get { return nSiRet84; }
            set
            {
                if (!object.Equals(nSiRet84, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet84"))
                    {
                        modifiedProperty.Add("NSiRet84", nSiRet84);
                        this.IsModified = true;
                    }
                    nSiRet84 = value;
                }
            }
        }

        private string nSiRet85;
        /// <summary>
        ///����󲡱��շֶ��Ը�
        /// </summary>
        [DataFieldName("N_SI_RET85"), DataFieldDefault("")]
        public string NSiRet85
        {
            get { return nSiRet85; }
            set
            {
                if (!object.Equals(nSiRet85, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet85"))
                    {
                        modifiedProperty.Add("NSiRet85", nSiRet85);
                        this.IsModified = true;
                    }
                    nSiRet85 = value;
                }
            }
        }

        private string nSiRet86;
        /// <summary>
        ///����󲡱��շֶ�1���
        /// </summary>
        [DataFieldName("N_SI_RET86"), DataFieldDefault("")]
        public string NSiRet86
        {
            get { return nSiRet86; }
            set
            {
                if (!object.Equals(nSiRet86, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet86"))
                    {
                        modifiedProperty.Add("NSiRet86", nSiRet86);
                        this.IsModified = true;
                    }
                    nSiRet86 = value;
                }
            }
        }

        private string nSiRet87;
        /// <summary>
        ///����󲡱��շֶ�2���
        /// </summary>
        [DataFieldName("N_SI_RET87"), DataFieldDefault("")]
        public string NSiRet87
        {
            get { return nSiRet87; }
            set
            {
                if (!object.Equals(nSiRet87, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet87"))
                    {
                        modifiedProperty.Add("NSiRet87", nSiRet87);
                        this.IsModified = true;
                    }
                    nSiRet87 = value;
                }
            }
        }

        private string nSiRet88;
        /// <summary>
        ///����󲡱��շֶ�3���
        /// </summary>
        [DataFieldName("N_SI_RET88"), DataFieldDefault("")]
        public string NSiRet88
        {
            get { return nSiRet88; }
            set
            {
                if (!object.Equals(nSiRet88, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet88"))
                    {
                        modifiedProperty.Add("NSiRet88", nSiRet88);
                        this.IsModified = true;
                    }
                    nSiRet88 = value;
                }
            }
        }

        private string nSiRet89;
        /// <summary>
        ///����󲡱��շֶ�1�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET89"), DataFieldDefault("")]
        public string NSiRet89
        {
            get { return nSiRet89; }
            set
            {
                if (!object.Equals(nSiRet89, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet89"))
                    {
                        modifiedProperty.Add("NSiRet89", nSiRet89);
                        this.IsModified = true;
                    }
                    nSiRet89 = value;
                }
            }
        }

        private string nSiRet90;
        /// <summary>
        ///����󲡱��շֶ�2�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET90"), DataFieldDefault("")]
        public string NSiRet90
        {
            get { return nSiRet90; }
            set
            {
                if (!object.Equals(nSiRet90, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet90"))
                    {
                        modifiedProperty.Add("NSiRet90", nSiRet90);
                        this.IsModified = true;
                    }
                    nSiRet90 = value;
                }
            }
        }

        private string nSiRet91;
        /// <summary>
        ///����󲡱��շֶ�3�Ը�����
        /// </summary>
        [DataFieldName("N_SI_RET91"), DataFieldDefault("")]
        public string NSiRet91
        {
            get { return nSiRet91; }
            set
            {
                if (!object.Equals(nSiRet91, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet91"))
                    {
                        modifiedProperty.Add("NSiRet91", nSiRet91);
                        this.IsModified = true;
                    }
                    nSiRet91 = value;
                }
            }
        }

        private string nSiRet92;
        /// <summary>
        ///����󲡱��շֶ�1�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET92"), DataFieldDefault("")]
        public string NSiRet92
        {
            get { return nSiRet92; }
            set
            {
                if (!object.Equals(nSiRet92, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet92"))
                    {
                        modifiedProperty.Add("NSiRet92", nSiRet92);
                        this.IsModified = true;
                    }
                    nSiRet92 = value;
                }
            }
        }

        private string nSiRet93;
        /// <summary>
        ///����󲡱��շֶ�2�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET93"), DataFieldDefault("")]
        public string NSiRet93
        {
            get { return nSiRet93; }
            set
            {
                if (!object.Equals(nSiRet93, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet93"))
                    {
                        modifiedProperty.Add("NSiRet93", nSiRet93);
                        this.IsModified = true;
                    }
                    nSiRet93 = value;
                }
            }
        }

        private string nSiRet94;
        /// <summary>
        ///����󲡱��շֶ�3�Ը�
        /// </summary>
        [DataFieldName("N_SI_RET94"), DataFieldDefault("")]
        public string NSiRet94
        {
            get { return nSiRet94; }
            set
            {
                if (!object.Equals(nSiRet94, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet94"))
                    {
                        modifiedProperty.Add("NSiRet94", nSiRet94);
                        this.IsModified = true;
                    }
                    nSiRet94 = value;
                }
            }
        }
        #endregion
        #region"������������" add by gq 20160711 {66E7D6DE-68F4-4173-B581-841E85BCE4AA}
        private string nSiRet95;
        /// <summary>
        ///�Ƿ�����ҵ��Ա
        /// </summary>
        [DataFieldName("N_SI_RET95"), DataFieldDefault("")]
        public string NSiRet95
        {
            get { return nSiRet95; }
            set
            {
                if (!object.Equals(nSiRet95, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet95"))
                    {
                        modifiedProperty.Add("NSiRet95", nSiRet95);
                        this.IsModified = true;
                    }
                    nSiRet95 = value;
                }
            }
        }

        private string nSiRet96;
        /// <summary>
        ///�󲡱��ջ���֧���ۼ�
        /// </summary>
        [DataFieldName("N_SI_RET96"), DataFieldDefault("")]
        public string NSiRet96
        {
            get { return nSiRet96; }
            set
            {
                if (!object.Equals(nSiRet96, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet96"))
                    {
                        modifiedProperty.Add("NSiRet96", nSiRet96);
                        this.IsModified = true;
                    }
                    nSiRet96 = value;
                }
            }
        }

        private string nSiRet97;
        /// <summary>
        ///�������
        /// </summary>
        [DataFieldName("N_SI_RET97"), DataFieldDefault("")]
        public string NSiRet97
        {
            get { return nSiRet97; }
            set
            {
                if (!object.Equals(nSiRet97, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet97"))
                    {
                        modifiedProperty.Add("NSiRet97", nSiRet97);
                        this.IsModified = true;
                    }
                    nSiRet97 = value;
                }
            }
        }

        private string nSiRet98;
        /// <summary>
        /// ����ҽ���ߵ͵�
        /// ������20170306
        /// </summary>
        [DataFieldName("N_SI_RET98"), DataFieldDefault("")]
        public string NSiRet98
        {
            get { return nSiRet98; }
            set
            {
                if (!object.Equals(nSiRet98, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet98"))
                    {
                        modifiedProperty.Add("NSiRet98", nSiRet98);
                        this.IsModified = true;
                    }
                    nSiRet98 = value;
                }
            }
        }
        private string nSiRet99;
        /// <summary>
        ///�Ƿ�α����˱��� add gq 20161028 {4A600AB0-1F04-4c4d-B69B-292C09D270B1}
        /// </summary>
        [DataFieldName("N_SI_RET99"), DataFieldDefault("")]
        public string NSiRet99
        {
            get { return nSiRet99; }
            set
            {
                if (!object.Equals(nSiRet99, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet99"))
                    {
                        modifiedProperty.Add("NSiRet99", nSiRet99);
                        this.IsModified = true;
                    }
                    nSiRet99 = value;
                }
            }
        }
         #endregion
        #region ������ƶ����֧��
        private string nSiRet100;
        /// <summary>
        ///������ƶ����֧��
        /// </summary>
        [DataFieldName("N_SI_RET100"), DataFieldDefault("")]
        public string NSiRet100
        {
            get { return nSiRet100; }
            set
            {
                if (!object.Equals(nSiRet100, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet100"))
                    {
                        modifiedProperty.Add("NSiRet100", nSiRet100);
                        this.IsModified = true;
                    }
                    nSiRet100 = value;
                }
            }
        }

        private string nSiRet101;
        [DataFieldName("N_SI_RET101"), DataFieldDefault("")]
        public string NSiRet101
        {
            get { return nSiRet101; }
            set
            {
                if (!object.Equals(nSiRet101, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet101"))
                    {
                        modifiedProperty.Add("NSiRet101", nSiRet101);
                        this.IsModified = true;
                    }
                    nSiRet101 = value;
                }
            }
        }
        private string nSiRet102 = "0";

        /// <summary>
        /// 
        /// </summary>
        [DataFieldName("N_SI_RET102"), DataFieldDefault("")]
        public string NSiRet102
        {
            get { return nSiRet102; }
            set
            {
                if (!object.Equals(nSiRet102, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet102"))
                    {
                        modifiedProperty.Add("NSiRet102", nSiRet102);
                        this.IsModified = true;
                    }
                    nSiRet102 = value;
                }
            }
        }

        private string nSiRet103 = "";

        /// <summary>
        /// 
        /// </summary>
        [DataFieldName("N_SI_RET103"), DataFieldDefault("")]
        public string NSiRet103
        {
            get { return nSiRet103; }
            set
            {
                if (!object.Equals(nSiRet103, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet103"))
                    {
                        modifiedProperty.Add("NSiRet103", nSiRet103);
                        this.IsModified = true;
                    }
                    nSiRet103 = value;
                }
            }
        }
        #endregion

        #region {F0F53EE5-A6C7-4223-BA83-BEC5F16A380C}   ̩����ְ��ҽ�����䱣�� han.xzh 2020-06-11

        /// <summary>
        /// ���䱣�ձ������
        /// </summary>
        private string nSiRet104 = "";

        /// <summary>
        /// ���䱣�ձ������
        /// </summary>
        [DataFieldName("N_SI_RET104"), DataFieldDefault("")]
        public string NSiRet104
        {
            get { return nSiRet104; }
            set
            {
                if (!object.Equals(nSiRet104, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet104"))
                    {
                        modifiedProperty.Add("NSiRet104", nSiRet104);
                        this.IsModified = true;
                    }
                    nSiRet104 = value;
                }
            }
        }

        /// <summary>
        /// ���벹�䱣�շ�Χ�ķ���
        /// </summary>
        private string nSiRet105 = "";

        /// <summary>
        /// ���벹�䱣�շ�Χ�ķ���
        /// </summary>
        [DataFieldName("N_SI_RET105"), DataFieldDefault("")]
        public string NSiRet105
        {
            get { return nSiRet105; }
            set
            {
                if (!object.Equals(nSiRet105, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet105"))
                    {
                        modifiedProperty.Add("NSiRet105", nSiRet105);
                        this.IsModified = true;
                    }
                    nSiRet105 = value;
                }
            }
        }

        /// <summary>
        /// ���䱣�ձ���ǰ���ۼ�
        /// </summary>
        private string nSiRet106 = "";

        /// <summary>
        /// ���䱣�ձ���ǰ���ۼ�
        /// </summary>
        [DataFieldName("N_SI_RET106"), DataFieldDefault("")]
        public string NSiRet106
        {
            get { return nSiRet106; }
            set
            {
                if (!object.Equals(nSiRet106, value))
                {
                    if (!modifiedProperty.ContainsKey("NSiRet106"))
                    {
                        modifiedProperty.Add("NSiRet106", nSiRet106);
                        this.IsModified = true;
                    }
                    nSiRet106 = value;
                }
            }
        }

        #endregion
        #endregion

        #region ����
        /// <summary>
        /// ǳ����¡
        /// </summary>
        public new SIReturn Clone()
        {
            // TODO:  ���� SIReturn.Clone ʵ��
            SIReturn obj = base.Clone() as SIReturn;

            return obj;
        }
        #endregion

    }

}