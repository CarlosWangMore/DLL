using System;


namespace Neusoft.HISFC.Object.SIInterface {


	/// <summary>
	/// Insurance ��ժҪ˵����
	/// </summary>
	public class Insurance:Neusoft.NFC.Object.NeuObject
	{
		public Insurance()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}

		private Neusoft.NFC.Object.NeuObject pactInfo = new Neusoft.NFC.Object.NeuObject();
		private Neusoft.NFC.Object.NeuObject kind = new Neusoft.NFC.Object.NeuObject();
		private string partId;
		private Decimal rate;
		private Decimal beginCost;
		private Decimal endCost;
		private Neusoft.NFC.Object.NeuObject operCode =  new Neusoft.NFC.Object.NeuObject();
		private DateTime operDate;
		/// <summary>
		/// ��ͬ��λ��Ϣ
		/// </summary>
		public Neusoft.NFC.Object.NeuObject PactInfo
		{
			set{pactInfo = value;}
			get{return pactInfo;}
		}
		/// <summary>
		/// ��Ա���
		/// </summary>
		public Neusoft.NFC.Object.NeuObject Kind
		{
			set{kind = value;}
			get{return kind;}
		}
		/// <summary>
		/// �ֶ����
		/// </summary>
		public string PartId
		{
			set{partId = value;}
			get{return partId;}
		}
		/// <summary>
		/// �����Ը�����
		/// </summary>
		public Decimal Rate
		{
			set{rate = value;}
			get{return rate;}
		}
		/// <summary>
		/// ���俪ʼ
		/// </summary>
		public Decimal BeginCost
		{
			set{beginCost = value;}
			get{return beginCost;}
		}
		/// <summary>
		/// �������
		/// </summary>
		public Decimal EndCost
		{
			set{endCost = value;}
			get{return endCost;}
		}
		/// <summary>
		/// ����Ա
		/// </summary>
		public Neusoft.NFC.Object.NeuObject OperCode
		{
			set{operCode = value;}
			get{return operCode;}
		}
		public DateTime OperDate
		{
			set{operDate = value;}
			get{return operDate;}
		}
	}
}
