using System;
using Neusoft.NFC.Object;


namespace Neusoft.HISFC.Object.SIInterface {


	/// <summary>
	/// Compare ��ժҪ˵����
	/// </summary>
	public class Compare : Neusoft.NFC.Object.NeuObject 
	{
		public Compare()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		//ҽ��������Ϣ
		private Item centerItem = new Item();
		//������Ŀ����
		private string hisCode;
		//������Ŀ������Ϣ
		private Neusoft.HISFC.Object.Base.Spell spellCode  = new Neusoft.HISFC.Object.Base.Spell(); 
		//������Ŀ���
		private string specs;
		//������Ŀ�۸�
		private Decimal price;
		//������Ŀ����
		private string doseCode;

		private string regularName;
        #region ������Ӧ֢
        //{8FE289B0-3034-442b-A9C3-CDBF7EBDB7B2}
        /// <summary>
        /// �Ƿ�����Ӧ֢
        /// </summary>
        private bool ispracticablesymptom = false;

        /// <summary>
        /// ҩƷ��Ӧ�ȼ���IDΪ����,NAMEΪ���ƣ�
        /// </summary>
        private Neusoft.NFC.Object.NeuObject practicablesymptom = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��Ӧ֢����
        /// </summary>
        private string practicablesymptomdepiction;
        //{8FE289B0-3034-442b-A9C3-CDBF7EBDB7B2} 
        #endregion 

		public string RegularName
		{
			set
			{
				regularName = value;
			}
			get
			{
				return regularName;
			}
		}

		/// <summary>
		/// ҽ��������Ϣ
		/// </summary>
		public Item CenterItem {
			get
			{
				return centerItem;
			}
			set
			{
				centerItem = value;
			}
		}
		/// <summary>
		/// ������Ŀ����
		/// </summary>
		public string HisCode
		{
			get
			{
				return hisCode;
			}
			set
			{
				hisCode = value;
			}
		}

		/// <summary>
		/// ������Ϣ
		/// </summary>
		public Neusoft.HISFC.Object.Base.Spell SpellCode {
			get
			{
				return spellCode;
			}
			set
			{
				spellCode = value;
			}
		}
		/// <summary>
		/// ���
		/// </summary>
		public string Specs
		{
			get
			{
				return specs;
			}
			set
			{
				specs = value;
			}
		}
		/// <summary>
		/// �Ը�����
		/// </summary>
		public Decimal Price
		{
			get
			{
				return price;
			}
			set
			{
				price = value;
			}
		}
		/// <summary>
		/// ���ͱ���
		/// </summary>
		public string DoseCode
		{
			get
			{
				return doseCode;
			}
			set
			{
				doseCode = value;
			}
		}
        #region ������Ӧ֢
        //{8FE289B0-3034-442b-A9C3-CDBF7EBDB7B2}
        /// <summary>
        /// �Ƿ�����Ӧ֢
        /// </summary>
        public bool Ispracticablesymptom
        {
            get
            {
                //{8DF3D566-FA34-44cb-A2D5-919FE05D1702}
                //if (this.practicablesymptomdepiction == "" || this.practicablesymptomdepiction == null)
                if (this.practicablesymptom.ID == "" || this.practicablesymptom.ID == null)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            set
            {
                ispracticablesymptom = value;
            }
        }

        /// <summary>
        /// ҩƷ��Ӧ�ȼ���IDΪ����,NAMEΪ���ƣ�
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Practicablesymptom
        {
            get
            {
                return practicablesymptom;
            }
            set
            {
                practicablesymptom = value;
            }
        }

        /// <summary>
        /// ��Ӧ֢����
        /// </summary>
        public string Practicablesymptomdepiction
        {
            get
            {
                return practicablesymptomdepiction;
            }
            set
            {
                practicablesymptomdepiction = value;
            }
        }
        //{8FE289B0-3034-442b-A9C3-CDBF7EBDB7B2} 
        #endregion

        #region ԭ������ô��û���ϴ����
        private string mUploadFlag = "0";
        /// <summary>
        /// �ϴ����
        /// <value>0����ʼ״̬��δ�ϴ���1�����ϴ���δ��ˣ�2������ˣ�δͨ����3���������ͨ��</value>
        /// </summary>
        public string UploadFlag
        {
            get { return mUploadFlag; }
            set { mUploadFlag = value; }
        }

        private NeuObject extension = new NeuObject();
        /// <summary>
        /// 
        /// </summary>
        public NeuObject Extension
        {
            get { return extension; }
            set { extension = value; }
        }
        #endregion

		public new Compare Clone()
		{
			Compare obj = base.Clone() as Compare;
			obj.centerItem = this.CenterItem.Clone();
			obj.SpellCode = this.SpellCode.Clone();
            obj.practicablesymptom = this.Practicablesymptom.Clone();
			return obj;
		}
	}
}
