using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// ͼƬǩ���õ�ʵ��
    /// </summary>
    public class SignedImage : Neusoft.NFC.Object.NeuObject
    {
        public SignedImage()
        {
        }

        private Neusoft.NFC.Object.NeuObject doct = new Neusoft.NFC.Object.NeuObject();

        private Neusoft.HISFC.Object.Base.OperEnvironment operEnv = new OperEnvironment();

        private Image image;

        private bool valid;

        /// <summary>
        /// ��Ч��
        /// </summary>
        public bool Valid
        {
            get
            {
                return this.valid;
            }
            set
            {
                this.valid = value;
            }
        }

        /// <summary>
        /// ҽ����Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Doct
        {
            get
            {
                return this.doct;
            }
            set
            {
                this.doct = value;
            }
        }

        /// <summary>
        /// ����Ա��Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperEnvironment
        {
            get
            {
                return this.operEnv;
            }
            set
            {
                this.operEnv = value;
            }
        }
        
        /// <summary>
        /// ͼƬ��Ϣ
        /// </summary>
        public Image Image
        {
            get
            {
                return this.image;
            }
            set
            {
                this.image = value;
            }
        }

        public new SignedImage Clone()
        {
            SignedImage sig = base.Clone() as SignedImage;

            sig.operEnv = this.operEnv.Clone();
            sig.doct = this.doct.Clone();
            sig.image = this.image.Clone() as Image;

            return sig;
        }
    }
}
