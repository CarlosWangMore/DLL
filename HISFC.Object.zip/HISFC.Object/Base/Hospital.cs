﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// [功能描述: 医院信息实体]<br></br>
    /// [创 建 者: 周雪松]<br></br>
    /// [创建时间: 2006-12-19]<br></br>
    /// <修改记录
    ///		修改人=''
    ///		修改时间='yyyy-mm-dd'
    ///		修改目的=''
    ///		修改描述=''
    ///  />
    /// 
    /// </summary>
    public class Hospital : Neusoft.NFC.Object.NeuObject
    {

        /// <summary>
        /// 构造函数
        /// </summary>
        public Hospital()
        {
        }
    }
    
}
