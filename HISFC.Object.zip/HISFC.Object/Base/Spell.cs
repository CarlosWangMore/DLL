using System;
using System.Collections;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// Spell<br></br>
    /// [��������: ������ʵ��]<br></br>
    /// [�� �� ��: ����ȫ]<br></br>
    /// [����ʱ��: 2006-08-28]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��='yyyy-mm-dd'
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    [System.Serializable]
    public class Spell : Neusoft.NFC.Object.NeuObject, Neusoft.HISFC.Object.Base.ISpell
    {

        /// <summary>
        /// ���캯��
        /// </summary>
        public Spell()
        {

        }

        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="id">����</param>
        /// <param name="name">����</param>
        /// <param name="memo">��ע</param>
        public Spell(string id, string name, string memo)
            : base(id, name, memo)
        {
            this.spellCode = Neusoft.NFC.Function.Convert.StrGetChinesePYCode(name);
            this.wubiCode = Neusoft.NFC.Function.Convert.StrGetChineseWBCode(name);
        }

        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="id">����</param>
        /// <param name="name">����</param>
        /// <param name="memo">��ע</param>
        /// <param name="pyCode">ƴ����</param>
        /// <param name="wbCode">�����</param>
        /// <param name="customCode">�Զ�����</param>
        public Spell(string id, string name, string memo, string pyCode, string wbCode, string customCode)
            : base(id, name, memo)
        {
            this.spellCode = pyCode;
            this.wubiCode = wbCode;
            this.userCode = customCode;
        }

        #region ����

        /// <summary>
        /// �Ƿ��Ѿ��ͷ���Դ
        /// </summary>
        private bool alreadyDisposed = false;

        /// <summary>
        /// ƴ����
        /// </summary>
        protected string spellCode;

        /// <summary>
        /// �����
        /// </summary>
        protected string wubiCode;

        /// <summary>
        /// �Զ�����
        /// </summary>
        protected string userCode;

        #endregion

        #region ����

        #region �ͷ���Դ

        /// <summary>
        /// �ͷ���Դ
        /// </summary>
        /// <param name="isDisposing"></param>
        protected override void Dispose(bool isDisposing)
        {
            if (this.alreadyDisposed)
            {
                return;
            }

            base.Dispose(isDisposing);

            this.alreadyDisposed = true;
        }

        #endregion

        #region ��¡
        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns>��ǰ��ʵ���ĸ���</returns>
        public new Spell Clone()
        {
            return base.Clone() as Spell;
        }

        #endregion

        #endregion

        #region �ӿ�ʵ��

        #region ISpellCode ��Ա

        /// <summary>
        /// ƴ����
        /// </summary>
        public string SpellCode
        {
            get
            {
                return this.spellCode;
            }
            set
            {
                this.spellCode = value;
            }
        }

        /// <summary>
        /// �����
        /// </summary>
        public string WBCode
        {
            get
            {
                return this.wubiCode;
            }
            set
            {
                this.wubiCode = value;
            }
        }

        /// <summary>
        /// �Զ�����
        /// </summary>
        public string UserCode
        {
            get
            {
                return this.userCode;
            }
            set
            {
                this.userCode = value;
            }
        }

        #endregion

        #endregion



    }
}
