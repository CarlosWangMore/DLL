using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// Const<br></br>
    /// [��������: ��Ϣ�����¼��]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2007-04]<br></br>
    /// 
    /// <˵�� >ID ��Ŀ����</˵��>
    /// </summary>
    public class ShiftRecord : Neusoft.NFC.Object.NeuObject
    {
        public ShiftRecord()
        {

        }

        #region �����

        /// <summary>
        /// �������
        /// </summary>
        private decimal happenNO;

        /// <summary>
        /// ��Ŀ��� 0 ҩƷ 1 ��ҩƷ 2 ����
        /// </summary>
        private string itemType;

        /// <summary>
        /// ԭʼ����
        /// </summary>
        private Neusoft.NFC.Object.NeuObject originalData = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject newData = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ���ԭ��
        /// </summary>
        private string shiftCause;

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// �������
        /// </summary>
        public decimal HappenNO
        {
            get
            {
                return this.happenNO;
            }
            set
            {
                this.happenNO = value;
            }
        }

        /// <summary>
        /// ��Ŀ��� 0 ҩƷ 1 ��ҩƷ 2 ����
        /// </summary>
        public string ItemType
        {
            get
            {
                return this.itemType;
            }
            set
            {
                this.itemType = value;
            }
        }

        /// <summary>
        /// ԭʼ����
        /// </summary>
        public Neusoft.NFC.Object.NeuObject OriginalData
        {
            get
            {
                return this.originalData;
            }
            set
            {
                this.originalData = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject NewData
        {
            get
            {
                return this.newData;
            }
            set
            {
                this.newData = value;
            }
        }

        /// <summary>
        /// ���ԭ��
        /// </summary>
        public string ShiftCause
        {
            get
            {
                return this.shiftCause;
            }
            set
            {
                this.shiftCause = value;
            }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }

        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new ShiftRecord Clone()
        {
            ShiftRecord sfRecord = base.Clone() as ShiftRecord;

            sfRecord.originalData = this.originalData.Clone();

            sfRecord.newData = this.newData.Clone();

            sfRecord.oper = this.oper.Clone();

            return sfRecord;
        }

        #endregion
    }
}
