using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// Const<br></br>
    /// [��������: ����ֶ���]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2007-04]<br></br>
    /// </summary>
    public class ShiftProperty : Neusoft.NFC.Object.NeuObject
    {
        public ShiftProperty()
        {

        }

        #region �����

        /// <summary>
        /// ��ȫ�� �����ռ�
        /// </summary>
        private Neusoft.NFC.Object.NeuObject reflectType = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ���¼�������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject property = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��������
        /// </summary>
        private string propertyDescription;

        /// <summary>
        /// �Ƿ��¼���
        /// </summary>
        private bool isRecord = false;

        /// <summary>
        /// ���ԭ��
        /// </summary>
        private string shiftCause;

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// ������ȫ�� �����ռ�
        /// </summary>
        public Neusoft.NFC.Object.NeuObject ReflectClass
        {
            get
            {
                return reflectType;
            }
            set
            {
                reflectType = value;

                if (value != null)
                {
                    base.ID = value.ID;
                    base.Name = value.Name;
                }
            }
        }

        /// <summary>
        /// ���¼�������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Property
        {
            get
            {
                return this.property;
            }
            set
            {
                this.property = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string PropertyDescription
        {
            get
            {
                return this.propertyDescription;
            }
            set
            {
                this.propertyDescription = value;
            }
        }

        /// <summary>
        /// �Ƿ��¼���
        /// </summary>
        public bool IsRecord
        {
            get
            {
                return this.isRecord;
            }
            set
            {
                this.isRecord = value;
            }
        }

        /// <summary>
        /// ���ԭ��
        /// </summary>
        public string ShiftCause
        {
            get
            {
                return this.shiftCause;
            }
            set
            {
                this.shiftCause = value;
            }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return this.oper;
            }
            set
            {
                this.oper = value;
            }
        }
        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new ShiftProperty Clone()
        {
            ShiftProperty sf = base.Clone() as ShiftProperty;

            sf.reflectType = reflectType.Clone();

            sf.property = property.Clone();

            sf.oper = oper.Clone();

            return sf;
        }

        #endregion
    }
}
