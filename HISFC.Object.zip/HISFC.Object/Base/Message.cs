using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// ID���룬Name��Ϣ����
    /// </summary>
    public class Message : Neusoft.NFC.Object.NeuObject
    {
        /// <summary>
        /// ��Ϣ����
        /// </summary>
        private string text;

        public string Text
        {
            get { return text; }
            set { text = value; }
        }
        /// <summary>
        /// ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject sender = new Neusoft.NFC.Object.NeuObject();

        public Neusoft.NFC.Object.NeuObject Sender
        {
            get { return sender; }
            set { sender = value; }
        }
        /// <summary>
        /// ������
        /// </summary>
        private Neusoft.NFC.Object.NeuObject receiver = new Neusoft.NFC.Object.NeuObject();

        public Neusoft.NFC.Object.NeuObject Receiver
        {
            get { return receiver; }
            set { receiver = value; }
        }
        /// <summary>
        /// �����˿���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject senderDept = new Neusoft.NFC.Object.NeuObject();

        public Neusoft.NFC.Object.NeuObject SenderDept
        {
            get { return senderDept; }
            set { senderDept = value; }
        }
        /// <summary>
        /// �����˿���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject receiverDept = new Neusoft.NFC.Object.NeuObject();

        public Neusoft.NFC.Object.NeuObject ReceiverDept
        {
            get { return receiverDept; }
            set { receiverDept = value; }
        }
        /// <summary>
        /// �Ƿ����״̬ 1���Ķ� 0δ�Ķ�
        /// </summary>
        private bool isRecieved = false;

        public bool IsRecieved
        {
            get { return isRecieved; }
            set { isRecieved = value; }
        }
        /// <summary>
        /// ��Ϣ��������  0���Ķ� 1 �ѻظ� 2 �Ѵ���
        /// </summary>
        private int replyType;

        public int ReplyType
        {
            get { return replyType; }
            set { replyType = value; }
        }
        /// <summary>
        /// ������
        /// </summary>
        private OperEnvironment oper = new OperEnvironment();

        public OperEnvironment Oper
        {
            get { return oper; }
            set { oper = value; }
        }

        /// <summary>
        /// ���߲���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject emr = new Neusoft.NFC.Object.NeuObject();

        public Neusoft.NFC.Object.NeuObject Emr
        {
            get { return emr; }
            set { emr = value; }
        }
        /// <summary>
        /// ����סԺ��ˮ��
        /// </summary>
        private string inpatientNo;

        public string InpatientNo
        {
            get { return inpatientNo; }
            set { inpatientNo = value; }
        }

        
    }
}
