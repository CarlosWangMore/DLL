using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Base
{
    /// <summary>
    /// Logo<br></br>
    /// [��������: ҽ�������]<br></br>
    /// [�� �� ��: ������]<br></br>
    /// [����ʱ��: 2009-10]<br></br>
    /// <˵��
    /// 
    ///         ID MedicalGroupID ��Name MedicalGroupName
    ///  />
    /// </summary>
    public class MedicalGroup : Neusoft.NFC.Object.NeuObject
    {
        public MedicalGroup()
        {

        }

        #region �� ����

        /// <summary>
        /// Ա����Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject empl = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ����ְ��
        /// </summary>
        private Neusoft.NFC.Object.NeuObject groupPosi = new Neusoft.NFC.Object.NeuObject();
    
        /// <summary>
        /// ��չ��Ϣ
        /// </summary>
        private string extend;
      
        /// <summary>
        /// ����������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new OperEnvironment();
       
        #endregion

        #region ����

        /// <summary>
        /// Ա����Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Empl
        {
            get
            {
                return this.empl;
            }
            set
            {
                this.empl = value;
            }
        }

        /// <summary>
        /// ����ְ��
        /// </summary>
        public Neusoft.NFC.Object.NeuObject GroupPosi
        {
            get
            {
                return groupPosi;
            }
            set
            {
                groupPosi = value;
            }
        }

        /// <summary>
        /// ��չ��Ϣ
        /// </summary>
        public string Extend
        {
            get
            {
                return extend;
            }
            set
            {
                extend = value;
            }
        }

        /// <summary>
        /// ����������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            {
                return oper;
            }
            set
            {
                oper = value;
            }
        }


        #endregion

        #region ����

        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns>Logo</returns>
        public new MedicalGroup Clone()
        {
            MedicalGroup info = base.Clone() as MedicalGroup;

            info.Empl = this.Empl.Clone();
            info.GroupPosi = this.GroupPosi.Clone();

            info.Oper = this.Oper.Clone();

            return info;
        }

        #endregion
    }
}
