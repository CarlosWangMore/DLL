using System;
using System.Collections.Generic;
using System.Text;


namespace Neusoft.HISFC.Object.Registration
{
    /// <summary>
    /// ҽ������Ϣʵ��
    /// �����ߣ��볬
    /// ����ʱ�䣺2010.3.8
    /// <˵��>
    /// 
    /// </summary>
    public class SiBigSick : Neusoft.NFC.Object.NeuObject
    {
        /// <summary>
        /// ���캯��
        /// </summary>
        public SiBigSick()
        {
        }

        #region ����
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        private string itemId = string.Empty;
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        private string itemName = string.Empty;
        /// <summary>
        /// ҽ������ϴ���
        /// </summary>
        private string dignoseId = string.Empty;
        /// <summary>
        /// ҽ�����������
        /// </summary>
        private string dignoseName = string.Empty;
        /// <summary>
        /// ҽ���󲡿�ʼʱ��
        /// </summary>
        private DateTime beginDate = new DateTime();
        /// <summary>
        /// ҽ���󲡽���ʱ��
        /// </summary>
        private DateTime endDate = new DateTime();
        /// <summary>
        /// ssn
        /// </summary>
        private string ssn = string.Empty;
        /// <summary>
        ///ƾ֤��
        /// </summary>
        private string priveNo = string.Empty;
        #endregion

        #region ����
        /// <summary>
        /// ��Ŀ����
        /// </summary>
        public new string ID
        {
            get
            {
                return base.ID;
            }
            set
            {
                base.ID = value;
            }
        }
        /// <summary>
        /// ��Ŀ����
        /// </summary>
        public new string Name
        {
            get
            {
                return base.Name;
            }
            set
            {
                base.Name = value;
            }
        }
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        public string ItemId
        {
            set
            {
                this.itemId = value;
            }
            get
            {
                return this.itemId;
            }
        }
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        public string ItemName
        {
            set
            {
                this.itemName = value;
            }
            get
            {
                return this.itemName;
            }
        }
        /// <summary>
        /// ҽ������ϴ���
        /// </summary>
        public string DignoseId
        {
            set
            {
                this.dignoseId = value;
            }
            get
            {
                return this.dignoseId;
            }
        }
        /// <summary>
        /// ҽ�����������
        /// </summary>
        public string DignoseName
        {
            set
            {
                this.dignoseName = value;
            }
            get
            {
                return this.dignoseName;
            }
        }
        /// <summary>
        /// ҽ���󲡿�ʼ����
        /// </summary>
        public DateTime MyBeginDate
        {
            set
            {
                this.beginDate = value;
            }
            get
            {
                return this.beginDate;
            }
        }
        /// <summary>
        /// ҽ���󲡽�ֹ����
        /// </summary>
        public DateTime MyEndDate
        {
            set
            {
                this.endDate = value;
            }
            get
            {
                return this.endDate;
            }
        }
        /// <summary>
        /// ҽ����
        /// </summary>
        public string SSN
        {
            set
            {
                this.ssn = value;
            }
            get
            {
                return this.ssn;
            }
        }
        /// <summary>
        /// ƾ֤��
        /// </summary>
        public string PriveNo
        {
            set
            {
                this.priveNo = value;
            }
            get
            {
                return this.priveNo;
            }
        }
        #endregion

    }
}
