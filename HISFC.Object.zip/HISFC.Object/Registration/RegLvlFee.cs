using System;
using Neusoft.HISFC.Object.Base;

namespace Neusoft.HISFC.Object.Registration
{   
    /// <summary>
    /// <br>RegLvlFee</br>
    /// <br>[��������: �Һŷ�ʵ��]</br>
    /// <br>[�� �� ��: ��С��]</br>
    /// <br>[����ʱ��: 2007-2-1]</br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��='yyyy-mm-dd'
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
	public class RegLvlFee:Neusoft.NFC.Object.NeuObject
	{        
        /// <summary>
        /// �Һŷ�ʵ��
        /// </summary>
		public RegLvlFee()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//            
        }

        #region ����
        /// <summary>
        ///�Һż��� 
        /// </summary>
        private RegLevel regLevel = new RegLevel();

        /// <summary>
        /// ��ͬ��λ
        /// </summary>
        private Neusoft.HISFC.Object.Base.Pact pact = new Pact();
        
        /// <summary>
        /// �Һŷ�
        /// </summary>
        private decimal regFee = 0m;

        /// <summary>
        /// ����
        /// </summary>
        private decimal chkFee = 0m;
        /// <summary>
        /// �Է�����
        /// </summary>
        private decimal ownDigFee = 0m;

        /// <summary>
        /// ��������
        /// </summary>
        private decimal pubDigFee = 0m;
        /// <summary>
        /// ������
        /// </summary>
        private decimal othFee = 0m;

        /// <summary>
        /// ��������
        /// </summary>
        private OperEnvironment oper = new OperEnvironment();
        #endregion

        #region ����

        /// <summary>
        /// �Һż���
        /// </summary>
        public RegLevel RegLevel
        {
            get { return regLevel; }
            set { regLevel = value; }
        }

        /// <summary>
        /// ��ͬ��λ
        /// </summary>
        public Pact Pact
        {
            get { return this.pact; }
            set { this.pact = value; }
        }

        /// <summary>
        /// �Һŷ�
        /// </summary>
        public decimal RegFee
        {
            get { return this.regFee; }
            set { this.regFee = value; }
        }

        private string mRegFeeCode;
        /// <summary>
        /// �Һŷѱ���
        /// </summary>
        public string RegFeeCode
        {
            get { return mRegFeeCode; }
            set { mRegFeeCode = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public decimal ChkFee
        {
            get { return this.chkFee; }
            set { this.chkFee = value; }
        }

        private string mChkFeeCode;
        /// <summary>
        /// ���ѱ���
        /// </summary>
        public string ChkFeeCode
        {
            get { return mChkFeeCode; }
            set { mChkFeeCode = value; }
        }

        /// <summary>
        /// �Է�����
        /// </summary>
        public decimal OwnDigFee
        {
            get { return this.ownDigFee; }
            set { this.ownDigFee = value; }
        }

        private string mOwnDigFeeCode;
        /// <summary>
        /// �Է����ѱ���
        /// </summary>
        public string OwnDigFeeCode
        {
            get { return mOwnDigFeeCode; }
            set { mOwnDigFeeCode = value; }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public decimal PubDigFee
        {
            get { return this.pubDigFee; }
            set { this.pubDigFee = value; }
        }

        private string mPubDigFeeCode;
        /// <summary>
        /// �������ѱ���
        /// </summary>
        public string PubDigFeeCode
        {
            get { return mPubDigFeeCode; }
            set { mPubDigFeeCode = value; }
        }

        /// <summary>
        /// ������
        /// </summary>
        public decimal OthFee
        {
            get { return this.othFee; }
            set { this.othFee = value; }
        }

        private string mOthFeeCode;
        /// <summary>
        /// �����ѱ���
        /// </summary>
        public string OthFeeCode
        {
            get { return mOthFeeCode; }
            set { mOthFeeCode = value; }
        }
 
        /// <summary>
        /// ��������
        /// </summary>
        public OperEnvironment Oper
        {
            get { return oper; }
            set { oper = value; }
        }

        #endregion

        #region ����
        public new RegLvlFee Clone ()
		{
			RegLvlFee regLvlFee = base.Clone() as RegLvlFee;
            regLvlFee.RegLevel = this.regLevel.Clone();
            regLvlFee.Pact = this.pact.Clone();

            return regLvlFee;
		}
        #endregion
    }
}
