using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Order
{
    public class UndrugDept : Neusoft.NFC.Object.NeuObject
    {
        public UndrugDept()
        {
 
        }
        #region ����
        /// <summary>
        /// ���
        /// </summary>
        private string seq;

        /// <summary>
        /// ��Ŀ����
        /// </summary>
        private string item_code;

        /// <summary>
        /// ���Ҵ���
        /// </summary>
        private string dept_code;

        /// <summary>
        /// ��������
        /// </summary>
        private string dept_name;

        /// <summary>
        /// ˳���
        /// </summary>
        private int soid;

        /// <summary>
        /// ������
        /// </summary>
        private string oper_code;

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime oper_date;

        #endregion

        #region ����

        /// <summary>
        /// ���
        /// </summary>
        public string Seq
        {
            get { return seq; }
            set { seq = value; }
        }

        /// <summary>
        /// ��Ŀ����
        /// </summary>
        public string Item_code
        {
            get { return item_code; }
            set { item_code = value; }
        }

        /// <summary>
        /// ���Ҵ���
        /// </summary>
        public string Dept_code
        {
            get { return dept_code; }
            set { dept_code = value; }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string Dept_name
        {
            get { return dept_name; }
            set { dept_name = value; }
        }

        /// <summary>
        /// ˳���
        /// </summary>
        public int Soid
        {
            get { return soid; }
            set { soid = value; }
        }

        /// <summary>
        /// ����Ա
        /// </summary>
        public string Oper_code
        {
            get { return oper_code; }
            set { oper_code = value; }
        }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime Oper_date
        {
            get { return oper_date; }
            set { oper_date = value; }
        }
        #endregion
    }
}
