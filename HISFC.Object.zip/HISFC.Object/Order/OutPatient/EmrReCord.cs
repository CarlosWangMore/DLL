using System;
using Neusoft.HISFC.Object.Base;
using Neusoft.NFC.Object;

namespace Neusoft.HISFC.Object.Order.OutPatient
{
    public class EmrReCord
    {
        public EmrReCord()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ����/����
        /// <summary>
        /// ���
        /// </summary>
        private string seqCode;

        public string SeqCode
        {
            get 
            { 
                return seqCode; 
            }
            set 
            { 
                seqCode = value; 
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        private string cardNo;

        public string CardNo
        {
            get 
            { 
                return cardNo; 
            }
            set 
            { 
                cardNo = value; 
            }
        }

        /// <summary>
        /// ������ˮ��
        /// </summary>
        private string clinicCode;

        public string ClinicCode
        {
            get 
            { 
                return clinicCode; 
            }
            set 
            { 
                clinicCode = value; 
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        private string isBody;

        public string IsBody
        {
            get 
            { 
                return isBody; 
            }
            set 
            {
                isBody = value; 
            }
        }

        /// <summary>
        /// ��ʹ
        /// </summary>
        private string isSore;

        public string IsSore
        {
            get 
            { 
                return isSore; 
            }
            set 
            { 
                isSore = value; 
            }
        }

        /// <summary>
        /// �Ƿ����
        /// </summary>
        private string isCough;

        public string IsCough
        {
            get 
            { 
                return isCough; 
            }
            set 
            { 
                isCough = value; 
            }
        }


        /// <summary>
        /// ������
        /// </summary>
        private string operCode;

        public string OperCode
        {
            get 
            { 
                return operCode; 
            }
            set 
            { 
                operCode = value; 
            }
        }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime operDate;

        public DateTime OperDate
        {
            get 
            { 
                return operDate; 
            }
            set 
            { 
                operDate = value; 
            }
        }
        #endregion
    }
}
