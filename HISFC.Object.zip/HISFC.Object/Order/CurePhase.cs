using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Order
{
    /// <summary>
    /// Neusoft.HISFC.Object.Order.CurePhase<br></br>
    /// [��������: ���ƽ׶���Ϣʵ��]<br></br>
    /// [�� �� ��: Sunm]<br></br>
    /// [����ʱ��: 2007-08-23]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��='yyyy-mm-dd'
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class CurePhase : Neusoft.NFC.Object.NeuObject
    {
        public CurePhase()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ����

        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        private string patientID;

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject dept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ���ƽ׶���Ϣ
        /// </summary>
        private Neusoft.NFC.Object.NeuObject curePhaseInfo = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��ʼʱ��
        /// </summary>
        private DateTime startTime;

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime endTime;

        /// <summary>
        /// ����ҽ��
        /// </summary>
        private Neusoft.NFC.Object.NeuObject doctor = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��ע
        /// </summary>
        private string remark;

        /// <summary>
        /// ��Ч��
        /// </summary>
        private bool isVaild;

        /// <summary>
        /// ������Ϣ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment oper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion

        #region ����

        /// <summary>
        /// סԺ��ˮ��
        /// </summary>
        public string PatientID
        {
            get { return this.patientID; }
            set { this.patientID = value; }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Dept
        {
            get { return this.dept; }
            set { this.dept = value; }
        }

        /// <summary>
        /// ���ƽ׶���Ϣ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject CurePhaseInfo
        {
            get { return this.curePhaseInfo; }
            set { this.curePhaseInfo = value; }
        }

        /// <summary>
        /// ��ʼʱ��
        /// </summary>
        public DateTime StartTime
        {
            get { return this.startTime; }
            set { this.startTime = value; }
        }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime EndTime
        {
            get { return this.endTime; }
            set { this.endTime = value; }
        }

        /// <summary>
        /// ����ҽ��
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Doctor
        {
            get { return this.doctor; }
            set { this.doctor = value; }
        }

        /// <summary>
        /// ��Ч��
        /// </summary>
        public bool IsVaild
        {
            get { return this.isVaild; }
            set { this.isVaild = value; }
        }

        /// <summary>
        /// ��ע
        /// </summary>
        public string Remark
        {
            get { return this.remark; }
            set { this.remark = value; }
        }

        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get { return this.oper; }
            set { this.oper = value; }
        }

        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public new CurePhase Clone()
        {
            // TODO:  ���� CurePhase.Clone ʵ��
            CurePhase obj = base.Clone() as CurePhase;
            
            obj.oper = this.oper.Clone();

            return obj;
        }

        #endregion

        
    }
}
