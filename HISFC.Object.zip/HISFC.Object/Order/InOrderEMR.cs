﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Order
{
    ////{EE98AECB-F208-44C4-ECB1-A50787D547D1} by sunzhiyuan 
    public class InOrderEMR : Neusoft.NFC.Object.NeuObject
    {
        public InOrderEMR()
        {
        }

        private string tablename = "fin_emr_patientinfo";

        /// <summary>
        /// 住院号
        /// </summary>
        private string inpatientNO;
        /// <summary>
        /// 病历
        /// </summary>
        private string diag;

        /// <summary>
        /// 住院号
        /// </summary>
        public string InpatientNO
        {
            get { return inpatientNO; }
            set { inpatientNO = value; }
        }

        /// <summary>
        /// 病历
        /// </summary>
        public string Diag
        {
            get { return diag; }
            set { diag = value; }
        }

        #region 方法
        /// <summary>
        /// 克隆
        /// </summary>
        /// <returns></returns>
        public new InOrderEMR Clone()
        {
            // TODO:  添加 Order.Clone 实现
            InOrderEMR obj = base.Clone() as InOrderEMR;
            return obj;
        }
        #endregion 
    }
}
