using System;
using System.Collections.Generic;
using Neusoft.NFC.Attribute;
using Neusoft.NFC.Management;

namespace Neusoft.HISFC.Object.Order
{
    /// <summary>
    /// TzMetDocIcd<para></para>
    /// [��������: ]<para></para>
    /// [�� �� ��: ]<para></para>
    /// [����ʱ��: 2011-07-18 13:38]<para></para>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  /><para></para>
    /// </summary>
    public class TzMetDocIcd : Neusoft.NFC.Management.NeuObjectExtra
    {
        /// <summary>
        /// һ�㹹�캯��
        /// </summary>
        public TzMetDocIcd()
        {
            objectStatus = ObjectStatus.New;
            pkFields = new string[] { "EmplCode", "Icd" };
        }

        /// <summary>
        /// ����һ��ʵ������¡����ʵ��
        /// </summary>
        public TzMetDocIcd(TzMetDocIcd argObj)
            : base(argObj)
        {
            pkFields = new string[] { "EmplCode", "Icd" };
        }

        #region ����

        #endregion

        #region ����
        /// <summary>
        /// ���ݿ����
        /// </summary>
        public override string TableName
        {
            get { return "TZ_MET_DOC_ICD"; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string ID
        {
            get { return Icd; }
            set { Icd = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public override string Name
        {
            get { return base.Name; }
            set { base.Name = value; }
        }


        private string emplCode;
        /// <summary>
        /// ҽ������
        /// </summary>
        [DataFieldName("EMPL_CODE"), DataFieldDefault("")]
        public string EmplCode
        {
            get { return emplCode; }
            set
            {
                if (!object.Equals(emplCode, value))
                {
                    if (!modifiedProperty.ContainsKey("EmplCode"))
                    {
                        modifiedProperty.Add("EmplCode", emplCode);
                        this.IsModified = true;
                    }
                    emplCode = value;
                }
            }
        }

        private string icd;
        /// <summary>
        /// ���������
        /// </summary>
        [DataFieldName("ICD"), DataFieldDefault("")]
        public string Icd
        {
            get { return icd; }
            set
            {
                if (!object.Equals(icd, value))
                {
                    if (!modifiedProperty.ContainsKey("Icd"))
                    {
                        modifiedProperty.Add("Icd", icd);
                        this.IsModified = true;
                    }
                    icd = value;
                }
            }
        }

        private string userName;
        /// <summary>
        /// �Զ�����
        /// </summary>
        [DataFieldName("USER_NAME"), DataFieldDefault("")]
        public string UserName
        {
            get { return userName; }
            set
            {
                if (!object.Equals(userName, value))
                {
                    if (!modifiedProperty.ContainsKey("UserName"))
                    {
                        modifiedProperty.Add("UserName", userName);
                        this.IsModified = true;
                    }
                    userName = value;
                }
            }
        }

        private string userCode;
        /// <summary>
        /// �Զ�����
        /// </summary>
        [DataFieldName("USER_CODE"), DataFieldDefault("")]
        public string UserCode
        {
            get { return userCode; }
            set
            {
                if (!object.Equals(userCode, value))
                {
                    if (!modifiedProperty.ContainsKey("UserCode"))
                    {
                        modifiedProperty.Add("UserCode", userCode);
                        this.IsModified = true;
                    }
                    userCode = value;
                }
            }
        }

        #endregion

        #region ����
        /// <summary>
        /// ǳ����¡
        /// </summary>
        public new TzMetDocIcd Clone()
        {
            // TODO:  ���� TzMetDocIcd.Clone ʵ��
            TzMetDocIcd obj = base.Clone() as TzMetDocIcd;

            return obj;
        }
        #endregion

    }

}