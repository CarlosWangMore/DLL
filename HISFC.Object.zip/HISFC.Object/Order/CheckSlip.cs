using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.Order
{   
    /// <summary>
    /// ������뵥��Ϣ
    /// </summary>
    public class CheckSlip : Neusoft.NFC.Object.NeuObject
    {
        public CheckSlip()
        {

        }

        #region ����

        /// <summary>
        /// ����
        /// </summary>
        private string checkSlipNo;

        /// <summary>
        /// סԺ��
        /// </summary>
        private string inpatientNO;

        /// <summary>
        /// �����
        /// </summary>
        private string cardNo;

        /// <summary>
        /// ��������
        /// </summary>
        private string doct_dept;

        /// <summary>
        /// ����
        /// </summary>
        private string zsInfo;

        /// <summary>
        /// ��������
        /// </summary>
        private string yxtzInfo;

        /// <summary>
        /// ����ʵ������
        /// </summary>
        private string yxsyInfo;

        /// <summary>
        /// �����
        /// </summary>
        private string diagName;

        /// <summary>
        /// ��鲿λ
        /// </summary>
        private string itemNote;

        /// <summary>
        /// ������ˮ��
        /// </summary>
        private string clinicNo;

        /// <summary>
        /// �Ƿ�Ӽ�(0��ͨ/1�Ӽ�)
        /// </summary>
        private string emcFlag;

        /// <summary>
        /// ��ע
        /// </summary>
        private string moNote;

        /// <summary>
        /// ��չ���1
        /// </summary>
        private string extFlag1;

        /// <summary>
        /// ��չ���2
        /// </summary>
        private string extFlag2;

        /// <summary>
        /// ��չ���3
        /// </summary>
        private string extFlag3;

        /// <summary>
        /// ��չ���4
        /// </summary>
        private string extFlag4;

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime applyDate;

        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime operDate;

        /// <summary>
        /// ����ҽ��
        /// </summary>
        private string doc_code;

        #endregion 

        #region ����

        /// <summary>
        /// ����
        /// </summary>
        public string CheckSlipNo
        {
            get { return checkSlipNo; }
            set { checkSlipNo = value; }
        }

        /// <summary>
        /// סԺ��
        /// </summary>
        public string InpatientNO
        {
            get { return inpatientNO; }
            set { inpatientNO = value; }
        }

        /// <summary>
        /// �����
        /// </summary>
        public string CardNo
        {
            get { return cardNo; }
            set { cardNo = value; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string Doct_dept
        {
            get { return doct_dept; }
            set { doct_dept = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        public string ZsInfo
        {
            get { return zsInfo; }
            set { zsInfo = value; }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public string YxtzInfo
        {
            get { return yxtzInfo; }
            set { yxtzInfo = value; }
        }

        /// <summary>
        /// ����ʵ������
        /// </summary>
        public string YxsyInfo
        {
            get { return yxsyInfo; }
            set { yxsyInfo = value; }
        }

        /// <summary>
        /// �����
        /// </summary>
        public string DiagName
        {
            get { return diagName; }
            set { diagName = value; }
        }

        /// <summary>
        /// ��鲿λ
        /// </summary>
        public string ItemNote
        {
            get { return itemNote; }
            set { itemNote = value; }
        }


        /// <summary>
        /// ������ˮ��
        /// </summary>
        public string ClinicNo
        {
            get { return clinicNo; }
            set { clinicNo = value; }
        }

        /// <summary>
        /// �Ƿ�Ӽ�(0��ͨ/1�Ӽ�)
        /// </summary>
        public string EmcFlag
        {
            get { return emcFlag; }
            set { emcFlag = value; }
        }

        /// <summary>
        /// ��ע
        /// </summary>
        public string MoNote
        {
            get { return moNote; }
            set { moNote = value; }
        }

        /// <summary>
        /// ��չ���1
        /// </summary>
        public string ExtFlag1
        {
            get { return extFlag1; }
            set { extFlag1 = value; }
        }

        /// <summary>
        /// ��չ���2
        /// </summary>
        public string ExtFlag2
        {
            get { return extFlag2; }
            set { extFlag2 = value; }
        }

        /// <summary>
        /// ��չ���3
        /// </summary>
        public string ExtFlag3
        {
            get { return extFlag3; }
            set { extFlag3 = value; }
        }

        /// <summary>
        /// ��չ���4
        /// </summary>
        public string ExtFlag4
        {
            get { return extFlag4; }
            set { extFlag4 = value; }
        }

        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime ApplyDate
        {
            get { return applyDate; }
            set { applyDate = value; }
        }

        /// <summary>
        /// ����ҽ��
        /// </summary>
        public string DocCode
        {
            get { return doc_code; }
            set { doc_code = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        private string zs;
        /// <summary>
        /// ����
        /// </summary>
        public string ZS
        {
            get { return zs; }
            set { zs = value; }
        }

        /// <summary>
        /// �ֲ�ʷ
        /// </summary>
        private string main;
        /// <summary>
        /// �ֲ�ʷ
        /// </summary>
        public string Main
        {
            get { return main; }
            set { main = value; }
        }

        /// <summary>
        /// ����
        /// </summary>
        private string cost;
        /// <summary>
        /// ����
        /// </summary>
        public string Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        /// <summary>
        /// ���뵥���� UC UL
        /// </summary>
        private string type;
        /// <summary>
        /// ���뵥���� UC��� UL����
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }


        /// <summary>
        /// ��ˮ��
        /// </summary>
        private string seqno;
        /// <summary>
        /// ��ˮ��
        /// </summary>
        public string SeqNo
        {
            get { return seqno; }
            set { seqno = value; }
        }

        /// <summary>
        /// �ϲ�����
        /// </summary>
        private string mergetype;
        /// <summary>
        /// �ϲ�����
        /// </summary>
        public string MergeType
        {
            get { return mergetype; }
            set { mergetype = value; }
        }


        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime OperDate
        {
            get { return operDate; }
            set { operDate = value; }
        }
        #endregion 

        #region ����
        /// <summary>
		/// ��¡
		/// </summary>
		/// <returns></returns>
        public new CheckSlip Clone()
        {
            // TODO:  ���� Order.Clone ʵ��
            CheckSlip obj = base.Clone() as CheckSlip;
            return obj;
        }
        #endregion 

    }
}
