using System;

namespace Neusoft.HISFC.Object.Board
{
	/// <summary>
	/// Item ��ժҪ˵����
	/// ��ʳ��Ŀ��Ϣʵ��
	/// </summary>
	public class Item:Neusoft.HISFC.Object.Base.Item
	{
        /// <summary>
        /// ִ�п���
        /// </summary>
        private Neusoft.NFC.Object.NeuObject executeDept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ִ�п���
        /// </summary>
        public Neusoft.NFC.Object.NeuObject ExecuteDept
        {
            get
            {
                return this.executeDept;
            }
            set
            {
                this.executeDept = value;
            }
        }


		public Item()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}

        /// <summary>
        /// ���ƶ���
        /// </summary>
        /// <returns>ʵ��</returns>
        public new Item Clone()
        {
            Item item = base.Clone() as Item;
            item.executeDept = this.executeDept.Clone();

            return item;
        }
	}
}
