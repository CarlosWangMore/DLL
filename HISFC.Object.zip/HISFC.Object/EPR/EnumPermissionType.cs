using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.EPR
{
    [Serializable]
    public enum EnumPermissionType
    {
        Order = 0,
        EMR = 1,
        Medical = 2
    }
}
