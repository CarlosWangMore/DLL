using System;
using System.Collections;
namespace Neusoft.HISFC.Object.EPR
{
	/// <summary>
	/// EMR ��ժҪ˵����
	/// ���Ӳ���ʵ��
	/// id inpatientNo,name ��������
	/// </summary>
    [Serializable]
	public class EMR:Neusoft.NFC.Object.NeuObject 
	{
		public EMR()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		/// <summary>
		/// ��������
		/// </summary>
		public Neusoft.NFC.Object.NeuObject Type=new Neusoft.NFC.Object.NeuObject();
		public string FullFileName;
		public ArrayList Folders;

		public string strFolders
		{
			get
			{
				return strFolder;
			}
			set
			{
				strFolder=value;
				try
				{
					string[] s=strFolder.Split('\\');
					this.Folders=new ArrayList();
					for(int i=0;i<s.GetUpperBound(0);i++)
					{
						this.Folders.Add(s[i]);
					}
				}
				catch{}
			}
		}

		public string FileName;
		public string HostIP="127.0.0.1";
		private string strFolder;
	}
}
