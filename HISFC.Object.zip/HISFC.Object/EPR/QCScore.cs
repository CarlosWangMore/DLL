
namespace Neusoft.HISFC.Object.EPR
{
    /// <summary>
    /// QCScoreSet ��ժҪ˵����
    /// </summary>
    [System.Serializable]
    public class QCScore : Neusoft.NFC.Object.NeuObject
    {
        public QCScore()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }
        private Neusoft.HISFC.Object.RADT.PatientInfo myPatientInfo = new Neusoft.HISFC.Object.RADT.PatientInfo();
        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.RADT.PatientInfo PatientInfo
        {
            get
            {
                return this.myPatientInfo;
            }
            set
            {
                this.myPatientInfo = value;
            }
        }
        private string type;
        /// <summary>
        /// ��Ŀ���
        /// </summary>
        public string Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }

        private string totalScore;
        /// <summary>
        /// ��Ŀ����ܷ�ֵ
        /// </summary>
        public string TotalScore
        {
            get
            {
                return this.totalScore;
            }
            set
            {
                this.totalScore = value;
            }
        }
        private string miniScore;
        /// <summary>
        /// ��С��ֵ
        /// </summary>
        public string MiniScore
        {
            get
            {
                return this.miniScore;
            }
            set
            {
                this.miniScore = value;
            }
        }
        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns></returns>
        public QCScore Clone()
        {
            QCScore score = base.Clone() as QCScore;
            score.PatientInfo = this.PatientInfo.Clone();
            return score;
        }
    }
}