using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.PhysicalExamination
{
    /// <summary>
    /// Suggestion<br></br>
    /// [��������: ��콨�鱣��]<br></br>
    /// [�� �� ��: �ſ���]<br></br>
    /// [����ʱ��: 2007-06-10]<br></br>
    /// <�޸ļ�¼ 
    ///		�޸���='' 
    ///		�޸�ʱ��='yyyy-mm-dd' 
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class Suggestion : Neusoft.NFC.Object.NeuObject
    { 
        #region ˽�б���
        //���к�
        private string seqNO = string.Empty;
        //�����ˮ��
        private string chkClinicNo = string.Empty; 
        //�����
        private string itemValue = string.Empty;
        //��콨��
        private SuggestionRule suggestions = new SuggestionRule();
        //����Ա��Ϣ
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

        #endregion 

        #region  ��������

        /// <summary>
        /// ��ˮ��
        /// </summary>
        public string SeqNO
        {
            get
            {
                return seqNO;
            }
            set
            {
                seqNO = value;
            }
        }

        /// <summary>
        /// �����ˮ��
        /// </summary>
        public string ChkClinicNo
        {
            get
            {
                return chkClinicNo;
            }
            set
            {
                chkClinicNo = value;
            }
        }

        /// <summary>
        /// �����
        /// </summary>
        public string ItemValue
        {
            get
            {
                return itemValue;
            }
            set
            {
                itemValue = value;
            }
        }
        /// <summary>
        /// ��콨��
        /// </summary>
        public SuggestionRule Suggestions
        {
            get
            {
                return suggestions;
            }
            set
            {
                suggestions = value;
            }
        }

        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }
        #endregion 
    }
}
