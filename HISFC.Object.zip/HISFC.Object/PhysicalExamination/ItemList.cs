using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.PhysicalExamination
{
    /// <summary>
    /// ItemList<br></br>
    /// [��������: ����շ���Ŀ��]<br></br>
    /// [�� �� ��: �ſ���]<br></br>
    /// [����ʱ��: 2007-03-2]<br></br>
    /// <�޸ļ�¼ 
    ///		�޸���='' 
    ///		�޸�ʱ��='yyyy-mm-dd' 
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class ItemList : NFC.Object.NeuObject
    {
        #region ˽�б��� 
        /// <summary>
        /// ��λ��ʶ 1 ҩƷ 2 ��ҩƷ 3��ϸ 4����
        /// </summary>
        private string unitFlag = string.Empty;

        /// <summary>
        /// ������� 1  ������� 2 ������� 
        /// </summary>
        private string chkFlag = string.Empty; 

        /// <summary>
        /// ������
        /// </summary>
        private string clinicNO = string.Empty; 

        /// <summary>
        /// ���￨��
        /// </summary>
        private string cardNO = string.Empty; 

        /// <summary>
        /// �Żݱ���
        /// </summary>
        private decimal ecoRate ;

        /// <summary>
        /// �Żݽ��
        /// </summary>
        private decimal realCost;

        /// <summary>
        /// ��Ϻ�
        /// </summary>
        private string comNO = string.Empty; 
 
        /// <summary>
        /// ���к�
        /// </summary>
        private string sequenceNO = string.Empty;  

        /// <summary>
        /// ȷ����
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment conformOper = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ����Ա
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        /// <summary>
        /// �շ�ԱԱ
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment feeOperInfo = new Neusoft.HISFC.Object.Base.OperEnvironment(); 

        /// <summary>
        /// ִ�п���
        /// </summary>
        private NFC.Object.NeuObject execDept = new Neusoft.NFC.Object.NeuObject();

        /// <summary>
        /// ��Ŀ
        /// </summary>
        private Neusoft.HISFC.Object.Fee.Item.Undrug item = new Neusoft.HISFC.Object.Fee.Item.Undrug();

        /// <summary>
        /// �Ƿ��Ѿ��ն�ȷ��
        /// </summary>
        private string isConfirm = string.Empty;
       
        /// <summary>
        /// ��������
        /// </summary>
        private decimal noBackQty;

        /// <summary>
        /// ����ҽ��
        /// </summary>
        private NFC.Object.NeuObject recipeDoc = new NFC.Object.NeuObject(); 
 
        /// <summary>
        /// ��������
        /// </summary>
        private NFC.Object.NeuObject recipeDept = new NFC.Object.NeuObject();
        /// <summary>
        /// ��Ϻ�
        /// </summary>
        private string combo = string.Empty;
        /// <summary>
        /// �շѱ�־
        /// </summary>
        private string feeFlag = string.Empty;
        private string recipeSequence = string.Empty; //���һ�η�Ʊ��Ϻ�
        private string accountFlag = string.Empty;
        #endregion

        #region ����
        /// <summary>
        /// ���˻���־ 0 û�п��˻� 1 �Ѿ����˻�
        /// </summary>
        public string AccountFlag
        {
            get
            {
                return accountFlag;
            }
            set
            {
                accountFlag = value;
            }
        }
        /// <summary>
        /// ���һ�η�Ʊ��Ϻ�
        /// </summary>
        public string RecipeSequence
        {
            get
            {
                return recipeSequence;
            }
            set
            {
                recipeSequence = value;
            }
        }
        /// <summary>
        /// �շѲ���Ա
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment FeeOperInfo
        {
            get
            {
                return feeOperInfo;
            }
            set
            {
                feeOperInfo = value;
            }
        }
        /// <summary>
        /// �շѱ�־  0 δ�շѣ�1�����շѣ�2����
        /// </summary>
        public string FeeFlag
        {
            get
            {
                return feeFlag;
            }
            set
            {
                feeFlag = value;
            }
        }
        /// <summary>
        /// ��Ϻ�
        /// </summary>
        public string Combo
        {
            get
            {
                return combo;
            }
            set
            {
                combo = value;
            }
        }
        /// <summary>
        /// ʵ�ս��
        /// </summary>
        public decimal RealCost
        {
            get
            {
                return realCost;
            }
            set
            {
                realCost = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public NFC.Object.NeuObject RecipeDept
        {
            get
            { 
                return recipeDept;
            }
            set
            {
                recipeDept = value;
            }
        }

        /// <summary>
        /// ����ҽ��
        /// </summary>
        public NFC.Object.NeuObject RecipeDoc  
        {
            get
            { 
                return recipeDoc;
            }
            set
            {
                recipeDoc = value;
            }
        }

        /// <summary>
        /// ������� 1������� 2 �������
        /// </summary>
        public string ChkFlag
        {
            get
            {
                return chkFlag;
            }
            set
            {
                chkFlag = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public decimal NoBackQty
        {
            get
            {
                return noBackQty;
            }
            set
            {
                noBackQty = value;
            }
        }

        /// <summary>
        /// ȷ�ϱ�־
        /// </summary>
        public string IsConfirm
        {
            get
            {
                return isConfirm;
            }
            set
            {
                isConfirm = value;
            }
        }

        /// <summary>
        /// ���к�
        /// </summary>
        public string SequenceNO
        {
            get
            {
                return sequenceNO;
            }
            set
            {
                sequenceNO = value;
            }
        }

        /// <summary>
        /// ��Ϻ�
        /// </summary>
        public string ComNO
        {
            get
            {
                return comNO;
            }
            set
            {
                comNO = value;
            }
        }

        /// <summary>
        /// ��Ŀ
        /// </summary>
        public Neusoft.HISFC.Object.Fee.Item.Undrug Item
        {
            get
            { 
                return item;
            }
            set
            {
                item = value;
            }
        }

        /// <summary>
        /// ִ�п���
        /// </summary>
        public NFC.Object.NeuObject ExecDept
        {
            get
            { 
                return execDept;
            }
            set
            {
                execDept = value;
            }
        }

        /// <summary>
        /// ����Ա
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }

        /// <summary>
        /// �Żݱ���
        /// </summary>
        public decimal EcoRate
        {
            get
            {
                return ecoRate;
            }
            set
            {
                ecoRate = value;
            }
        }

        /// <summary>
        /// ȷ����
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment ConformOper
        {
            get
            { 
                return conformOper;
            }
            set
            {
                conformOper = value;
            }
        }

        /// <summary>
        /// ���￨��
        /// </summary>
        public string CardNO
        {
            get
            {
                return cardNO;
            }
            set
            {
                cardNO = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public string ClinicNO
        {
            get
            {
                return clinicNO;
            }
            set
            {
                clinicNO = value;
            }
        }

        /// <summary>
        /// ��λ��ʶ 0ҩƷ/1 ��ҩƷ/2����/3������Ŀ
        /// </summary>
        public string UnitFlag
        {
            get
            {
                return unitFlag;
            }
            set
            {
                unitFlag = value;
            }
        }
        #endregion 

        #region ��������
        /// <summary>
        /// ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� ClinicNO ����", true)]
        public string ClinicNo
        {
            get
            {
                return clinicNO;
            }
            set
            {
                clinicNO = value;
            }
        }

        /// <summary>
        /// ���￨��
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� CardNO ����", true)]
        public string CardNo
        {
            get
            {
                return cardNO;
            }
            set
            {
                cardNO = value;
            }
        }

        /// <summary>
        /// ��Ϻ�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� ComNO ����", true)]
        public string ComNo
        {
            get
            {
                return comNO;
            }
            set
            {
                comNO = value;
            }
        }

        /// <summary>
        /// ���к�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� SequenceNO ����", true)]
        public string SequenceNo
        {
            get
            {
                return sequenceNO;
            }
            set
            {
                sequenceNO = value;
            }
        }

        /// <summary>
        /// ȷ������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� ConformOper.OperTime ����", true)]
        public System.DateTime ConformDate
        {
            //get
            //{
            //    //return conformTime;
            //}
            set
            {
                //conformTime = value;
            }
        }

        /// <summary>
        /// ȷ�ϱ�־
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� ISConfirm ����", true)]
        public string ConfirmFlag 
        {
            get
            {
                return isConfirm;
            }
            set
            {
                isConfirm = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� NoBackQty ����", true)]
        public decimal NoBackNum
        {
            get
            {
                return noBackQty;
            }
            set
            {
                noBackQty = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� OperInfo ��Ĳ���ʱ����� ����", true)]
        public System.DateTime OperDate
        {
            get
            {
                return operDate;
            }
            set
            {
                operDate = value;
            }
        }

        /// <summary>
        /// ����Ա
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� OperInfo ����", true)]
        public Neusoft.HISFC.Object.Base.OperEnvironment Oper
        {
            get
            { 
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }

        /// <summary>
        /// ��չ��־
        /// </summary>
        //[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]
        public string ExtChar1
        {
            get
            {
                return extChar1;
            }
            set
            {
                extChar1 = value;
            }
        }

        /// <summary>
        /// �Ƽ۵�λ
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ,��item.PriceUnit", true)]
        public string ExtChar
        {
            get
            {
                return extChar;
            }
            set
            {
                extChar = value;
            }
        }

        /// <summary>
        /// �Ż�ǰ�۸�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ��Item �е� Price ����", true)]
        public decimal ExtNumber1
        {
            get
            {
                return extNumber1;
            }
            set
            {
                extNumber1 = value;
            }
        }

        /// <summary>
        /// �Żݺ�۸�
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ��RealCost����  ", true)]
        public decimal ExtNumber
        {
            get
            {
                return extNumber;
            }
            set
            {
                extNumber = value;
            }
        }

        /// <summary>
        /// ��չ��־
        /// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� �� Combo����", true)]
        public string ExtFlag1
        {
            get
            {
                return extFlag1;
            }
            set
            {
                extFlag1 = value;
            }
        }

        /// <summary>
        /// ��չ��־
        /// </summary>
        //[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]
        public string ExtFlag
        {
            get
            {
                return extFlag;
            }
            set
            {
                extFlag = value;
            }
        }
        #endregion 

        #region ��������

        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("���� ��OperInfo �ڵĲ���ʱ�����", true)]
        private System.DateTime operDate;

        //[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]
        private string extFlag; 
   
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]                    
        private decimal extNumber;

        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]                      
        private string extChar; 

        //[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]                  
        private string extFlag1;

        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]                        
        private decimal extNumber1;

        //[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never), System.Obsolete("����", true)]                        
        private string extChar1;

        #endregion 

        #region ��¡����
        public new ItemList Clone()
        {
            ItemList obj = base.Clone() as ItemList;
            obj.item = this.item.Clone();
            obj.execDept = this.ExecDept.Clone();//(neusoft.HISFC.Object.Fee.Invoice)Invoice.Clone();
            obj.operInfo = this.OperInfo.Clone();
            obj.conformOper = this.ConformOper.Clone();
            return obj;
        }
        #endregion 
    }

}
