using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.PhysicalExamination
{
    /// <summary>
    /// SuggestionRuleDetail<br></br>
    /// [��������: ��콨�������ϸ]<br></br>
    /// [�� �� ��: �ſ���]<br></br>
    /// [����ʱ��: 2007-06-10]<br></br>
    /// <�޸ļ�¼ 
    ///		�޸���='' 
    ///		�޸�ʱ��='yyyy-mm-dd' 
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class SuggestionRuleDetail :Neusoft.NFC.Object.NeuObject
    {
        #region ˽�б���  
        // ID ������ϸ����
        //Name ������ϸ����
        private SuggestionRule rule = new SuggestionRule(); //������ 
        private Neusoft.NFC.Object.NeuObject itemType = new Neusoft.NFC.Object.NeuObject();//��������
        private Neusoft.NFC.Object.NeuObject firstOperation = new Neusoft.NFC.Object.NeuObject();//��������1
        private Neusoft.NFC.Object.NeuObject firstDetailValue = new Neusoft.NFC.Object.NeuObject();//ֵ1
        private Neusoft.NFC.Object.NeuObject secondOperation = new Neusoft.NFC.Object.NeuObject();//��������2
        private Neusoft.NFC.Object.NeuObject secondDetailValue = new Neusoft.NFC.Object.NeuObject();//ֵ2
        //����Ա��Ϣ
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion 

        #region  �������� 
        /// <summary>
        /// ���� 
        /// </summary>
        public SuggestionRule Rule
        {
            get
            {
                return rule;
            }
            set
            {
                rule = value;
            }
        } 
        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject FirstOperation
        {
            get
            {
                return firstOperation;
            }
            set
            {
                firstOperation = value;
            }
        }
        /// <summary>
        /// ֵ1
        /// </summary>
        public Neusoft.NFC.Object.NeuObject FirstDetailValue
        {
            get
            {
                return firstDetailValue;
            }
            set
            {
                firstDetailValue = value;
            }
        }
        /// <summary>
        ///�������� 
        /// </summary>
        public Neusoft.NFC.Object.NeuObject ItemType
        {
            get
            {
                return itemType;
            }
            set
            {
                itemType = value;
            }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject SecondOperation
        {
            get
            {
                return secondOperation;
            }
            set
            {
                secondOperation = value;
            }
        }
        /// <summary>
        /// ֵ
        /// </summary>
        public Neusoft.NFC.Object.NeuObject SecondDetailValue
        {
            get
            {
                return secondDetailValue;
            }
            set
            {
                secondDetailValue = value;
            }
        }
        #endregion 

        #region ��¡����
        #endregion 
    }
}
