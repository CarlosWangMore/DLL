using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.PhysicalExamination
{
    /// <summary>
    /// SuggestionRule<br></br>
    /// [��������: ��콨�����]<br></br>
    /// [�� �� ��: �ſ���]<br></br>
    /// [����ʱ��: 2007-06-10]<br></br>
    /// <�޸ļ�¼ 
    ///		�޸���='' 
    ///		�޸�ʱ��='yyyy-mm-dd' 
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// </summary>
    public class SuggestionRule : Neusoft.NFC.Object.NeuObject, Neusoft.HISFC.Object.Base.IValid,Neusoft.HISFC.Object.Base.ISpell
    {
        #region ˽�б���
        //ID �������
        //Name ��������
        private bool isValid = true; //��Ч��־
        private string spellCode = string.Empty; //ƴ����
        private string wbCode = string.Empty;//�����
        private string userCode = string.Empty;//�Զ�����
        private string suggestionValue = string.Empty;//����
        private Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        #endregion

        #region ��������

        /// <summary>
        /// ����Ա��Ϣ
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }
        /// <summary>
        /// ����
        /// </summary>
        public string SuggestionValue
        {
            get
            {
                return suggestionValue;
            }
            set
            {
                suggestionValue = value;
            }
        }

        #region IValid ��Ա
        /// <summary>
        /// ��Ч��־
        /// </summary>
        public bool IsValid
        {
            get
            {
                return isValid;
            }
            set
            {
                isValid = value;
            }
        }
        #endregion

        #region ISpell ��Ա
        /// <summary>
        /// ƴ����
        /// </summary>
        public string SpellCode
        {
            get
            {
                return spellCode;
            }
            set
            {
                spellCode = value;
            }
        }
        /// <summary>
        /// �����
        /// </summary>
        public string WBCode
        {
            get
            {
                return wbCode;
            }
            set
            {
                wbCode = value;
            }
        }
        /// <summary>
        /// �Զ�����
        /// </summary>
        public string UserCode
        {
            get
            {
                return userCode;
            }
            set
            {
                userCode = value;
            }
        }

        #endregion

        #endregion 

        #region ��¡����
        /// <summary>
        /// ��¡����
        /// </summary>
        /// <returns></returns>
        public new SuggestionRule Clone()
        {
            SuggestionRule obj = base.Clone() as SuggestionRule;
            obj.operInfo = this.operInfo.Clone();
            return obj;
        }
        #endregion
    }
}