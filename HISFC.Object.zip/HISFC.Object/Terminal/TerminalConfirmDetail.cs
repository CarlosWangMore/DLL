using Neusoft.NFC.Object;


namespace Neusoft.HISFC.Object.Terminal
{
    /// <summary>
    /// TerminalConfirmDetail <br></br>
    /// [��������: �ն�ȷ��ҵ����ϸ]<br></br>
    /// [�� �� ��: ��һ��]<br></br>
    /// [����ʱ��: 2007-3-1]<br></br>
    /// <˵��>
    ///     1��  {F8383442-78B0-40c2-B906-50BA52ADB139}  ����ʵ������ ִ���豸��ִ�м�ʦ
    /// </˵��>
    /// </summary>
    public class TerminalConfirmDetail : Neusoft.NFC.Object.NeuObject
    {
        public TerminalConfirmDetail()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ����

        /// <summary>
        /// ���뵥��Ϣ
        /// </summary>
        TerminalApply terminalApply = new TerminalApply();

        /// <summary>
        /// ҽԺ�������
        /// </summary>
        Neusoft.NFC.Object.NeuObject hospital = new NeuObject();

        /// <summary>
        /// ��¼��ˮ��
        /// </summary>
        string sequence = "";

        /// <summary>
        /// ʣ������
        /// </summary>
        decimal freeCount = 0m;

        /// <summary>
        /// ״̬
        /// </summary>
        Neusoft.NFC.Object.NeuObject status = new NeuObject();
        private string moOrder = ""; //ҽ����ˮ��
        private string execMoOrder = "";//ҽ������ˮ��
        //����Ա
        Neusoft.HISFC.Object.Base.OperEnvironment operInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();
        //������
        Neusoft.HISFC.Object.Base.OperEnvironment cancelInfo = new Neusoft.HISFC.Object.Base.OperEnvironment();

        //ִ���豸
        private string execDevice = "";

        //ִ�м�ʦ
        Neusoft.HISFC.Object.Base.Employee oper = new Neusoft.HISFC.Object.Base.Employee();

        #endregion

        #region ����

        /// <summary>
        /// ִ���豸
        /// </summary>
        public string ExecDevice
        {
            get
            {
                return execDevice;
            }
            set
            {
                execDevice = value;
            }
        }

        /// <summary>
        /// ִ�м�ʦ
        /// </summary>
        public Neusoft.HISFC.Object.Base.Employee Oper
        {
            get
            {
                return oper;
            }
            set
            {
                oper = value;
            }
        }

        /// <summary>
        /// ����Ա 
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment OperInfo
        {
            get
            {
                return operInfo;
            }
            set
            {
                operInfo = value;
            }
        }

        /// <summary>
        /// ������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment CancelInfo
        {
            get
            {
                return cancelInfo;
            }
            set
            {
                cancelInfo = value;
            }
        }

        /// <summary>
        /// ���뵥��Ϣ
        /// </summary>
        public TerminalApply Apply
        {
            get
            {
                return this.terminalApply;
            }
            set
            {
                this.terminalApply = value;
            }
        }


        /// <summary>
        /// ҽԺ�������
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Hospital
        {
            get
            {
                return this.hospital;
            }
            set
            {
                this.hospital = value;
            }
        }

        /// <summary>
        /// ��¼��ˮ��
        /// </summary>
        public string Sequence
        {
            get
            {
                return this.sequence;
            }
            set
            {
                this.sequence = value;
            }
        }

        /// <summary>
        /// ʣ������
        /// </summary>
        public decimal FreeCount
        {
            get
            {
                return this.freeCount;
            }
            set
            {
                this.freeCount = value;
            }
        }

        /// <summary>
        /// ״̬
        /// </summary>
        public Neusoft.NFC.Object.NeuObject Status
        {
            get
            {
                return this.status;
            }
            set
            {
                this.status = value;
            }
        }
        /// <summary>
        /// ҽ����ˮ��
        /// </summary>
        public string MoOrder
        {
            get
            {
                return moOrder;
            }
            set
            {
                moOrder = value;
            }
        }
        /// <summary>
        /// ҽ����ִ����ˮ��
        /// </summary>
        public string ExecMoOrder
        {
            get
            {
                return execMoOrder;
            }
            set
            {
                execMoOrder = value;
            }
        }
        #endregion

        #region ����

        /// <summary>
        /// ��¡
        /// </summary>
        /// <returns>�ն�ȷ����ϸ</returns>
        public new TerminalConfirmDetail Clone()
        {
            TerminalConfirmDetail terminalConfirmDetail = base.Clone() as TerminalConfirmDetail;

            terminalConfirmDetail.Apply = this.Apply.Clone();
            terminalConfirmDetail.Hospital = this.Hospital.Clone();
            terminalConfirmDetail.Status = this.Status.Clone();
            terminalConfirmDetail.oper = this.Oper.Clone();

            return terminalConfirmDetail;
        }

        #endregion
    }
}
