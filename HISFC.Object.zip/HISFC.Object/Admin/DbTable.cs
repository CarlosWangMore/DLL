using System;
using System.Collections.Generic;
using Neusoft.NFC.Attribute;
using Neusoft.NFC.Management;

namespace Neusoft.HISFC.Object.Admin
{
    /// <summary>
    /// DbTable<para></para>
    /// [��������: ���ݿ����(�������)]<para></para>
    /// [�� �� ��: �����]<para></para>
    /// [����ʱ��: 2011-09-08 17:12]<para></para>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  /><para></para>
    /// </summary>
    public class DbTable : Neusoft.NFC.Management.NeuObjectExtra
    {
        /// <summary>
        /// һ�㹹�캯��
        /// </summary>
        public DbTable()
        {
            objectStatus = ObjectStatus.New;
        }

        /// <summary>
        /// ����һ��ʵ������¡����ʵ��
        /// </summary>
        public DbTable(DbTable argObj)
            : base(argObj)
        {
        }

        #region ����

        #endregion

        #region ����
        /// <summary>
        /// ���ݿ����
        /// </summary>
        public override string TableName
        {
            get { return "COM_DBTABLE"; }
        }
        
        /// <summary>
        /// ����
        /// </summary>
        [DataFieldName("TABLE_NAME"), DataFieldDefault("")]
        public override string ID
        {
            get { return base.ID; }
            set
            {
                if (!object.Equals(base.ID, value))
                {
                    if (!modifiedProperty.ContainsKey("ID"))
                    {
                        modifiedProperty.Add("ID", base.ID);
                        this.IsModified = true;
                    }
                    base.ID = value;
                }
            }
        }

        /// <summary>
        /// ��ע��
        /// </summary>
        [DataFieldName("TABLE_EXPLAIN"), DataFieldDefault("")]
        public override string Name
        {
            get { return base.Name; }
            set
            {
                if (!object.Equals(base.Name, value))
                {
                    if (!modifiedProperty.ContainsKey("Name"))
                    {
                        modifiedProperty.Add("Name", base.Name);
                        this.IsModified = true;
                    }
                    base.Name = value;
                }
            }
        }

        private int tableType;
        /// <summary>
        /// 1��ʾҵ�����ݣ�2��ʾ�������ݣ�0Ĭ��ֵ������
        /// </summary>
        [DataFieldName("TABLE_TYPE")]
        public int TableType
        {
            get { return tableType; }
            set
            {
                if (!object.Equals(tableType, value))
                {
                    if (!modifiedProperty.ContainsKey("TableType"))
                    {
                        modifiedProperty.Add("TableType", tableType);
                        this.IsModified = true;
                    }
                    tableType = value;
                }
            }
        }

        private string clearSql;
        /// <summary>
        /// truncate��ʾ���������ݣ�where����ʾʹ��delete��Ϊnull������
        /// </summary>
        [DataFieldName("CLEAR_SQL"), DataFieldDefault("")]
        public string ClearSql
        {
            get { return clearSql; }
            set
            {
                if (!object.Equals(clearSql, value))
                {
                    if (!modifiedProperty.ContainsKey("ClearSql"))
                    {
                        modifiedProperty.Add("ClearSql", clearSql);
                        this.IsModified = true;
                    }
                    clearSql = value;
                }
            }
        }

        #endregion

        #region ����
        /// <summary>
        /// ǳ����¡
        /// </summary>
        public new DbTable Clone()
        {
            // TODO:  ���� DbTable.Clone ʵ��
            DbTable obj = base.Clone() as DbTable;

            return obj;
        }
        #endregion

    }

}