using System;
using System.Collections;


namespace Neusoft.HISFC.Object.Admin {


	/// <summary>
	/// User ��ժҪ˵����
	/// </summary>
	public class PowerUser : Neusoft.NFC.Object.NeuObject       
	{
		public PowerUser()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			
			//

			Department = new Neusoft.NFC.Object.NeuObject();
			GrantDepartment = new Neusoft.NFC.Object.NeuObject();

			Department.ID = "";
			Department.Name = "";
		}

		//ID;
		//Name;

		/// <summary>
		/// Ȩ�޲���
		/// </summary>
		public NFC.Object.NeuObject Department;

		public NFC.Object.NeuObject GrantDepartment;


		private IList powerDetails ;
		private IList roleDetails;


		public string PowerClass1 ;
		public string PowerClass2 ;
		public string PowerClass3 ;


		/// <summary>
		/// ��Ա����չȨ��
		/// </summary>
		public IList PowerDetails
		{
			get
			{
				return this.powerDetails;
			}
			set
			{
				this.powerDetails = value;
			}
		}


		public IList RoleDetails
		{
			get
			{
				return this.roleDetails;
			}
			set
			{
				this.roleDetails = value;
			}
		}
	}
}
