using System;

namespace Neusoft.HISFC.Object.IMA
{
	/// <summary>
	/// [��������: ��Ŀ���ƻ�����Ϣ]<br></br>
	/// [�� �� ��: ������]<br></br>
	/// [����ʱ��: 2006-09-11]<br></br>
	/// <�޸ļ�¼
	///		�޸���=''
	///		�޸�ʱ��='yyyy-mm-dd'
	///		�޸�Ŀ��=''
	///		�޸�����=''
	///  />
	/// </summary>
	public class NameService : Neusoft.HISFC.Object.Base.Spell
	{

		public NameService()
		{
		}


		#region ����
		/// <summary>
		/// ͨ����
		/// </summary>
		private string regularName;

		/// <summary>
		/// ͨ����ƴ����
		/// </summary>
		private Neusoft.HISFC.Object.Base.Spell regularSpell = new Neusoft.HISFC.Object.Base.Spell();

		/// <summary>
		/// ѧ��
		/// </summary>
		private string formalName;

		/// <summary>
		/// ѧ��ƴ����
		/// </summary>
		private Neusoft.HISFC.Object.Base.Spell formalSpell = new Neusoft.HISFC.Object.Base.Spell();

		/// <summary>
		/// ����
		/// </summary>
		private string otherName;

		/// <summary>
		/// ѧ��ƴ����
		/// </summary>
		private Neusoft.HISFC.Object.Base.Spell otherSpell = new Neusoft.HISFC.Object.Base.Spell();

		/// <summary>
		/// Ӣ����
		/// </summary>
		private string englishName;

		/// <summary>
		/// Ӣ��ͨ����
		/// </summary>
		private string englishRegularName;

		/// <summary>
		/// Ӣ�ı���
		/// </summary>
		private string englishOtherName;

		/// <summary>
		/// ���ʱ���
		/// </summary>
		private string internationalCode;

		/// <summary>
		/// ���ұ���
		/// </summary>
		private string gbCode;

		#endregion

		/// <summary>
		/// ͨ����
		/// </summary>		
		public string RegularName
		{
			get
			{
				return this.regularName;
			}
			set
			{
				this.regularName = value;
			}
		}


		/// <summary>
		/// ͨ����������
		/// </summary>
		public Neusoft.HISFC.Object.Base.Spell RegularSpell
		{
			get
			{
				return this.regularSpell;
			}
			set
			{
				this.regularSpell = value;
			}
		}
		

		/// <summary>
		/// ѧ��
		/// </summary>
		public string FormalName
		{
			get
			{
				return this.formalName;
			}
			set
			{
				this.formalName = value;
			}
		}


		/// <summary>
		/// ѧ��������
		/// </summary>
		public Neusoft.HISFC.Object.Base.Spell FormalSpell
		{
			get
			{
				return this.formalSpell;
			}
			set
			{
				this.formalSpell = value;
			}
		}
		

		/// <summary>
		/// ����
		/// </summary>
		public string OtherName
		{
			get
			{
				return this.otherName;
			}
			set
			{
				this.otherName = value;
			}
		}
		

		/// <summary>
		/// ����������
		/// </summary>
		public Neusoft.HISFC.Object.Base.Spell OtherSpell
		{
			get
			{
				return this.otherSpell;
			}
			set
			{
				this.otherSpell = value;
			}
		}
		

		/// <summary>
		/// Ӣ����
		/// </summary>
		public string EnglishName
		{
			get
			{
				return this.englishName;
			}
			set
			{
				this.englishName = value;
			}
		}
		

		/// <summary>
		/// Ӣ��ͨ����
		/// </summary>
		public string EnglishRegularName
		{
			get
			{
				return this.englishRegularName;
			}
			set
			{
				this.englishRegularName = value;
			}
		}


		/// <summary>
		/// Ӣ�ı���
		/// </summary>
		public string EnglishOtherName
		{
			get
			{
				return this.englishOtherName;
			}
			set
			{
				this.englishOtherName = value;
			}
		}
		

		/// <summary>
		/// ���ʱ���
		/// </summary>
		public string InternationalCode
		{
			get
			{
				return this.internationalCode;
			}
			set
			{
				this.internationalCode = value;
			}
		}
		

		/// <summary>
		/// ���ұ���
		/// </summary>
		public string GbCode
		{
			get
			{
				return this.gbCode;
			}
			set
			{
				this.gbCode = value;
			}
		}


		/// <summary>
		/// ��¡����
		/// </summary>
		/// <returns></returns>
		public new NameService Clone()
		{
			NameService nameS = base.Clone() as NameService;

			nameS.RegularSpell = this.RegularSpell.Clone();
			nameS.FormalSpell = this.FormalSpell.Clone();
			nameS.OtherSpell = this.OtherSpell.Clone();

			return nameS;
		}
	}
}
