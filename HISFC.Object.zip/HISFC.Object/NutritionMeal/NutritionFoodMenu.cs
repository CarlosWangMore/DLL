using System;
using System.Collections.Generic;
using System.Text;

namespace Neusoft.HISFC.Object.NutritionMeal
{
    /// <summary>
    /// Terminal<br></br>
    /// [��������: ����ά��]<br></br>
    /// [�� �� ��: ��ΰ��]<br></br>
    /// [����ʱ��: 2007-9]<br></br>
    /// <�޸ļ�¼
    ///		�޸���=''
    ///		�޸�ʱ��=''
    ///		�޸�Ŀ��=''
    ///		�޸�����=''
    ///  />
    /// ID�����ױ��룬NAME���������ƣ�MEMO����������(0����ͨ��ʳ���ס�1��������ʳ����)
    /// </summary>
    public class NutritionFoodMenu : Neusoft.NFC.Object.NeuObject, Neusoft.HISFC.Object.Base.IValid, Neusoft.HISFC.Object.Base.ISpell
    {
        /// <summary>
        /// ��Ч��
        /// </summary>
        private bool isValid;

        /// <summary>
        /// ���׽��
        /// </summary>
        private decimal money;

        /// <summary>
        /// ��������
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment createEnv = new Neusoft.HISFC.Object.Base.OperEnvironment();

        /// <summary>
        /// ȡ������
        /// </summary>
        private Neusoft.HISFC.Object.Base.OperEnvironment cancelEnv = new Neusoft.HISFC.Object.Base.OperEnvironment();

        private string spellCode;
        private string wbCode;
        private string userCode;


        #region IValid ��Ա

        /// <summary>
        /// ��Ч��
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.isValid;
            }
            set
            {
                this.isValid = value;
            }
        }

        #endregion

        /// <summary>
        /// ���׽��
        /// </summary>
        public decimal Money
        {
            get
            {
                return this.money;
            }
            set
            {
                this.money = value;
            }
        }

        /// <summary>
        /// ��������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment CreateEnv
        {
            get
            {
                return this.createEnv;
            }
            set
            {
                this.createEnv = value;
            }
        }

        /// <summary>
        /// ȡ������
        /// </summary>
        public Neusoft.HISFC.Object.Base.OperEnvironment CancelEnv
        {
            get
            {
                return this.cancelEnv;
            }
            set
            {
                this.cancelEnv = value;
            }
        }

        public new NutritionFoodMenu Clone()
        {
            NutritionFoodMenu n = base.Clone() as NutritionFoodMenu;
            n.createEnv = this.createEnv.Clone();
            n.cancelEnv = this.cancelEnv.Clone();

            return n;
        }

        #region ISpell ��Ա

        /// <summary>
        /// ƴ����
        /// </summary>
        public string SpellCode
        {
            get
            {
                return this.spellCode;
            }
            set
            {
                this.spellCode = value;
            }
        }

        /// <summary>
        /// �����
        /// </summary>
        public string WBCode
        {
            get
            {
                return this.wbCode;
            }
            set
            {
                this.wbCode = value;
            }
        }

        /// <summary>
        /// �Զ�����
        /// </summary>
        public string UserCode
        {
            get
            {
                return this.userCode;
            }
            set
            {
                this.userCode = value;
            }
        }

        #endregion
    }
}
