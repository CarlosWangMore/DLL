using System;
using System.Collections;

namespace Neusoft.HISFC.Management.Registration
{
    /// <summary>
    /// �Һż��������
    /// </summary>
    public class RegLevel : Neusoft.NFC.Management.Database
    {
        /// <summary>
        /// �Һż��������
        /// </summary>
        public RegLevel()
        {
            //
            // TODO: �ڴ˴����ӹ��캯���߼�
            //
        }

        #region ����
        /// <summary>
        /// �Һż���ʵ��
        /// </summary>
        protected Neusoft.HISFC.Object.Registration.RegLevel regLvl = null;

        /// <summary>
        ///ArrayList
        /// </summary>
        protected ArrayList al = null;
        #endregion

        #region ����
        /// <summary>
        /// ����һ���Һż���
        /// </summary>
        /// <param name="regLevel"></param>
        /// <returns></returns>
        public int Insert(Neusoft.HISFC.Object.Registration.RegLevel regLevel)
        {
            string sql = "";

            if (this.Sql.GetSql("Registration.RegLevel.Insert", ref sql) == -1) return -1;

            try
            {
                sql = string.Format(sql, regLevel.ID, regLevel.Name, regLevel.UserCode, regLevel.SortID.ToString(),
                    Neusoft.NFC.Function.NConvert.ToInt32(regLevel.IsValid).ToString(),
                    Neusoft.NFC.Function.NConvert.ToInt32(regLevel.IsExpert).ToString(),
                    Neusoft.NFC.Function.NConvert.ToInt32(regLevel.IsFaculty).ToString(),
                    Neusoft.NFC.Function.NConvert.ToInt32(regLevel.IsDefault).ToString(), regLevel.Oper.ID,
                    regLevel.Oper.OperTime.ToString(), Neusoft.NFC.Function.NConvert.ToInt32(regLevel.IsSpecial),
                    (regLevel.User01 ?? "").ToString());
            }
            catch (Exception e)
            {
                this.Err = "[Registration.RegLevel.Insert]��ʽ��ƥ��!" + e.Message;
                this.ErrCode = e.Message;
                return -1;
            }

            return this.ExecNoQuery(sql);
        }
        #endregion

        #region ɾ��
        /// <summary>
        /// ���ݹҺż������ɾ��һ���Һż���
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public int Delete(string ID)
        {
            string sql = "";

            if (this.Sql.GetSql("Registration.RegLevel.Delete", ref sql) == -1) return -1;

            try
            {
                sql = string.Format(sql, ID);
            }
            catch (Exception e)
            {
                this.Err = "[Registration.RegLevel.Delete]��ʽ��ƥ��!" + e.Message;
                this.ErrCode = e.Message;
                return -1;
            }

            return this.ExecNoQuery(sql);
        }
        #endregion

        #region ��ѯ
        /// <summary>
        /// ��ѯȫ���Һż���
        /// </summary>
        /// <returns></returns>
        public ArrayList Query()
        {
            string sql = "";

            if (this.Sql.GetSql("Registration.RegLevel.Query.1", ref sql) == -1) return null;

            return this.queryBase(sql);
        }
        /// <summary>
        /// ���Ƿ���Ч��ѯ�Һż���
        /// </summary>
        /// <param name="isValid"></param>
        /// <returns></returns>
        public ArrayList Query(bool isValid)
        {
            string sql = "", where = "";

            if (this.Sql.GetSql("Registration.RegLevel.Query.1", ref sql) == -1) return null;
            if (this.Sql.GetSql("Registration.RegLevel.Query.3", ref where) == -1) return null;

            sql = sql + " " + where;
            try
            {
                sql = string.Format(sql, Neusoft.NFC.Function.NConvert.ToInt32(isValid).ToString());
            }
            catch (Exception e)
            {
                this.Err = "[Registration.RegLevel.Query3]��ʽ��ƥ��!" + e.Message;
                this.ErrCode = e.Message;
                return null;
            }

            return this.queryBase(sql);
        }
        /// <summary>
        /// ���ݴ������һ���Һż���
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Neusoft.HISFC.Object.Registration.RegLevel Query(string ID)
        {
            string sql = "", where = "";

            if (this.Sql.GetSql("Registration.RegLevel.Query.1", ref sql) == -1) return null;
            if (this.Sql.GetSql("Registration.RegLevel.Query.4", ref where) == -1) return null;

            sql = sql + " " + where;
            try
            {
                sql = string.Format(sql, ID);
            }
            catch (Exception e)
            {
                this.Err = "[Registration.RegLevel.Query4]��ʽ��ƥ��!" + e.Message;
                this.ErrCode = e.Message;
                return null;
            }

            if (this.queryBase(sql) == null) return null;

            if (al == null)
            {
                return null;
            }
            else if (al.Count == 0)
            {
                return new Neusoft.HISFC.Object.Registration.RegLevel();
            }
            else
            {
                return (Neusoft.HISFC.Object.Registration.RegLevel)al[0];
            }
        }
        /// <summary>
        /// ����sql��ѯ�Һż�����Ϣ
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        private ArrayList queryBase(string sql)
        {
            if (this.ExecQuery(sql) == -1) return null;
            try
            {
                this.al = new ArrayList();

                while (this.Reader.Read())
                {
                    this.regLvl = new Neusoft.HISFC.Object.Registration.RegLevel();
                    //���
                    this.regLvl.ID = this.Reader[2].ToString();
                    //����
                    this.regLvl.Name = this.Reader[3].ToString();
                    //������
                    this.regLvl.UserCode = this.Reader[4].ToString();
                    //��ʾ˳��
                    this.regLvl.SortID = Neusoft.NFC.Function.NConvert.ToInt32(this.Reader[5].ToString());
                    //�Ƿ���Ч
                    this.regLvl.IsValid = Neusoft.NFC.Function.NConvert.ToBoolean(this.Reader[6].ToString());
                    //�Ƿ�ר�Һ�
                    this.regLvl.IsExpert = Neusoft.NFC.Function.NConvert.ToBoolean(this.Reader[7].ToString());
                    //�Ƿ�ר�ƺ�
                    this.regLvl.IsFaculty = Neusoft.NFC.Function.NConvert.ToBoolean(this.Reader[8].ToString());
                    //�Ƿ������
                    this.regLvl.IsSpecial = Neusoft.NFC.Function.NConvert.ToBoolean(this.Reader[9].ToString());
                    //�Ƿ�Ĭ��
                    this.regLvl.IsDefault = Neusoft.NFC.Function.NConvert.ToBoolean(this.Reader[10].ToString());
                    //����Ա
                    this.regLvl.Oper.ID = this.Reader[11].ToString();
                    //����ʱ��
                    this.regLvl.Oper.OperTime = Neusoft.NFC.Function.NConvert.ToDateTime(this.Reader[12].ToString());
                    //ext
                    this.regLvl.User01 = (this.Reader[13] ?? "").ToString();
                    this.al.Add(this.regLvl);
                }
                this.Reader.Close();
            }
            catch (Exception e)
            {
                this.Err = "��ѯ�Һż������!" + e.Message;
                this.ErrCode = e.Message;
                return null;
            }

            return al;
        }

        //{F7ACB57F-903A-40cd-B9C3-19267D79CFEC} �Һ��ԷѲ���ȫ����ҽԺ�渶��Ϣ
        public string GetPactNameByExt(string ext)
        {
            if (string.IsNullOrEmpty(ext))
            {
                return null;
            }

            string[] pactList = ext.Split(',');
            string sql = null;
            if (this.Sql.GetSql("SH.Local.QueryPactNameByID", ref sql) == -1) return null;

            string t = null;
            foreach (string s in pactList)
            {
                t += this.ExecSqlReturnOne(string.Format(sql, s)) + ",";
            }
            return t.Trim(',');
        }
        #endregion
    }
}
