using System;
using System.Collections;

namespace Neusoft.HISFC.Management.Registration
{
	/// <summary>
	/// �Һſ��ҹ�����
	/// </summary>
	public class Permission:Neusoft.NFC.Management.Database
	{
		/// <summary>
		/// �Һſ��ҹ�����
		/// </summary>
		public Permission()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		/// <summary>
		/// ����
		/// </summary>
		protected ArrayList al=null;
		/// <summary>
		/// neuObject
		/// </summary>
		protected Neusoft.NFC.Object.NeuObject obj=null;

        #region ��ѯ
        /// <summary>
		/// ����ܲ���ĳһ���ڵ���Ա�б�
		/// </summary>
		/// <param name="formName"></param>
		/// <returns></returns>
		public ArrayList Query(string formName)
		{
			string sql="";

			if(this.Sql.GetSql("Registration.Permission.Query.1",ref sql)==-1)return null;

			try
			{
				sql=string.Format(sql,formName);
			}
			catch(Exception e)
			{
				this.Err="[Registration.Permission.Query.1]��ʽ��ƥ��!"+e.Message;
				this.ErrCode=e.Message;
				return null;
			}

			this.al=new ArrayList();

			try
			{
				if(this.ExecQuery(sql)==-1)return null;
				while(this.Reader.Read())
				{
					obj=new Neusoft.NFC.Object.NeuObject();
					obj.ID=this.Reader[0].ToString();//Ա������
					obj.Name=this.Reader[1].ToString();//Ա������

					this.al.Add(obj);
				}
				this.Reader.Close();
			}
			catch(Exception e)
			{
				this.Err="��ȡ��������"+formName+"����Ա�б�����!"+e.Message;
				this.ErrCode=e.Message;
				return null;
			}
			return al;
		}
		/// <summary>
		/// ��ѯ��Ա����Һſ���
		/// </summary>
		/// <param name="person"></param>
		/// <returns></returns>
		public ArrayList Query(Neusoft.NFC.Object.NeuObject person)
		{
			string sql="";
			if(this.Sql.GetSql("Registration.Permission.Query.2",ref sql)==-1)return null;

			this.al=new ArrayList();
			try
			{
				sql=string.Format(sql,person.ID);
				if(this.ExecQuery(sql)==-1)return null;

				while(this.Reader.Read())
				{
					this.obj=new Neusoft.NFC.Object.NeuObject();

					this.obj.ID=this.Reader[2].ToString();//Ա������
					this.obj.User01=this.Reader[3].ToString();//�Һſ���
					this.obj.User02=this.Reader[4].ToString();//����Ա
					this.obj.User03=this.Reader[5].ToString();//����ʱ��

					this.al.Add(this.obj);
				}
				this.Reader.Close();
			}
			catch(Exception e)
			{
				this.Err="��ѯ��Ա�Һſ���Ȩ�޳���!"+e.Message;
				this.ErrCode=e.Message;
				return null;
			}
			return this.al;

        }
        #endregion

        #region ����
        /// <summary>
		/// �Ǽ���Ա�Һſ��ұ�
		/// </summary>
		/// <param name="permission"></param>
		/// <returns></returns>
		public int Insert(Neusoft.NFC.Object.NeuObject permission)
		{
			string sql="";
			if(this.Sql.GetSql("Registration.Permission.Insert",ref sql)==-1)return -1;

			try
			{
				sql=string.Format(sql,permission.ID,permission.User01,permission.User02);

				return this.ExecNoQuery(sql);
			}
			catch(Exception e)
			{
				this.Err="����Һ�ԱȨ�ޱ�����![Registration.Permission.Insert]"+e.Message;
				this.ErrCode=e.Message;
				return -1;
			}
        }
        #endregion

        #region ɾ��
        /// <summary>
		/// ɾ���Һ�Ա����ĹҺſ���
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		public int Delete(string userID)
		{
			string sql="";

			if(this.Sql.GetSql("Registration.Permission.Delete",ref sql)==-1)return -1;

			try
			{
				sql=string.Format(sql,userID);

				return this.ExecNoQuery(sql);
			}
			catch(Exception e)
			{
				this.Err="ɾ���Һ�ԱȨ�ޱ�����![Registration.Permission.Delete]"+e.Message;
				this.ErrCode=e.Message;
				return -1;
			}
        }
        #endregion
    }
}
