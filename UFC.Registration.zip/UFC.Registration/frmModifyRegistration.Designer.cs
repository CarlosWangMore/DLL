﻿namespace Neusoft.UFC.Registration
{
    partial class frmModifyRegistration
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.panel3 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.label9 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtSeeNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label8 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtRecipeNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.groupBox3 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.label6 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtCardNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.groupBox2 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.cmbSex = new Neusoft.NFC.Interface.Controls.NeuComboBox();
            this.txtPhone = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.dtBirthday = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.txtAdress = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.txtName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.button1 = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.button2 = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.label2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.panel2 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.groupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.label7 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(472, 303);
            this.panel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtSeeNo);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.txtRecipeNo);
            this.panel3.Controls.Add(this.groupBox3);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.txtCardNo);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.cmbSex);
            this.panel3.Controls.Add(this.txtPhone);
            this.panel3.Controls.Add(this.dtBirthday);
            this.panel3.Controls.Add(this.txtAdress);
            this.panel3.Controls.Add(this.txtName);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 46);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(472, 257);
            this.panel3.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("宋体", 12F);
            this.label9.Location = new System.Drawing.Point(240, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 23);
            this.label9.TabIndex = 23;
            this.label9.Text = "看诊序号:";
            // 
            // txtSeeNo
            // 
            this.txtSeeNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtSeeNo.Font = new System.Drawing.Font("宋体", 12F);
            this.txtSeeNo.Location = new System.Drawing.Point(323, 57);
            this.txtSeeNo.Name = "txtSeeNo";
            this.txtSeeNo.ReadOnly = true;
            this.txtSeeNo.Size = new System.Drawing.Size(122, 26);
            this.txtSeeNo.TabIndex = 22;
            this.txtSeeNo.Text = "";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("宋体", 12F);
            this.label8.Location = new System.Drawing.Point(19, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 23);
            this.label8.TabIndex = 21;
            this.label8.Text = "处 方 号:";
            // 
            // txtRecipeNo
            // 
            this.txtRecipeNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtRecipeNo.Font = new System.Drawing.Font("宋体", 12F);
            this.txtRecipeNo.Location = new System.Drawing.Point(102, 57);
            this.txtRecipeNo.Name = "txtRecipeNo";
            this.txtRecipeNo.ReadOnly = true;
            this.txtRecipeNo.Size = new System.Drawing.Size(112, 26);
            this.txtRecipeNo.TabIndex = 20;
            this.txtRecipeNo.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Font = new System.Drawing.Font("宋体", 2F);
            this.groupBox3.Location = new System.Drawing.Point(12, 45);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(448, 3);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("宋体", 12F);
            this.label6.Location = new System.Drawing.Point(19, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 23);
            this.label6.TabIndex = 18;
            this.label6.Text = "病 历 号:";
            // 
            // txtCardNo
            // 
            this.txtCardNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCardNo.Font = new System.Drawing.Font("宋体", 12F);
            this.txtCardNo.Location = new System.Drawing.Point(102, 11);
            this.txtCardNo.Name = "txtCardNo";
            this.txtCardNo.Size = new System.Drawing.Size(112, 26);
            this.txtCardNo.TabIndex = 0;
            this.txtCardNo.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Font = new System.Drawing.Font("宋体", 2F);
            this.groupBox2.Location = new System.Drawing.Point(10, 213);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(448, 3);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            // 
            // cmbSex
            // 
            this.cmbSex.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbSex.Font = new System.Drawing.Font("宋体", 12F);
            this.cmbSex.IsFlat = false;
            this.cmbSex.IsLike = true;
            this.cmbSex.Location = new System.Drawing.Point(323, 98);
            this.cmbSex.Name = "cmbSex";
            this.cmbSex.PopForm = null;
            this.cmbSex.ShowCustomerList = false;
            this.cmbSex.ShowID = false;
            this.cmbSex.Size = new System.Drawing.Size(122, 24);
            this.cmbSex.TabIndex = 2;
            this.cmbSex.Tag = "";
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPhone.Font = new System.Drawing.Font("宋体", 12F);
            this.txtPhone.Location = new System.Drawing.Point(323, 135);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(122, 26);
            this.txtPhone.TabIndex = 4;
            this.txtPhone.Text = "";
            // 
            // dtBirthday
            // 
            this.dtBirthday.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtBirthday.CalendarFont = new System.Drawing.Font("宋体", 9F);
            this.dtBirthday.CustomFormat = "yyyy-MM-dd";
            this.dtBirthday.Font = new System.Drawing.Font("宋体", 12F);
            this.dtBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBirthday.Location = new System.Drawing.Point(102, 135);
            this.dtBirthday.Name = "dtBirthday";
            this.dtBirthday.ShowUpDown = true;
            this.dtBirthday.Size = new System.Drawing.Size(112, 26);
            this.dtBirthday.TabIndex = 3;
            // 
            // txtAdress
            // 
            this.txtAdress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAdress.Font = new System.Drawing.Font("宋体", 12F);
            this.txtAdress.Location = new System.Drawing.Point(102, 172);
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(343, 26);
            this.txtAdress.TabIndex = 5;
            this.txtAdress.Text = "";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.Font = new System.Drawing.Font("宋体", 12F);
            this.txtName.Location = new System.Drawing.Point(102, 98);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(112, 26);
            this.txtName.TabIndex = 1;
            this.txtName.Text = "";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("宋体", 12F);
            this.label5.Location = new System.Drawing.Point(19, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 23);
            this.label5.TabIndex = 15;
            this.label5.Text = "联系地址:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("宋体", 12F);
            this.label4.Location = new System.Drawing.Point(240, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 23);
            this.label4.TabIndex = 14;
            this.label4.Text = "联系电话:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 12F);
            this.label3.Location = new System.Drawing.Point(19, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 23);
            this.label3.TabIndex = 13;
            this.label3.Text = "出生日期:";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(263, 224);
            this.button1.Name = "button1";
            this.button1.TabIndex = 6;
            this.button1.Text = "确定(&O)";
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(368, 224);
            this.button2.Name = "button2";
            this.button2.TabIndex = 7;
            this.button2.Text = "退出(&X)";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(240, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "性    别:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(19, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "姓    名:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 46);
            this.panel2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Font = new System.Drawing.Font("宋体", 2F);
            this.groupBox1.Location = new System.Drawing.Point(0, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(472, 3);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(16, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(430, 27);
            this.label7.TabIndex = 0;
            this.label7.Text = "    发票重打可调整患者挂号信息,然后确定保存。系统自动将前一张发票作废,并重新打印一张新的发票";
            // 
            // frmModifyRegistration
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(472, 328);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmModifyRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "发票重打";
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuPanel panel1;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel2;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel3;
        private Neusoft.NFC.Interface.Controls.NeuLabel label1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label2;
        private Neusoft.NFC.Interface.Controls.NeuButton button2;
        private Neusoft.NFC.Interface.Controls.NeuButton button1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label3;
        private Neusoft.NFC.Interface.Controls.NeuLabel label4;
        private Neusoft.NFC.Interface.Controls.NeuLabel label5;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbSex;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtAdress;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtPhone;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtName;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBirthday;
        private Neusoft.NFC.Interface.Controls.NeuLabel label7;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox1;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox2;
        private Neusoft.NFC.Interface.Controls.NeuLabel label6;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox3;
        private Neusoft.NFC.Interface.Controls.NeuLabel label8;
        private Neusoft.NFC.Interface.Controls.NeuLabel label9;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtRecipeNo;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtSeeNo;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCardNo;
    }
}