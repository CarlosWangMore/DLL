using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Reflection;
using TZZYYLocal.HISFC.POS.Classes;
using System.Data.SqlClient;
using Neusoft.HISFC.Integrate.Registration;
using Neusoft.HISFC.Management.Registration;



namespace Neusoft.UFC.Registration
{
    /// <summary>
    /// ����Һ�
    /// </summary>
    public partial class ucRegister : Neusoft.NFC.Interface.Controls.ucBaseControl, Neusoft.NFC.Interface.Forms.IInterfaceContainer, Neusoft.HISFC.Integrate.FeeInterface.ISIReadCard
    {
        public ucRegister()
        {
            InitializeComponent();

            this.Load += new EventHandler(ucRegister_Load);
            this.cmbRegLevel.SelectedIndexChanged += new EventHandler(cmbRegLevel_SelectedIndexChanged);
            this.cmbDept.SelectedIndexChanged += new EventHandler(cmbDept_SelectedIndexChanged);
            this.cmbDoctor.SelectedIndexChanged += new EventHandler(cmbDoctor_SelectedIndexChanged);

            this.cmbCardType.KeyDown += new KeyEventHandler(cmbCardType_KeyDown);
            this.dtBookingDate.ValueChanged += new EventHandler(dtBookingDate_ValueChanged);
            this.dtBookingDate.KeyDown += new KeyEventHandler(dtBookingDate_KeyDown);
            this.dtBegin.ValueChanged += new EventHandler(dtBegin_ValueChanged);
            this.dtBegin.KeyDown += new KeyEventHandler(dtBegin_KeyDown);
            this.dtEnd.ValueChanged += new EventHandler(dtEnd_ValueChanged);
            this.dtEnd.KeyDown += new KeyEventHandler(dtEnd_KeyDown);
            this.txtOrder.KeyDown += new KeyEventHandler(txtOrder_KeyDown);
            this.cmbUnit.SelectedIndexChanged += new EventHandler(cmbUnit_SelectedIndexChanged);
            this.txtOrder.TextChanged += new EventHandler(txtOrder_TextChanged);
            this.llPd.Click += new EventHandler(llPd_Click);
            this.txtRecipeNo.KeyDown += new KeyEventHandler(txtRecipeNo_KeyDown);
            this.txtRecipeNo.Validating += new CancelEventHandler(txtRecipeNo_Validating);
            this.fpSpread1.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(fpSpread1_CellClick);
            this.cmbDoctor.TextChanged += new EventHandler(cmbDoctor_TextChanged);
            this.txtPhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPhone_KeyDown);
            this.txtPhone.Enter += new System.EventHandler(this.txtCardNo_Enter);
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            this.txtName.Enter += new System.EventHandler(this.txtName_Enter);
            this.cmbDept.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbDept_KeyDown);
            this.cmbDept.TextChanged += new System.EventHandler(this.cmbDept_TextChanged);
            this.cmbDept.Enter += new System.EventHandler(this.cmbDept_Enter);
            this.cmbDoctor.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbDoctor_KeyDown);
            this.cmbDoctor.Enter += new System.EventHandler(this.cmbDoctor_Enter);
            this.cmbUnit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbUnit_KeyDown);
            this.txtAge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAge_KeyDown);
            this.txtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAddress_KeyDown);
            this.txtAddress.Leave += new System.EventHandler(this.txtAddress_Leave);
            this.txtAddress.Enter += new System.EventHandler(this.txtAddress_Enter);
            this.txtMcardNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMcardNo_KeyDown);
            this.txtMcardNo.Enter += new System.EventHandler(this.txtCardNo_Enter);
            this.cmbPayKind.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbPayKind_KeyDown);
            this.cmbPayKind.Enter += new System.EventHandler(this.cmbPayKind_Enter);
            this.cmbSex.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbSex_KeyDown);
            this.cmbSex.Enter += new System.EventHandler(this.txtCardNo_Enter);
            this.txtCardNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCardNo_KeyDown);
            this.txtCardNo.Enter += new System.EventHandler(this.txtCardNo_Enter);
            this.cmbRegLevel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbRegLevel_KeyDown);
            this.cmbRegLevel.Enter += new System.EventHandler(this.cmbRegLevel_Enter);
            this.dtBirthday.KeyDown += new KeyEventHandler(dtBirthday_KeyDown);
            this.txtVIPNo.KeyDown += new KeyEventHandler(txtVIPNo_KeyDown);
        }

        #region ����
        #region ������
        /// <summary>
        /// ����������
        /// </summary>
        private Neusoft.HISFC.Integrate.Manager conMgr = new Neusoft.HISFC.Integrate.Manager();

        /// <summary>
        /// �Һ�ԱȨ����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Permission permissMgr = new Neusoft.HISFC.Management.Registration.Permission();
        /// <summary>
        /// ����������
        /// </summary>
        private Neusoft.NFC.Management.ControlParam ctlMgr = new Neusoft.NFC.Management.ControlParam();
        /// <summary>
        /// �Ű������
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Schema SchemaMgr = new Neusoft.HISFC.Management.Registration.Schema();
        /// <summary>
        /// ���߹�����
        /// </summary>
        private Neusoft.HISFC.Integrate.RADT patientMgr = new Neusoft.HISFC.Integrate.RADT();
        /// <summary>
        /// �ҺŹ�����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Register regMgr = new Neusoft.HISFC.Management.Registration.Register();
        /// <summary>
        /// ��ͬ��λ������
        /// </summary>
        private Neusoft.HISFC.Integrate.Fee feeMgr = new Neusoft.HISFC.Integrate.Fee();
        /// <summary>
        /// �Һż��������
        /// </summary>
        private Neusoft.HISFC.Management.Registration.RegLevel RegLevelMgr = new Neusoft.HISFC.Management.Registration.RegLevel();
        /// <summary>
        /// ԤԼ������
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Booking bookingMgr = new Neusoft.HISFC.Management.Registration.Booking();
        /// <summary>
        /// �Һŷѹ�����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.RegLvlFee regFeeMgr = new Neusoft.HISFC.Management.Registration.RegLvlFee();

        /// <summary>
        /// �˻�������
        /// </summary>
        private Neusoft.HISFC.Management.Fee.Account accountMgr = new Neusoft.HISFC.Management.Fee.Account();

        private Neusoft.HISFC.Management.Order.Order orderMgr = new Neusoft.HISFC.Management.Order.Order();

        /// <summary>
        /// ��ʿ������Ϣ
        /// </summary>
        //private Neusoft.HISFC.Integrate. assMgr = new neusoft.HISFC.Management.Nurse.Assign();
        /// <summary>
        /// ҽ���ӿ���
        /// </summary>
        //private MedicareInterface.Class.Clinic SIMgr = new MedicareInterface.Class.Clinic();
        //private neusoft.HISFC.Management.Fee.Interface InterfaceMgr = new neusoft.HISFC.Management.Fee.Interface();
        ////
        #endregion

        /// <summary>
        /// �ҺŽ���Ĭ�ϵ��������뷨
        /// </summary>
        private InputLanguage CHInput = null;
        //// <summary>
        //// �Һ�Ʊ�Ƿ񰴷�Ʊ����
        //// </summary>
        //private bool IsGetInvoice = false;
        /// <summary>
        /// �Һ�ʵ��
        /// </summary>
        private Neusoft.HISFC.Object.Registration.Register regObj;
        /// <summary>
        /// ��������б�
        /// </summary>
        private ArrayList alDept = new ArrayList();
        /// <summary>
        /// �����Һ�Ա�ҺŵĿ���
        /// </summary>
        private ArrayList alAllowedDept = new ArrayList();
        /// <summary>
        /// ҽ���б�
        /// </summary>
        private ArrayList alDoct = new ArrayList();
        /// <summary>
        /// ���
        /// </summary>
        private ArrayList alNoon = new ArrayList();
        /// <summary>
        /// �Ƿ񴥷�SelectedIndexChanged�¼�
        /// </summary>
        private bool IsTriggerSelectedIndexChanged = true;
        private bool isBirthdayEnd = true;

        /// <summary>
        /// �Ƿ���ʾ�˻���ҽ���Ȼ�����Ϣ�� {54603DD0-3484-4dba-B88A-B89F2F59EA40}
        /// </summary>
        private bool isShowSIBalanceCost = true;

        //{AEFEC6C1-019F-4bad-9373-556B2DFB4FEC}
        /// <summary>
        /// �Ƿ����ùҺ�����ʱ��ι���
        /// </summary>
        private bool isOpenFreeSeeDoctor = false;
        /// <summary>
        /// ����ʱ����б�
        /// </summary>
        private ArrayList alFreeSeeDate = new ArrayList();
        /// <summary>
        /// ҵ������
        /// </summary>
        private Neusoft.HISFC.Integrate.Manager managerIntergrate = new Neusoft.HISFC.Integrate.Manager();
        /// <summary>
        /// ��ֹ�ظ�����
        /// {D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2} minqsh 20180326 add
        /// </summary>
        private bool isSaveing = false;


        /// <summary>
        /// ���б�{B42210EB-D925-4c60-A4FD-0E9580F8DAC5} YYTPOS
        /// </summary>
        protected ArrayList alBanks = new ArrayList();


        /// <summary>
        /// ����Һż���
        /// </summary>
        private string freeRegLevel = string.Empty;
        #region �Ϻ����ӣ�ҽ������Ϣ¼�� {2B6167F7-339B-4f09-9af6-C5CD6Agg3AC89}
        /// <summary>
        /// ҽ�����ֶ�
        /// </summary>
        //private string siBigSickItem = "";  //ҽ������Ŀ
        //private string siBigSickDignose = "";  //ҽ�������
        //private string siBigSickItemName = "";  //ҽ�������
        //private string siBigSickDignoseName = "";  //ҽ�������
        //private string priveNo = "";  //ҽ�������
        //private DateTime siBigSickBeginTime = new DateTime();  //�󲡺ſ�ʼʱ��
        //private DateTime siBigSickEndTime = new DateTime();  //�󲡺Ž�ֹʱ��
        #endregion
        /// <summary>
        /// �Һż��������
        /// </summary>
        private Neusoft.HISFC.Management.Registration.RegLevel regLevelManager = new Neusoft.HISFC.Management.Registration.RegLevel();

        #region ����
        /// <summary>
        /// Ĭ����ʾ�ĺ�ͬ��λ����
        /// </summary>
        private string DefaultPactID = "";
        /// <summary>
        /// ���ѻ��������չҺ��޶�
        /// </summary>
        private int DayRegNumOfPub = 10;
        /// <summary>
        /// ����Ƿ����
        /// </summary>
        private bool IsPubDiagFee = false;
        /// <summary>
        /// ר�Һ��Ƿ���ѡ�����
        /// </summary>
        private bool IsSelectDeptFirst = false;
        /// <summary>
        /// �Һ��Ƿ�¼������
        /// </summary>
        private bool IsInputName = true;
        //{920686B9-AD51-496e-9240-5A6DA098404E}
        /// <summary>
        /// ҽ�������������б��Ƿ���ʾȫԺ��ҽ�������ң�������˭�ܿ����ף�˭�񾭲�
        /// </summary>
        //private bool ComboxIsListAll = true;
        /// <summary>
        /// �Һſ�����ʾ����
        /// </summary>
        private int DisplayDeptColumnCnt = 1;
        /// <summary>
        /// �Һ�ҽ����ʾ����
        /// </summary>
        private int DisplayDoctColumnCnt = 1;
        /// <summary>
        /// �Һ��Ƿ����������Ű��޶�
        /// </summary>
        private bool IsAllowOverrun = true;
        /// <summary>
        /// 2�����ŶԲ���Ա������1�ɲ���Ա�Լ�¼�봦����
        /// </summary>
        private int GetRecipeType = 1;

        private int GetInvoiceType = 1;
        /// <summary>
        /// �س��Ƿ�����Ԥ����ˮ�Ŵ�
        /// </summary>
        private bool IsInputOrder = true;
        /// <summary>
        /// ����Ƿ�����ԤԼʱ��δ�
        /// </summary>
        private bool IsInputTime = true;
        /// <summary>
        /// ����ʱ�Ƿ���ʾ
        /// </summary>
        private bool IsPrompt = true;
        /// <summary>
        /// �Ƿ�ԤԼ����������ֳ���ǰ��
        /// </summary>
        private bool IsPreFirst = false;

        /// <summary>
        /// �Ƿ���ȡ�յ���
        /// </summary>
        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
        //private bool IsKTF = true;

        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
        /// <summary>
        /// �������ѡ�����0���յ���1��������2��������
        /// </summary>
        private string otherFeeType = string.Empty;

        /// <summary>
        /// ר�Һ��Ƿ����ֽ��ڼ���
        /// </summary>
        private bool IsDivLevel = false;
        /// <summary>
        /// ���ź��Ƿ���Ϊ�ǼӺ�
        /// </summary>
        private bool MultIsAppend = true;
        /// <summary>
        /// �����б�
        /// </summary>
        private ArrayList alProfessor = new ArrayList();
        #endregion
        /// <summary>
        /// ѡ��ԤԼʱ���
        /// </summary>
        private ucChooseBookingDate ucChooseDate;

        /// <summary>
        /// ҽ���ӿڴ���
        /// </summary>
        Neusoft.HISFC.Integrate.FeeInterface.MedcareInterfaceProxy MedcareInterfaceProxy = new Neusoft.HISFC.Integrate.FeeInterface.MedcareInterfaceProxy();
        private bool isReadCard = false;
        /// <summary>
        /// �Һ���Ϣʵ�壺ҽ�����ʹ��
        /// </summary>
        //Neusoft.HISFC.Object.Registration.Register myYBregObj = new Neusoft.HISFC.Object.Registration.Register ();

        /// <summary>
        /// �Ƿ񵯳����㴰��{F0661633-4754-4758-B683-CB0DC983922B}
        /// </summary>
        private bool isShowChangeCostForm = false;

        private Neusoft.HISFC.Object.Registration.Booking booking = new Neusoft.HISFC.Object.Registration.Booking();


        #region ��Ʊ
        /// <summary>
        /// ��ӡ�ӿ�
        /// </summary>
        private Neusoft.HISFC.Integrate.Registration.IRegPrint IRegPrint = null;
        #endregion

        private DataSet dsItems;
        private DataView dvDepts;
        private DataView dvDocts;

        private Decimal regFee;

        private ArrayList al = new ArrayList();
        /// <summary>
        /// ��ʾ���Ƿ�ʹ���ʻ�֧��
        /// </summary>
        private bool isAccountMessage = true;

        #region ҽ���������Կ��ƺ��޸�����ҽ���б��Ϳ����б�{920686B9-AD51-496e-9240-5A6DA098404E}
        /// <summary>
        /// �Ƿ���������ҽ��
        /// </summary>
        private bool isAddAllDoct = false;

        /// <summary>
        /// �Ƿ��г����п���
        /// </summary>
        private bool isAddAllDept = false;

        /// <summary>
        /// ��ͨ��ʱ��ҽ���ؼ��Ƿ��ý���
        /// </summary>
        private bool isSetDoctFocusForCommon = false;

        /// <summary>
        /// ����ʱ����{E43E0363-0B22-4d2a-A56A-455CFB7CF211}
        /// </summary>
        private Neusoft.HISFC.Management.Interface.Registration.IProcessRegiter iProcessRegiter = null;

        #endregion
        #region ��Ϣչʾ��չ�ӿ�

        /// <summary>
        /// ��Ϣչʾ��չ�ӿ� {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        /// </summary>
        private Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion iShowOperationInforamtion = null;

        /// <summary>
        /// ״̬�������Ƿ��ʼ���ɹ������Ϣչʾ��չ�ӿ�
        /// </summary>
        private bool isInitedIShowOperationInforamtion = false;

        #region {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        private Forms.frmReturnCost frmOpen = new Neusoft.UFC.Registration.Forms.frmReturnCost();
        #endregion

        //{A9412582-3456-4f55-9217-1F33CB51BCED}  �Ƿ���ݹҺż���Һ�begin  add by chenzl 2011-05-22
        private bool IsCheckLevel = false;
        //end

        #endregion

        #endregion
        #region �Ƿ����Ƶ绰��סַ������һ��


        private bool isLimit = false;
        [Category("�ؼ�����"), Description("�Ƿ����Ƶ绰��סַ������һ��")]
        public bool IsLimit
        {
            set
            {
                this.isLimit = value;
            }
            get
            {
                return this.isLimit;
            }
        }

        #endregion

        #region ����

        /// <summary>
        /// �Ƿ���ʾ����
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ���ʾ����")]
        public bool IsShowEncrpt
        {
            get
            {
                return this.chbEncrpt.Visible;
            }
            set
            {
                this.chbEncrpt.Visible = value;
            }
        }

        /// <summary>
        /// �Ƿ�ֱ�Ӵ�ӡ
        /// </summary>
        private bool isAutoPrint = true;

        /// <summary>
        /// �Ƿ��Զ���ӡ
        /// </summary>
        [Category("�ؼ�����"), Description("������Ƿ��Զ���ӡ"), DefaultValue(true)]
        public bool IsAutoPrint
        {
            get
            {
                return this.isAutoPrint;
            }
            set
            {
                this.isAutoPrint = value;
            }
        }
        [Category("�ؼ�����"), Description("�����Ƿ��ý���"), DefaultValue(true)]
        public bool IsBirthdayEnd
        {
            get
            {
                return isBirthdayEnd;
            }
            set
            {
                isBirthdayEnd = value;
            }
        }

        [Category("�ؼ�����"), Description("��ʾ���Ƿ�ʹ���ʻ�֧��True:��ʾ,False:����ʾ��ȡ�ʻ�")]
        public bool IsAccountMessage
        {
            get
            {
                return isAccountMessage;
            }
            set
            {
                isAccountMessage = value;
            }
        }

        // {54603DD0-3484-4dba-B88A-B89F2F59EA40}
        [Category("�ؼ�����"), Description("��ʾ����ʾ�����˻���ҽ�������True:��ʾ,False:����ʾ")]
        public bool IsShowSIBalanceCost
        {
            get
            {
                return this.isShowSIBalanceCost;
            }
            set
            {
                this.isShowSIBalanceCost = value;
                this.lblSIBalanceTEXT.Visible = value;
                this.tbSIBalanceCost.Visible = value;
            }
        }
        #region ҽ���������Կ��ƺ��޸�����ҽ���б��Ϳ����б�{920686B9-AD51-496e-9240-5A6DA098404E}
        /// <summary>
        /// �Һ�ҽ���Ƿ����ſ��ұ仯
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ�����ȫԺҽ����True:����ȫԺҽ����ѡ�����ʱҽ���б������ű仯,False:�仯"), DefaultValue(true)]
        public bool IsAddAllDoct
        {
            get { return isAddAllDoct; }
            set { isAddAllDoct = value; }
        }

        /// <summary>
        /// �Һ�ҽ���Ƿ����ſ��ұ仯
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ�����ȫԺ���ң�True:����,False:ֻ���ӹҺſ���"), DefaultValue(false)]
        public bool IsAddAllDept
        {
            get { return isAddAllDept; }
            set { isAddAllDept = value; }
        }


        /// <summary>
        /// ��ͨ��ʱ��ҽ���ؼ��Ƿ��ý���
        /// </summary>
        [Category("�ؼ�����"), Description("��ͨ��ʱ��ҽ���ؼ��Ƿ��ý��㣬True:���,False:�����"), DefaultValue(false)]
        public bool IsSetDoctFocusForCommon
        {
            get { return isSetDoctFocusForCommon; }
            set { isSetDoctFocusForCommon = value; }
        }

        #endregion

        /// <summary>
        /// �Ƿ񵯳����㴰��{F0661633-4754-4758-B683-CB0DC983922B}
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ񵯳����㴰��"), DefaultValue(false)]
        public bool IsShowChangeCostForm
        {
            get { return isShowChangeCostForm; }
            set { isShowChangeCostForm = value; }
        }


        /// <summary>
        /// �Ƿ���������ʱ������ƹ���{AEFEC6C1-019F-4bad-9373-556B2DFB4FEC}
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ���������ʱ�������"), DefaultValue(false)]
        public bool IsOpenFreeSeeDoctor
        {
            get { return isOpenFreeSeeDoctor; }
            set { isOpenFreeSeeDoctor = value; }
        }
        /// <summary>
        /// �Ƿ���ʾ����Һŷ�Ʊ�� {F2FB1293-6433-4db5-9BF1-EC855FDF408C}
        /// </summary>
        [Category("�ؼ�����"), Description("�Ƿ���ʾ����Һŷ�Ʊ��"), DefaultValue(true)]
        private bool IsViewInvoiceNo = true;

        public bool IsViewInvoiceNo1
        {
            get { return IsViewInvoiceNo; }
            set { IsViewInvoiceNo = value; }
        }
        //{F2FB1293-6433-4db5-9BF1-EC855FDF408C}

        #region  �Ƿ���ݹҺż���Һ� {A9412582-3456-4f55-9217-1F33CB51BCED}  add by chenzl 2011-05-22 ̩������ҽԺ ���� com_controlargument���ӿ��ؿ���
        /// <summary>
        /// �Ƿ���ݹҺż���Һ�
        /// </summary>
        //[Category("�ؼ�����"), Description("�Ƿ���ݹҺ����Һ�"), DefaultValue(true)]
        //private bool isCheckLevel = true;
        //public bool IsCheckLevel
        //{
        //    get { return isCheckLevel; }
        //    set { isCheckLevel = value; }
        //}
        #endregion

        #endregion

        #region ��ʼ��
        private void ucRegister_Load(object sender, EventArgs e)
        {
            if (this.DesignMode) return;
            this.init();
            this.SetRegLevelDefault();
            this.clear();
            this.initInputMenu();
            this.readInputLanguage();
            this.ChangeRecipe();

            //{A9412582-3456-4f55-9217-1F33CB51BCED}  add by chenzl 2011-05-22  �����Һż���Һ�  ����ֱ�ӻ�ȡ��ҽ��
            //if (!IsCheckLevel)
            //{
            //    this.cmbDoctor.Focus();
            //}

            if (Screen.PrimaryScreen.Bounds.Height == 600)
            {
                this.panel5.Height = 29;
            }

            this.LoadPrint();
            this.FindForm().FormClosing += new FormClosingEventHandler(ucRegister_FormClosing);
            frmOpen.BackCost += new Neusoft.UFC.Registration.Forms.frmReturnCost.BackCostHandle(frmOpen_BackCost);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        }
        /// <summary>
        /// ��ʼ��
        /// </summary>
        private void init()
        {
            Neusoft.HISFC.Integrate.Manager mangerIntergrate = new Neusoft.HISFC.Integrate.Manager();
            alBanks = mangerIntergrate.GetConstantList("Bank");
            if (alBanks == null || alBanks.Count <= 0)
            {
                MessageBox.Show("��ȡ�����б�ʧ��!");

                return;
            }

            //neusoft.neuFC.Interface.Classes.Function.ShowWaitForm("") ;
            //Application.DoEvents() ;


            this.GetParameter();
            this.initDataSet();
            this.setStyle();
            this.initRegLevel();
            this.alDept = this.GetClinicDepts();
            if (this.alDept == null) this.alDept = new ArrayList();

            this.InitRegDept();
            this.InitDoct();
            this.initPact();
            this.InitBookingDate();
            this.InitNoon();
            //̩����ҽԺ�ֳ��Һ����ӡ�ְҵ��{B51EA52F-ABDF-4aba-B2C8-3A874FB39DBA}
            this.cmbProfession.AddItems(mangerIntergrate.GetConstantList(Neusoft.HISFC.Object.Base.EnumConstant.PROFESSION));
            this.cmbSex.AddItems(Neusoft.HISFC.Object.Base.SexEnumService.List());
            //this.cmbSex.AddItems(mangerIntergrate.GetConstantList("sex"));//�ӳ������л�ȡ�Ա���Ϣ��{DFFA6190-0292-4b75-9B07-0A3A73461294}
            this.InitCardType();
            this.Retrieve();
            this.GetRecipeNo(regMgr.Operator.ID);

            //neusoft.neuFC.Interface.Classes.Function.HideWaitForm() ;

            this.cmbRegLevel.IsFlat = true;
            this.cmbDept.IsFlat = true;
            this.cmbDoctor.IsFlat = true;
            this.cmbPayKind.IsFlat = true;
            this.cmbSex.IsFlat = true;
            this.cmbUnit.IsFlat = true;
            this.cmbCardType.IsFlat = true;
            this.cmbPayKind.IsLike = false;//������ģ����ѯ
            //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
            //Ϊ��������ʱ��ʾ
            if (this.otherFeeType == "1")
            {
                this.chbBookFee.Visible = true;
            }
            else
            {
                this.chbBookFee.Visible = false;
            }
            //{E43E0363-0B22-4d2a-A56A-455CFB7CF211}
            this.InitInterface();
        }
        /// <summary>
        /// init DataSet
        /// </summary>
        private void initDataSet()
        {
            dsItems = new DataSet();
            dsItems.Tables.Add("Dept");
            dsItems.Tables.Add("Doct");

            dsItems.Tables["Dept"].Columns.AddRange(new DataColumn[]
                {
                    new DataColumn("ID",System.Type.GetType("System.String")),
                    new DataColumn("Name",System.Type.GetType("System.String")),
                    new DataColumn("Spell_Code",System.Type.GetType("System.String")),
                    new DataColumn("Wb_code",System.Type.GetType("System.String")),
                    new DataColumn("Input_Code",System.Type.GetType("System.String")),
                    new DataColumn("RegLmt",System.Type.GetType("System.Decimal")),
                    new DataColumn("Reged",System.Type.GetType("System.Decimal")),
                    new DataColumn("TelLmt",System.Type.GetType("System.Decimal")),
                    new DataColumn("Teled",System.Type.GetType("System.Decimal")),
                    new DataColumn("BeginTime",System.Type.GetType("System.DateTime")),
                    new DataColumn("EndTime",System.Type.GetType("System.DateTime")),
                    new DataColumn("Noon",System.Type.GetType("System.String")),
                    new DataColumn("IsAppend",System.Type.GetType("System.Boolean"))
                });

            dsItems.Tables["Doct"].Columns.AddRange(new DataColumn[]
                {
                    new DataColumn("ID",System.Type.GetType("System.String")),
                    new DataColumn("Name",System.Type.GetType("System.String")),
                    new DataColumn("Spell_Code",System.Type.GetType("System.String")),
                    new DataColumn("Wb_code",System.Type.GetType("System.String")),					
                    new DataColumn("RegLmt",System.Type.GetType("System.Decimal")),
                    new DataColumn("Reged",System.Type.GetType("System.Decimal")),
                    new DataColumn("TelLmt",System.Type.GetType("System.Decimal")),
                    new DataColumn("Teled",System.Type.GetType("System.Decimal")),
                    new DataColumn("SpeLmt",System.Type.GetType("System.Decimal")),
                    new DataColumn("Sped",System.Type.GetType("System.Decimal")),
                    new DataColumn("BeginTime",System.Type.GetType("System.DateTime")),
                    new DataColumn("EndTime",System.Type.GetType("System.DateTime")),
                    new DataColumn("Noon",System.Type.GetType("System.String")),
                    new DataColumn("IsAppend",System.Type.GetType("System.Boolean")),
                    new DataColumn("Memo",System.Type.GetType("System.String")),
                    new DataColumn("IsProfessor",System.Type.GetType("System.Boolean"))
                });

            dsItems.CaseSensitive = false;

            dvDepts = new DataView(dsItems.Tables["Dept"]);
            dvDocts = new DataView(dsItems.Tables["Doct"]);
        }
        /// <summary>
        /// ����farpoint�ĸ�ʽ
        /// </summary>
        private void setStyle()
        {
            FarPoint.Win.Spread.CellType.TextCellType txt = new FarPoint.Win.Spread.CellType.TextCellType();

            #region �Һż���
            //�������ùҺż�����ʾ����
            string colCount = this.ctlMgr.QueryControlerInfo("400001");
            //û��Ĭ����ʾһ��
            if (colCount == null || colCount == "-1" || colCount == "")
                colCount = "1";


            this.fpRegLevel.ColumnCount = int.Parse(colCount) * 2;
            int width = /*this.fpSpread1.Width*/500 * 2 / this.fpRegLevel.ColumnCount;
            //������
            for (int i = 0; i < this.fpRegLevel.ColumnCount; i++)
            {
                if (i % 2 == 0)
                {
                    this.fpRegLevel.ColumnHeader.Cells[0, i].Text = "����";
                    this.fpRegLevel.Columns[i].Width = width / 3;
                    this.fpRegLevel.Columns[i].BackColor = Color.Linen;
                    this.fpRegLevel.Columns[i].CellType = txt;
                }
                else
                {
                    this.fpRegLevel.ColumnHeader.Cells[0, i].Text = "�Һż�������";
                    this.fpRegLevel.Columns[i].Width = width * 2 / 3;
                }
            }

            this.fpRegLevel.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpRegLevel.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpRegLevel.RowHeader.Visible = false;
            this.fpRegLevel.RowCount = 0;
            #endregion

            #region �������
            colCount = this.ctlMgr.QueryControlerInfo("400003");
            if (colCount == null || colCount == "-1" || colCount == "") colCount = "1";

            this.fpPayKind.ColumnCount = int.Parse(colCount) * 2;
            width = /*this.fpSpread1.Width*/500 * 2 / this.fpPayKind.ColumnCount;

            FarPoint.Win.Spread.CellType.TextCellType txtType = new FarPoint.Win.Spread.CellType.TextCellType();
            txtType.StringTrim = System.Drawing.StringTrimming.EllipsisCharacter;

            //������
            for (int i = 0; i < this.fpPayKind.ColumnCount; i++)
            {
                if (i % 2 == 0)
                {
                    this.fpPayKind.ColumnHeader.Cells[0, i].Text = "����";
                    this.fpPayKind.Columns[i].Width = width / 3;
                    this.fpPayKind.Columns[i].BackColor = Color.Linen;
                    this.fpPayKind.Columns[i].CellType = txt;
                }
                else
                {
                    this.fpPayKind.ColumnHeader.Cells[0, i].Text = "�������";
                    this.fpPayKind.Columns[i].Width = width * 2 / 3;
                    this.fpPayKind.Columns[i].CellType = txtType;
                }
            }

            this.fpPayKind.GrayAreaBackColor = SystemColors.Window;
            this.fpPayKind.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpPayKind.RowHeader.Visible = false;
            this.fpPayKind.RowCount = 0;
            #endregion

            #region ���߹Һ���Ϣ
            this.fpList.ColumnHeader.Cells[0, 0].Text = "������";
            this.fpList.Columns[0].Width = 100F;
            this.fpList.Columns[0].CellType = txt;
            this.fpList.ColumnHeader.Cells[0, 1].Text = "����";
            this.fpList.Columns[1].Width = 90F;
            this.fpList.ColumnHeader.Cells[0, 2].Text = "�������";
            this.fpList.Columns[2].Width = 90F;
            this.fpList.ColumnHeader.Cells[0, 3].Text = "�Һż���";
            this.fpList.Columns[3].Width = 80F;
            this.fpList.ColumnHeader.Cells[0, 4].Text = "�Һſ���";
            this.fpList.Columns[4].Width = 80F;
            this.fpList.ColumnHeader.Cells[0, 5].Text = "����ҽ��";
            this.fpList.Columns[5].Width = 78F;
            this.fpList.ColumnHeader.Cells[0, 6].Text = "���";
            this.fpList.Columns[6].Width = 40;
            this.fpList.ColumnHeader.Cells[0, 7].Text = "�Һŷ�(�Է��ܶ�)";
            this.fpList.Columns[7].Width = 120;
            this.fpList.ColumnHeader.Cells[0, 8].Text = "���������";
            this.fpList.Columns[8].Width = 80;
            this.fpList.Columns.Count = 9;

            this.fpList.GrayAreaBackColor = SystemColors.Window;
            this.fpList.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpList.RowCount = 0;
            #endregion

            //��ʼ����ʾ�Ű����
            this.SetDeptFpStyle(false);

            this.SetDoctFpStyle(false);
        }
        /// <summary>
        /// ���ÿ����б���ʾ�ĸ�ʽ
        /// </summary>
        /// <param name="IsDisplaySchema"></param>
        private void SetDeptFpStyle(bool IsDisplaySchema)
        {
            //��ʾר���Ű����,��ʾ���롢�������ơ����ʱ��Ρ��Һ��޶�ѹ�������ԤԼ�޶ԤԼ�ѹ�
            this.fpDept.Reset();
            this.fpDept.SheetName = "�Һſ���";

            FarPoint.Win.Spread.CellType.TextCellType txt = new FarPoint.Win.Spread.CellType.TextCellType();

            if (IsDisplaySchema)
            {
                this.fpDept.ColumnCount = 7;
                this.fpDept.ColumnHeader.Cells[0, 0].Text = "����";
                this.fpDept.ColumnHeader.Columns[0].Width = 45;
                this.fpDept.Columns[0].CellType = txt;
                this.fpDept.ColumnHeader.Cells[0, 1].Text = "��������";
                this.fpDept.ColumnHeader.Columns[1].Width = 95;
                this.fpDept.ColumnHeader.Cells[0, 2].Text = "����ʱ��";
                this.fpDept.ColumnHeader.Columns[2].Width = 120;
                this.fpDept.ColumnHeader.Cells[0, 3].Text = "�Һ��޶�";
                this.fpDept.Columns[3].ForeColor = Color.Red;
                this.fpDept.Columns[3].Font = new Font("����", 10, FontStyle.Bold);
                this.fpDept.ColumnHeader.Cells[0, 4].Text = "�ѹҺ���";
                this.fpDept.ColumnHeader.Cells[0, 5].Text = "ԤԼ�޶�";
                this.fpDept.Columns[5].ForeColor = Color.Blue;
                this.fpDept.Columns[5].Font = new Font("����", 10, FontStyle.Bold);
                this.fpDept.ColumnHeader.Cells[0, 6].Text = "ԤԼ�ѹ�";
            }
            else//����ר�ҡ������û���Ű�Ŀ���,ֻ��ʾ���������
            {
                this.fpDept.ColumnCount = this.DisplayDeptColumnCnt * 2;
                int width = /*this.fpSpread1.Width*/500 * 2 / this.fpDept.ColumnCount;

                //������
                for (int i = 0; i < this.fpDept.ColumnCount; i++)
                {
                    if (i % 2 == 0)
                    {
                        this.fpDept.ColumnHeader.Cells[0, i].Text = "����";
                        this.fpDept.Columns[i].Width = width / 3;
                        this.fpDept.Columns[i].BackColor = Color.Linen;
                        this.fpDept.Columns[i].CellType = txt;
                    }
                    else
                    {
                        this.fpDept.ColumnHeader.Cells[0, i].Text = "��������";
                        this.fpDept.Columns[i].Width = width * 2 / 3;
                    }
                }
            }
            this.fpDept.GrayAreaBackColor = SystemColors.Window;
            this.fpDept.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpDept.RowHeader.Visible = false;
            this.fpDept.RowCount = 0;
        }
        /// <summary>
        /// ����ҽ���б���ʾ�ĸ�ʽ
        /// </summary>
        /// <param name="IsDisplaySchema"></param>
        private void SetDoctFpStyle(bool IsDisplaySchema)
        {
            this.fpDoctor.Reset();
            this.fpDoctor.SheetName = "�������";

            FarPoint.Win.Spread.CellType.TextCellType txt = new FarPoint.Win.Spread.CellType.TextCellType();

            if (IsDisplaySchema)
            {
                this.fpDoctor.ColumnCount = 10;
                this.fpDoctor.ColumnHeader.Rows[0].Height = 30;

                this.fpDoctor.ColumnHeader.Cells[0, 0].Text = "����";
                this.fpDoctor.ColumnHeader.Columns[0].Width = 40;
                this.fpDoctor.Columns[0].CellType = txt;
                this.fpDoctor.ColumnHeader.Cells[0, 1].Text = "ר������";
                this.fpDoctor.ColumnHeader.Columns[1].Width = 60;
                this.fpDoctor.ColumnHeader.Cells[0, 2].Text = "����ʱ��";
                this.fpDoctor.ColumnHeader.Columns[2].Width = 120;
                this.fpDoctor.ColumnHeader.Cells[0, 3].Text = "�Һ��޶�";
                this.fpDoctor.ColumnHeader.Columns[3].Width = 35;
                this.fpDoctor.Columns[3].ForeColor = Color.Red;
                this.fpDoctor.Columns[3].Font = new Font("����", 10, FontStyle.Bold);
                this.fpDoctor.ColumnHeader.Cells[0, 4].Text = "ʣ�����";
                this.fpDoctor.ColumnHeader.Columns[4].Width = 35;
                this.fpDoctor.ColumnHeader.Cells[0, 5].Text = "ԤԼ�޶�";
                this.fpDoctor.ColumnHeader.Columns[5].Width = 35;
                this.fpDoctor.Columns[5].ForeColor = Color.Blue;
                this.fpDoctor.Columns[5].Font = new Font("����", 10, FontStyle.Bold);
                this.fpDoctor.ColumnHeader.Cells[0, 6].Text = "��ԤԼ��";
                this.fpDoctor.ColumnHeader.Columns[6].Width = 35;
                this.fpDoctor.ColumnHeader.Cells[0, 7].Text = "�����޶�";
                this.fpDoctor.ColumnHeader.Columns[7].Width = 35;
                this.fpDoctor.Columns[7].ForeColor = Color.Magenta;
                this.fpDoctor.Columns[7].Font = new Font("����", 10, FontStyle.Bold);
                this.fpDoctor.ColumnHeader.Cells[0, 8].Text = "�����ѹ�";
                this.fpDoctor.ColumnHeader.Columns[8].Width = 35;
                this.fpDoctor.ColumnHeader.Cells[0, 9].Text = "ר��";
                this.fpDoctor.ColumnHeader.Columns[9].Width = 100;
            }
            else
            {
                this.fpDoctor.ColumnCount = this.DisplayDoctColumnCnt * 2;
                int width = /*this.fpSpread1.Width*/500 * 2 / this.fpDoctor.ColumnCount;

                //������
                for (int i = 0; i < this.fpDoctor.ColumnCount; i++)
                {
                    if (i % 2 == 0)
                    {
                        this.fpDoctor.ColumnHeader.Cells[0, i].Text = "����";
                        this.fpDoctor.Columns[i].Width = width / 3;
                        this.fpDoctor.Columns[i].BackColor = Color.Linen;
                        this.fpDoctor.Columns[i].CellType = txt;
                    }
                    else
                    {
                        this.fpDoctor.ColumnHeader.Cells[0, i].Text = "��������";
                        this.fpDoctor.Columns[i].Width = width * 2 / 3;
                    }
                }
            }
            this.fpDoctor.GrayAreaBackColor = SystemColors.Window;
            this.fpDoctor.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpDoctor.RowHeader.Visible = false;
            this.fpDoctor.RowCount = 0;
        }
        /// <summary>
        /// ��ȡ��������
        /// </summary>
        private void GetParameter()
        {
            //Ĭ����ʾ��ͬ��λ
            this.DefaultPactID = this.ctlMgr.QueryControlerInfo("400005");
            if (DefaultPactID == null || DefaultPactID == "-1") DefaultPactID = "";
            //���ѻ��߹Һ�����
            string rtn = this.ctlMgr.QueryControlerInfo("400007");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "10";

            this.DayRegNumOfPub = int.Parse(rtn);
            //����Ƿ���
            rtn = this.ctlMgr.QueryControlerInfo("400008");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "0";
            this.IsPubDiagFee = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
            //ר�Һ��Ƿ�ѡ�����
            rtn = this.ctlMgr.QueryControlerInfo("400010");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "0";
            this.IsSelectDeptFirst = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
            //			//��ר�ƺ��Ƿ�ֻ��ʾ����ר��
            //			rtn = this.ctlMgr.QueryControlerInfo("400011") ;
            //			if( rtn == null || rtn == "-1" || rtn == "") rtn = "0" ;
            //			this.IsDisplaySchemaDept = neusoft.neuFC.Function.NConvert.ToBoolean(rtn) ;
            //�Һ��Ƿ����������Ű��޶�
            rtn = this.ctlMgr.QueryControlerInfo("400015");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.IsAllowOverrun = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
            //�Һſ�����ʾ����
            rtn = this.ctlMgr.QueryControlerInfo("400002");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.DisplayDeptColumnCnt = int.Parse(rtn);
            //�Һ�ҽ����ʾ����
            rtn = this.ctlMgr.QueryControlerInfo("400004");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.DisplayDoctColumnCnt = int.Parse(rtn);
            //��ӡ�վ�?
            //			rtn = this.ctlMgr.QueryControlerInfo("400017");
            //			if( rtn == null || rtn == "-1" || rtn == "") rtn = "Invoice" ;
            //			this.PrintWhat = rtn ;

            //��ȡ���������ͣ�1����Ʊ��,2����Ʊ�ţ����Һ��վݺ�,3����Ʊ�ţ��������վݺţ�
            rtn = this.ctlMgr.QueryControlerInfo("400019");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.GetRecipeType = int.Parse(rtn);


            //��ȡ����Ƿ�����ԤԼ��ˮ�Ŵ�
            rtn = this.ctlMgr.QueryControlerInfo("400020");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.IsInputOrder = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            //ҽ�������������б��Ƿ���ʾȫԺ��ҽ��������
            //{920686B9-AD51-496e-9240-5A6DA098404E}
            //rtn = this.ctlMgr.QueryControlerInfo("400022");
            //if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            //this.ComboxIsListAll = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            //����Ƿ�����ԤԼʱ��δ�
            rtn = this.ctlMgr.QueryControlerInfo("400023");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.IsInputTime = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            //����ʱ�Ƿ���ʾ
            rtn = this.ctlMgr.QueryControlerInfo("400024");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            this.IsPrompt = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            ///�Ƿ�ԤԼ�ſ�����������ֳ���ǰ���
            rtn = this.ctlMgr.QueryControlerInfo("400026");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "0";
            this.IsPreFirst = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            ///����������0���յ���1��������2��������
            rtn = this.ctlMgr.QueryControlerInfo("400027");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
            //this.IsKTF = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
            this.otherFeeType = rtn;

            //ר�Һ��Ƿ����ֽ��ڼ���
            rtn = this.ctlMgr.QueryControlerInfo("400028");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "0";
            this.IsDivLevel = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);

            if (this.IsDivLevel)
            {
                this.alProfessor = this.conMgr.QueryConstantList("Professor");
            }

            //���źŵڶ����Ƿ����Ӻ�
            rtn = this.ctlMgr.QueryControlerInfo("400029");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";

            //{AEFEC6C1-019F-4bad-9373-556B2DFB4FEC}
            alFreeSeeDate = managerIntergrate.GetConstantList("FreeSeeDoctorDay");

            //{AEFEC6C1-019F-4bad-9373-556B2DFB4FEC}
            rtn = this.ctlMgr.QueryControlerInfo("Reg001");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "1";
            freeRegLevel = rtn;

            //{A9412582-3456-4f55-9217-1F33CB51BCED}  ��ȡ���� �Ƿ���ݹҺŹҺŻ��߸���ҽ����������Һż��� add by chenzl 2011-05-22
            //begin
            rtn = this.ctlMgr.QueryControlerInfo("400031");
            if (rtn == null || rtn == "-1" || rtn == "") rtn = "0";
            this.IsCheckLevel = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
            //end

            this.MultIsAppend = Neusoft.NFC.Function.NConvert.ToBoolean(rtn);
        }
        /// <summary>
        /// ������ʹ��ֱ���շ����ɵĺ��ٽ��йҺ�
        /// </summary>
        /// <param name="CardNO"></param>
        /// <returns></returns>
        private int ValidCardNO(string CardNO)
        {
            Neusoft.HISFC.Integrate.Common.ControlParam controlParams = new Neusoft.HISFC.Integrate.Common.ControlParam();

            string cardRule = controlParams.GetControlParam<string>(Neusoft.HISFC.Integrate.Const.NO_REG_CARD_RULES, false, "9");
            if (CardNO != "" && CardNO != string.Empty)
            {
                if (CardNO.Substring(0, 1) == cardRule)
                {
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�˺Ŷ�Ϊֱ���շ�ʹ�ã���ѡ�������Ŷ�"), Neusoft.NFC.Management.Language.Msg("��ʾ"));
                    return -1;
                }
            }
            return 1;
        }

        #region regLevel
        /// <summary>
        /// ��ʼ���Һż���
        /// </summary>
        /// <returns></returns>
        private int initRegLevel()
        {
            al = this.getRegLevelFromXML();
            if (al == null) return -1;

            ///�������û������,�����ݿ��ж�ȡ 
            if (al.Count == 0)
            {
                al = this.RegLevelMgr.Query(true);
            }

            if (al == null)
            {
                MessageBox.Show("��ѯ�Һż������!" + this.RegLevelMgr.Err, "��ʾ");
                return -1;
            }

            this.AddRegLevelToFp(al);
            this.AddRegLevelToCombox(al);
            return 0;
        }

        /// <summary>
        /// �ӱ��ض�ȡ�Һż���,Ȩ�޿���
        /// </summary>
        /// <returns></returns>
        private ArrayList getRegLevelFromXML()
        {
            ArrayList alLists = new ArrayList();
            XmlDocument doc = new XmlDocument();

            try
            {
                doc.Load(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/RegLevelList.xml");
            }
            catch { return alLists; }


            try
            {
                XmlNodeList nodes = doc.SelectNodes(@"//Level");

                foreach (XmlNode node in nodes)
                {
                    Neusoft.HISFC.Object.Registration.RegLevel level = new Neusoft.HISFC.Object.Registration.RegLevel();
                    level.ID = node.Attributes["ID"].Value;//
                    level.Name = node.Attributes["Name"].Value;
                    level.IsExpert = Neusoft.NFC.Function.NConvert.ToBoolean(node.Attributes["IsExpert"].Value);
                    level.IsFaculty = Neusoft.NFC.Function.NConvert.ToBoolean(node.Attributes["IsFaculty"].Value);
                    level.IsSpecial = Neusoft.NFC.Function.NConvert.ToBoolean(node.Attributes["IsSpecial"].Value);
                    level.IsDefault = Neusoft.NFC.Function.NConvert.ToBoolean(node.Attributes["IsDefault"].Value);

                    alLists.Add(level);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("��ȡ�Һż������!" + e.Message);
                return null;
            }

            return alLists;
        }
        /// <summary>
        /// ���Һż������ӵ�FarPoint�б���
        /// </summary>
        /// <param name="regLevels"></param>
        /// <returns></returns>
        private int AddRegLevelToFp(ArrayList regLevels)
        {
            int count = 0, row = 0, colCount = 0;

            colCount = this.fpRegLevel.ColumnCount / 2;

            if (this.fpRegLevel.RowCount > 0)
                this.fpRegLevel.Rows.Remove(0, this.fpRegLevel.RowCount);

            foreach (Neusoft.NFC.Object.NeuObject obj in regLevels)
            {
                if (count % colCount == 0)
                {
                    this.fpRegLevel.Rows.Add(this.fpRegLevel.RowCount, 1);
                    row = this.fpRegLevel.RowCount - 1;
                }

                this.fpRegLevel.SetValue(row, 2 * (count % colCount), obj.ID, false);
                this.fpRegLevel.SetValue(row, 2 * (count % colCount) + 1, obj.Name, false);

                count++;
            }

            return 0;
        }
        /// <summary>
        /// ���Һż������ӵ�Combox��
        /// </summary>
        /// <param name="regLevels"></param>
        /// <returns></returns>
        private int AddRegLevelToCombox(ArrayList regLevels)
        {
            //���ӵ������б�
            this.cmbRegLevel.AddItems(al);

            return 0;
        }

        #endregion

        #region dept
        /// <summary>
        /// ��ȡ�����������
        /// </summary>
        /// <returns></returns>
        private ArrayList GetClinicDepts()
        {
            al = null;
            //al = this.conMgr.QueryRegDepartment();                        add  by ww              {35099CEF-4FB0-4ab9-A72A-2587B52A2155}
            al = this.conMgr.QueryRegDepartmentbyHospital(((Neusoft.HISFC.Object.Base.Employee)Neusoft.NFC.Management.Connection.Operator).Hospital.ID);
            if (al == null)
            {
                MessageBox.Show("��ȡ�������ʱ����!" + this.conMgr.Err, "��ʾ");
                return null;
            }

            return al;
        }
        /// <summary>
        /// ��ȡ����Ա�Һſ���
        /// </summary>
        private int InitRegDept()
        {
            //��ȡ��������Ա�ҺŵĿ����б�
            this.alAllowedDept = this.GetAllowedDepts();

            //����
            if (alAllowedDept == null)
            {
                this.alAllowedDept = new ArrayList();
                return -1;
            }
            //���ӵ�DataSet��
            this.AddAllowedDeptToDataSet(this.alAllowedDept);

            //û��ά������Ա��Ӧ�ĹҺſ���,Ĭ�Ͽɹ������������
            if (alAllowedDept.Count == 0)
            {
                this.AddClinicDeptsToDataSet(this.alDept);
            }

            //��dataset���ӵ�farpoint
            this.addRegDeptToFp(false);
            //��dataset���ӵ�combox
            this.addRegDeptToCombox();

            return 0;
        }
        /// <summary>
        /// ��ȡ��������Ա�ҺŵĿ����б�
        /// </summary>
        /// <returns></returns>
        private ArrayList GetAllowedDepts()
        {
            al = this.permissMgr.Query((Neusoft.NFC.Object.NeuObject)this.regMgr.Operator);
            if (al == null)
            {
                MessageBox.Show("��ȡ����Ա�Һſ���ʱ����!" + this.permissMgr.Err, "��ʾ");
                return null;
            }

            return al;
        }

        /// <summary>
        /// ����������Ա�ҺŵĿ������ӵ�DataSet
        /// </summary>
        /// <param name="allowedDepts"></param>
        private void AddAllowedDeptToDataSet(ArrayList allowedDepts)
        {
            this.dsItems.Tables[0].Rows.Clear();

            //�����Һſ������鷵�ص���neuobjectʵ��
            foreach (Neusoft.NFC.Object.NeuObject obj in allowedDepts)
            {
                //��ת��ΪDeptartment ʵ��,
                Neusoft.HISFC.Object.Base.Department dept;
                //���ݴ������ʵ��
                dept = this.getDeptByID(obj.User01);
                //��ʵ�����ӵ�DataSet��
                if (dept != null)
                    this.addDeptToDataSet(dept);
            }
        }
        /// <summary>
        /// ���ҿ���-���ݿ��Ҵ���
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Base.Department getDeptByID(string ID)
        {
            #region no used
            //			IEnumerator index=this.alDept.GetEnumerator();
            //			
            //			while(index.MoveNext())
            //			{
            //				if((index.Current as neusoft.HISFC.Object.Base.Department).ID==ID)
            //					return (index.Current;
            //			}
            //			return null;
            #endregion

            foreach (Neusoft.HISFC.Object.Base.Department obj in this.alDept)
            {
                if (obj.ID == ID)
                    return obj;
            }
            return null;
        }
        /// <summary>
        /// Add deptartment to DataSet,����ʵ�ֶ�̬���˹���
        /// </summary>
        /// <param name="dept"></param>
        private void addDeptToDataSet(Neusoft.HISFC.Object.Base.Department dept)
        {
            dsItems.Tables["Dept"].Rows.Add(new object[]
                {
                    dept.ID,
                    dept.Name,
                    dept.SpellCode,
                    dept.WBCode,
                    dept.UserCode,
                    0,
                    0,
                    0,
                    0,
                    DateTime.MinValue,
                    DateTime.MinValue,
                    "",
                    false});
        }

        /// <summary>
        /// ������������ӵ�Dataset
        /// </summary>
        /// <param name="depts"></param>
        private void AddClinicDeptsToDataSet(ArrayList depts)
        {
            this.dsItems.Tables[0].Rows.Clear();

            foreach (Neusoft.HISFC.Object.Base.Department dept in depts)
            {
                this.addDeptToDataSet(dept);
            }
        }
        /// <summary>
        /// ���ɹҺſ����б�-FarPoint
        /// </summary>
        /// <returns></returns>
        private int addRegDeptToFp(bool IsDisplaySchema)
        {
            //���ӵ�farpoint
            if (this.fpDept.RowCount > 0)
                this.fpDept.Rows.Remove(0, this.fpDept.RowCount);

            DataRowView dataRow;

            if (IsDisplaySchema)
            {
                for (int i = 0; i < dvDepts.Count; i++)
                {
                    dataRow = dvDepts[i];
                    this.fpDept.Rows.Add(this.fpDept.RowCount, 1);

                    this.fpDept.SetValue(i, 0, dataRow["ID"], false);
                    this.fpDept.SetValue(i, 1, dataRow["Name"], false);

                    if (dataRow["IsAppend"].ToString().ToUpper() == "TRUE")//�Ӻ�
                    {
                        this.fpDept.SetValue(i, 2, this.getNoon(dataRow["Noon"].ToString()) + "[�Ӻ�]", false);
                    }
                    else
                    {
                        this.fpDept.SetValue(i, 2, this.getNoon(dataRow["Noon"].ToString()) +
                            "[" + DateTime.Parse(dataRow["BeginTime"].ToString()).ToString("HH:mm") + "��" +
                            DateTime.Parse(dataRow["EndTime"].ToString()).ToString("HH:mm") + "]", false);
                    }

                    this.fpDept.SetValue(i, 3, dataRow["RegLmt"], false);
                    this.fpDept.SetValue(i, 4, dataRow["Reged"], false);
                    this.fpDept.SetValue(i, 5, dataRow["TelLmt"], false);
                    this.fpDept.SetValue(i, 6, dataRow["Teled"], false);
                }
                this.fpDept.Tag = "1";
            }
            else
            {
                #region ""
                int count = 0, colCount = 0, row = 0;

                colCount = this.fpDept.Columns.Count / 2;

                for (int i = 0; i < dvDepts.Count; i++)
                {
                    if (count % colCount == 0)
                    {
                        this.fpDept.Rows.Add(this.fpDept.RowCount, 1);
                        row = this.fpDept.RowCount - 1;
                    }

                    dataRow = dvDepts[i];
                    this.fpDept.SetValue(row, 2 * (count % colCount), dataRow[0].ToString(), false);
                    this.fpDept.SetValue(row, 2 * (count % colCount) + 1, dataRow[1].ToString(), false);
                    count++;
                }
                #endregion
                this.fpDept.Tag = "0";
            }
            return 0;
        }

        /// <summary>
        /// init Reg department combox
        /// </summary>
        private void addRegDeptToCombox()
        {
            DataRow row;
            al = new ArrayList();

            for (int i = 0; i < this.dsItems.Tables["Dept"].Rows.Count; i++)
            {
                row = this.dsItems.Tables["Dept"].Rows[i];
                //�ظ��Ĳ�����
                if (i > 0 && row["ID"].ToString() == dsItems.Tables["Dept"].Rows[i - 1]["ID"].ToString()) continue;

                Neusoft.HISFC.Object.Base.Department dept = new Neusoft.HISFC.Object.Base.Department();
                dept.ID = row["ID"].ToString();
                dept.Name = row["Name"].ToString();
                dept.SpellCode = row["Spell_Code"].ToString();
                dept.WBCode = row["Wb_Code"].ToString();
                dept.UserCode = row["Input_Code"].ToString();

                this.al.Add(dept);
            }

            this.cmbDept.AddItems(this.al);
        }
        #endregion

        #region doct
        /// <summary>
        /// ��ʼ��ҽ���б�
        /// </summary>
        /// <returns></returns>
        private int InitDoct()
        {
            alDoct = this.conMgr.QueryEmployee(Neusoft.HISFC.Object.Base.EnumEmployeeType.D);
            if (alDoct == null)
            {
                MessageBox.Show("��ȡ����ҽ���б�ʱ����!" + conMgr.Err, "��ʾ");
                alDoct = new ArrayList();
                //return -1;
            }

            this.cmbDoctor.AddItems(alDoct);

            this.AddDoctToDataSet(alDoct);
            this.AddDoctToFp(false);

            return 0;
        }
        /// <summary>
        /// ��ҽ�����ӵ�DataSet 
        /// </summary>
        /// <param name="alPersons"></param>
        /// <returns></returns>
        private int AddDoctToDataSet(ArrayList alPersons)
        {
            dsItems.Tables["Doct"].Rows.Clear();

            foreach (Neusoft.HISFC.Object.Base.Employee person in alPersons)
            {
                this.dsItems.Tables["Doct"].Rows.Add(new object[]
                    {
                        person.ID,	//ҽ������
                        person.Name,//ҽ������
                        person.SpellCode,
                        person.WBCode,
                        0,0,0,0,0,0,DateTime.MinValue,DateTime.MinValue,"",false,"",false
                    });
            }

            return 0;
        }

        /// <summary>
        /// ������ҽ�����ӵ�ҽ���б�
        /// </summary>
        /// <param name="ds"></param>
        private void AddDoctToDataSet(DataSet ds)
        {
            dsItems.Tables["Doct"].Rows.Clear();

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                DataRow row = ds.Tables[0].Rows[i];

                dsItems.Tables["Doct"].Rows.Add(new object[]
                    {
                        row[0],//ҽ������
                        row[1],//ҽ������
                        row[12],//ƴ����
                        row[13],//�����						
                        row[5],//�Һ��޶�
                        row[6],//�ѹҺ���
                        row[7],//ԤԼ�޶�
                        row[8],//��ԤԼ��
                        row[9],//�����޶�
                        row[10],//�����ѹ�
                        row[3],//��ʼʱ��
                        row[4],//����ʱ��
                        row[2],//���
                        Neusoft.NFC.Function.NConvert.ToBoolean(row[11]),
                        row[14],
                        Neusoft.NFC.Function.NConvert.ToBoolean(row[15])//�Ƿ����
                    });
            }
        }
        /// <summary>
        /// ��ҽ���������ӵ�FarPoint��
        /// </summary>	
        /// <param name="IsDisplaySchema"></param>	
        /// <returns></returns>
        private int AddDoctToFp(bool IsDisplaySchema)
        {
            //���
            if (this.fpDoctor.RowCount > 0)
                this.fpDoctor.Rows.Remove(0, this.fpDoctor.RowCount);

            DataRowView row;

            if (IsDisplaySchema)
            {
                #region ""

                Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;

                if (this.IsProfessor(level))//�ҽ��ںţ���������ǰ��
                {
                    this.dvDocts.Sort = "IsProfessor Desc, ID, Noon, IsAppend, BeginTime";
                }
                else//�����ں�,����������ǰ��
                {
                    this.dvDocts.Sort = "IsProfessor, ID, Noon, IsAppend, BeginTime";
                }

                for (int i = 0; i < dvDocts.Count; i++)
                {
                    row = dvDocts[i];

                    this.fpDoctor.Rows.Add(this.fpDoctor.RowCount, 1);

                    this.fpDoctor.SetValue(i, 0, row["ID"], false);
                    this.fpDoctor.SetValue(i, 1, row["Name"], false);

                    if (row["IsAppend"].ToString().ToUpper() == "TRUE")//�Ӻ�
                    {
                        this.fpDoctor.SetValue(i, 2, this.getNoon(row["Noon"].ToString()) + "[�Ӻ�]", false);
                    }
                    else
                    {
                        this.fpDoctor.SetValue(i, 2, this.getNoon(row["Noon"].ToString()) +
                            "[" + DateTime.Parse(row["BeginTime"].ToString()).ToString("HH:mm") + "��" +
                            DateTime.Parse(row["EndTime"].ToString()).ToString("HH:mm") + "]", false);
                    }

                    this.fpDoctor.SetValue(i, 3, row["RegLmt"], false);
                    this.fpDoctor.SetValue(i, 4, Neusoft.NFC.Function.NConvert.ToInt32(row["RegLmt"]) - Neusoft.NFC.Function.NConvert.ToInt32(row["Reged"]), false);
                    this.fpDoctor.SetValue(i, 5, row["TelLmt"], false);
                    this.fpDoctor.SetValue(i, 6, row["Teled"], false);
                    this.fpDoctor.SetValue(i, 7, row["SpeLmt"], false);
                    this.fpDoctor.SetValue(i, 8, row["Sped"], false);
                    this.fpDoctor.SetValue(i, 9, row["Memo"], false);
                    //���ڡ���������ɫ����
                    if (row["IsProfessor"].ToString().ToUpper() == "TRUE")
                    {
                        this.fpDoctor.Rows[i].BackColor = Color.LightGreen;
                    }
                }
                this.Span();

                #endregion
                this.fpDoctor.Tag = "1";
            }
            else
            {
                int RowCount = 0, ColumnCount, Row = 0;

                ColumnCount = this.fpDoctor.ColumnCount / 2;
                foreach (DataRowView dv in this.dvDocts)
                {
                    if (RowCount % ColumnCount == 0)
                    {
                        this.fpDoctor.Rows.Add(this.fpDoctor.RowCount, 1);
                        Row = this.fpDoctor.RowCount - 1;
                    }

                    this.fpDoctor.SetValue(Row, 2 * (RowCount % ColumnCount), dv["ID"].ToString(), false);
                    this.fpDoctor.SetValue(Row, 2 * (RowCount % ColumnCount) + 1, dv["Name"].ToString(), false);

                    RowCount++;
                }
                this.fpDoctor.Tag = "0";
            }

            return 0;
        }
        /// <summary>
        /// ѹ����ʾҽ������
        /// </summary>
        private void Span()
        {
            int rowLastDoct = 0;

            int rowCnt = this.fpDoctor.RowCount;

            for (int i = 0; i < rowCnt; i++)
            {
                if (i > 0 && this.fpDoctor.GetText(i, 0) != this.fpDoctor.GetText(i - 1, 0))
                {
                    if (i - rowLastDoct > 1)
                    {
                        this.fpDoctor.Models.Span.Add(rowLastDoct, 0, i - rowLastDoct, 1);
                        this.fpDoctor.Models.Span.Add(rowLastDoct, 1, i - rowLastDoct, 1);
                    }

                    rowLastDoct = i;
                }

                //���һ�д���
                if (i > 0 && i == rowCnt - 1 && this.fpDoctor.GetText(i, 0) == this.fpDoctor.GetText(i - 1, 0))
                {
                    this.fpDoctor.Models.Span.Add(rowLastDoct, 0, i - rowLastDoct + 1, 1);
                    this.fpDoctor.Models.Span.Add(rowLastDoct, 1, i - rowLastDoct + 1, 1);
                }
            }
        }
        /// <summary>
        /// add doctor to combox
        /// </summary>
        private void AddDoctToCombox()
        {
            DataRow row;
            al = new ArrayList();

            for (int i = 0; i < this.dsItems.Tables["Doct"].Rows.Count; i++)
            {
                row = this.dsItems.Tables["Doct"].Rows[i];
                //�ظ��Ĳ�����
                if (i > 0 && row["ID"].ToString() == dsItems.Tables["Doct"].Rows[i - 1]["ID"].ToString()) continue;

                Neusoft.HISFC.Object.Base.Employee p = new Neusoft.HISFC.Object.Base.Employee();
                p.ID = row["ID"].ToString();
                p.Name = row["Name"].ToString();
                p.SpellCode = row["Spell_Code"].ToString();
                p.WBCode = row["Wb_Code"].ToString();
                p.IsExpert = Neusoft.NFC.Function.NConvert.ToBoolean(row["IsProfessor"].ToString());//�Ƿ�ר��
                p.Memo = "[" + this.getNoon(row["Noon"].ToString()) + "] " + row["Memo"].ToString();

                this.al.Add(p);
            }

            this.cmbDoctor.AddItems(this.al);
        }
        #endregion

        /// <summary>
        /// ��ʼ��֤�����
        /// </summary>
        /// <returns></returns>
        private int InitCardType()
        {
            al = this.conMgr.QueryConstantList("CardType");
            if (al == null)
            {
                MessageBox.Show("��ȡ֤������ʱ����!" + this.conMgr.Err, "��ʾ");
                return -1;
            }

            this.cmbCardType.AddItems(al);

            return 0;
        }

        /// <summary>
        /// ���ɽ�������б�
        /// </summary>
        /// <returns></returns>
        private int initPact()
        {
            int count = 0, colCount = 0, row = 0;

            this.al = this.conMgr.QueryConstantList("PACTUNIT");
            //this.al = this.pactMgr.GetPactUnitInfo() ;
            if (al == null)
            {
                MessageBox.Show("��ȡ���ߺ�ͬ��λ��Ϣʱ����!" + this.conMgr.Err, "��ʾ");
                return -1;
            }

            colCount = this.fpPayKind.ColumnCount / 2;

            if (this.fpPayKind.RowCount > 0)
                this.fpPayKind.Rows.Remove(0, this.fpPayKind.RowCount);

            foreach (Neusoft.HISFC.Object.Base.Const obj in this.al)
            {
                if (obj.IsValid == false) continue;//����

                if (count % colCount == 0)
                {
                    this.fpPayKind.Rows.Add(this.fpPayKind.RowCount, 1);
                    row = this.fpPayKind.RowCount - 1;
                }

                this.fpPayKind.SetValue(row, 2 * (count % colCount), obj.ID, false);
                this.fpPayKind.SetValue(row, 2 * (count % colCount) + 1, obj.Name, false);

                count++;
            }

            this.cmbPayKind.AddItems(this.al);

            return 0;
        }
        /// <summary>
        /// �������뷨�б�
        /// </summary>
        private void initInputMenu()
        {

            for (int i = 0; i < InputLanguage.InstalledInputLanguages.Count; i++)
            {
                InputLanguage t = InputLanguage.InstalledInputLanguages[i];
                System.Windows.Forms.ToolStripMenuItem m = new ToolStripMenuItem();
                m.Text = t.LayoutName;
                //m.Checked = true;
                m.Click += new EventHandler(m_Click);

                this.neuContextMenuStrip1.Items.Add(m);
            }
        }

        /// <summary>
        /// ��ʼ��ԤԼʱ��ؼ�
        /// </summary>
        private void InitBookingDate()
        {
            this.ucChooseDate = new ucChooseBookingDate();

            this.panel1.Controls.Add(ucChooseDate);

            this.ucChooseDate.BringToFront();
            this.ucChooseDate.Location = new Point(this.dtBookingDate.Left, this.dtBookingDate.Top + this.dtBookingDate.Height);
            this.ucChooseDate.Visible = false;
            this.ucChooseDate.SelectedItem += new Registration.ucChooseBookingDate.dSelectedItem(ucChooseDate_SelectedItem);
        }
        /// <summary>
        /// ����
        /// </summary>
        private void clear()
        {
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();

            this.regObj = null;
            //�趨Ĭ��     //{E3583E08-B745-42ad-8543-1829EC837EE2} �ж�Ϊ��ʱ���ı�Һż���Ĭ��Ϊ��ͨ��
            this.SetRegLevelDefault();

            this.cmbDept.Tag = "";
            this.cmbDoctor.Tag = "";
            this.txtCardNo.Text = "";
            this.cmbSex.Text = "��";

            this.txtAge.Text = "";
            this.txtName.Text = "";
            this.cmbUnit.SelectedIndex = 0;
            this.cmbPayKind.Tag = this.DefaultPactID;
            this.txtMcardNo.Text = "";
            this.txtPhone.Text = "";
            this.txtAddress.Text = "";
            this.cmbCardType.Tag = "";
            this.dtBirthday.Value = current;
            //this.lbSum.Text = this.fpList.RowCount.ToString(); 
            this.lbSum.Text = this.SetRegNum();
            //this.lbTot.Text = "";
            //this.lbReceive.Text = "";
            this.lbTip.Text = "";

            this.ClearBookingInfo();
            this.SetBookingDate(current);
            this.SetDefaultBookingTime(current);
            this.cmbRegLevel.Focus();
            this.chbEncrpt.Checked = false;
            this.isReadCard = false;
            this.chbBookFee.Checked = false; //minqsh 20100603 �޸�Ϊfalse���Ϻ���ұ�������ղ������� {708443C7-3CAE-4ede-B69E-6C9CAFC9AECD}

            this.chbCardFee.Checked = false;//add by wwei_neu 2013-12-26 ��ҽͨ����Ҫ�۳���������

            this.txtIdNO.Text = "";
            // this.myYBregObj = null;
            this.SetEnabled(true);
            //{2B6167F7-339B-4f09-9af6-C5CD6Agg3AC89}
            //this.siBigSickDignose = "";
            //this.siBigSickDignoseName = "";
            //this.siBigSickItem = "";
            //this.siBigSickItemName = "";
            //this.priveNo = "";
            //this.lbSiInformation.Visible = false;
            //{F2FB1293-6433-4db5-9BF1-EC855FDF408C}
            this.ViewInvoiceNo();   //��ʾ��Ʊ��
            //{F2FB1293-6433-4db5-9BF1-EC855FDF408C}
            // {E68CD3A2-C8BF-4df5-A02B-E23B13747654} add by zzr  2010-11-22 ת�ﵥ��
            txtTranHospCode.Text = "";
            tbSIBalanceCost.Clear();
            txtVIPNo.Clear(); // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
            txtName.ReadOnly = false;
            this.txtParentName.Text = "";

            this.booking = new Neusoft.HISFC.Object.Registration.Booking();
            this.cmbRegLevel.Enabled = true;
            this.cmbDept.Enabled = true;
            this.cmbDoctor.Enabled = true;

        }

        /// <summary>
        /// ���ԤԼ��Ϣ
        /// </summary>
        private void ClearBookingInfo()
        {
            this.txtOrder.Text = "";
            this.txtOrder.Tag = null;
        }

        /// <summary>
        /// �趨�Һż����Ĭ��ֵ
        /// </summary>
        private void SetRegLevelDefault()
        {
            if (this.cmbRegLevel.alItems != null)
            {
                ///�Һ��շѣ�ÿ�ܶ����ġ���Ĭ�Ͻ��Һ�����Ϊ���������
                ///add by shenwei 2014-12-17 {6ECB3211-3D94-4de7-94CE-B0DAEA9468EC}
                DateTime currentDate = this.regMgr.GetDateTimeFromSysDateTime();//DateTime.Now;
                string week = getWeek(currentDate);
                foreach (Neusoft.NFC.Object.NeuObject obj in this.cmbRegLevel.alItems)
                {
                    if (week == "���ڶ�" || week == "������" || week == "������")
                    {
                        if ((obj as Neusoft.HISFC.Object.Registration.RegLevel).Name == "��������")
                        {
                            this.cmbRegLevel.Text = (obj as Neusoft.HISFC.Object.Registration.RegLevel).Name;
                            this.cmbRegLevel.Tag = (obj as Neusoft.HISFC.Object.Registration.RegLevel).ID;
                            return;
                        }
                    }
                }

                foreach (Neusoft.NFC.Object.NeuObject obj in this.cmbRegLevel.alItems)
                {
                    if ((obj as Neusoft.HISFC.Object.Registration.RegLevel).IsDefault)
                    {
                        this.cmbRegLevel.Text = (obj as Neusoft.HISFC.Object.Registration.RegLevel).Name;
                        this.cmbRegLevel.Tag = (obj as Neusoft.HISFC.Object.Registration.RegLevel).ID;
                        return;
                    }
                }
            }
            this.cmbRegLevel.Tag = "";//�˵��ǻ���,���û��Ĭ��ֵ��س��������ʾ�޹Һż���,��
        }

        /// <summary>
        /// ��ʼ�����
        /// </summary>
        private void InitNoon()
        {
            Neusoft.HISFC.Management.Registration.Noon noonMgr = new Neusoft.HISFC.Management.Registration.Noon();

            this.alNoon = noonMgr.Query();
            if (alNoon == null)
            {
                MessageBox.Show("��ȡ�����Ϣʱ����!" + noonMgr.Err, "��ʾ");
                return;
            }
        }

        /// <summary>
        /// ��ȡ���
        /// </summary>
        /// <param name="current"></param>
        /// <returns></returns>
        private string getNoon(DateTime current)
        {
            if (this.alNoon == null) return "";
            /*
             * ���������Ϊ���Ӧ���ǰ���һ��ȫ��ʱ�����磺06~12,����:12~18����Ϊ����,
             * ʵ�����Ϊҽ������ʱ���,�������Ϊ08~11:30������Ϊ14~17:30
             * ��������Һ�Ա����������ʱ��ιҺ�,���п�����ʾ���δά��
             * ���Ը�Ϊ���ݴ���ʱ�����ڵ�������磺9��30��06~12֮�䣬��ô���ж��Ƿ��������
             * 06~12֮�䣬ȫ������˵��9:30���Ǹ�������
             */
            //			foreach(neusoft.HISFC.Object.Registration.Noon obj in alNoon)
            //			{
            //				if(int.Parse(current.ToString("HHmmss"))>=int.Parse(obj.BeginTime.ToString("HHmmss"))&&
            //					int.Parse(current.ToString("HHmmss"))<int.Parse(obj.EndTime.ToString("HHmmss")))
            //				{
            //					return obj.ID;
            //				}
            //			}

            int[,] zones = new int[,] { { 0, 120000 }, { 120000, 180000 }, { 180000, 235959 } };
            int time = int.Parse(current.ToString("HHmmss"));
            int begin = 0, end = 0;

            for (int i = 0; i < 3; i++)
            {
                if (zones[i, 0] <= time && zones[i, 1] > time)
                {
                    begin = zones[i, 0];
                    end = zones[i, 1];
                    break;
                }
            }

            foreach (Neusoft.HISFC.Object.Base.Noon obj in alNoon)
            {
                if (int.Parse(obj.StartTime.ToString("HHmmss")) >= begin &&
                    int.Parse(obj.EndTime.ToString("HHmmss")) <= end)
                {
                    return obj.ID;
                }
            }

            return "";
        }
        /// <summary>
        /// �����������ȡ�������
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private string getNoon(string ID)
        {
            if (this.alNoon == null) return ID;

            foreach (Neusoft.HISFC.Object.Base.Noon obj in alNoon)
            {
                if (obj.ID == ID) return obj.Name;
            }

            return ID;
        }
        private string QeryNoonName(string noonid)
        {
            Neusoft.HISFC.Management.Registration.Noon noonMgr = new Neusoft.HISFC.Management.Registration.Noon();
            return noonMgr.Query(noonid);

        }

        #region Get��Set Oper's Recipe
        /// <summary>
        /// ��ȡ��ǰ������
        /// </summary>
        /// <param name="OperID"></param>		
        private void GetRecipeNo(string OperID)
        {
            if (this.GetRecipeType == 1)
            {
                this.txtRecipeNo.Text = "";//ÿ�ε�½�Լ�¼�봦����
            }
            else if (this.GetRecipeType == 2)
            {
                Neusoft.NFC.Object.NeuObject obj = this.conMgr.GetConstansObj("RegRecipeNo", OperID);
                if (obj == null)
                {
                    MessageBox.Show("��ȡ�����ų���!" + this.conMgr.Err, "��ʾ");
                    return;
                }
                if (obj.Name == "")
                {
                    this.txtRecipeNo.Text = "0";
                }
                else
                {
                    this.txtRecipeNo.Text = obj.Name;
                }
            }
            //{B0B20CE3-195C-4aee-AB13-CEBB5EA9BB94}
            else
            {
                Neusoft.NFC.Object.NeuObject obj = this.conMgr.GetConstansObj("RegRecipeNo", OperID);
                if (obj == null)
                {
                    MessageBox.Show("��ȡ�����ų���!" + this.conMgr.Err, "��ʾ");
                    return;
                }
                if (obj.Name == "")
                {
                    this.txtRecipeNo.Text = "0";
                }
                else
                {
                    this.txtRecipeNo.Text = obj.Name;
                }
            }
        }

        /// <summary>
        /// �޸Ĵ�����
        /// </summary>
        private void ChangeRecipe()
        {
            //this.txtRecipeNo.TabStop = true ;
            this.txtRecipeNo.BorderStyle = BorderStyle.Fixed3D;
            this.txtRecipeNo.BackColor = SystemColors.Window;
            this.txtRecipeNo.ReadOnly = false;
            this.txtRecipeNo.ForeColor = SystemColors.WindowText;
            this.txtRecipeNo.Font = new Font("����", 10);
            this.txtRecipeNo.Location = new Point(381, 10);

            this.txtRecipeNo.Focus();
        }
        private void txtRecipeNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.cmbRegLevel.Focus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        /// <summary>
        /// ���ô���
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>		
        private void txtRecipeNo_Validating(object sender, CancelEventArgs e)
        {
            if (this.txtRecipeNo.ReadOnly == false)
            {
                string r = this.txtRecipeNo.Text.Trim();

                try
                {
                    if (long.Parse(r) < 0)
                    {
                        MessageBox.Show("�����Ų���С����!", "��ʾ");
                        e.Cancel = true;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    string err = ex.Message;
                    MessageBox.Show("�����ű���������!", "��ʾ");
                    e.Cancel = true;
                    return;
                }
                this.SetRecipeNo();
            }
        }

        /// <summary>
        /// ���ô�����ֻ��
        /// </summary>
        private void SetRecipeNo()
        {
            //this.txtRecipeNo.TabStop = false ;
            this.txtRecipeNo.ReadOnly = true;
            this.txtRecipeNo.Location = new Point(381, 14);
            this.txtRecipeNo.BackColor = SystemColors.AppWorkspace;
            this.txtRecipeNo.ForeColor = Color.Yellow;
            this.txtRecipeNo.Font = new Font("����", 11, FontStyle.Bold);
            this.txtRecipeNo.BorderStyle = BorderStyle.None;
        }


        /// <summary>
        /// �رմ���ʱ����Һ�Ա�Ĵ�����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ucRegister_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (this.regMgr.Connection.State == ConnectionState.Closed) return;
            string recipeNO = this.txtRecipeNo.Text.Trim();
            if ((recipeNO != "" && recipeNO != string.Empty))
            {
                if (this.SaveRecipeNo() == -1)
                {
                    //e.Cancel = true ;
                }
            }
        }
        /// <summary>
        /// ���洦����¼
        /// </summary>
        /// <returns></returns>
        private int SaveRecipeNo()
        {
            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(this.regMgr.con);
            //SQLCA.BeginTransaction();

            try
            {
                this.conMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);

                Neusoft.HISFC.Object.Base.Const con = new Neusoft.HISFC.Object.Base.Const();
                con.ID = this.regMgr.Operator.ID;//����Ա
                con.Name = this.txtRecipeNo.Text.Trim();//������
                con.IsValid = true;

                int rtn = this.conMgr.UpdateConstant("RegRecipeNo", con);
                if (rtn == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.conMgr.Err, "��ʾ");
                    return -1;
                }
                if (rtn == 0)//����û�����ݡ�����
                {
                    if (this.conMgr.InsertConstant("RegRecipeNo", con) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.conMgr.Err, "��ʾ");
                        return -1;
                    }
                }

                Neusoft.NFC.Management.PublicTrans.Commit();
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return -1;
            }

            return 0;
        }
        #endregion

        #region Query operator's registration information of today
        /// <summary>
        /// ������Ա�������չҺ���Ϣ
        /// </summary>
        private void Retrieve()
        {
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();

            al = this.regMgr.Query(current.Date, current.Date.AddDays(1), this.regMgr.Operator.ID);
            if (al == null)
            {
                MessageBox.Show("�����Һ�Ա���չҺ���Ϣʱ����!" + regMgr.Err, "��ʾ");
                return;
            }

            if (this.fpList.RowCount > 0)
                this.fpList.Rows.Remove(0, this.fpList.RowCount);

            foreach (Neusoft.HISFC.Object.Registration.Register obj in al)
            {
                this.addRegister(obj);
            }
            this.lbSum.Text = this.SetRegNum();

        }
        /// <summary>
        /// ������Ч�Һ���

        /// </summary>
        /// <returns></returns>
        private string SetRegNum()
        {
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();
            string result = this.regMgr.QueryValidRegNumByOperAndOperDT(this.regMgr.Operator.ID, current.Date.ToString(), current.Date.AddDays(1).ToString());
            if (result == "-1")
            {
                MessageBox.Show(this.regMgr.Err);
                result = "0";
            }

            return result;

        }
        /// <summary>
        /// ���ӹҺż�¼
        /// </summary>
        /// <param name="obj"></param>
        private void addRegister(Neusoft.HISFC.Object.Registration.Register obj)
        {
            this.fpList.Rows.Add(this.fpList.RowCount, 1);
            int cnt = this.fpList.RowCount - 1;
            this.fpList.ActiveRowIndex = cnt;

            this.fpList.SetValue(cnt, 0, obj.PID.CardNO, false);//������
            this.fpList.SetValue(cnt, 1, obj.Name, false);//����
            this.fpList.SetValue(cnt, 2, obj.Pact.Name, false);
            this.fpList.SetValue(cnt, 3, obj.DoctorInfo.Templet.RegLevel.Name, false);
            this.fpList.SetValue(cnt, 4, obj.DoctorInfo.Templet.Dept.Name, false);
            this.fpList.SetValue(cnt, 5, obj.DoctorInfo.Templet.Doct.Name, false);
            this.fpList.SetValue(cnt, 6, obj.OrderNO, false);
            this.fpList.SetValue(cnt, 7, obj.OwnCost, false);
            this.fpList.SetValue(cnt, 8, obj.PubCost, false);
            if (obj.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back ||
                obj.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Cancel)
            {
                this.fpList.Rows[cnt].BackColor = Color.MistyRose;
            }

            this.fpList.Rows[cnt].Tag = obj;
        }

        #endregion

        /// <summary>
        /// װ�ش�ӡ�ؼ�
        /// </summary>
        /// <returns></returns>
        private int LoadPrint()
        {
            //��ȡ��ӡ�ؼ�������   

            //object o = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(typeof(UFC.Registration.ucRegister), typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint));
            //if (o == null)
            //{
            //    MessageBox.Show("��ά��UFC.Registration.ucRegister����ӿ�Neusoft.HISFC.Integrate.Registration.IRegPrint��ʵ������!");                
            //}
            //else
            //{
            //    IRegPrint = o as Neusoft.HISFC.Integrate.Registration.IRegPrint;
            //}

            return 0;
        }

        #endregion

        #region Set booking Date
        /// <summary>
        /// set booking date
        /// </summary>
        /// <param name="seeDate"></param>
        private void SetBookingDate(DateTime seeDate)
        {
            this.dtBookingDate.Value = seeDate.Date;
            this.lbWeek.Text = this.getWeek(seeDate);
        }
        /// <summary>
        /// �������
        /// </summary>
        /// <param name="current"></param>
        /// <returns></returns>
        private string getWeek(DateTime current)
        {
            string[] week = new string[] { "������", "����һ", "���ڶ�", "������", "������", "������", "������" };

            return week[(int)current.DayOfWeek];
        }

        /// <summary>
        /// ����Ĭ�������,���ﰲ��ʱ�����ʾ
        /// </summary>
        /// <param name="seeDate"></param>
        private void SetDefaultBookingTime(DateTime seeDate)
        {
            Neusoft.HISFC.Object.Registration.Schema schema = new Neusoft.HISFC.Object.Registration.Schema();
            schema.Templet.Begin = seeDate.Date;
            schema.Templet.End = seeDate.Date;

            this.SetBookingTime(schema);

            this.SetBookingTag(null);
        }

        /// <summary>
        /// ���þ���ʱ���
        /// </summary>
        /// <param name="begin"></param>
        /// <param name="end"></param>
        private void SetBookingTime(Neusoft.HISFC.Object.Registration.Schema schema)
        {
            this.dtBegin.Value = schema.Templet.Begin;
            this.dtEnd.Value = schema.Templet.End;

            this.SetBookingTag(schema);
        }
        /// <summary>
        /// ��������ʱ���ʵ����Ϣ
        /// </summary>
        /// <param name="schema"></param>
        private void SetBookingTag(Neusoft.HISFC.Object.Registration.Schema schema)
        {
            this.dtBookingDate.Tag = schema;

            if (schema == null)
            {
                this.lbRegLmt.Text = "";
                this.lbReg.Text = "";
                this.lbTelLmt.Text = "";
                this.lbTel.Text = "";
                this.lbSpeLmt.Text = "";
                this.lbSpe.Text = "";
            }
            else
            {
                this.lbRegLmt.Text = schema.Templet.RegQuota.ToString();//���˹Һ��޶�
                this.lbReg.Text = schema.RegedQTY.ToString();//�ѹҺ�����
                this.lbTelLmt.Text = schema.Templet.TelQuota.ToString();//�����޶�
                this.lbTel.Text = schema.TeledQTY.ToString();
                this.lbSpeLmt.Text = schema.Templet.SpeQuota.ToString();//�����޶�
                this.lbSpe.Text = schema.SpedQTY.ToString();
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// �Һż���õ�����,��ʾ�Һż����б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbRegLevel_Enter(object sender, System.EventArgs e)
        {
            this.QueryRegLevl();

            if (this.fpSpread1.ActiveSheetIndex != 0) this.fpSpread1.ActiveSheetIndex = 0;

            this.setEnterColor(this.cmbRegLevel);
        }
        /// <summary>
        /// �Һſ��ҵõ����㣬��ʾ�Һſ����б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDept_Enter(object sender, System.EventArgs e)
        {
            this.setEnterColor(this.cmbDept);

            if (this.fpSpread1.ActiveSheetIndex != 1) this.fpSpread1.ActiveSheetIndex = 1;
        }
        /// <summary>
        /// ҽ���õ����㣬��ʾҽ���б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDoctor_Enter(object sender, System.EventArgs e)
        {
            if (this.fpSpread1.ActiveSheetIndex != 2) this.fpSpread1.ActiveSheetIndex = 2;

            this.setEnterColor(this.cmbDoctor);
        }
        /// <summary>
        /// �������õ����㣬��ʾ�б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbPayKind_Enter(object sender, System.EventArgs e)
        {
            if (this.fpSpread1.ActiveSheetIndex != 3) this.fpSpread1.ActiveSheetIndex = 3;

            this.setEnterColor(this.cmbPayKind);
        }
        /// <summary>
        /// �����ŵõ�����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCardNo_Enter(object sender, System.EventArgs e)
        {
            if (this.fpSpread1.ActiveSheetIndex != 4) this.fpSpread1.ActiveSheetIndex = 4;

            this.setEnterColor(this.txtCardNo);
        }
        private void txtName_Enter(object sender, System.EventArgs e)
        {
            if (this.CHInput != null) InputLanguage.CurrentInputLanguage = this.CHInput;
            if (this.fpSpread1.ActiveSheetIndex != 4) this.fpSpread1.ActiveSheetIndex = 4;

            this.setEnterColor(this.txtName);
        }
        private void txtName_Leave(object sender, System.EventArgs e)
        {
            InputLanguage.CurrentInputLanguage = InputLanguage.DefaultInputLanguage;
        }
        private void txtAddress_Enter(object sender, System.EventArgs e)
        {
            if (this.CHInput != null) InputLanguage.CurrentInputLanguage = this.CHInput;
            if (this.fpSpread1.ActiveSheetIndex != 4) this.fpSpread1.ActiveSheetIndex = 4;

            this.setEnterColor(this.txtAddress);
        }

        private void txtAddress_Leave(object sender, System.EventArgs e)
        {
            InputLanguage.CurrentInputLanguage = InputLanguage.DefaultInputLanguage;
        }


        #endregion

        #region ���õ�ǰ�ؼ���ɫ
        private void setEnterColor(Control ctl)
        {
            ctl.BackColor = Color.OldLace;
        }
        private void setLeaveColor(Control ctl)
        {
            ctl.BackColor = Color.WhiteSmoke;
        }
        #endregion

        #region �س�

        #region reglevel
        /// <summary>
        /// ������Ӧ�Һ���Ϣ(ģ��,�ѹ�,ʣ�����Ϣ)
        /// </summary>
        private void QueryRegLevl()
        {
            //�ָ���ʼ״̬
            this.cmbDept.Tag = "";
            this.cmbDoctor.Tag = "";
            this.lbTip.Text = "";

            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;

            #region {A9412582-3456-4f55-9217-1F33CB51BCED} �жϸ��ݹҺż���Һ�  add by chenzl 2011-05-22 ̩������ҽԺ

            if (!IsCheckLevel)
            {
                #region  ����
                if (this.IsSelectDeptFirst)//�����ѡ����,���ɿ����Ű��б�
                {
                    //��ʾ�����б�
                    this.SetDeptFpStyle(false);
                    if (this.alAllowedDept != null && this.alAllowedDept.Count > 0)
                    {
                        this.AddAllowedDeptToDataSet(this.alAllowedDept);
                        this.addRegDeptToCombox();
                    }
                    else//��ʾȫ������
                    {
                        this.AddClinicDeptsToDataSet(this.alDept);
                        this.cmbDept.AddItems(this.alDept);
                    }
                    this.addRegDeptToFp(false);
                }

                #endregion
            }

            #endregion

            #region {A9412582-3456-4f55-9217-1F33CB51BCED} �жϸ��ݹҺż���Һ�
            if (IsCheckLevel)
            {

                #region ���ɹҺż����Ӧ�Ŀ��ҡ�ҽ���б�
                Neusoft.HISFC.Object.Registration.RegLevel Level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                //{D58D1188-512B-4b58-BBCF-65DA054C5E0E}
                if (Level == null) return;
                //{D58D1188-512B-4b58-BBCF-65DA054C5E0E}
                if (Level.IsExpert || Level.IsSpecial)//ר�ҡ�����
                {
                    #region ר��
                    if (this.IsSelectDeptFirst)//�����ѡ����,���ɿ����Ű��б�
                    {
                        this.SetDeptFpStyle(false);
                        //�����Ҳ����ר�ҵĿ����б�
                        this.GetSchemaDept(Neusoft.HISFC.Object.Base.EnumSchemaType.Doct);
                        this.addRegDeptToFp(false);

                        //����Combox�����б�
                        //{920686B9-AD51-496e-9240-5A6DA098404E}
                        //if (!this.ComboxIsListAll)
                        if (!this.isAddAllDept)
                        {
                            this.addRegDeptToCombox();
                        }
                        else
                        {
                            this.cmbDept.AddItems(this.alDept);
                        }

                        //���ҽ���б�,��ѡ����Һ��ټ�������ר��
                        ArrayList al = new ArrayList();

                        this.AddDoctToDataSet(al);
                        this.AddDoctToFp(true);
                        this.cmbDoctor.AddItems(al);
                    }
                    else
                    {
                        //ר�Һ�ֱ��ѡ��ҽ��,���������Ҵ�,����ȫ����������б�
                        this.SetDeptFpStyle(false);
                        this.AddClinicDeptsToDataSet(this.alDept);
                        this.addRegDeptToFp(false);
                        this.cmbDept.AddItems(this.alDept);
                        //
                        this.GetDoct();//���ȫ������ҽ��
                    }
                    #endregion
                }
                else if (Level.IsFaculty)//ר��
                {
                    #region ר��
                    //��ȡ����ר���б�
                    this.SetDeptFpStyle(true);
                    this.GetSchemaDept(Neusoft.HISFC.Object.Base.EnumSchemaType.Dept);
                    this.addRegDeptToFp(true);

                    //����Combox���������б�
                    //{920686B9-AD51-496e-9240-5A6DA098404E}
                    //if (this.ComboxIsListAll)
                    if (this.isAddAllDept)
                    {
                        this.cmbDept.AddItems(this.alDept);
                    }
                    else
                    {
                        this.addRegDeptToCombox();
                    }

                    //���ҽ���б�,ר�Ʋ���Ҫѡ��ҽ��
                    ArrayList al = new ArrayList();

                    this.AddDoctToDataSet(al);
                    this.AddDoctToFp(false);
                    this.cmbDoctor.AddItems(al);
                    #endregion
                }
                else//��ͨ
                {
                    //��ʾ�����б�
                    this.SetDeptFpStyle(false);
                    if (this.alAllowedDept != null && this.alAllowedDept.Count > 0)
                    {
                        this.AddAllowedDeptToDataSet(this.alAllowedDept);
                        this.addRegDeptToCombox();
                    }
                    else//��ʾȫ������
                    {
                        this.AddClinicDeptsToDataSet(this.alDept);
                        this.cmbDept.AddItems(this.alDept);
                    }
                    this.addRegDeptToFp(false);

                }
                #endregion
            }
            #endregion
            //���ԤԼ��Ϣ
            this.ClearBookingInfo();

            //�趨Ĭ�Ͼ���ʱ���
            this.SetDefaultBookingTime(this.dtBookingDate.Value);

        }

        /// <summary>
        /// ѡ��Һż���
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbRegLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////�ָ���ʼ״̬
            //this.cmbDept.Tag = "";
            //this.cmbDoctor.Tag = "";
            //this.lbTip.Text = "";

            //if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;

            //#region ���ɹҺż����Ӧ�Ŀ��ҡ�ҽ���б�
            //Neusoft.HISFC.Object.Registration.RegLevel Level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;

            //if (Level.IsExpert || Level.IsSpecial)//ר�ҡ�����
            //{
            //    #region ר��
            //    if (this.IsSelectDeptFirst)//�����ѡ����,���ɿ����Ű��б�
            //    {
            //        this.SetDeptFpStyle(false);
            //        //�����Ҳ����ר�ҵĿ����б�
            //        this.GetSchemaDept(Neusoft.HISFC.Object.Base.EnumSchemaType.Doct);
            //        this.addRegDeptToFp(false);

            //        //����Combox�����б�
            //        if (!this.ComboxIsListAll)
            //        {
            //            this.addRegDeptToCombox();
            //        }
            //        else
            //        {
            //            this.cmbDept.AddItems(this.alDept);
            //        }

            //        //���ҽ���б�,��ѡ����Һ��ټ�������ר��
            //        ArrayList al = new ArrayList();

            //        this.AddDoctToDataSet(al);
            //        this.AddDoctToFp(true);
            //        this.cmbDoctor.AddItems(al);
            //    }
            //    else
            //    {
            //        //ר�Һ�ֱ��ѡ��ҽ��,���������Ҵ�,����ȫ����������б�
            //        this.SetDeptFpStyle(false);
            //        this.AddClinicDeptsToDataSet(this.alDept);
            //        this.addRegDeptToFp(false);
            //        this.cmbDept.AddItems(this.alDept);
            //        //
            //        this.GetDoct();//���ȫ������ҽ��
            //    }
            //    #endregion
            //}
            //else if (Level.IsFaculty)//ר��
            //{
            //    #region ר��
            //    //��ȡ����ר���б�
            //    this.SetDeptFpStyle(true);
            //    this.GetSchemaDept(Neusoft.HISFC.Object.Base.EnumSchemaType.Dept);
            //    this.addRegDeptToFp(true);

            //    //����Combox���������б�
            //    if (this.ComboxIsListAll)
            //    {
            //        this.cmbDept.AddItems(this.alDept);
            //    }
            //    else
            //    {
            //        this.addRegDeptToCombox();
            //    }

            //    //���ҽ���б�,ר�Ʋ���Ҫѡ��ҽ��
            //    ArrayList al = new ArrayList();

            //    this.AddDoctToDataSet(al);
            //    this.AddDoctToFp(false);
            //    this.cmbDoctor.AddItems(al);
            //    #endregion
            //}
            //else//��ͨ
            //{
            //    //��ʾ�����б�
            //    this.SetDeptFpStyle(false);
            //    if (this.alAllowedDept != null && this.alAllowedDept.Count > 0)
            //    {
            //        this.AddAllowedDeptToDataSet(this.alAllowedDept);
            //        this.addRegDeptToCombox();
            //    }
            //    else//��ʾȫ������
            //    {
            //        this.AddClinicDeptsToDataSet(this.alDept);
            //        this.cmbDept.AddItems(this.alDept);
            //    }
            //    this.addRegDeptToFp(false);

            //}
            //#endregion

            ////���ԤԼ��Ϣ
            //this.ClearBookingInfo();

            ////�趨Ĭ�Ͼ���ʱ���
            //this.SetDefaultBookingTime(this.dtBookingDate.Value); 

            //{A9412582-3456-4f55-9217-1F33CB51BCED} ���ݿ��ҡ�ҽ����ȡ�Ű���Ϣ���Һż��� add by chenzl 2011-05-23  ̩����ҽԺ
            if (IsCheckLevel)
            {
                this.QueryRegLevl();
            }

            //{8632997E-814D-4639-A02A-40DE9BD84ADA}��������͹Һż������
            Neusoft.HISFC.Object.Registration.RegLevel Level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            if (null != Level && !string.IsNullOrEmpty(Level.ID))
            {
                if (Level.ID == "06")
                {
                    this.cmbDept.Tag = "1027";
                }
                else if (Level.ID.Equals("15"))
                {
                    //����
                    this.cmbDept.Tag = "1033";
                }
                else
                {
                    this.cmbDept.Tag = null;
                }
            }
            //this.QueryRegLevl();
        }
        /// <summary>
        /// �Һż���س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbRegLevel_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmbRegLevel.Tag == null || this.cmbRegLevel.Tag.ToString() == "")
                {
                    MessageBox.Show("��ѡ��Һż���!", "��ʾ");
                    this.cmbRegLevel.Focus();
                    return;
                }

                //�ж���ר�Һ�,������ҽ����
                Neusoft.HISFC.Object.Registration.RegLevel Level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                //���ɷ���
                if (this.getCost() == -1)
                {
                    this.cmbRegLevel.Focus();
                    return;
                }

                //������ת
                //ר�ҡ�����Ų���ѡ��Һſ���,ֱ������ҽ����
                if (Level.IsExpert || Level.IsSpecial)
                {
                    if (this.IsSelectDeptFirst)
                    {
                        this.cmbDept.Focus();
                    }
                    else
                    {
                        this.cmbDoctor.Focus();
                    }
                }
                else if (Level.IsFaculty)//ר�ƺ�,ֱ���������Ҵ�
                {
                    this.cmbDept.Focus();
                }
                else//��������3��,����Ҫ�����Ű��޶�,���ò��Ű�ҽԺ,�����Ӳ���,�趨��ת˳��,�Լ��Ƿ�Ҫ¼�뿴��ҽ��
                {
                    this.cmbDept.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// ��ȡ�������
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private int GetSchemaDept(Neusoft.HISFC.Object.Base.EnumSchemaType type)
        {
            DataSet ds = new DataSet();

            ds = this.SchemaMgr.QueryDept(this.dtBookingDate.Value.Date,
                                        this.regMgr.GetDateTimeFromSysDateTime(), type);
            if (ds == null)
            {
                MessageBox.Show(this.SchemaMgr.Err, "��ʾ");
                return -1;
            }

            this.addDeptToDataSet(ds, type);

            return 0;
        }
        /// <summary>
        /// ��ר�ơ�ר�ҳ���������ӵ�DataSet
        /// </summary>
        /// <param name="ds"></param>
        /// <param name="type"></param>
        private void addDeptToDataSet(DataSet ds, Neusoft.HISFC.Object.Base.EnumSchemaType type)
        {
            dsItems.Tables[0].Rows.Clear();
            //DateTime current = this.regMgr.GetDateTimeFromSysDateTime() ;

            if (type == Neusoft.HISFC.Object.Base.EnumSchemaType.Dept)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dsItems.Tables["Dept"].Rows.Add(new object[]
                        {
                            row[0],//���Ҵ���
                            row[1],//��������
                            row[10],//ƴ����
                            row[11],//�����
                            row[12],//�Զ�����
                            row[5],//�Һ��޶�
                            row[6],//�ѹҺ���
                            row[7],//ԤԼ�޶�
                            row[8],//��ԤԼ��
                            row[3],//��ʼʱ��
                            row[4],//����ʱ��
                            row[2],//���
                            Neusoft.NFC.Function.NConvert.ToBoolean(row[9])
                        });
                }
            }
            else
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dsItems.Tables["Dept"].Rows.Add(new object[]
                        {
                            row[0],//���Ҵ���
                            row[1],//��������
                            row[2],//ƴ����
                            row[3],//�����
                            row[4],//�Զ�����
                            0,//�Һ��޶�
                            0,//�ѹҺ���
                            0,//ԤԼ�޶�
                            0,//��ԤԼ��
                            DateTime.MinValue,//��ʼʱ��
                            DateTime.MinValue,//����ʱ��
                            "",//���
                            false
                        });
                }
            }
        }
        #endregion

        #region dept
        /// <summary>
        /// ѡ��Һſ���
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.IsTriggerSelectedIndexChanged == false) return;

            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;

            //���ԤԼ��Ϣ
            this.ClearBookingInfo();
            //���ҽ��
            this.cmbDoctor.Tag = "";

            //ר�ҡ�ר�ơ�����Ŷ���Ҫ���Ű��޶�
            Neusoft.HISFC.Object.Registration.RegLevel regLevel = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            if (regLevel == null)//û��ѡ��Һż���
            {
                MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                this.cmbRegLevel.Focus();
                return;
            }

            //��ʾ�ÿ�����ҽ���б�
            if (regLevel.IsSpecial || regLevel.IsExpert)
            {
                this.GetDoctByDept(this.cmbDept.Tag.ToString(), true);
            }
            else
            {
                #region {D0593887-0DEF-4fef-8190-28750FCEEF96} ��ͨ��ҽ���б�Ҳȡ���Ű��
                //this.GetDoctByDept(this.cmbDept.Tag.ToString(), false);
                this.GetDoctByDept(this.cmbDept.Tag.ToString(), true);
                #endregion
            }

            if (regLevel.IsExpert || regLevel.IsSpecial || regLevel.IsFaculty)
            {
                //�趨һ����Ч�ľ���ʱ���
                this.SetDeptZone(this.cmbDept.Tag.ToString(), this.dtBookingDate.Value, regLevel);
            }
            else
            {
                //�趨Ĭ��ԤԼʱ���
                this.SetDefaultBookingTime(this.dtBookingDate.Value);
            }

            //{8632997E-814D-4639-A02A-40DE9BD84ADA}��������͹Һż������
            if (this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() == "1027")
            {
                this.cmbRegLevel.Tag = "06";
                this.cmbRegLevel.Enabled = false;
            }
            else if (this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() == "1033")
            {
                this.cmbRegLevel.Tag = "15";
                this.cmbRegLevel.Enabled = false;
            }
            else
            {
                if (this.cmbRegLevel.Tag != null && (this.cmbRegLevel.Tag.ToString() == "06" || this.cmbRegLevel.Tag.ToString() == "15"))
                {
                    this.cmbRegLevel.Tag = "01";
                }
                this.cmbRegLevel.Enabled = true;
            }
        }
        /// <summary>
        /// �Һſ��һس�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDept_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Neusoft.HISFC.Object.Registration.RegLevel regLevel = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                if (regLevel == null)
                {
                    MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                    this.cmbRegLevel.Focus();
                    return;
                }

                //û��ѡ�����,��ʾ���е�ҽ��
                if (this.cmbDept.Tag == null || this.cmbDept.Tag.ToString() == "")
                {
                    if (regLevel.IsExpert || regLevel.IsSpecial)
                    {
                        this.GetDoct();//���ȫ������ҽ��
                    }
                    else
                    {
                        this.SetDoctFpStyle(false);
                        this.cmbDoctor.AddItems(this.alDoct);
                        this.AddDoctToDataSet(this.alDoct);
                        this.AddDoctToFp(false);
                    }
                    //�趨Ĭ��ԤԼʱ���
                    this.SetDefaultBookingTime(this.dtBookingDate.Value);
                }

                this.cmbDoctor.Tag = "";

                if (regLevel.IsFaculty)
                {
                    //��ȡ�����Ч��һ���Ű���Ϣ ��ҽ������ֲ����ˣ�������������
                    /*if(this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() != "")
                    {
                        if( this.getLastSchema(neusoft.HISFC.Object.Registration.SchemaTypeNUM.Dept,regLevel,
                            this.cmbDept.Tag.ToString(), "") == -1)
                        {
                            this.cmbDept.Focus() ;
                            return ;
                        }
                    }*/
                    if (this.cmbDept.Tag != null & this.cmbDept.Tag.ToString() != "")
                    {
                        if (this.DisplaySchemaTip(Neusoft.HISFC.Object.Base.EnumSchemaType.Dept) == -1)
                        {
                            this.cmbDept.Focus();
                            return;
                        }
                    }
                    this.dtBookingDate.Focus();
                }
                else if (regLevel.IsSpecial || regLevel.IsExpert)
                {
                    this.cmbDoctor.Focus();
                }
                else//����ר�ҡ�ר�ơ�����Ų������뿴��ҽ���;���ʱ��,��Ȼ�����ò���Ҫ��������ҽ����
                {
                    //{920686B9-AD51-496e-9240-5A6DA098404E} ��������ά���Ƿ���������ҽ��
                    if (this.IsSetDoctFocusForCommon)
                    {
                        this.cmbDoctor.Focus();
                    }
                    else
                    {
                        this.txtCardNo.Focus();
                    }
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
                return;
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// ���ݿ��Ҵ����ѯ����ҽ��
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="IsDisplaySchema"></param>
        /// <returns></returns>
        private int GetDoctByDept(string deptID, bool IsDisplaySchema)
        {
            if (IsDisplaySchema)
            {
                DataSet ds;

                ds = this.SchemaMgr.QueryDoct(this.dtBookingDate.Value,
                                                this.regMgr.GetDateTimeFromSysDateTime(), deptID);
                if (ds == null)
                {
                    MessageBox.Show(this.SchemaMgr.Err, "��ʾ");
                    return -1;
                }

                this.SetDoctFpStyle(true);
                this.AddDoctToDataSet(ds);
                //{920686B9-AD51-496e-9240-5A6DA098404E} ��������ά���Ƿ���������ҽ��
                //if (this.ComboxIsListAll)
                if (this.isAddAllDoct)
                {
                    this.cmbDoctor.AddItems(this.alDoct);
                }
                else
                {
                    this.AddDoctToCombox();
                }
            }
            else
            {
                //{920686B9-AD51-496e-9240-5A6DA098404E} ��������ά���Ƿ���������ҽ��
                if (this.isAddAllDoct)
                {
                    this.cmbDoctor.AddItems(this.alDoct);
                    this.SetDoctFpStyle(false);
                    this.AddDoctToDataSet(this.alDoct);
                }
                else
                {
                    al = this.conMgr.QueryEmployee(Neusoft.HISFC.Object.Base.EnumEmployeeType.D, deptID);
                    if (al == null)
                    {
                        MessageBox.Show("��ȡ����ҽ��ʱ����!" + this.conMgr.Err, "��ʾ");
                        return -1;
                    }
                    this.cmbDoctor.AddItems(al);
                    this.SetDoctFpStyle(false);
                    this.AddDoctToDataSet(al);
                }
            }

            this.AddDoctToFp(IsDisplaySchema);

            return 0;
        }
        /// <summary>
        /// ��ȡ���ճ���ȫ��ҽ��
        /// </summary>
        /// <returns></returns>
        private int GetDoct()
        {
            DataSet ds;

            ds = this.SchemaMgr.QueryDoct(this.dtBookingDate.Value, this.regMgr.GetDateTimeFromSysDateTime());
            if (ds == null)
            {
                MessageBox.Show(this.SchemaMgr.Err, "��ʾ");
                return -1;
            }

            this.SetDoctFpStyle(true);
            this.AddDoctToDataSet(ds);
            this.AddDoctToFp(true);
            //{920686B9-AD51-496e-9240-5A6DA098404E}
            //if (this.ComboxIsListAll)
            if (this.isAddAllDoct)
            {
                this.cmbDoctor.AddItems(this.alDoct);
            }
            else
            {
                this.AddDoctToCombox();
            }

            return 0;
        }

        /// <summary>
        /// �ҵ��ǽ��ں�or�����ں�
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        private bool IsProfessor(Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            bool rtn = false;

            if (level.IsExpert || level.IsSpecial)
            {
                foreach (Neusoft.HISFC.Object.Base.Const con in this.alProfessor)
                {
                    if (con.ID == level.ID)
                    {
                        return true;
                    }
                }
            }

            return rtn;
        }
        /// <summary>
        /// �趨����Ĭ�Ͼ���ʱ���
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="bookingDate"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        private int SetDeptZone(string deptID, DateTime bookingDate, Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            Registration.RegTypeNUM regType = Registration.RegTypeNUM.Faculty;

            #region Set regType value
            regType = this.getRegType(level);
            #endregion

            this.ucChooseDate.QueryDeptBooking(bookingDate, deptID, regType);

            //Ĭ����ʾ��һ������������ʱ��δ���ڡ��޶�δ�������Ű���Ϣ
            Neusoft.HISFC.Object.Registration.Schema schema = this.ucChooseDate.GetValidBooking(regType);

            if (schema == null)//û�з���������
            {
                this.SetDefaultBookingTime(bookingDate.Date);
            }
            else
            {
                this.SetBookingTime(schema);
            }

            return 0;
        }
        /// <summary>
        /// ���ݹҺż���ת��Ϊö��,�Һż������Ϊר�ҡ�ר�ơ�����
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        private Registration.RegTypeNUM getRegType(Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            Registration.RegTypeNUM regType = Registration.RegTypeNUM.Faculty;

            if (level.IsExpert)
            {
                regType = Registration.RegTypeNUM.Expert;
            }
            else if (level.IsFaculty)
            {
                regType = Registration.RegTypeNUM.Faculty;
            }
            else if (level.IsSpecial)
            {
                regType = Registration.RegTypeNUM.Special;
            }

            return regType;
        }

        /// <summary>
        /// ��ȡ�������Ч�Ű���Ϣ
        /// </summary>
        /// <param name="schemaType"></param>
        /// <param name="regLevel"></param>
        /// <param name="deptID"></param>
        /// <param name="doctID"></param>
        /// <returns></returns>
        private int getLastSchema(Neusoft.HISFC.Object.Base.EnumSchemaType schemaType,
            Neusoft.HISFC.Object.Registration.RegLevel regLevel, string deptID, string doctID)
        {
            Neusoft.HISFC.Object.Registration.Schema schema = this.SchemaMgr.Query(schemaType,
                                                    this.regMgr.GetDateTimeFromSysDateTime(), deptID, doctID);
            if (schema == null)
            {
                //����
                MessageBox.Show("��ȡ����Ű���Ϣ����!" + this.SchemaMgr.Err, "��ʾ");
                return -1;
            }


            if (schema.Templet.ID == "")
            {
                MessageBox.Show("û����Ч���Ű��¼!", "��ʾ");
                return -1;
            }

            this.IsTriggerSelectedIndexChanged = false;
            this.cmbDept.Tag = schema.Templet.Dept.ID;
            this.IsTriggerSelectedIndexChanged = true;

            this.SetBookingDate(schema.SeeDate);
            this.SetBookingTime(schema);

            return 0;
        }

        /// <summary>
        /// ��ʾҽ��һ�ܳ�����Ϣ
        /// </summary>
        /// <returns></returns>
        private int DisplaySchemaTip(Neusoft.HISFC.Object.Base.EnumSchemaType schemaType)
        {
            this.lbTip.Text = "";

            //����û�г���ҽ��
            if (this.dtBookingDate.Tag == null)
            {
                DateTime current = this.dtBookingDate.Value.Date;

                DateTime end = current.AddDays(6 - (int)current.DayOfWeek);

                //��дҵ����ˣ����췳
                //string sql = "SELECT distinct week FROM fin_opr_schema WHERE " +
                //    " see_date>to_date('" + current.ToString() + "','yyyy-mm-dd hh24:mi:ss') AND " +
                //    " see_date<=to_date('" + end.ToString() + "','yyyy-mm-dd hh24:mi:ss') ";

                DataSet ds = new DataSet();

                if (schemaType == Neusoft.HISFC.Object.Base.EnumSchemaType.Dept)
                {
                    //sql = sql + " AND schema_type = '0' AND dept_code = '" + this.cmbDept.Tag.ToString() + "'" +
                    //    " AND valid_flag = '1' ";
                    ds = this.SchemaMgr.QuerySchemaForRegister(current.ToString(), end.ToString(), "0", this.cmbDept.Tag.ToString(), "A");
                    if (ds == null)
                    {
                        MessageBox.Show(this.SchemaMgr.Err);
                        return -1;
                    }
                }
                else
                {
                    if (this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() != "")
                    {
                        //sql = sql + " AND schema_type = '1' AND doct_code = '" + this.cmbDoctor.Tag.ToString() + "'" +
                        //    " AND dept_code = '" + this.cmbDept.Tag.ToString() + "' AND valid_flag = '1' ";
                        ds = this.SchemaMgr.QuerySchemaForRegister(current.ToString(), end.ToString(), "1", this.cmbDept.Tag.ToString(), this.cmbDoctor.Tag.ToString());
                        if (ds == null)
                        {
                            MessageBox.Show(this.SchemaMgr.Err);
                            return -1;
                        }
                    }
                    else
                    {
                        //sql = sql + " AND schema_type = '1' AND doct_code = '" + this.cmbDoctor.Tag.ToString() + "'" +
                        //    " AND valid_flag = '1' ";
                        ds = this.SchemaMgr.QuerySchemaForRegister(current.ToString(), end.ToString(), "1", "A", this.cmbDoctor.Tag.ToString());
                        if (ds == null)
                        {
                            MessageBox.Show(this.SchemaMgr.Err);
                            return -1;
                        }
                    }
                }

                //DataSet ds = new DataSet();

                //if (this.SchemaMgr.ExecQuery(sql, ref ds) == -1)
                //{
                //    MessageBox.Show("��ȡ�Ű���Ϣ������!" + this.SchemaMgr.Err, "��ʾ");
                //    return -1;
                //}

                if (ds == null || ds.Tables[0].Rows.Count == 0)
                {
                    if (schemaType == Neusoft.HISFC.Object.Base.EnumSchemaType.Dept)
                    {
                        if (this.fpDept.RowCount == 0)
                        {
                            this.lbTip.Text = "��ר��һ���޳���";
                            MessageBox.Show("��������Ч�Ű��¼!", "��ʾ");
                            return -1;
                        }
                        else
                        {
                            this.lbTip.Text = "�����ѹ���,һ���޳���";
                            return 0;
                        }
                    }
                    else
                    {
                        if (this.fpDoctor.RowCount == 0)
                        {
                            this.lbTip.Text = "��ҽ��һ��δ�Ű�";
                            MessageBox.Show("��������Ч�Ű��¼!", "��ʾ");
                            return -1;
                        }
                        else
                        {
                            this.lbTip.Text = "�����ѹ���,һ���޳���";
                            return 0;
                        }
                    }
                }

                string[] week = new string[] { "��", "һ", "��", "��", "��", "��", "��" };
                string tip = "��";

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    tip = tip + week[Neusoft.NFC.Function.NConvert.ToInt32(row[0])] + "��";
                }
                this.lbTip.Text = tip.Substring(0, tip.Length - 1) + "����";

                //MessageBox.Show("��������Ч�Ű��¼!","��ʾ") ;

                return 0;
            }

            return 0;
        }
        /// <summary>
        /// ����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDept_TextChanged(object sender, System.EventArgs e)
        {
            string strFilter = "ID like '%" + this.cmbDept.Text + "%' or Spell_Code like '%" + this.cmbDept.Text + "%'"
                    + " or Name like '%" + this.cmbDept.Text + "%'";
            /* or Wb_Code like '%"+this.cmbDept.Text
            +"%' or Input_Code like '%"+this.cmbDept.Text+"%'";*/

            try
            {
                dvDepts.RowFilter = strFilter;
            }
            catch { }

            this.addRegDeptToFp(Neusoft.NFC.Function.NConvert.ToBoolean(this.fpDept.Tag));
        }
        #endregion

        #region doctor
        /// <summary>
        /// ѡ��ҽ��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDoctor_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ѡ��һ�������������Ű���Ϣ��ΪԤԼʱ��
            if (this.IsTriggerSelectedIndexChanged == false) return;

            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;
            //���ԤԼ��Ϣ
            this.ClearBookingInfo();

            #region {A9412582-3456-4f55-9217-1F33CB51BCED}  ����ҽ���Ű����ȡ�Һż��� add by chenzl 2011-05-22
            if (!IsCheckLevel)
            {
                //string docLevelCode = this.SchemaMgr.GetByID(obj.ID);
                Neusoft.NFC.Object.NeuObject schemaObj = new Neusoft.NFC.Object.NeuObject();
                Neusoft.HISFC.Object.Registration.Schema schemaList = new Neusoft.HISFC.Object.Registration.Schema();
                //schemaList = this.SchemaMgr.GetByDoctAndDept(cmbDept.Tag.ToString(), cmbDoctor.Tag.ToString());
                //{E3583E08-B745-42ad-8543-1829EC837EE2} �ж�Ϊ��ʱ���ı�Һż���
                //zhangwei 2019-09-24 �Һż��� ���Զ�ѡ����ҪĬ�ϳɵ�һ�� {C1553FFF-8A20-4a90-B571-68D23F7425AF}

                //if (schemaList.Templet.RegLevel.ID.ToString() != "")
                //{
                //    this.cmbRegLevel.Tag = schemaList.Templet.RegLevel.ID;
                //    this.cmbDept.Tag = schemaList.Templet.Dept.ID;
                //}

            }
            #endregion

            //ר�ҡ�ר�ơ�����Ŷ���Ҫ���Ű��޶�
            Neusoft.HISFC.Object.Registration.RegLevel regLevel = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;

            if (regLevel == null)//û��ѡ��Һż���
            {
                MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                this.cmbRegLevel.Focus();
                return;
            }
            //zhangwei 2019-09-24 �Һż��� ���Զ�ѡ����ҪĬ�ϳɵ�һ�� {C1553FFF-8A20-4a90-B571-68D23F7425AF}
            string sqlSE = @"select  
                                1
                                  FROM fin_opr_schema --ҽʦ����� 
                                 where dept_code = '{0}'
                                   and doct_code = '{1}'
                                   and to_char(begin_time, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
                                   and reglevl_code = '{2}'
                                   and end_time>sysdate and begin_time<sysdate";
            if (cmbDept.Tag!=null &&cmbDoctor.Tag!=null &&!string.IsNullOrEmpty(cmbDept.Tag.ToString()) && !string.IsNullOrEmpty(cmbDoctor.Tag.ToString()) && !string.IsNullOrEmpty(regLevel.ID))
            {
                sqlSE = string.Format(sqlSE, cmbDept.Tag.ToString(), cmbDoctor.Tag.ToString(), regLevel.ID);
                sqlSE = this.SchemaMgr.ExecSqlReturnOne(sqlSE);
                if (sqlSE != "1")
                {
                    MessageBox.Show("��ѯ�����Ű���Ϣ!", "��ʾ");
                    this.cmbRegLevel.Focus();
                    this.cmbRegLevel.Tag = "";///
                    return;
                }
            }
            if (regLevel.IsExpert || regLevel.IsSpecial)
            {
                //�趨һ����Ч�ľ���ʱ���
                this.SetDoctZone(this.cmbDoctor.Tag.ToString(), this.dtBookingDate.Value, regLevel);
            }
            else if (regLevel.IsFaculty) { }
            else
            {
                //�趨Ĭ��ԤԼʱ���
                this.SetDefaultBookingTime(this.dtBookingDate.Value);
            }

            //
            //Neusoft.NFC.Object.NeuObject obj = this.cmbDoctor.SelectedItem as Neusoft.NFC.Object.NeuObject;
            ////{DB2C7658-97F9-4467-89B0-E51E17A44DFE}
            //if (obj == null) return;
            ////{DB2C7658-97F9-4467-89B0-E51E17A44DFE}
            //this.lblDoctTip.Text = "ҽ��ר��:"+obj.Memo;

            //{D3A9E4D9-349B-4602-B6F1-4ED6DA7AB066}
            try
            {
                Neusoft.NFC.Object.NeuObject obj = this.cmbDoctor.SelectedItem as Neusoft.NFC.Object.NeuObject;
                Neusoft.HISFC.Object.Base.Employee emp = this.conMgr.GetEmployeeInfo(obj.ID);

                this.lblDoctTip.Text = "ҽ��ר��:" + emp.Memo;
            }
            catch (Exception ex)
            { }

            //#region {A9412582-3456-4f55-9217-1F33CB51BCED}  ����ҽ���Ű����ȡ�Һż��� add by chenzl 2011-05-22
            //if (!IsCheckLevel)
            //{
            //    //string docLevelCode = this.SchemaMgr.GetByID(obj.ID);
            //    Neusoft.NFC.Object.NeuObject schemaObj = new Neusoft.NFC.Object.NeuObject();
            //    Neusoft.HISFC.Object.Registration.Schema schemaList = new Neusoft.HISFC.Object.Registration.Schema();
            //    schemaList = this.SchemaMgr.GetByDoctAndDept(cmbDept.Tag.ToString(), cmbDoctor.Tag.ToString());
            //    this.cmbRegLevel.Tag = schemaList.Templet.RegLevel.ID;
            //    this.cmbDept.Tag = schemaList.Templet.Dept.ID;

            //}
            //#endregion
        }

        /// <summary>
        /// �趨ר��Ĭ�Ͼ���ʱ���
        /// </summary>
        /// <param name="doctID"></param>
        /// <param name="bookingDate"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        private int SetDoctZone(string doctID, DateTime bookingDate, Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            Registration.RegTypeNUM regType = Registration.RegTypeNUM.Faculty;

            #region Set regType value
            regType = this.getRegType(level);
            #endregion

            if (this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() != "")
            {
                this.ucChooseDate.QueryDoctBooking(bookingDate, doctID, this.cmbDept.Tag.ToString(), regType);
            }
            else
            {
                this.ucChooseDate.QueryDoctBooking(bookingDate, doctID, regType);
            }

            //Ĭ����ʾ��һ������������ʱ��δ���ڡ��޶�δ�������Ű���Ϣ
            Neusoft.HISFC.Object.Registration.Schema schema = this.ucChooseDate.GetValidBooking(regType);

            if (schema == null)//û�з���������
            {
                this.SetDefaultBookingTime(bookingDate.Date);
            }
            else
            {
                this.IsTriggerSelectedIndexChanged = false;
                this.cmbDept.Tag = schema.Templet.Dept.ID;
                this.IsTriggerSelectedIndexChanged = true;

                this.SetBookingTime(schema);
            }

            return 0;
        }

        /// <summary>
        /// ҽ���س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDoctor_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Neusoft.HISFC.Object.Registration.RegLevel regLevel = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                if (regLevel == null)
                {
                    MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                    this.cmbRegLevel.Focus();
                    return;
                }
                //��Ϊ��������ԤԼ��,���Բ����Ʊ�������ҽ��
                //				if((regLevel.IsExpert || regLevel.IsSpecial)&&(this.cmbDoctor.Tag == null||this.cmbDoctor.Tag.ToString() == ""))
                //				{
                //					MessageBox.Show("ר�Һű���ָ������ҽ��!","��ʾ") ;
                //					this.cmbDoctor.Focus();
                //					return ;
                //				}

                if (regLevel.IsFaculty)
                {
                    //��ȡ�����Ч��һ���Ű���Ϣ
                    #region
                    /*if(this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() != "")
                    {
                        if( this.getLastSchema(neusoft.HISFC.Object.Registration.SchemaTypeNUM.Dept,regLevel,
                            this.cmbDept.Tag.ToString(), "") == -1)
                        {
                            this.cmbDept.Focus() ;
                            return ;
                        }
                    }*/

                    if (this.cmbDept.Tag != null && this.cmbDept.Tag.ToString() != "")
                    {
                        if (this.DisplaySchemaTip(Neusoft.HISFC.Object.Base.EnumSchemaType.Dept) == -1)
                        {
                            this.cmbDept.Focus();
                            return;
                        }
                    }

                    #region {A5F4ED8D-79D2-4c41-B096-D1DAD1D1039C} �����Һ�����ԤԼ��ؿؼ�
                    //this.dtBookingDate.Focus();

                    this.txtCardNo.Focus();
                    #endregion
                    #endregion
                }
                else if (regLevel.IsExpert)
                {
                    //��ȡ�����Ч��һ���Ű���Ϣ
                    #region
                    /*if(this.cmbDoctor.Tag != null && this.cmbDoctor.Tag.ToString() != "")
                    {
                        if( this.getLastSchema(neusoft.HISFC.Object.Registration.SchemaTypeNUM.Doct,regLevel,
                            "",this.cmbDoctor.Tag.ToString()) == -1)
                        {
                            this.cmbDoctor.Focus() ;
                            return ;
                        }
                    }*/

                    if (this.cmbDoctor.Tag != null && this.cmbDoctor.Tag.ToString() != "")
                    {
                        ///�жϽ��ں�¼��Һż����Ƿ���ȷ
                        ///

                        //						if(!this.VerifyIsProfessor(regLevel,(neusoft.HISFC.Object.RADT.Person)this.cmbDoctor.SelectedItem))
                        //						{
                        //							this.cmbDoctor.Focus() ;
                        //							return ;
                        //						}

                        Neusoft.HISFC.Object.Registration.Schema schema = (Neusoft.HISFC.Object.Registration.Schema)this.dtBookingDate.Tag;
                        if (schema != null)
                        {
                            if (this.VerifyIsProfessor(regLevel, schema) == false)
                            {
                                this.cmbDoctor.Focus();
                                return;
                            }
                        }

                        if (this.DisplaySchemaTip(Neusoft.HISFC.Object.Base.EnumSchemaType.Doct) == -1)
                        {
                            this.cmbDoctor.Focus();
                            return;
                        }
                    }

                    #endregion
                    if (this.IsInputOrder)
                    {
                        this.txtOrder.Focus();
                    }
                    else
                    {
                        #region {A5F4ED8D-79D2-4c41-B096-D1DAD1D1039C} �����Һ�����ԤԼ��ؿؼ�
                        //this.dtBookingDate.Focus();

                        this.txtCardNo.Focus();
                        #endregion
                    }
                }
                else if (regLevel.IsSpecial)
                {
                    //��ȡ�����Ч��һ���Ű���Ϣ
                    #region
                    /*if(this.cmbDoctor.Tag != null && this.cmbDoctor.Tag.ToString() != "")
                    {
                        if( this.getLastSchema(neusoft.HISFC.Object.Registration.SchemaTypeNUM.Doct,regLevel,
                            "",this.cmbDoctor.Tag.ToString()) == -1)
                        {
                            this.cmbDoctor.Focus() ;
                            return ;
                        }
                    }*/
                    if (this.cmbDoctor.Tag != null && this.cmbDoctor.Tag.ToString() != "")
                    {
                        if (this.DisplaySchemaTip(Neusoft.HISFC.Object.Base.EnumSchemaType.Doct) == -1)
                        {
                            this.cmbDoctor.Focus();
                            return;
                        }
                    }
                    #endregion

                    #region {A5F4ED8D-79D2-4c41-B096-D1DAD1D1039C} �����Һ�����ԤԼ��ؿؼ�
                    //this.dtBookingDate.Focus();

                    this.txtCardNo.Focus();
                    #endregion
                }
                else
                {
                    this.txtCardNo.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        /// <summary>
        /// ����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbDoctor_TextChanged(object sender, EventArgs e)
        {
            string strFilter = "ID like '%" + this.cmbDoctor.Text + "%' or Spell_Code like '%" + this.cmbDoctor.Text + "%'"
                    + " or Name like '%" + this.cmbDoctor.Text + "%'";
            /* or Wb_Code like '%"+this.cmbDept.Text
            +"%' or Input_Code like '%"+this.cmbDept.Text+"%'";*/

            try
            {
                dvDocts.RowFilter = strFilter;
            }
            catch { }

            this.AddDoctToFp(Neusoft.NFC.Function.NConvert.ToBoolean(this.fpDoctor.Tag));
        }

        /// <summary>
        /// ��֤���ںŹҵ��Ƿ��ǽ��ڣ������ںŹҵ��Ƿ��Ǹ�����
        /// </summary>
        /// <param name="level"></param>
        /// <param name="doct"></param>
        /// <returns></returns>
        private bool VerifyIsProfessor(Neusoft.HISFC.Object.Registration.RegLevel level, Neusoft.HISFC.Object.Base.Employee doct)
        {
            if (this.IsDivLevel)
            {
                if (!level.IsSpecial)//����Ų����ж�
                {
                    if (this.IsProfessor(level))//���ں�
                    {
                        if (!doct.IsExpert)
                        {
                            MessageBox.Show("��ҽ���Ǹ�����,���ܹҽ��ں�!", "��ʾ");
                            return false;
                        }
                    }
                    else//������
                    {
                        if (doct.IsExpert)
                        {
                            MessageBox.Show("��ҽ���ǽ���,���ܹҸ����ں�!", "��ʾ");
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        private bool VerifyIsProfessor(Neusoft.HISFC.Object.Registration.RegLevel level, string doctID)
        {
            if (this.IsDivLevel)
            {
                if (!level.IsSpecial)//����Ų����ж�
                {
                    Neusoft.HISFC.Object.Base.Employee p = this.conMgr.GetEmployeeInfo(doctID);
                    if (p == null)
                    {
                        MessageBox.Show("��ȡ��Ա��Ϣ����!" + this.conMgr.Err, "��ʾ");
                        return false;
                    }

                    if (this.IsProfessor(level))//���ں�
                    {
                        if (!(p.Level.ID == "2" || p.Level.ID == "21" || p.Level.ID == "17" || p.Level.ID == "33"))
                        {
                            MessageBox.Show("��ҽ���Ǹ�����,���ܹҽ��ں�!", "��ʾ");
                            return false;
                        }
                    }
                    else//������
                    {
                        if (p.Level.ID == "2" || p.Level.ID == "21" || p.Level.ID == "17" || p.Level.ID == "33")
                        {
                            MessageBox.Show("��ҽ���ǽ���,���ܹҸ����ں�!", "��ʾ");
                            return false;
                        }
                    }
                }
            }
            return true;
        }


        private bool VerifyIsProfessor(Neusoft.HISFC.Object.Registration.RegLevel level, Neusoft.HISFC.Object.Registration.Schema schema)
        {
            if (this.IsDivLevel)
            {
                if (schema.Templet.RegLevel.ID != null && schema.Templet.RegLevel.ID != "" &&
                    level.ID != schema.Templet.RegLevel.ID)
                {
                    MessageBox.Show(schema.Templet.Doct.Name + "ҽ���Ű༶��Ϊ:" + schema.Templet.RegLevel.Name + ",���ܹ�:" +
                        level.Name + ",���޸�!", "��ʾ");
                    return false;
                }
            }

            return true;
        }

        private bool VerifyIsProfessor(Neusoft.HISFC.Object.Registration.RegLevel level, Neusoft.HISFC.Object.Registration.Booking booking)
        {
            Neusoft.HISFC.Object.Registration.Schema schema = this.SchemaMgr.GetByID(booking.DoctorInfo.Templet.ID);

            if (schema == null || schema.Templet.ID == "")
            {
                MessageBox.Show("�޴���Ϊ:" + schema.Templet.ID + "���Ű���Ϣ!", "��ʾ");
                return false;
            }

            if (this.VerifyIsProfessor(level, schema) == false) return false;

            return true;
        }
        #endregion

        #region Set booking zone
        /// <summary>
        /// ���ԤԼ��ˮ��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtOrder_TextChanged(object sender, EventArgs e)
        {
            this.txtOrder.Tag = null;
        }
        /// <summary>
        /// ԤԼ��ˮ�Żس�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtOrder_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string ID = this.txtOrder.Text.Trim();

                if (ID != "")
                {
                    /*  --ֱ�Ӹ���ԤԼ��Ϣ����ҳ�渳ֵ
                    if (this.cmbRegLevel.Tag == null || this.cmbRegLevel.Tag.ToString() == "")
                    {
                        MessageBox.Show("��ѡ��Һż���!", "��ʾ");
                        this.cmbRegLevel.Focus();
                        return;
                    }

                    //�ж���ר�Һ�,������ҽ����

                    Neusoft.HISFC.Object.Registration.RegLevel Level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                    if (!(Level.IsSpecial || Level.IsExpert || Level.IsFaculty))
                    {
                        MessageBox.Show("ԤԼ�ű�����ר��/ר�ƺ�!", "��ʾ");
                        this.txtOrder.Text = "";
                        this.cmbRegLevel.Focus();
                        return;
                    }
                    */

                    this.booking = this.bookingMgr.GetByID(ID);
                    if (booking == null)
                    {
                        MessageBox.Show("��ȡԤԼ�Һ���Ϣ����!" + this.bookingMgr.Err, "��ʾ");
                        this.txtOrder.Focus();
                        return;
                    }

                    if (booking.ID == null || booking.ID == "")
                    {
                        MessageBox.Show("û����ˮ��Ϊ:" + ID + "��ԤԼ��Ϣ!", "��ʾ");
                        this.txtOrder.Focus();
                        return;
                    }

                    if (booking.IsSee)
                    {
                        MessageBox.Show("��ԤԼ��Ϣ�ѿ���,��ѡ������ԤԼ��Ϣ!", "��ʾ");
                        this.txtOrder.Focus();
                        return;
                    }

                    /*//�ĳɸ���ԤԼ��Ϣ���Զ����
                    if (Level.IsExpert && (booking.DoctorInfo.Templet.Doct.ID == null || booking.DoctorInfo.Templet.Doct.ID == ""))
                    {
                        MessageBox.Show("��ԤԼ��ϢΪר�ƺ�,���ܹ�ר�Һ�!", "��ʾ");
                        this.cmbRegLevel.Focus();
                        return;
                    }

                    if (!Level.IsExpert && booking.DoctorInfo.Templet.Doct.ID != null && booking.DoctorInfo.Templet.Doct.ID != "")
                    {
                        MessageBox.Show("��ԤԼ��ϢΪר�Һ�,���ܹ�ר�ƺ�!", "��ʾ");
                        this.cmbRegLevel.Focus();
                        return;
                    }
                    */

                    if (this.IsInputTime)//��ɽ�����ж��Ƿ�ʱ
                    {
                        if (!booking.DoctorInfo.Templet.IsAppend)
                        {
                            DateTime current = this.bookingMgr.GetDateTimeFromSysDateTime();

                            if (booking.DoctorInfo.Templet.End < current)
                            {
                                MessageBox.Show("��ԤԼ��Ϣ�Ѿ�����,����ʹ��!", "��ʾ");
                                this.txtOrder.Focus();
                                return;
                            }

                            if (booking.DoctorInfo.Templet.Begin > current)
                            {
                                DialogResult dr = MessageBox.Show("��û�е�ԤԼʱ��,�Ƿ����?", "��ʾ",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                                if (dr == DialogResult.No)
                                {
                                    this.txtOrder.Focus();
                                    return;
                                }
                            }

                            if (booking.DoctorInfo.Templet.Begin < current &&
                                booking.DoctorInfo.Templet.End > current)
                            {
                                DialogResult dr = MessageBox.Show("�Ѿ�����ԤԼ��ʼʱ��,�Ƿ����?", "��ʾ",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                                if (dr == DialogResult.No)
                                {
                                    this.txtOrder.Focus();
                                    return;
                                }
                            }
                        }
                        else
                        {
                            if (booking.DoctorInfo.SeeDate.Date < this.bookingMgr.GetDateTimeFromSysDateTime().Date)
                            {
                                MessageBox.Show("��ԤԼ��Ϣ�Ѿ�����,����ʹ��!", "��ʾ");
                                this.txtOrder.Focus();
                                return;
                            }
                        }
                    }

                    Neusoft.HISFC.Object.Registration.Schema schema = this.SchemaMgr.GetByID(booking.DoctorInfo.Templet.ID);

                    this.cmbRegLevel.Tag = schema.Templet.RegLevel.ID;
                    this.cmbRegLevel.Text = schema.Templet.RegLevel.Name;

                    //��ֵ					
                    this.IsTriggerSelectedIndexChanged = false;
                    this.cmbDept.AddItems(this.alDept);
                    this.cmbDept.Tag = booking.DoctorInfo.Templet.Dept.ID;//ԤԼ����
                    this.cmbDept.Text = booking.DoctorInfo.Templet.Dept.Name;

                    this.cmbDoctor.AddItems(this.alDoct);
                    this.AddDoctToDataSet(this.alDoct);
                    this.AddDoctToFp(false);
                    this.cmbDoctor.Tag = booking.DoctorInfo.Templet.Doct.ID;//ԤԼҽ��
                    this.cmbDoctor.Text = booking.DoctorInfo.Templet.Doct.Name;

                    MessageBox.Show(booking.DoctorInfo.Templet.Dept.ID);
                    MessageBox.Show(this.cmbDept.Tag.ToString());

                    this.cmbRegLevel.Enabled = false;
                    this.cmbDept.Enabled = false;
                    this.cmbDoctor.Enabled = false;

                    //add by niuxinyuan

                    this.IsTriggerSelectedIndexChanged = true;

                    ///�жϽ��ں�¼���Ƿ���ȷ
                    ///
                    //if (Level.IsExpert)
                    //{
                    //    if (this.VerifyIsProfessor(Level, booking) == false)
                    //    {
                    //        this.cmbRegLevel.Focus();
                    //        return;
                    //    }
                    //}

                    this.dtBookingDate.Value = booking.DoctorInfo.SeeDate;
                    this.dtBegin.Value = booking.DoctorInfo.Templet.Begin;
                    this.dtEnd.Value = booking.DoctorInfo.Templet.End;

                    this.txtOrder.Text = ID;//Text��Tag˳���ܵߵ�
                    this.txtOrder.Tag = booking;

                    this.txtCardNo.Text = booking.PID.CardNO;
                    this.txtCardNo_KeyDown(new object(), new KeyEventArgs(Keys.Enter));
                }
                else
                {
                    this.dtBookingDate.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        /// <summary>
        /// �������
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtBookingDate_ValueChanged(object sender, EventArgs e)
        {
            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;
            this.SetBookingTag(null);
            //���ԤԼ��Ϣ
            this.ClearBookingInfo();

            this.lbWeek.Text = this.getWeek(this.dtBookingDate.Value);
        }
        /// <summary>
        /// ԤԼ���ڻس�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtBookingDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.dtBookingDate.Value.Date < this.regMgr.GetDateTimeFromSysDateTime().Date)
                {
                    MessageBox.Show("ԤԼ���ڲ���С�ڵ�ǰ����", "��ʾ");
                    this.dtBookingDate.Focus();
                    return;
                }

                if (this.IsInputTime)
                {
                    this.dtBegin.Focus();
                }
                else
                {
                    this.txtCardNo.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.llPd_Click(new object(), new EventArgs());
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        /// <summary>
        /// �����ʼʱ��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtBegin_ValueChanged(object sender, EventArgs e)
        {
            //���ԤԼ��Ϣ
            this.ClearBookingInfo();
            this.SetBookingTag(null);
            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;
        }

        /// <summary>
        /// ��ʼʱ��س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtBegin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.dtEnd.Focus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.llPd_Click(new object(), new EventArgs());
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// �������ʱ��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtEnd_ValueChanged(object sender, EventArgs e)
        {
            //���ԤԼ��Ϣ
            this.ClearBookingInfo();
            this.SetBookingTag(null);
            if (this.ucChooseDate.Visible) this.ucChooseDate.Visible = false;
        }

        /// <summary>
        /// ����ʱ��س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtEnd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.dtBookingDate.Tag == null)
                {
                    Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                    if (level != null)
                    {
                        Neusoft.HISFC.Object.Registration.Schema schema = this.GetValidSchema(level);

                        this.SetBookingTag(schema);
                    }
                }

                this.txtCardNo.Focus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.llPd_Click(new object(), new EventArgs());
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
        }
        /// <summary>
        /// ѡ��ԤԼʱ���
        /// </summary>
        /// <param name="sender"></param>
        private void ucChooseDate_SelectedItem(Neusoft.HISFC.Object.Registration.Schema sender)
        {
            this.ucChooseDate.Visible = false;

            if (sender == null) return;

            Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            if (level == null)
            {
                MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                this.cmbRegLevel.Focus();
                return;
            }

            if (!level.IsSpecial && !level.IsExpert && !level.IsFaculty) return;

            Registration.RegTypeNUM regType = this.getRegType(level);

            #region ���Σ����һ���ж��Ƿ񳬳��޶�
            /* 
            if((regType == Registration.RegTypeNUM.Faculty ||regType == Registration.RegTypeNUM.Expert)
                &&sender.Templet.RegLmt<=sender.RegedQty)
            {
                if(MessageBox.Show("�ֳ��Һ����Ѿ����������,�Ƿ����?","��ʾ",MessageBoxButtons.YesNo,MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    this.dtBookingDate.Focus() ;
                    return ;
                }
            }

            if(regType == Registration.RegTypeNUM.Special &&sender.Templet.SpeLmt<=sender.SpeReged)
            {
                if(MessageBox.Show("����Һ����Ѿ����������,�Ƿ����?","��ʾ",MessageBoxButtons.YesNo,MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    this.dtBookingDate.Focus() ;
                    return ;
                }
            }*/
            #endregion

            //ר�ҡ�ר�ƺ��ֳ��ѹҺ��������ֳ������
            if ((((regType == Registration.RegTypeNUM.Faculty || regType == Registration.RegTypeNUM.Expert) && sender.Templet.RegQuota <= sender.RegedQTY) ||
                //��������š������ѹҺ����������������
                (regType == Registration.RegTypeNUM.Special && sender.Templet.SpeQuota <= sender.SpedQTY)) &&
                //���Ҳ��ǼӺ�
                !sender.Templet.IsAppend)
            {
                if (!this.IsAllowOverrun)
                {
                    MessageBox.Show("�Ű೬�޶�����Һ�!", "��ʾ");
                    this.dtBookingDate.Focus();
                    return;
                }
            }

            //����
            this.IsTriggerSelectedIndexChanged = false;
            this.cmbDept.Tag = sender.Templet.Dept.ID;
            //ҽ��
            if (sender.Templet.Doct.ID == "None")//ר�ƺ�
            {
                this.cmbDoctor.Tag = "";
            }
            else
            {
                this.cmbDoctor.Tag = sender.Templet.Doct.ID;
            }
            this.IsTriggerSelectedIndexChanged = true;

            //ԤԼʱ���
            this.SetBookingTime(sender);
            this.txtCardNo.Focus();
        }
        /// <summary>
        /// ��ʾԤԼʱ����б�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llPd_Click(object sender, EventArgs e)
        {
            if (this.ucChooseDate.Visible)
            {
                this.ucChooseDate.Visible = false;
                this.dtBookingDate.Focus();
            }
            else
            {
                DateTime bookingDate = this.dtBookingDate.Value;
                DateTime current = this.bookingMgr.GetDateTimeFromSysDateTime();

                if (bookingDate.Date < current.Date)
                {
                    MessageBox.Show("ԤԼ���ڲ���С�ڵ�ǰ����!", "��ʾ");
                    this.dtBookingDate.Focus();
                    return;
                }

                Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                if (level == null)
                {
                    MessageBox.Show("����ѡ��Һż���!", "��ʾ");
                    this.cmbRegLevel.Focus();
                    return;
                }

                if (!level.IsFaculty && !level.IsExpert && !level.IsSpecial) return;

                string deptID = this.cmbDept.Tag.ToString();
                string doctID = this.cmbDoctor.Tag.ToString();

                //ר�ƺ�,�Һſ��Ҳ���Ϊ��
                if (level.IsFaculty)
                {
                    #region dept
                    if (deptID == null || deptID == "")
                    {
                        MessageBox.Show("ר�ƺű���ָ���Һſ���!", "��ʾ");
                        this.cmbDept.Focus();
                        return;
                    }

                    this.SetDeptZone(deptID, bookingDate, level);

                    if (this.ucChooseDate.Count > 0)
                    {
                        this.ucChooseDate.Visible = true;
                        this.ucChooseDate.Focus();
                    }
                    else if (this.ucChooseDate.Bookings.Count > 0)
                    {
                        MessageBox.Show("û�з����������Ű���Ϣ,������ѡ��ԤԼ����", "��ʾ");
                        this.dtBookingDate.Focus();
                        return;
                    }
                    else
                    {
                        MessageBox.Show("ר��û���Ű�!", "��ʾ");
                        this.dtBookingDate.Focus();
                        return;
                    }
                    #endregion
                }
                //ר�Һ�,����ָ������ҽ��
                if (level.IsExpert || level.IsSpecial)
                {
                    #region doct
                    if (doctID == null || doctID == "")
                    {
                        MessageBox.Show("ר�Һű���ָ������ר��!", "��ʾ");
                        this.cmbDoctor.Focus();
                        return;
                    }

                    this.SetDoctZone(doctID, bookingDate, level);

                    if (this.ucChooseDate.Count > 0)
                    {
                        this.ucChooseDate.Visible = true;
                        this.ucChooseDate.Focus();
                    }
                    else if (this.ucChooseDate.Bookings.Count > 0)
                    {
                        MessageBox.Show("û�з����������Ű���Ϣ,������ѡ��ԤԼ����", "��ʾ");
                        this.dtBookingDate.Focus();
                        return;
                    }
                    else
                    {
                        MessageBox.Show("ר��û���Ű�!", "��ʾ");
                        this.dtBookingDate.Focus();
                        return;
                    }
                    #endregion
                }
            }
        }

        #endregion

        #region txtCardNo
        /// <summary>
        /// �����Żس�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCardNo_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                string cardNo = this.txtCardNo.Text.Trim();
                this.txtName.ReadOnly = false;
                if (cardNo == "")
                {
                    //MessageBox.Show("�����Ų���Ϊ��!","��ʾ");
                    //this.txtCardNo.Focus();
                    //return ;
                    //ֱ������������,�ɸ����������������������Ϣ
                    this.txtName.Focus();
                    return;
                }

                string cardNOTemp = null;

                cardNOTemp = cardNo;
                cardNo = cardNo.PadLeft(10, '0');
                //minqsh 20100602 {B8CBAC93-4E5B-46d9-82E3-9991279A1340} ��Ϊ�Ϻ�ҽ���������ϲ�������12λ��ϵͳֻ�ܴ�10λ���ĳ�ȡ��10λ
                cardNo = cardNo.Substring(cardNo.Length - 10, 10);

                this.txtCardNo.Text = cardNo;
                if (this.ValidCardNO(cardNo) < 0)
                {
                    this.txtCardNo.Focus();
                    return;
                }

                #region ������¼�뺺��
                if (Neusoft.NFC.Public.String.ValidMaxLengh(cardNo, 10) == false)
                {
                    MessageBox.Show("�����Ų������뺺��!", "��ʾ");
                    this.txtCardNo.Focus();
                    return;
                }
                #endregion
                if (this.isReadCard == true) //|| this.myYBregObj.SIMainInfo.Memo != null || this.myYBregObj.SIMainInfo.Memo.Trim() != "")
                {
                    //ҽ������
                    //this.regObj = this.getRegInfo(cardNo);
                    #region {755B9D43-269A-415f-A39D-3D2DC7CCC345} edit by shen-zh 2017-07-17 �жϿ��Ƿ�ʹ��
                    //this.regObj.PID.CardNO = cardNo;
                    ////this.txtPhone.Focus();
                    //this.setNextControlFocus();
                    //this.cmbPayKind.Focus();
                    Neusoft.HISFC.Object.Registration.Register newregObj;
                    #region ����������Ϣ
                    newregObj = this.getRegInfo(cardNo);
                    if ((newregObj == null) || String.IsNullOrEmpty(newregObj.Name))
                    {
                        this.regObj.PID.CardNO = cardNo;
                        //this.txtPhone.Focus();
                        this.setNextControlFocus();
                        this.cmbPayKind.Focus();
                        return;
                    }

                    #region by wwei_neu  ��ѯ������Ϣ�Ƿ���Ч YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}

                    string isValid = this.regMgr.ExecSqlReturnOne("select a.is_valid from com_patientinfo a where a.card_no='" + cardNo + "'", "");
                    if (isValid == "2")
                    {
                        MessageBox.Show("�����ƿ��Ѿ�ע�����޷�ʹ�ã�");
                        return;
                    }

                    #endregion

                    #endregion
                    this.regObj = newregObj;
                    #region ��ֵ

                    //{EF076D89-17FE-4922-AC71-3F4D61158505} ������20151020���ϼҳ�����
                    this.txtParentName.Text = this.regObj.ParentName;

                    this.txtCardNo.Text = cardNo;
                    this.txtName.Text = this.regObj.Name;
                    if (!string.IsNullOrEmpty(this.regObj.Name))
                    {
                        this.txtName.ReadOnly = true;
                    }
                    this.cmbSex.Tag = this.regObj.Sex.ID;
                    //�Ѿ�����ҽ��������Ҫȡ���߻�����Ϣ�������ݸ��ǡ�������ߵ�һ���ԷѾ���˴�ҽ�����˴�����������
                    //this.cmbPayKind.Tag = this.regObj.Pact.ID;
                    //this.txtMcardNo.Text = this.regObj.SSN;
                    //this.txtIdNO.Text = this.regObj.IDCard;
                    //if (this.regObj.Birthday != DateTime.MinValue)
                    //    this.dtBirthday.Value = this.regObj.Birthday;
                    //this.cmbCardType.Tag = this.regObj.CardType.ID;

                    this.txtPhone.Text = this.regObj.PhoneHome;
                    this.txtAddress.Text = this.regObj.AddressHome;
                    //{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}

                    //this.setAge(this.regObj.Birthday);
                    this.getCost();

                    Neusoft.HISFC.Object.Base.PactInfo pact = conMgr.GetPactUnitInfoByPactCode(this.regObj.Pact.ID);
                    this.getPayRate(pact);
                    #endregion
                    #endregion

                }
                else
                {
                    #region �Էѻ���
                    #region //�����ʻ�����
                    //==================================================================================
                    //if (cardNOTemp.Substring(0, 1) == ";" && cardNOTemp.Substring(cardNOTemp.Length - 1, 1) == "?")
                    //{
                    //    cardNOTemp = cardNOTemp.Substring(1, cardNOTemp.Length - 2);
                    //    //{DA67A335-E85E-46e1-A672-4DB409BCC11B}
                    //    //bool returnValue = this.feeMgr.GetCardNoByMarkNo(cardNOTemp, Neusoft.HISFC.Object.Account.MarkTypes.Magcard, ref cardNo);
                    //    bool returnValue = this.feeMgr.GetCardNoByMarkNo(cardNOTemp, ref cardNo);

                    //    if (returnValue == false)
                    //    {
                    //        MessageBox.Show(this.feeMgr.Err);
                    //        return;
                    //    }
                    //}


                    ////�����뷨
                    //if (Neusoft.NFC.Public.String.ValidMaxLengh(cardNOTemp, 1) == false)
                    //{
                    //    if (cardNOTemp.Substring(0, 2) == "��" && cardNOTemp.Substring(cardNOTemp.Length - 2, 1) == "��")
                    //    {
                    //        cardNOTemp = cardNOTemp.Substring(3, cardNOTemp.Length - 4);
                    //        //{DA67A335-E85E-46e1-A672-4DB409BCC11B}
                    //        //bool returnValue = this.feeMgr.GetCardNoByMarkNo(cardNOTemp, Neusoft.HISFC.Object.Account.MarkTypes.Magcard, ref cardNo);
                    //        bool returnValue = this.feeMgr.GetCardNoByMarkNo(cardNOTemp, ref cardNo);
                    //        if (returnValue == false)
                    //        {
                    //            MessageBox.Show(this.feeMgr.Err);
                    //            return;
                    //        }
                    //    }
                    //}
                    //===========================================================================================
                    #endregion


                    #region ����������Ϣ
                    this.regObj = this.getRegInfo(cardNo);
                    if (regObj == null)
                    {
                        this.txtCardNo.Focus();
                        return;
                    }

                    #region by wwei_neu  ��ѯ������Ϣ�Ƿ���Ч YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}

                    string isValid = this.regMgr.ExecSqlReturnOne("select a.is_valid from com_patientinfo a where a.card_no='" + cardNo + "'", "");
                    if (isValid == "2")
                    {
                        MessageBox.Show("�����ƿ��Ѿ�ע�����޷�ʹ�ã�");
                        return;
                    }

                    #endregion

                    #endregion

                    #region ��ֵ

                    //{EF076D89-17FE-4922-AC71-3F4D61158505} ������20151020���ϼҳ�����
                    this.txtParentName.Text = this.regObj.ParentName;

                    this.txtCardNo.Text = cardNo;
                    this.txtName.Text = this.regObj.Name;
                    if (!string.IsNullOrEmpty(this.regObj.Name))
                    {
                        this.txtName.ReadOnly = true;
                    }
                    this.cmbSex.Tag = this.regObj.Sex.ID;
                    this.cmbPayKind.Tag = this.regObj.Pact.ID;
                    if (!string.IsNullOrEmpty(this.regObj.SSN))
                    {
                        this.txtMcardNo.Text = this.regObj.SSN;
                    }
                    this.txtPhone.Text = this.regObj.PhoneHome;
                    this.txtAddress.Text = this.regObj.AddressHome;
                    //{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}
                    this.txtIdNO.Text = this.regObj.IDCard;
                    if (this.regObj.Birthday != DateTime.MinValue)
                        this.dtBirthday.Value = this.regObj.Birthday;

                    this.cmbCardType.Tag = this.regObj.CardType.ID;

                    this.setAge(this.regObj.Birthday);
                    this.getCost();

                    Neusoft.HISFC.Object.Base.PactInfo pact = conMgr.GetPactUnitInfoByPactCode(this.regObj.Pact.ID);
                    this.getPayRate(pact);
                    #endregion
                    #endregion
                }

                if (this.IsInputName) this.txtName.Focus();
                else { this.cmbSex.Focus(); }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// ���ݲ����Ż�û��߹Һ���Ϣ
        /// </summary>
        /// <param name="CardNo"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Registration.Register getRegInfo(string CardNo)
        {
            Neusoft.HISFC.Object.Registration.Register ObjReg = new Neusoft.HISFC.Object.Registration.Register();
            Neusoft.HISFC.Integrate.RADT radt = new Neusoft.HISFC.Integrate.RADT();
            Neusoft.HISFC.Object.RADT.PatientInfo p;
            int regCount = this.regMgr.QueryRegiterByCardNO(CardNo);


            if (regCount == 1)
            {
                ObjReg.IsFirst = false;
            }
            else
            {
                if (regCount == 0)
                {
                    ObjReg.IsFirst = true;

                }
                else
                {
                    return null;
                }
            }
            //�ȼ������߻�����Ϣ��,���Ƿ���ڸû�����Ϣ
            p = radt.QueryComPatientInfo(CardNo);
            if (p == null || p.Name == "")
            {
                //�����ڻ�����Ϣ
                ObjReg.PID.CardNO = CardNo;
                //ObjReg.IsFirst = true;
                ObjReg.Sex.ID = "M";
                ObjReg.Pact.ID = this.DefaultPactID;
            }
            else
            {
                //���ڻ��߻�����Ϣ,ȡ������Ϣ

                //{EF076D89-17FE-4922-AC71-3F4D61158505} ������20151020���ϼҳ�����
                ObjReg.ParentName = p.ParentName;//�ҳ�����

                ObjReg.PID.CardNO = CardNo;
                ObjReg.Name = p.Name;
                ObjReg.Sex.ID = p.Sex.ID;
                ObjReg.Birthday = p.Birthday;
                ObjReg.Pact.ID = p.Pact.ID;
                ObjReg.Pact.PayKind.ID = p.Pact.PayKind.ID;
                ObjReg.SSN = p.SSN;
                ObjReg.PhoneHome = p.PhoneHome;
                ObjReg.AddressHome = p.AddressHome;
                ObjReg.IDCard = p.IDCard;
                ObjReg.NormalName = p.NormalName;
                ObjReg.IsEncrypt = p.IsEncrypt;
                //{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}
                ObjReg.IDCard = p.IDCard;
                if (p.IsEncrypt == true)
                {
                    ObjReg.Name = Neusoft.NFC.Interface.Classes.Function.Decrypt3DES(p.NormalName);
                }
                this.chbEncrpt.Checked = p.IsEncrypt;
                //ObjReg.IsFirst = false;

                if (this.validCardType(p.Memo))//����Memo�洢֤�����
                {
                    ObjReg.CardType.ID = p.Memo;
                }
            }

            return ObjReg;
        }

        /// <summary>
        /// ��֤֤������Ƿ���Ч
        /// </summary>
        /// <param name="cardType"></param>
        /// <returns></returns>
        private bool validCardType(string cardType)
        {
            bool found = false;

            foreach (Neusoft.NFC.Object.NeuObject obj in this.cmbCardType.alItems)
            {
                if (obj.ID == cardType)
                {
                    found = true;
                    break;
                }
            }
            return found;
        }
        /// <summary>
        /// ��������ԤԼ��Ϣ
        /// </summary>
        /// <param name="CardNo"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Registration.Register getBookingInfo(string CardNo)
        {
            Neusoft.HISFC.Object.Registration.Booking booking = null;// this.bookingMgr.Query(CardNo);

            if (booking == null)
            {
                MessageBox.Show("��������ԤԼ��Ϣʱ����!" + this.bookingMgr.Err, "��ʾ");
                return null;
            }

            Neusoft.HISFC.Object.Registration.Register regInfo = new Neusoft.HISFC.Object.Registration.Register();
            //û��ԤԼ��Ϣ
            //if (booking.ID == null || booking.ID == "")
            //{
            //    regInfo.PID.CardNO = CardNo;
            //    regInfo.IsFirst = true;
            //    regInfo.Sex.ID = "M";
            //    regInfo.Pact.ID = this.DefaultPactID;
            //}
            //else
            //{
            //    regInfo = (Neusoft.HISFC.Object.RADT.Patient)booking;
            //    regInfo.PID.CardNO = CardNo;
            //    regInfo.IsFirst = true;
            //    regInfo.Pact.ID = this.DefaultPactID;
            //}

            return regInfo;
        }
        /// <summary>
        /// Set Age
        /// </summary>
        /// <param name="birthday"></param>
        private void setAge(DateTime birthday)
        {
            this.txtAge.Text = "";

            if (birthday == DateTime.MinValue)
            {
                return;
            }

            DateTime current;
            int year, month, day;

            current = this.regMgr.GetDateTimeFromSysDateTime();
            year = current.Year - birthday.Year;
            month = current.Month - birthday.Month;
            day = current.Day - birthday.Day;

            if (year > 1)
            {
                this.txtAge.Text = year.ToString();
                this.cmbUnit.SelectedIndex = 0;
            }
            else if (year == 1)
            {
                if (month >= 0)//һ��
                {
                    this.txtAge.Text = year.ToString();
                    this.cmbUnit.SelectedIndex = 0;
                }
                else
                {
                    this.txtAge.Text = Convert.ToString(12 + month);
                    this.cmbUnit.SelectedIndex = 1;
                }
            }
            else if (month > 0)
            {
                this.txtAge.Text = month.ToString();
                this.cmbUnit.SelectedIndex = 1;
            }
            else if (day > 0)
            {
                this.txtAge.Text = day.ToString();
                this.cmbUnit.SelectedIndex = 2;
            }

        }
        /// <summary>
        /// �õ�����Ӧ��
        /// </summary>		
        /// <returns></returns>
        private int getCost()
        {
            this.lbReceive.Text = "";

            if (this.cmbRegLevel.Tag == null || this.cmbRegLevel.Tag.ToString() == "" ||
                this.cmbPayKind.Tag == null || this.cmbPayKind.Tag.ToString() == "")
            {
                return 0;//û¼����ȫ������
            }

            string regLvlID, pactID;
            decimal regfee = 0, chkfee = 0, digfee = 0, othfee = 0, owncost = 0, pubcost = 0;

            regLvlID = this.cmbRegLevel.Tag.ToString();
            pactID = this.cmbPayKind.Tag.ToString();

            int rtn = this.GetRegFee(pactID, regLvlID, ref regfee, ref chkfee, ref digfee, ref othfee);
            if (rtn == -1 || rtn == 1) return 0;

            //��û���Ӧ�ա�����
            if (this.regObj == null || this.regObj.PID.CardNO == "")
            {
                this.getCost(regfee, chkfee, digfee, ref othfee, ref owncost, ref pubcost, "");
            }
            else
            {
                this.getCost(regfee, chkfee, digfee, ref othfee, ref owncost, ref pubcost, this.regObj.PID.CardNO);
            }


            this.lbReceive.Text = owncost.ToString();

            return 0;
        }

        /// <summary>
        /// ��û���ʵ��Ӧ�����������м����¼�
        /// </summary>
        /// <returns></returns>
        private int getCostByAge()
        {
            //DateTime birthday = this.dtBirthday.Value;
            //string pactID = string.Empty;

            if (this.regObj == null)
            {
                return 1;
            }

            this.regObj.ID = this.regMgr.GetSequence("Registration.Register.ClinicID");
            this.regObj.TranType = Neusoft.HISFC.Object.Base.TransTypes.Positive;//������

            this.regObj.DoctorInfo.Templet.RegLevel.ID = this.cmbRegLevel.Tag.ToString();
            this.regObj.DoctorInfo.Templet.RegLevel.Name = this.cmbRegLevel.Text;

            this.regObj.DoctorInfo.Templet.Dept.ID = this.cmbDept.Tag.ToString();
            this.regObj.DoctorInfo.Templet.Dept.Name = this.cmbDept.Text;

            this.regObj.DoctorInfo.Templet.Doct.ID = this.cmbDoctor.Tag.ToString();
            this.regObj.DoctorInfo.Templet.Doct.Name = this.cmbDoctor.Text;

            this.regObj.Name = this.txtName.Text.Trim();//��������
            this.regObj.Sex.ID = this.cmbSex.Tag.ToString();//�Ա�

            this.regObj.Birthday = this.dtBirthday.Value;//��������		

            this.regObj.Pact.ID = this.cmbPayKind.Tag.ToString();//��ͬ��λ

            Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            this.regObj.RegType = Neusoft.HISFC.Object.Base.EnumRegType.Reg;


            decimal owncost = 0;
            int rtn = 0;


            //ѡ���Ϊ�����
            if (this.regObj.DoctorInfo.Templet.RegLevel.ID == freeRegLevel)
            {
                DateTime now = this.regFeeMgr.GetDateTimeFromSysDateTime().Date;
                bool isCanFreeSeeDoctor = false;
                foreach (Neusoft.NFC.Object.NeuObject obj in alFreeSeeDate)
                {
                    DateTime beginTime = now.AddDays(1);
                    DateTime endTime = now.AddDays(1);
                    try
                    {
                        beginTime = DateTime.Parse(obj.Name);
                        endTime = DateTime.Parse(obj.Memo);
                    }
                    catch { }
                    if (now >= beginTime && now <= endTime)
                    {
                        isCanFreeSeeDoctor = true;
                        break;
                    }
                }
                if (isCanFreeSeeDoctor)
                {
                    //˵��Ϊ����ʱ���                  

                    this.lbReceive.Text = "0";
                }
                else
                {
                    //�ӿ�ʵ��{E43E0363-0B22-4d2a-A56A-455CFB7CF211}            
                    if (this.iProcessRegiter != null)
                    {
                        rtn = this.iProcessRegiter.GetCost(regObj, ref owncost);

                        if (rtn == 1)
                        {
                            this.lbReceive.Text = owncost.ToString();

                            return 1;
                        }
                        if (rtn == 0)
                        {
                            this.getCost();

                            return 1;
                        }
                        if (rtn < 0)
                        {
                            MessageBox.Show("��û���Ӧ��������");

                            return -1;

                        }

                    }

                }
            }
            else
            {

                //�ӿ�ʵ��{E43E0363-0B22-4d2a-A56A-455CFB7CF211}            
                if (this.iProcessRegiter != null)
                {
                    rtn = this.iProcessRegiter.GetCost(regObj, ref owncost);

                    if (rtn == 1)
                    {
                        this.lbReceive.Text = owncost.ToString();

                        return 1;
                    }
                    if (rtn == 0)
                    {
                        this.getCost();

                        return 1;
                    }
                    if (rtn < 0)
                    {
                        MessageBox.Show("��û���Ӧ��������");

                        return -1;

                    }

                }
            }
            return 1;

        }

        /// <summary>
        /// ��ȡ�Һŷ�
        /// </summary>
        /// <param name="pactID"></param>
        /// <param name="regLvlID"></param>
        /// <param name="regFee"></param>
        /// <param name="chkFee"></param>
        /// <param name="digFee"></param>
        /// <param name="othFee"></param>
        /// <param name="digPubFee"></param>
        /// <returns></returns>
        private int GetRegFee(string pactID, string regLvlID, ref decimal regFee, ref decimal chkFee,
            ref decimal digFee, ref decimal othFee)
        {
            Neusoft.HISFC.Object.Registration.RegLvlFee p = this.regFeeMgr.Get(pactID, regLvlID);
            if (p == null)//����
            {
                return -1;
            }
            if (p.ID == null || p.ID == "")//û��ά���Һŷ�
            {
                return 1;
            }

            //{AEFEC6C1-019F-4bad-9373-556B2DFB4FEC}
            if (isOpenFreeSeeDoctor)
            {
                //ѡ���Ϊ�����
                if (regLvlID == freeRegLevel)
                {
                    DateTime now = this.regFeeMgr.GetDateTimeFromSysDateTime().Date;
                    bool isCanFreeSeeDoctor = false;
                    foreach (Neusoft.NFC.Object.NeuObject obj in alFreeSeeDate)
                    {
                        DateTime beginTime = now.AddDays(1);
                        DateTime endTime = now.AddDays(1);
                        try
                        {
                            beginTime = DateTime.Parse(obj.Name);
                            endTime = DateTime.Parse(obj.Memo);
                        }
                        catch { }
                        if (now >= beginTime && now <= endTime)
                        {
                            isCanFreeSeeDoctor = true;
                            break;
                        }
                    }
                    if (isCanFreeSeeDoctor)
                    {
                        //˵��Ϊ����ʱ���
                        regFee = 0;
                        chkFee = 0;
                        digFee = 0;
                        othFee = 0;
                    }
                    else
                    {
                        regFee = p.RegFee;
                        chkFee = p.ChkFee;
                        digFee = p.OwnDigFee;
                        othFee = p.OthFee;
                    }
                }
                else
                {
                    regFee = p.RegFee;
                    chkFee = p.ChkFee;
                    digFee = p.OwnDigFee;
                    othFee = p.OthFee;
                }
            }
            else
            {
                regFee = p.RegFee;
                chkFee = p.ChkFee;
                digFee = p.OwnDigFee;
                othFee = p.OthFee;
            }

            return 0;
        }

        /// <summary>
        /// ��Ӧ�ɽ��תΪ�Һ�ʵ��,
        /// ���Բ�����Ϊref�������� TNND
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private int ConvertRegFeeToObject(Neusoft.HISFC.Object.Registration.Register obj)
        {
            decimal regFee = 0, chkFee = 0, digFee = 0, othFee = 0;

            int rtn = this.GetRegFee(obj.Pact.ID, obj.DoctorInfo.Templet.RegLevel.ID,
                          ref regFee, ref chkFee, ref digFee, ref othFee);

            obj.RegLvlFee.RegFee = regFee;
            obj.RegLvlFee.ChkFee = chkFee;
            obj.RegLvlFee.OwnDigFee = digFee;
            obj.RegLvlFee.OthFee = othFee;

            this.regFee = regFee + chkFee + digFee + othFee;

            return rtn;
        }

        /// <summary>
        /// ��û���Ӧ�����������
        /// </summary>
        /// <param name="regFee"></param>
        /// <param name="chkFee"></param>
        /// <param name="digFee"></param>
        /// <param name="othFee"></param>
        /// <param name="digPub"></param>
        /// <param name="ownCost"></param>
        /// <param name="pubCost"></param>
        /// <param name="cardNo"></param>		
        private void getCost(decimal regFee, decimal chkFee, decimal digFee, ref decimal othFee,
            ref decimal ownCost, ref decimal pubCost, string cardNo)
        {
            if (this.IsPubDiagFee)
            {
                ownCost = regFee + chkFee + othFee;//�Һŷ��Է�
                pubCost = digFee;//������
            }
            else
            {
                /*
                 * �յ�����ȡ�㷨
                 * �����ϡ�����Һŷֱ���ȡһ�οյ��ѡ�
                 * ͬһ����ͬһ���Ҷ��ź�ֻ��ȡһ�οյ���
                 * �յ�����othFee��ʾ
                 */

                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                //if (this.IsKTF)
                if (this.otherFeeType == "0") //�յ���
                {

                    //û�����뻼����Ϣʱ��Ĭ����ʾ��ȡ�յ���
                    if (cardNo == null || cardNo == "")
                    {
                        ///
                    }
                    else
                    {
                        DateTime regDate = this.dtBookingDate.Value.Date;

                        if (this.dtBegin.Value.ToString("HHmm") == "0000")
                        {
                            regDate = DateTime.Parse(regDate.ToString("yyyy-MM-dd") + " " + this.regMgr.GetSysDateTime("HH24:mi:ss"));
                        }
                        else
                        {
                            regDate = DateTime.Parse(regDate.ToString("yyyy-MM-dd") + " " + this.dtBegin.Value.ToString("HH:mm:ss"));
                        }

                        ///�������Ų�ѯ�������һ�ιҺ���Ϣ
                        ArrayList alRegs = this.regMgr.Query(cardNo, regDate.Date);

                        string currentNoon = this.getNoon(regDate);

                        if (alRegs != null)
                        {
                            foreach (Neusoft.HISFC.Object.Registration.Register obj in alRegs)
                            {
                                //δ�ҺŻ������һ�ιҺ�ʱ��ͬ��ǰʱ�����ͬ,����ȡ�Һŷ�
                                if (obj.DoctorInfo.SeeDate.Date == regDate.Date)
                                {
                                    if (obj.DoctorInfo.Templet.Noon.ID != currentNoon)
                                    {
                                        ///
                                    }
                                    else
                                    {
                                        othFee = 0;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                if (this.otherFeeType == "1") //��������
                {
                    if (!this.chbBookFee.Checked) //ͨ������ѡ��
                    {
                        othFee = 0;
                    }
                }

                ownCost = regFee + chkFee + othFee + digFee;
                pubCost = 0;
            }

            //			ownCost = regFee + chkFee + othFee + digFee ;
            //			pubCost = digPub ;
        }

        /// <summary>
        /// ��Ӧ�ɽ��תΪ�Һ�ʵ��,
        /// ���Բ�����Ϊref�������� TNND
        /// </summary>
        /// <param name="obj"></param>
        private void ConvertCostToObject(Neusoft.HISFC.Object.Registration.Register obj)
        {
            decimal othFee = 0, ownCost = 0, pubCost = 0;
            othFee = obj.RegLvlFee.OthFee; //add by niux
            this.getCost(obj.RegLvlFee.RegFee, obj.RegLvlFee.ChkFee, obj.RegLvlFee.OwnDigFee,
                    ref othFee, ref ownCost, ref pubCost, this.regObj.PID.CardNO);

            obj.RegLvlFee.OthFee = othFee;
            obj.OwnCost = ownCost;
            obj.PubCost = pubCost;

        }
        #endregion
        
        
        #region txtName
        /// <summary>
        /// ���������س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtName_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.IsInputName && this.txtName.Text.Trim() == "")
                {
                    MessageBox.Show("�����뻼������!", "��ʾ");
                    this.txtName.Focus();
                    return;
                }

                //û�����벡����,����ݻ������������Һ���Ϣ
                if (this.txtCardNo.Text.Trim() == "")
                {
                    string CardNo = this.GetCardNoByName(this.txtName.Text.Trim());

                    if (CardNo == "")
                    {
                        this.txtName.Focus();
                        return;
                    }
                    this.txtCardNo.Text = CardNo;

                    this.txtCardNo_KeyDown(new object(), new KeyEventArgs(Keys.Enter));
                }
                else
                {
                    //this.cmbSex.Focus();
                    this.setNextControlFocus();
                    //this.txtIdNO.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }

        }
        /// <summary>
        /// ͨ�����������������߹Һ���Ϣ
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        private string GetCardNoByName(string Name)
        {
            frmQueryPatientByName f = new frmQueryPatientByName();

            f.QueryByName(Name);
            DialogResult dr = f.ShowDialog();

            if (dr == DialogResult.OK)
            {
                string CardNo = f.SelectedCardNo;
                f.Dispose();
                return CardNo;
            }

            f.Dispose();

            return "";
        }
        #endregion

        #region KeyEnter
        private void cmbSex_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmbSex.Tag == null || this.cmbSex.Tag.ToString() == "")
                {
                    MessageBox.Show("��ѡ�����Ա�!", "��ʾ");
                    this.cmbSex.Focus();
                    return;
                }
                //if (IsBirthdayEnd)
                //{
                //    this.dtBirthday.Focus();
                //}
                //else
                //{
                //    cmbPayKind.Focus();
                //}
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        private void txtAge_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(txtAge.Text.Trim()))
                {
                    txtAge.Focus();
                    MessageBox.Show("����������!");
                    return;
                }
                this.getBirthday();

                int r = this.getCostByAge();//��ʾӦ�����

                //if (this.cmbUnit.Enabled)
                //    this.cmbUnit.Focus();
                //else
                //    this.txtPhone.Focus();
                if (IsBirthdayEnd)
                {
                    this.dtBirthday.Focus();
                }
                else
                {
                    if (this.txtMcardNo.Enabled)
                        this.txtMcardNo.Focus();
                    else
                        txtPhone.Focus();
                }
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        /// <summary>
        /// ��ȡ��������
        /// </summary>
        private void getBirthday()
        {
            string age = this.txtAge.Text.Trim();
            int i = 0;

            if (age == "") age = "0";

            try
            {
                i = int.Parse(age);
            }
            catch (Exception e)
            {
                string error = e.Message;
                MessageBox.Show("�������䲻��ȷ,����������!", "��ʾ");
                this.txtAge.Focus();
                return;
            }

            ///
            ///

            DateTime birthday = DateTime.MinValue;

            this.getBirthday(i, this.cmbUnit.Text, ref birthday);

            if (birthday < this.dtBirthday.MinDate)
            {
                MessageBox.Show("���䲻�ܹ���!", "��ʾ");
                this.txtAge.Focus();
                return;
            }

            //this.dtBirthday.Value = birthday ;

            if (this.cmbUnit.Text == "��")
            {

                //���ݿ��д���ǳ�������,������䵥λ����,��������ĳ������ں����ݿ��г������������ͬ
                //�Ͳ��������¸�ֵ,��Ϊ����ĳ�����������Ϊ����,���������ݿ���Ϊ׼

                if (this.dtBirthday.Value.Year != birthday.Year)
                {
                    this.dtBirthday.Value = birthday;
                }
            }
            else
            {
                this.dtBirthday.Value = birthday;
            }
        }
        /// <summary>
        /// ��������õ���������
        /// </summary>
        /// <param name="age"></param>
        /// <param name="ageUnit"></param>
        /// <param name="birthday"></param>
        private void getBirthday(int age, string ageUnit, ref DateTime birthday)
        {
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();

            if (ageUnit == "��")
            {
                birthday = current.AddYears(-age);
            }
            else if (ageUnit == "��")
            {
                birthday = current.AddMonths(-age);
            }
            else if (ageUnit == "��")
            {
                birthday = current.AddDays(-age);
            }
        }

        private void cmbUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.getBirthday();
        }
        private void cmbUnit_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.txtPhone.Focus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        private void cmbPayKind_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmbPayKind.Tag == null || this.cmbPayKind.Tag.ToString() == "")
                {
                    MessageBox.Show("��ѡ���߽������!", "��ʾ");
                    this.cmbPayKind.Focus();
                    return;
                }

                if (this.ValidCombox("��ѡ��ĺ�ͬ��λ������ں�ͬ��λ�������б���,������ѡ��") < 0)
                {
                    //this.cmbPayKind.Focus();
                    return;
                }

                //�ж��Ƿ���Ҫ����ҽ��֤��,�����Ҫ,��������ҽ��֤�Ŵ�
                Neusoft.HISFC.Object.Base.PactInfo pact = conMgr.GetPactUnitInfoByPactCode(this.cmbPayKind.Tag.ToString());
                if (pact == null)
                {
                    MessageBox.Show("������ͬ��λʱ����!" + conMgr.Err, "��ʾ");
                    this.cmbPayKind.Focus();
                    return;
                }

                if (pact.ID == null || pact.ID == "")//û�м�����
                {
                    MessageBox.Show("���ݿ��Ѿ��䶯,���˳��������µ�½!", "��ʾ");
                    return;
                }

                //this.getCost();
                this.getCostByAge();

                this.getPayRate(pact);

                //if (pact.IsNeedMCard && IsBirthdayEnd)
                //{
                //    if (this.txtMcardNo.Enabled)
                //        this.txtMcardNo.Focus();
                //    else if (txtAge.Enabled)
                //        txtAge.Focus();
                //    else
                //        txtPhone.Focus();
                //}
                //else if (pact.IsNeedMCard && !IsBirthdayEnd)
                //{
                //    if (txtAge.Enabled)
                //        txtAge.Focus();
                //    else
                //        txtPhone.Focus();
                //}
                //else
                //{
                //    if (IsBirthdayEnd && this.dtBirthday.Enabled)
                //    {
                //        if (this.txtAge.Text.Trim() == "")
                //        {
                //            if (txtAge.Enabled)
                //                this.txtAge.Focus();
                //            else
                //                txtPhone.Focus();
                //        }
                //        else
                //        {
                //            this.txtPhone.Focus();
                //        }
                //    }
                //    else if (this.txtAge.Enabled)
                //    {
                //        txtAge.Focus();
                //    }
                //    else
                //    {
                //        this.txtPhone.Focus();
                //    }
                //}
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                //this.setPriorControlFocus() ;
                this.dtBirthday.Focus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// ��ʾ��ͬ��λ֧������
        /// </summary>
        /// <param name="pact"></param>
        private void getPayRate(Neusoft.HISFC.Object.Base.PactInfo pact)
        {
            this.lbTot.Text = "";

            if (pact != null && pact.Rate.PayRate != 0)
            {
                decimal rate = pact.Rate.PayRate * 100;
                this.lbTot.Text = rate.ToString("###") + "%";
            }
        }
        private void txtMcardNo_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //if (this.txtAge.Text.Trim() == "")
                //{
                //    this.txtAge.Focus();
                //}
                //else
                //{
                //    this.txtPhone.Focus();
                //}
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        private void dtBirthday_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DateTime current = this.regMgr.GetDateTimeFromSysDateTime().Date;

                if (this.dtBirthday.Value.Date > current)
                {
                    MessageBox.Show("�������ڲ��ܴ��ڵ�ǰʱ��!", "��ʾ");
                    this.dtBirthday.Focus();
                    return;
                }

                //��������
                if (this.dtBirthday.Value.Date != current)
                {
                    this.setAge(this.dtBirthday.Value);
                }

                int r = this.getCostByAge();//��ʾ����ʵ��Ӧ�����

                //if (this.cmbPayKind.Enabled)
                //    this.cmbPayKind.Focus();
                //else
                //    this.txtAge.Focus();
                if (this.txtMcardNo.Enabled)
                    this.txtMcardNo.Focus();
                else
                    txtPhone.Focus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        private void EditingControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.cmbSex.Focus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.cmbPayKind.Focus();
            }
        }
        private void txtPhone_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //this.txtAddress.Focus();
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        /// <summary>
        /// {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void txtVIPNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrEmpty(txtVIPNo.Text.Trim()))
                {
                    string vipNo = txtVIPNo.Text.Trim().PadLeft(10, '0');
                    decimal dVacancy = 0m;
                    int ret = this.feeMgr.GetAccountVacancy(vipNo, ref dVacancy);
                    if (ret == 1)
                    {
                        tbSIBalanceCost.Text = dVacancy.ToString("0.##");
                        //cmbPayKind.Tag = "5";
                        this.regObj.TranHospCode = vipNo;
                    }
                    else
                    {
                        MessageBox.Show("VIP���Ŷ������ȷ!");
                        txtVIPNo.Clear();
                    }
                }
                //this.txtAddress.Focus();
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        private void txtAddress_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //this.cmbCardType.Focus();
                this.setNextControlFocus();
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }

        private void cmbCardType_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //if (this.save(false) == -1) {D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2}
                if (this.SaveByControl(false) == -1)
                {
                    cmbRegLevel.Focus();
                }

                return;
            }
            else if (e.KeyCode == Keys.PageUp)
            {
                //������ת
                this.setPriorControlFocus();
            }
            else if (e.KeyCode == Keys.PageDown)
            {
                this.setNextControlFocus();
            }
        }
        #endregion
        #endregion

        #region �Զ���ȡ���￨������ǿ2007-09-24
        /// <summary>
        /// �Զ���ȡ���￨��
        /// </summary>
        private void AutoGetCardNO()
        {
            int autoGetCardNO;
            autoGetCardNO = regMgr.AutoGetCardNO();
            if (autoGetCardNO == -1)
            {
                MessageBox.Show("δ�ܳɹ��Զ��������ţ����ֶ����룡", "��ʾ");
            }
            else
            {
                this.txtCardNo.Text = autoGetCardNO.ToString().PadLeft(10, '0');
            }
            this.txtCardNo.Focus();
        }
        #endregion

        #region PageUp,PageDown�л�������ת
        /// <summary>
        /// ������һ���ؼ���ý���
        /// </summary>		
        private void setPriorControlFocus()
        {
            System.Windows.Forms.SendKeys.Send("+{TAB}");

        }

        /// <summary>
        /// ������һ���ؼ���ý���
        /// </summary>		
        private void setNextControlFocus()
        {
            System.Windows.Forms.SendKeys.Send("{TAB}");
        }
        #endregion

        #region ���뷨�˵��¼�
        private void m_Click(object sender, EventArgs e)
        {
            foreach (ToolStripMenuItem m in this.neuContextMenuStrip1.Items)
            {
                if (sender == m)
                {
                    m.Checked = true;
                    this.CHInput = this.getInputLanguage(m.Text);
                    //�������뷨
                    this.saveInputLanguage();
                }
                else
                {
                    m.Checked = false;
                }
            }
        }
        /// <summary>
        /// ��ȡ��ǰĬ�����뷨
        /// </summary>
        private void readInputLanguage()
        {
            if (!System.IO.File.Exists(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/feeSetting.xml"))
            {
                Neusoft.UFC.Common.Classes.Function.CreateFeeSetting();

            }
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/feeSetting.xml");
                XmlNode node = doc.SelectSingleNode("//IME");

                this.CHInput = this.getInputLanguage(node.Attributes["currentmodel"].Value);

                if (this.CHInput != null)
                {
                    foreach (ToolStripMenuItem m in this.neuContextMenuStrip1.Items)
                    {
                        if (m.Text == this.CHInput.LayoutName)
                        {
                            m.Checked = true;
                        }
                    }
                }

                //���ӵ�������

            }
            catch (Exception e)
            {
                MessageBox.Show("��ȡ�Һ�Ĭ���������뷨����!" + e.Message);
                return;
            }
        }

        private void addContextToToolbar()
        {
            Neusoft.NFC.Interface.Controls.NeuToolBar main = null;

            foreach (Control c in FindForm().Controls)
            {
                if (c.GetType() == typeof(Neusoft.NFC.Interface.Controls.NeuToolBar))
                {
                    main = (Neusoft.NFC.Interface.Controls.NeuToolBar)c;
                }
            }

            ToolBarButton button = null;

            if (main != null)
            {
                foreach (ToolBarButton b in main.Buttons)
                {
                    if (b.Text == "���뷨") button = b;
                }
            }

            //if(button != null)
            //{
            //    ToolStripDropDownButton drop = (ToolStripDropDownButton)button;
            //    foreach(ToolStripMenuItem m in neuContextMenuStrip1.Items)
            //    {
            //        drop.DropDownItems.Add(m);
            //    }
            //}
        }

        /// <summary>
        /// �������뷨���ƻ�ȡ���뷨
        /// </summary>
        /// <param name="LanName"></param>
        /// <returns></returns>
        private InputLanguage getInputLanguage(string LanName)
        {
            foreach (InputLanguage input in InputLanguage.InstalledInputLanguages)
            {
                if (input.LayoutName == LanName)
                {
                    return input;
                }
            }
            return null;
        }
        /// <summary>
        /// ���浱ǰ���뷨
        /// </summary>
        private void saveInputLanguage()
        {
            if (!System.IO.File.Exists(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/feeSetting.xml"))
            {
                Neusoft.UFC.Common.Classes.Function.CreateFeeSetting();
            }
            if (this.CHInput == null) return;

            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/feeSetting.xml");
                XmlNode node = doc.SelectSingleNode("//IME");

                node.Attributes["currentmodel"].Value = this.CHInput.LayoutName;

                doc.Save(Neusoft.NFC.Interface.Classes.Function.SettingPath + "/feeSetting.xml");
            }
            catch (Exception e)
            {
                MessageBox.Show("����Һ�Ĭ���������뷨����!" + e.Message);
                return;
            }
        }
        #endregion
        /// <summary>
        /// {D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2} minqsh 20180326 add����ֹ�ظ�����
        /// </summary>
        /// <returns></returns>
        private int SaveByControl(bool isPos)
        {
            int iReturn = 0;

            if (isSaveing)
            {
                MessageBox.Show("���ڱ��棬���Ժ����ԣ�", "��ʾ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return -1;
            }

            try
            {
                iReturn = this.save(isPos);
            }
            finally
            {
                isSaveing = false;
            }

            return iReturn;
        }
        #region ����
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        private int save(bool isPos)
        {
            isSaveing = true;//{D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2} minqsh 20180326 add����ֹ�ظ�����
            if (this.valid() == -1) return 2;
            if (this.getValue() == -1) return 2;

            if (this.ValidCardNO(this.regObj.PID.CardNO) < 0)
            {
                return -1;
            }

            if (this.regObj.Birthday.Date >= this.regMgr.GetDateTimeFromSysDateTime().Date)
            {
                txtAge.Focus();
                MessageBox.Show("���䲻��ȷ!");
                return -1;
            }
            #region YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
            if (this.chbCardFee.Checked)
            {
                string re = this.regMgr.ExecSqlReturnOne("select count(a.sequence_no) from fin_opb_accountrecord a where a.opertype='11' and a.card_no='" + this.regObj.PID.CardNO + "'", "0");
                if (Neusoft.NFC.Function.NConvert.ToDecimal(re) > 0)
                {
                    MessageBox.Show("�����Ѿ���ȡ�������ѣ��������ٴ���ȡ��");
                    return 2;
                }
            }
            #endregion

            if (this.IsPrompt)
            {
                //ȷ����ʾ
                if (MessageBox.Show("¼�������Ƿ���ȷ?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button1) == DialogResult.No)
                {
                    this.cmbRegLevel.Focus();
                    return -1;
                }
            }
            #region //��ѯadd by feng.ch{2B6167F7-339B-4f09-9af6-C5CD6Agg3AC89}
            ////�жϣ�����Һ����Ϊ�󲡺��򱣴�󲡵Ǽ���Ϣ
            //if (this.cmbRegLevel.Tag.ToString() == "08")
            //{
            //    if (SIBigSickGetInfo() == -1)
            //        return -1;
            //}
            #endregion

            int rtn;
            string Err = "";
            //�ӿ�ʵ��{E43E0363-0B22-4d2a-A56A-455CFB7CF211}
            //if (this.iProcessRegiter != null)
            //{
            //    rtn = this.iProcessRegiter.SaveBegin(ref regObj, ref Err);

            //    if (rtn < 0)
            //    {
            //        MessageBox.Show(Err);
            //        return -1;
            //    }
            //}

            this.MedcareInterfaceProxy.SetPactCode(this.regObj.Pact.ID);

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction t = new Neusoft.NFC.Management.Transaction(this.regMgr.con);
            //t.BeginTransaction();

            this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.bookingMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.SchemaMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.patientMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.feeMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            //this.SIMgr.SetTrans(t);
            //this.InterfaceMgr.SetTrans(t.Trans);
            #region ȡ��Ʊ
            //{1EE40E26-848D-4029-81FD-B2543127A8B1} 0���ùҺŲ���ӡ��Ʊ
            //YYT {22498834-0618-4ef5-BC2B-C08E492AC69E} �������ƿ������ѵ�ʱ������Ҫ��Ʊ�ģ������ӵĻ��������߲�ȡ�ţ�����ķ�Ʊ�ǲ������ŵġ�
            if ((regObj.RegLvlFee.RegFee + regObj.RegLvlFee.OthFee + regObj.RegLvlFee.OwnDigFee + regObj.RegLvlFee.PubDigFee + regObj.RegLvlFee.ChkFee) == 0 && (!this.chbCardFee.Checked))
            {
                this.regObj.InvoiceNO = "T" + this.regObj.RecipeNO.ToString().PadLeft(11, '0');
            }
            else
            {
                if (this.GetRecipeType == 2)
                {
                    //this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO(Neusoft.HISFC.Object.Fee.EnumInvoiceType.R);
                    this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO("R");

                    if (this.regObj.InvoiceNO == null || this.regObj.InvoiceNO == "")
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�ò���Աû�п���ʹ�õ�����Һŷ�Ʊ������ȡ");
                        return -1;
                    }
                }
                else if (this.GetRecipeType == 3)
                {
                    //this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO(Neusoft.HISFC.Object.Fee.EnumInvoiceType.C);
                    //ȡ�����վ�
                    this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO("C");
                    if (this.regObj.InvoiceNO == null || this.regObj.InvoiceNO == "")
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�ò���Աû�п��Կ���ʹ�õ������շѷ�Ʊ������ȡ");
                        return -1;
                    }
                }
                else if (this.GetRecipeType == 1)
                {
                    this.regObj.InvoiceNO = this.regObj.RecipeNO.ToString().PadLeft(12, '0');
                }
            }
            #endregion

            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();

            string CardCost = this.ctlMgr.QueryControlerInfo("CardCost");
            decimal CardFee = Neusoft.NFC.Function.NConvert.ToDecimal(CardCost);

            try
            {
                #region ���¿������
                int orderNo = 0;

                //2�������		
                if (this.UpdateSeeID(this.regObj.DoctorInfo.Templet.Dept.ID, this.regObj.DoctorInfo.Templet.Doct.ID,
                    this.regObj.DoctorInfo.Templet.Noon.ID, this.regObj.DoctorInfo.SeeDate, ref orderNo,
                    ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                regObj.DoctorInfo.SeeNO = orderNo;

                //ר�ҡ�ר�ơ����ԤԼ�Ÿ����Ű��޶�
                #region schema
                if (this.UpdateSchema(this.SchemaMgr, this.regObj.RegType, ref orderNo, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    if (Err != "") MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                regObj.DoctorInfo.SeeNO = orderNo;
                #endregion

                //1ȫԺ��ˮ��			
                if (this.Update(this.regMgr, current, ref orderNo, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                regObj.OrderNO = orderNo;
                #endregion

                //ԤԼ�Ÿ����ѿ����־
                #region booking
                if (this.regObj.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)
                {
                    //���¿����޶�
                    //rtn = this.bookingMgr.Update((this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).ID, true, regMgr.Operator.ID, current);
                    rtn = this.bookingMgr.Update((this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).ID, true, regMgr.Operator.ID, current, regObj.ID);
                    if (rtn == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("����ԤԼ������Ϣ����!" + this.bookingMgr.Err, "��ʾ");
                        return -1;
                    }
                    if (rtn == 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("ԤԼ�Һ���Ϣ״̬�Ѿ����,�����¼���!", "��ʾ");
                        return -1;
                    }
                }
                #endregion

                #region �����ӿ�ʵ��
                this.MedcareInterfaceProxy.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.MedcareInterfaceProxy.Connect();

                this.MedcareInterfaceProxy.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.MedcareInterfaceProxy.BeginTranscation();

                this.regObj.SIMainInfo.InvoiceNo = this.regObj.InvoiceNO;
                // add by zzr 2010-11-21 {E68CD3A2-C8BF-4df5-A02B-E23B13747654}
                //this.regObj.TranHospCode = this.txtTranHospCode.Text;//ת�ﵥ��
                int returnValue = this.MedcareInterfaceProxy.UploadRegInfoOutpatient(this.regObj);
                if (returnValue == -1)
                {
                    this.MedcareInterfaceProxy.Rollback();
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�ϴ��Һ���Ϣʧ��!") + this.MedcareInterfaceProxy.ErrMsg);

                    return -1;
                }
                ////ҽ�����ߵǼ�ҽ����Ϣ
                //if (this.regObj.Pact.PayKind.ID == "02")
                //{
                this.regObj.OwnCost = this.regObj.SIMainInfo.OwnCost;  //�Էѽ��
                this.regObj.PubCost = this.regObj.SIMainInfo.PubCost;  //ͳ����
                this.regObj.PayCost = this.regObj.SIMainInfo.PayCost;  //�ʻ����
                #region {EB17EE6F-AE42-40d7-BAEE-141570E77EFA} VIP��
                //if (this.regObj.EcoCost > 0) //{F7ACB57F-903A-40cd-B9C3-19267D79CFEC} by jizhr Ϊ�Һŷ��Ż���
                //{
                //    this.regObj.OwnCost -= this.regObj.EcoCost;
                //} 
                #endregion
                //}
                #endregion

                //���������ʻ����� {EB17EE6F-AE42-40d7-BAEE-141570E77EFA} VIP��
                if (this.regObj.OwnCost > 0 && this.AccountPatient() < 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    return -1;
                }

                //ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
                //��Ϊ�˰汾ҽ��Rollbackδ��ʵ�֣�ֻ���ȴ��������ˡ�����ҽ���ɹ���Ȼ������ʧ�ܣ�����ҽ�������ˡ�
                //��������ɹ�������ҽ��ʧ�ܣ��������ȳ���������Ա�����ֽ����ʽ���գ�Ȼ���ֹ����ˡ�
                if (isPos && this.regObj.OwnCost > 0)
                {
                    decimal posCost = this.regObj.OwnCost;

                    //MessageBox.Show("��ʹ��ũ��POS�շѣ� " + posCost.ToString() + " Ԫ");

                    Neusoft.TaiZhouABCBank.POS.Function posFunction = new Neusoft.TaiZhouABCBank.POS.Function();
                    posFunction.InputListInfo.Clear();
                    posFunction.InputListInfo.Add(posCost);//���
                    string err = string.Empty;
                    if (posFunction.Do(ref err) < 1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        this.MedcareInterfaceProxy.Rollback();
                        MessageBox.Show("�����շѳ���!" + err, "��ʾ");
                        return -1;
                    }

                    this.regObj.PosPayMethod = posFunction.OutputListInfo[20].ToString();//����֧����ʽ
                    this.regObj.PosTransOut = posFunction.StrReturn;//ԭʼ����
                }

                //�ǼǹҺ���Ϣ
                if (this.regMgr.Insert(this.regObj) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.MedcareInterfaceProxy.Rollback();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }

                //���»��߻�����Ϣ
                if (this.UpdatePatientinfo(this.regObj, this.patientMgr, this.regMgr, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.MedcareInterfaceProxy.Rollback();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }
                //�ӿ�ʵ��{E43E0363-0B22-4d2a-A56A-455CFB7CF211}
                if (this.iProcessRegiter != null)
                {
                    rtn = this.iProcessRegiter.SaveEnd(ref regObj, ref Err);

                    if (rtn < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        this.MedcareInterfaceProxy.Rollback();
                        MessageBox.Show(Err);
                        return -1;
                    }
                }
                #region YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
                if (this.chbCardFee.Checked)
                {
                    string sql = @"Insert Into FIN_OPB_ACCOUNTRECORD
                                      (SEQUENCE_NO,
                                       CARD_NO,
                                       OPERTYPE,
                                       MONEY,
                                       Remark,
                                       OPER_CODE,
                                       OPER_DATE,
                                       VACANCY,
                                       NAME,
                                       valid)
                                    Values
                                      (SEQ_FIN_OPB_ACCOUNTRECORD.Nextval,
                                       '{0}', --����
                                       '11',
                                       -1*{1}, --���
                                       '{2}', --cliniccode
                                       '{3}', --����Ա��
                                       sysdate,
                                       0,
                                       '{4}', --����
                                       '1')";
                    sql = string.Format(sql, this.regObj.PID.CardNO, CardFee.ToString(), this.regObj.ID, NFC.Management.Connection.Operator.ID, this.regObj.Name);
                    if (this.regMgr.ExecNoQuery(sql) < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        this.MedcareInterfaceProxy.Rollback();
                        MessageBox.Show(regMgr.Err, "��ʾ");
                        return -1;
                    }
                }
                #endregion

                //����ҽ������
                //this.MedcareInterfaceProxy.UploadRegInfoOutpatient

                //���п��շ� {B42210EB-D925-4c60-A4FD-0E9580F8DAC5} YYTPOS by wwei_neu 
                if (isPos && (this.regObj.OwnCost + this.regObj.PubCost + this.regObj.PayCost > 0 || this.chbCardFee.Checked))
                {
                    #region  �������ϣ�ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
                    /*
                    EntFinOprPay pay = new EntFinOprPay();
                    pay.OperCode = Neusoft.NFC.Management.Connection.Operator.ID;
                    pay.TotCost = this.regObj.OwnCost + this.regObj.PubCost + this.regObj.PayCost;
                    if (this.chbCardFee.Checked)
                    {
                        pay.TotCost = pay.TotCost + CardFee;
                        pay.IsCardfee = "1"; //�۳�������
                    }
                    pay.IsCardfee = "0"; //ľ�п۳�������
                    pay.ClinicCode = this.regObj.ID;
                    pay.TransType = "1";
                    pay.ModeCode = "DB";
                    pay.RealCost = pay.TotCost;
                    pay.OperDate = regMgr.GetDateTimeFromSysDateTime();



                    string returnCode = SoftPosAPI.UnionpayFee(ref pay);

                    if (returnCode != "00")
                    {
                        if (returnCode == "51")
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            this.MedcareInterfaceProxy.Rollback();
                            MessageBox.Show("����");
                            return -1;

                        }
                        else
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            this.MedcareInterfaceProxy.Rollback();
                            MessageBox.Show("�շ�����������:" + returnCode);
                            return -1;
                        }
                    }
                    else
                    {
                        Neusoft.HISFC.Object.Base.Const bank = FindBank(pay.BankCode);

                        if (bank != null)
                            pay.BankName = bank.Name;
                        else
                            pay.BankName = "����";



                        if (pay.InsertData() < 0)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            this.MedcareInterfaceProxy.Rollback();
                            MessageBox.Show("��������֧����ʽ����:");

                            //SoftPosAPI.CancleUnionpayFeeQuick(ref pay);

                            return -1;
                        }
                    }
                    */
                    #endregion
                }

                Neusoft.NFC.Management.PublicTrans.Commit();
                this.MedcareInterfaceProxy.Commit();
                this.MedcareInterfaceProxy.Disconnect();

                //�����´�����,�� 1,��ֹ��;��������
                this.UpdateRecipeNo(1);

                this.QueryRegLevl();
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return -1;
            }

            this.ShowOperationInformation(this.regObj);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}


            ////����{F0661633-4754-4758-B683-CB0DC983922B}
            //if (this.isShowChangeCostForm && this.regObj.OwnCost > 0)
            //{
            //    rtn = this.ShowChangeForm(this.regObj);
            //    {
            //        if (rtn < 0)
            //        {
            //            return -1;
            //        }
            //    }
            //}

            #region ��ҽͨ���￨�����Ѵ��� YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
            //string CardCost=this.ctlMgr.QueryControlerInfo("CardCost");
            //decimal CardFee = Neusoft.NFC.Function.NConvert.ToDecimal(CardCost);

            //�ڹ�ѡ�۳���Ѻ���ʱ�� ���ڹҺż�¼���Էѽ�������ӿ������ѣ���ʾ����������ϣ�
            //Ȼ���ڽ������֮���ٴӹҺż�¼��owncost����ȥ���������ѣ��������������⴦��
            //�������Ѹ��������Ѳ�һ������Ҫ������������˻������Բ����뵽�Һ���Ϣ����ȥ
            if (this.chbCardFee.Checked)
            {
                this.regObj.OwnCost = this.regObj.OwnCost + CardFee;
            }

            //����{F0661633-4754-4758-B683-CB0DC983922B}
            bool bl_autoCancel = false;//�Զ��˺ű�־
            if (this.isShowChangeCostForm && this.regObj.OwnCost > 0)
            {
                rtn = this.ShowChangeForm(this.regObj);
                {
                   
                    if (rtn < 0)
                    {
                        bl_autoCancel = true;  //{C57BE0DB-CE4C-47dd-8879-17442C1BEA71}
                       
                        
                        
                        //return -1;
                    }
                }
            }
            if (this.chbCardFee.Checked)
            {
                this.regObj.OwnCost = this.regObj.OwnCost - CardFee;
            }

            #endregion

            //{1EE40E26-848D-4029-81FD-B2543127A8B1} 0���ùҺŲ���ӡ��Ʊ
            if (
                (regObj.RegLvlFee.RegFee + regObj.RegLvlFee.OthFee + regObj.RegLvlFee.OwnDigFee + regObj.RegLvlFee.PubDigFee + regObj.RegLvlFee.ChkFee) >= 0 ||
                this.chbCardFee.Checked)
            {
                if (this.isAutoPrint)
                {
                    this.Print(this.regObj, this.regMgr);
                }
                else
                {
                    DialogResult rs = MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ѡ���Ƿ��ӡ�Һ�Ʊ"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                    if (rs == DialogResult.Yes)
                    {
                        this.Print(this.regObj, this.regMgr);
                    }
                }
            }

            if (bl_autoCancel)  //{C57BE0DB-CE4C-47dd-8879-17442C1BEA71}
            {
                Neusoft.UFC.Registration.ucCancel cancelGh = new Neusoft.UFC.Registration.ucCancel();
                if (cancelGh.saveCancel(this.regObj) < 0)
                {
                    MessageBox.Show("�Զ��˷�ʧ�ܣ����ֶ��˹Һŷ�");
                    return -1;
                }
                
            }

            this.addRegister(this.regObj);

            try
            {
                int rs = -1;

                string db = orderMgr.ExecSqlReturnOne("select c.control_value from com_controlargument c where c.control_code='pacsorddb'");

                orderMgr.ExecSPCommand(db, "dt_insert_pmain",
                    new IDataParameter[] { new SqlParameter("@i_mrn",Convert.ToInt32(this.regObj.PID.CardNO.TrimStart(new char[]{'0'}))),
                                           new SqlParameter("@s_pname",this.regObj.Name),
                                      new SqlParameter("@dt_pbirthday",this.regObj.Birthday),
                                      new SqlParameter("@i_age",string.IsNullOrEmpty(this.txtAge.Text)?0:Convert.ToInt32(this.txtAge.Text)),
                                      new SqlParameter("@s_psex",this.regObj.Sex.ID),
                                        new SqlParameter("@s_paddress",this.regObj.AddressHome),
                                        new SqlParameter("@s_pphone",this.regObj.PhoneHome),
                                        new SqlParameter("@s_ageunit","Y"),
                                        new SqlParameter("@dt_pdate",orderMgr.GetDateTimeFromSysDateTime()),
                                        new SqlParameter("@i_rtn",rs)
                    });
            }
            catch (Exception ee)
            {
                MessageBox.Show("����PACS�û���Ϣʧ��,��Ӱ��Һ�" + ee.Message);
            }


            this.clear();
            return 0;


        }

        /// <summary>
        /// �������� {B42210EB-D925-4c60-A4FD-0E9580F8DAC5} YYTPOS
        /// </summary>
        /// <param name="bankCode"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Base.Const FindBank(string bankCode)
        {
            if (alBanks != null && alBanks.Count > 0)
            {
                foreach (object c in alBanks)
                {
                    Neusoft.HISFC.Object.Base.Const conster = c as Neusoft.HISFC.Object.Base.Const;

                    if (conster.Memo == bankCode)
                    {
                        return conster;
                    }
                }
            }

            return null;
        }


        #region ��Ч����֤
        /// <summary>
        /// ��Ч����֤
        /// </summary>
        /// <returns></returns>
        private int valid()
        {
            this.txtAddress.Focus();//��ֹ��combox�²��س��ͱ������
            if (this.txtRecipeNo.Text.Trim() == "")
            {
                MessageBox.Show("�����봦����!", "��ʾ");
                this.ChangeRecipe();
                return -1;
            }

            if (this.cmbRegLevel.Tag == null || this.cmbRegLevel.Tag.ToString() == "")
            {
                MessageBox.Show("��ѡ��Һż���!", "��ʾ");
                this.cmbRegLevel.Focus();
                return -1;
            }

            Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            if ((this.cmbDept.Tag == null || this.cmbDept.Tag.ToString() == ""))
            {
                MessageBox.Show("������Һſ���!", "��ʾ");
                this.cmbDept.Focus();
                return -1;
            }

            if (this.cmbDept.SelectedItem == null)
            {
                MessageBox.Show("��ѡ��Һſ���!", "��ʾ");
                this.cmbDept.Focus();
                return -1;
            }
            if (this.cmbDept.Text != this.cmbDept.SelectedItem.Name && this.cmbDept.Text != this.cmbDept.Tag.ToString())
            {
                MessageBox.Show("��������ȷ�ĹҺſ���!", "��ʾ");
                this.cmbDept.Focus();
                return -1;
            }

            if ((level.IsExpert || level.IsSpecial) &&
                (this.cmbDoctor.Tag == null || this.cmbDoctor.Tag.ToString() == ""))
            {
                MessageBox.Show("ר�Һű���ָ������ҽ��!", "��ʾ");
                this.cmbDoctor.Focus();
                return -1;
            }

            if (this.regObj == null)
            {
                MessageBox.Show("��¼��ҺŻ���!", "��ʾ");
                this.txtCardNo.Focus();
                return -1;
            }

            //{05B4AB01-C7FC-4e1b-9A77-80B83E77F77F} �жϲ������Ƿ�Ϊ�� xuc
            if (string.IsNullOrEmpty(this.regObj.PID.CardNO) == true)
            {
                MessageBox.Show("��¼�벡����!", "��ʾ");
                this.txtCardNo.Focus();
                return -1;
            }

            if (this.IsInputName && this.txtName.Text.Trim() == "")
            {
                MessageBox.Show("�����뻼������!", "��ʾ");
                this.txtName.Focus();
                return -1;
            }

            if (this.dtBegin.Value.TimeOfDay > this.dtEnd.Value.TimeOfDay)
            {
                MessageBox.Show("�Һſ�ʼʱ�䲻�ܴ��ڽ���ʱ��!", "��ʾ");
                this.dtEnd.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtName.Text.Trim(), 40) == false)
            {
                MessageBox.Show("������������¼��20������!", "��ʾ");
                this.txtName.Focus();
                return -1;
            }
            if (this.cmbSex.Tag == null || this.cmbSex.Tag.ToString() == "")
            {
                MessageBox.Show("��ѡ�����Ա�!", "��ʾ");
                this.cmbSex.Focus();
                return -1;
            }

            if (this.cmbPayKind.Tag == null || this.cmbPayKind.Tag.ToString() == "")
            {
                MessageBox.Show("���߽��������Ϊ��!", "��ʾ");
                this.cmbPayKind.Focus();
                return -1;
            }
            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtPhone.Text.Trim(), 20) == false)
            {
                MessageBox.Show("��ϵ�绰����¼��20λ����!", "��ʾ");
                this.txtPhone.Focus();
                return -1;
            }
            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtAddress.Text.Trim(), 60) == false)
            {
                MessageBox.Show("��ϵ�˵�ַ����¼��30������!", "��ʾ");
                this.txtAddress.Focus();
                return -1;
            }
            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtMcardNo.Text.Trim(), 30) == false)
            {
                MessageBox.Show("ҽ��֤������¼��30λ����!", "��ʾ");
                this.txtMcardNo.Focus();
                return -1;
            }
            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtAge.Text.Trim(), 3) == false)
            {
                MessageBox.Show("��������¼��3λ����!", "��ʾ");
                this.txtAge.Focus();
                return -1;
            }
            if (IsLimit)
            {
                if ((this.txtPhone.Text == null || this.txtPhone.Text.Trim() == "") &&
                   (this.txtAddress.Text == null || this.txtAddress.Text.Trim() == ""))
                {
                    MessageBox.Show("��ϵ�绰�͵�ַ����ͬʱΪ��,��������һ��!", "��ʾ");
                    this.txtPhone.Focus();
                    return -1;
                }
            }

            if (this.txtAge.Text.Trim().Length > 0)
            {
                try
                {
                    int age = int.Parse(this.txtAge.Text.Trim());
                    if (age <= 0)
                    {
                        MessageBox.Show("���䲻��Ϊ����!", "��ʾ");
                        this.txtAge.Focus();
                        return -1;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("����¼���ʽ����ȷ!" + e.Message, "��ʾ");
                    this.txtAge.Focus();
                    return -1;
                }
            }
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime().Date;
            if (this.dtBirthday.Value.Date >= current)
            {
                MessageBox.Show("�������ڲ���ȷ��\r\n���ܴ��ڵ��ڵ�ǰʱ��!", "��ʾ");
                this.dtBirthday.Focus();
                return -1;
            }

            if (Convert.ToInt32(this.txtAge.Text.Trim()) <= 14)
            {
                if (string.IsNullOrEmpty(this.txtParentName.Text.Trim()))
                {
                    MessageBox.Show("�û�������С�ڵ���14���꣬������ҳ�����!", "��ʾ");
                    this.txtParentName.Focus();
                    return -1;
                }
            }

            //У���ͬ��λ
            if (this.ValidCombox("��ѡ��ĺ�ͬ��λ������ں�ͬ��λ�������б���,������ѡ��") < 0)
            {
                this.cmbPayKind.Focus();
                return -1;
            }

            //У������֤��
            if (!string.IsNullOrEmpty(this.txtIdNO.Text))
            {

                int reurnValue = this.ProcessIDENNO(this.txtIdNO.Text, EnumCheckIDNOType.Saveing);

                if (reurnValue < 0)
                {
                    return -1;
                }
            }
            // {C621B618-753B-4ff5-AC11-F1C0F90D5F7E} У�黼�������Ƿ�һ��
            Neusoft.HISFC.Object.RADT.PatientInfo p = this.patientMgr.QueryComPatientInfo(this.regObj.PID.CardNO);
            if (p != null && !string.IsNullOrEmpty(p.Name.Trim()) && p.Name != this.txtName.Text.Trim())
            {
                MessageBox.Show("������ԭ�еĻ�������Ϊ " + p.Name + " ������ " + this.txtName.Text.Trim() + " �޷����棡", "��ʾ");
                return -1;
            }
            this.cmbPayKind.Tag.ToString();
            return 0;
        }

        #region У���ͬ��λ
        /// <summary>
        /// У��combox
        /// </summary>
        private int ValidCombox(string ErrMsg)
        {
            int j = 0;
            for (int i = 0; i < this.cmbPayKind.Items.Count; i++)
            {
                if (this.cmbPayKind.Text.Trim() == this.cmbPayKind.Items[i].ToString())
                {

                    this.cmbPayKind.SelectedIndex = i;
                    j++;
                    break;

                }


            }
            //"��ѡ��ĺ�ͬ��λ������ں�ͬ��λ�������б���,������ѡ��"
            if (j == 0)
            {
                MessageBox.Show(ErrMsg);

                return -1;
            }
            return 1;


        }
        #endregion

        #endregion

        #region ��֤�˾��￨���Ƿ�ס��Ժ
        ///// <summary>
        ///// ��֤�˾��￨���Ƿ�ס��Ժ
        ///// </summary>
        ///// <param name="cardNO"></param>
        ///// <returns></returns>
        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
        //private ArrayList ValidIsSendInhosCase(string cardNO)
        //{


        //    return patientMgr.GetPatientInfoHaveCaseByCardNO(cardNO);

        //}
        #endregion

        #region ��ȡ�Һ���Ϣ
        /// <summary>
        /// ��ȡ�Һ���Ϣ
        /// </summary>
        /// <returns></returns>
        private int getValue()
        {
            //�����
            this.regObj.ID = this.regMgr.GetSequence("Registration.Register.ClinicID");

            //{EF076D89-17FE-4922-AC71-3F4D61158505} ������20151020���ϼҳ�����
            this.regObj.ParentName = this.txtParentName.Text;

            this.regObj.TranType = Neusoft.HISFC.Object.Base.TransTypes.Positive;//������

            this.regObj.DoctorInfo.Templet.RegLevel.ID = this.cmbRegLevel.Tag.ToString();
            this.regObj.DoctorInfo.Templet.RegLevel.Name = this.cmbRegLevel.Text;
            this.regObj.Profession.ID = this.cmbProfession.Tag.ToString();//̩����ҽԺ�ֳ��Һ����ӡ�ְҵ��{B51EA52F-ABDF-4aba-B2C8-3A874FB39DBA}
            this.regObj.DoctorInfo.Templet.Dept.ID = this.cmbDept.Tag.ToString();
            this.regObj.DoctorInfo.Templet.Dept.Name = this.cmbDept.Text;

            this.regObj.DoctorInfo.Templet.Doct.ID = this.cmbDoctor.Tag.ToString();
            this.regObj.DoctorInfo.Templet.Doct.Name = this.cmbDoctor.Text;

            this.regObj.Name = this.txtName.Text.Trim();//��������
            this.regObj.Sex.ID = this.cmbSex.Tag.ToString();//�Ա�

            this.regObj.Birthday = this.dtBirthday.Value;//��������			

            Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
            this.regObj.RegType = Neusoft.HISFC.Object.Base.EnumRegType.Reg;
            //��Ϊ��˵����ԤԼ��
            if (this.txtOrder.Tag != null)
            {
                this.regObj.RegType = Neusoft.HISFC.Object.Base.EnumRegType.Pre;

                this.regObj.DoctorInfo.Templet.RegLevel.ID = this.booking.DoctorInfo.Templet.RegLevel.ID;
                this.regObj.DoctorInfo.Templet.RegLevel.Name = this.booking.DoctorInfo.Templet.RegLevel.Name;

                this.regObj.DoctorInfo.Templet.Dept.ID = this.booking.DoctorInfo.Templet.Dept.ID;
                this.regObj.DoctorInfo.Templet.Dept.Name = this.booking.DoctorInfo.Templet.Dept.Name;

                this.regObj.DoctorInfo.Templet.Doct.ID = this.booking.DoctorInfo.Templet.Doct.ID;
                this.regObj.DoctorInfo.Templet.Doct.Name = this.booking.DoctorInfo.Templet.Doct.Name;
            }
            else if (level.IsSpecial)
            {
                this.regObj.RegType = Neusoft.HISFC.Object.Base.EnumRegType.Spe;
            }

            Neusoft.HISFC.Object.Registration.Schema schema = null;

            ////ֻ��ר�ҡ�ר�ơ�������Ҫ���뿴��ʱ��Ρ������޶�
            if (this.regObj.RegType != Neusoft.HISFC.Object.Base.EnumRegType.Pre
                        && (level.IsSpecial || level.IsFaculty || level.IsExpert))
            {
                schema = this.GetValidSchema(level);
                if (schema == null)
                {
                    MessageBox.Show("ԤԼʱ��ָ������,û�з����������Ű���Ϣ!", "��ʾ");
                    this.dtBookingDate.Focus();
                    return -1;
                }
                this.SetBookingTag(schema);
            }

            if (level.IsExpert && this.regObj.RegType != Neusoft.HISFC.Object.Base.EnumRegType.Pre)
            {
                if (this.VerifyIsProfessor(level, schema) == false)
                {
                    this.cmbRegLevel.Focus();
                    return -1;
                }
            }

            #region �������
            this.regObj.Pact.ID = this.cmbPayKind.Tag.ToString();//��ͬ��λ
            //this.regObj.Pact.Name = this.cmbPayKind.Text;

            Neusoft.HISFC.Object.Base.PactInfo pact = conMgr.GetPactUnitInfoByPactCode(this.regObj.Pact.ID);
            if (pact == null || pact.ID == "")
            {
                MessageBox.Show("��ȡ����Ϊ:" + this.regObj.Pact.ID + "�ĺ�ͬ��λ��Ϣ����!" + this.conMgr.Err, "��ʾ");
                return -1;
            }
            this.regObj.Pact.Name = pact.Name;
            this.regObj.Pact.PayKind.Name = pact.PayKind.Name;
            this.regObj.Pact.PayKind.ID = pact.PayKind.ID;
            this.regObj.SSN = this.txtMcardNo.Text.Trim();//ҽ��֤��

            if (pact.IsNeedMCard && this.regObj.SSN == "")
            {
                MessageBox.Show("��Ҫ����ҽ��֤��!", "��ʾ");
                this.txtMcardNo.Focus();
                return -1;
            }
            //{F6189E06-2CD7-47fd-9D7B-FD4A2D7E904D}
            if (pact.IsNeedMCard && string.IsNullOrEmpty(this.txtIdNO.Text))
            {
                MessageBox.Show("��Ҫ��������֤��!", "��ʾ");
                this.txtIdNO.Focus();
                return -1;
            }
            //��Ա�������ж�
            if (this.validMcardNo(this.regObj.Pact.ID, this.regObj.SSN) == -1) return -1;

            #endregion

            this.regObj.PhoneHome = this.txtPhone.Text.Trim();//��ϵ�绰
            this.regObj.AddressHome = this.txtAddress.Text.Trim();//��ϵ��ַ
            this.regObj.CardType.ID = this.cmbCardType.Tag.ToString();

            #region ԤԼʱ���
            if (this.regObj.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)//ԤԼ�ſ��Ű��޶�
            {
                this.regObj.IDCard = (this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).IDCard;
                this.regObj.DoctorInfo.Templet.Noon.ID = (this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).DoctorInfo.Templet.Noon.ID;
                this.regObj.DoctorInfo.Templet.IsAppend = (this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).DoctorInfo.Templet.IsAppend;
                this.regObj.DoctorInfo.SeeDate = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                    this.dtBegin.Value.ToString("HH:mm:ss"));//�Һ�ʱ��
                this.regObj.DoctorInfo.Templet.Begin = this.regObj.DoctorInfo.SeeDate;
                this.regObj.DoctorInfo.Templet.End = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                    this.dtEnd.Value.ToString("HH:mm:ss"));//����ʱ��
                this.regObj.DoctorInfo.Templet.ID = (this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).DoctorInfo.Templet.ID;
            }
            else if (level.IsSpecial || level.IsExpert || level.IsFaculty)//ר�ҡ�ר�ơ�����ſ��Ű��޶�
            {
                this.regObj.DoctorInfo.Templet.Noon.ID = (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.Noon.ID;
                this.regObj.DoctorInfo.Templet.IsAppend = (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.IsAppend;
                this.regObj.DoctorInfo.SeeDate = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                    this.dtBegin.Value.ToString("HH:mm:ss"));//�Һ�ʱ��
                this.regObj.DoctorInfo.Templet.Begin = this.regObj.DoctorInfo.SeeDate;
                this.regObj.DoctorInfo.Templet.End = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                    this.dtEnd.Value.ToString("HH:mm:ss"));//����ʱ��
                this.regObj.DoctorInfo.Templet.ID = (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.ID;
            }
            else//�����Ų����޶�
            {
                this.regObj.DoctorInfo.SeeDate = this.regMgr.GetDateTimeFromSysDateTime();
                this.regObj.DoctorInfo.Templet.Begin = DateTime.Parse(this.regObj.DoctorInfo.SeeDate.Date.ToString("yyyy-MM-dd") + " " +
                        this.dtBegin.Value.ToString("HH:mm:ss"));
                this.regObj.DoctorInfo.Templet.End = DateTime.Parse(this.regObj.DoctorInfo.SeeDate.Date.ToString("yyyy-MM-dd") + " " +
                        this.dtEnd.Value.ToString("HH:mm:ss"));

                ///����Һ����ڴ��ڽ���,ΪԤԼ�����յĺ�,���¹Һ�ʱ��
                ///
                if (this.regObj.DoctorInfo.SeeDate.Date < this.dtBookingDate.Value.Date)
                {
                    this.regObj.DoctorInfo.SeeDate = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                        this.dtBegin.Value.ToString("HH:mm:ss"));//�Һ�ʱ��
                    this.regObj.DoctorInfo.Templet.Begin = this.regObj.DoctorInfo.SeeDate;
                    this.regObj.DoctorInfo.Templet.End = DateTime.Parse(this.dtBookingDate.Value.ToString("yyyy-MM-dd") + " " +
                        this.dtEnd.Value.ToString("HH:mm:ss"));//����ʱ��

                    this.regObj.DoctorInfo.Templet.Noon.ID = this.getNoon(this.regObj.DoctorInfo.Templet.Begin);
                }
                else
                {
                    this.regObj.DoctorInfo.Templet.Noon.ID = this.getNoon(this.regObj.DoctorInfo.SeeDate);
                }


                if (this.regObj.DoctorInfo.Templet.Noon.ID == "")
                {
                    MessageBox.Show("δά�������Ϣ,����ά��!", "��ʾ");
                    return -1;
                }
                this.regObj.DoctorInfo.Templet.ID = "";
            }
            #endregion

            if (this.regObj.Pact.PayKind.ID == "03")//���������ж�
            {
                if (this.IsAllowPubReg(this.regObj.PID.CardNO, this.regObj.DoctorInfo.SeeDate) == -1) return -1;
            }

            #region �Һŷ�
            int rtn = ConvertRegFeeToObject(regObj);
            if (rtn == -1)
            {
                MessageBox.Show("��ȡ�Һŷѳ���!" + this.regFeeMgr.Err, "��ʾ");
                this.cmbRegLevel.Focus();
                return -1;
            }
            if (rtn == 1)
            {
                MessageBox.Show("�ùҺż���δά���Һŷ�,����ά���Һŷ�!", "��ʾ");
                this.cmbRegLevel.Focus();
                return -1;
            }

            //��û���Ӧ�ա�����
            ConvertCostToObject(regObj);

            #endregion

            //������
            //  this.regObj.InvoiceNO = this.txtRecipeNo.Text.Trim();
            this.regObj.RecipeNO = this.txtRecipeNo.Text.Trim();


            this.regObj.IsFee = false;
            this.regObj.Status = Neusoft.HISFC.Object.Base.EnumRegisterStatus.Valid;
            this.regObj.IsSee = false;
            this.regObj.InputOper.ID = this.regMgr.Operator.ID;
            this.regObj.InputOper.OperTime = this.regMgr.GetDateTimeFromSysDateTime();
            //add by niuxinyuan
            this.regObj.DoctorInfo.SeeDate = this.regObj.InputOper.OperTime;
            this.regObj.DoctorInfo.Templet.Noon.Name = this.QeryNoonName(this.regObj.DoctorInfo.Templet.Noon.ID);
            // add by niuxinyuan
            this.regObj.CancelOper.ID = "";
            this.regObj.CancelOper.OperTime = DateTime.MinValue;
            ArrayList al = new ArrayList();
            //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
            //al = this.ValidIsSendInhosCase(this.regObj.PID.CardNO);
            //if (al != null && al.Count > 0)
            //{
            //    DialogResult result;
            //    result = MessageBox.Show("���ڴ˲����ŵ�סԺ��¼���Ƿ��򲡰��Ҵ���׼����ȡ������־", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //    if (result == DialogResult.Yes)
            //    {
            //        this.regObj.CaseState = "1";
            //    }
            //    else
            //    {
            //        this.regObj.CaseState = "0";
            //    }
            //}
            //���ܴ���

            if (this.chbEncrpt.Checked)
            {
                this.regObj.IsEncrypt = true;
                this.regObj.NormalName = Neusoft.NFC.Interface.Classes.Function.Encrypt3DES(this.regObj.Name);
                this.regObj.Name = "******";
            }

            this.regObj.IDCard = this.txtIdNO.Text;
            //ҽ��
            //if (this.regObj.Pact.ID == "2")
            //{
            //this.regObj.SIMainInfo = this.myYBregObj.SIMainInfo;

            //}
            return 0;
        }
        #endregion

        #region �ж��Ƿ��ʻ���������ʻ��������ʻ�
        /// <summary>
        /// �ж��Ƿ��ʻ���������ʻ��������ʻ�
        /// </summary>
        /// <returns></returns>
        private int AccountPatient()
        {
            decimal vacancy = 0;
            decimal OwnCostTot = this.regObj.OwnCost;

            string CardType = accountMgr.ExecSqlReturnOne("select type from fin_opb_accountcard a where a.card_no='" + this.regObj.PID.CardNO + "'", "");
            //��ҽͨ���￨�Ƿ����˹����ڿ۳��˻���� wwei_neu  YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
            string ISYYTZF = ctlMgr.QueryControlerInfo("ISZLKZF");

            // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
            //if (cmbPayKind.SelectedItem.ID == "5")
            //{
            //    this.regObj.TranHospCode = this.regObj.PID.CardNO;
            //}
            //by wwei_neu  YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
            if (cmbPayKind.SelectedItem.ID == "5" || (CardType.Equals("3") && ISYYTZF.Equals("1")))
            {
                this.regObj.TranHospCode = this.regObj.PID.CardNO;
            }

            if (string.IsNullOrEmpty(this.regObj.TranHospCode))
            {
                return 1;
            }
            if (this.regObj.DoctorInfo.Templet.RegLevel.ID == "01" && cmbPayKind.SelectedItem.ID == "5")
            {
                if (this.regObj.EcoCost == 0)
                {
                    this.regObj.EcoCost = this.regObj.OwnCost;
                    this.regObj.OwnCost = 0;
                }
            }
            int result = this.feeMgr.GetAccountVacancy(this.regObj.TranHospCode, ref vacancy);
            //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
            if (result < 0)
            {
                MessageBox.Show(this.feeMgr.Err);
                return -1;
            }

            if (result >= 0)//result==0 �Ļ��ǲ������˻��ģ�������ֱ���ԷѴ��� YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
            {   //����ʻ�������0���ԷѴ�����ֱ��������
                if (vacancy == 0 || result == 0)//����result==0�Ĵ������������˻��������ԷѴ��� YYT {22498834-0618-4ef5-BC2B-C08E492AC69E}
                {
                    return 1;
                }
                //if (IsAccountMessage)
                //{
                //    DialogResult diaResult = MessageBox.Show("�Ƿ�ʹ���ʻ�֧����", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //    if (diaResult == DialogResult.No)
                //    {
                //        return 1;
                //    }
                //}
                // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                string cardNo = this.regObj.PID.CardNO;
                this.regObj.PID.CardNO = this.regObj.TranHospCode;
                //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
                //������ 
                if (vacancy < this.regObj.OwnCost)
                {
                    //{DA67A335-E85E-46e1-A672-4DB409BCC11B}
                    //bool returnValue = this.feeMgr.AccountPay(this.regObj.PID.CardNO, vacancy, this.regObj.InvoiceNO, this.regObj.DoctorInfo.Templet.Dept.ID);
                    int returnValue = this.feeMgr.AccountPay(this.regObj, vacancy, this.regObj.InvoiceNO, this.regObj.DoctorInfo.Templet.Dept.ID, "R");
                    {
                        //if (returnValue == false)
                        if (returnValue < 0)
                        {
                            MessageBox.Show(this.feeMgr.Err);
                            return -1;
                        }
                        this.regObj.PayCost = this.regObj.PayCost + vacancy;
                        this.regObj.OwnCost = this.regObj.OwnCost - vacancy;
                        this.regObj.IsAccount = "Y";   //�ʻ�֧�� {C666B232-9973-4e4d-8A89-2F73729B2F28}
                    }
                }
                else //����
                {
                    //bool returnValue = this.feeMgr.AccountPay(this.regObj.PID.CardNO, this.regObj.OwnCost, this.regObj.InvoiceNO, this.regObj.DoctorInfo.Templet.Dept.ID);
                    int returnValue = this.feeMgr.AccountPay(this.regObj, this.regObj.OwnCost, this.regObj.InvoiceNO, this.regObj.DoctorInfo.Templet.Dept.ID, "R");
                    //if (returnValue == false)
                    if (returnValue < 0)
                    {
                        MessageBox.Show(this.feeMgr.Err);
                        return -1;
                    }
                    this.regObj.PayCost = this.regObj.PayCost + this.regObj.OwnCost;
                    this.regObj.OwnCost = 0;
                    this.regObj.IsAccount = "Y";    //�ʻ�֧�� {C666B232-9973-4e4d-8A89-2F73729B2F28}
                }
                // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                this.regObj.PID.CardNO = cardNo;
                //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
            }

            return 1;
        }
        #endregion

        #region У��ҽ������
        /// <summary>
        /// �ж�ҽ��֤���Ƿ��Ѿ�����
        /// </summary>
        /// <param name="pactID"></param>
        /// <param name="mcardNo"></param>
        /// <returns></returns>
        private int validMcardNo(string pactID, string mcardNo)
        {
            //��Ժְ���ж�ҽ��֤���Ƿ񶳽�
            //neusoft.HISFC.Management.Medical.MedicalCard mCardMgr = new neusoft.HISFC.Management.Medical.MedicalCard();

            //if (!mCardMgr.isValidInnerEmployee(pactID, mcardNo))
            //{
            //    MessageBox.Show("��Ժְ��ҽ��֤�ѱ�����,����ʹ��!");
            //    this.cmbPayKind.Focus();
            //    return -1;
            //}

            ////�ж�ҽ��֤�Ƿ���ȫԺ������
            //neusoft.HISFC.Management.Fee.Interface interfaceMgr = new neusoft.HISFC.Management.Fee.Interface();

            //if (interfaceMgr.ExistBlackList(pactID, mcardNo))
            //{
            //    MessageBox.Show("�û���ҽ��֤����Ա��������,���ܹҺ�!");
            //    this.cmbPayKind.Focus();
            //    return -1;
            //}

            return 0;
        }
        #endregion

        #region ���»��߻�����Ϣ
        /// <summary>
        /// ���»��߻�����Ϣ
        /// </summary>
        /// <param name="regInfo"></param>
        /// <param name="patMgr"></param>
        /// <param name="registerMgr"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int UpdatePatientinfo(Neusoft.HISFC.Object.Registration.Register regInfo,
            Neusoft.HISFC.Integrate.RADT patMgr, Neusoft.HISFC.Management.Registration.Register registerMgr,
            ref string Err)
        {
            int rtn = registerMgr.Update(Neusoft.HISFC.Management.Registration.EnumUpdateStatus.PatientInfo,
                                            regInfo);

            if (rtn == -1)
            {
                Err = registerMgr.Err;
                return -1;
            }

            if (rtn == 0)//û�и��µ�������Ϣ������
            {
                Neusoft.HISFC.Object.RADT.PatientInfo p = new Neusoft.HISFC.Object.RADT.PatientInfo();

                p.PID.CardNO = regInfo.PID.CardNO;
                p.Name = regInfo.Name;
                p.Sex.ID = regInfo.Sex.ID;
                p.Birthday = regInfo.Birthday;
                p.Pact = regInfo.Pact;
                p.Pact.PayKind.ID = regInfo.Pact.PayKind.ID;
                p.SSN = regInfo.SSN;
                p.PhoneHome = regInfo.PhoneHome;
                p.AddressHome = regInfo.AddressHome;
                p.IDCard = regInfo.IDCard;
                p.Memo = regInfo.CardType.ID;
                p.NormalName = regInfo.NormalName;
                p.IsEncrypt = regInfo.IsEncrypt;
                p.Profession.ID = regInfo.Profession.ID;//̩����ҽԺ�ֳ��Һ����ӡ�ְҵ��{B51EA52F-ABDF-4aba-B2C8-3A874FB39DBA}
                p.ParentName = regInfo.ParentName;      //{EF076D89-17FE-4922-AC71-3F4D61158505} ���Ӽҳ����� ������20151020

                if (patientMgr.RegisterComPatient(p) == -1)
                {
                    Err = patientMgr.Err;
                    return -1;
                }
            }

            return 0;
        }
        #endregion

        #region ҽ���ӿ�,������
        /*
        /// <summary>
        /// ҽ���ӿ�
        /// </summary>
        /// <param name="reg"></param>
        /// <param name="MedMgr"></param>
        /// <param name="ifeMgr"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int RegSI(neusoft.HISFC.Object.Registration.Register reg,
            MedicareInterface.Class.Clinic MedMgr, neusoft.HISFC.Management.Fee.Interface ifeMgr, ref string Err)
        {
            //����ҽ��
            //if (MedMgr.Connect(reg.Pact.ID) == false)
            //{
            //    Err = MedMgr.ErrMsg;
            //    return -1;
            //}

            ////��ȡҽ���Ǽ���Ϣ
            //if (!MedMgr.Reg(ref reg))
            //{
            //    Err = MedMgr.ErrMsg;
            //    return -1;
            //}

            //���浽����
            //			if( ifeMgr.InsertSIMainInfo(reg) == -1)
            //			{
            //				Err = ifeMgr.Err ;
            //				return -1 ;
            //			}

            //�Ͽ�����
            //if (!MedMgr.DisConnect(reg.Pact.ID))
            //{
            //    Err = MedMgr.ErrMsg;
            //    return -1;
            //}

            return 0;
        }*/

        #endregion

        #region ��֤
        /// <summary>
        /// ��ȡ��Ч���Ű���Ϣ��������
        /// ���Ǵ���Ŀ�б�ѡ����ʱ���,����ֱ������
        /// ����ʱ���
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Registration.Schema GetValidSchema(Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            Neusoft.HISFC.Object.Registration.Schema schema = (Neusoft.HISFC.Object.Registration.Schema)this.dtBookingDate.Tag;
            if (schema != null) return schema;

            DateTime bookingDate = this.dtBookingDate.Value.Date;
            al = null;

            if (level.IsFaculty)//ר�ƺ�
            {
                al = this.SchemaMgr.QueryByDept(bookingDate.Date, this.cmbDept.Tag.ToString());
            }
            else if (level.IsExpert)//ר�Һ�
            {
                al = this.SchemaMgr.QueryByDoct(bookingDate.Date, this.cmbDoctor.Tag.ToString());
            }
            else if (level.IsSpecial)//�����
            {
                al = this.SchemaMgr.QueryByDoct(bookingDate.Date, this.cmbDoctor.Tag.ToString());
            }

            if (al == null || al.Count == 0) return null;

            return this.GetValidSchema(al, level);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="Schemas"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Registration.Schema GetValidSchema(ArrayList Schemas,
            Neusoft.HISFC.Object.Registration.RegLevel level)
        {
            DateTime current = this.SchemaMgr.GetDateTimeFromSysDateTime();
            DateTime begin = this.dtBegin.Value;
            DateTime end = this.dtEnd.Value;

            string currentNoon = this.getNoon(current);

            foreach (Neusoft.HISFC.Object.Registration.Schema obj in Schemas)
            {
                if (obj.SeeDate < current.Date) continue;//С�ڵ�ǰ����

                //ֻ�е��յĲ��ж�ʱ��
                if (obj.SeeDate == current.Date)
                {
                    if (obj.Templet.Begin.TimeOfDay != begin.TimeOfDay) continue;//��ʼʱ�䲻��
                    if (obj.Templet.End.TimeOfDay != end.TimeOfDay) continue;//����ʱ�䲻��
                }

                #region ��Ϊ�������޹Һ�,���Բ�����
                /*
                if(level.IsFaculty || level.IsExpert)
                {
                    if(!obj.Templet.IsAppend && obj.Templet.RegLmt == 0)continue ;//û���趨ԤԼ�޶�				
                    if(!obj.Templet.IsAppend && obj.Templet.RegLmt <= obj.RegedQty) continue;//�����޶�
                }
                else if(level.IsSpecial)
                {
                    if(!obj.Templet.IsAppend && obj.Templet.SpeLmt == 0)continue ;//û���趨ԤԼ�޶�				
                    if(!obj.Templet.IsAppend && obj.Templet.SpeLmt <= obj.SpeReged) continue;//�����޶�
                }*/
                #endregion

                if (!obj.Templet.IsAppend)
                {
                    //
                    //ֻ��������ͬ,���ж�ʱ���Ƿ�ʱ,�������ԤԼ���Ժ�����,ʱ�䲻���ж�
                    //
                    if (current.Date == obj.SeeDate)
                    {
                        if (obj.Templet.End.TimeOfDay < current.TimeOfDay) continue;//ʱ��С�ڵ�ǰʱ��
                    }
                }
                else
                {
                    if (obj.SeeDate.Date == current.Date)//���չҺ�,�ӺŲ���ȫΪ����,����ݵ�ǰʱ���ж�Ӧ�����绹������Ӻ�
                    {
                        if (currentNoon != obj.Templet.Noon.ID) continue;
                    }
                }

                return obj;
            }
            return null;
        }


        /// <summary>
        /// ���ѻ��������ж�
        /// </summary>
        /// <param name="cardNo"></param>
        /// <param name="regDate"></param>
        /// <returns></returns>
        private int IsAllowPubReg(string cardNo, DateTime regDate)
        {
            int num = this.regMgr.QuerySeeNum(cardNo, regDate);
            if (num == -1)
            {
                MessageBox.Show(this.regMgr.Err, "��ʾ");
                return -1;
            }

            if (num >= this.DayRegNumOfPub)
            {
                DialogResult dr = MessageBox.Show("���ѻ��߹Һ�����:" + this.DayRegNumOfPub.ToString() + ", �û����ѹҺ�����:" +
                    num.ToString() + ",�Ƿ����������Һ�?", "��ʾ", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                if (dr == DialogResult.No)
                {
                    this.txtCardNo.Focus();
                    return -1;
                }
            }

            return 0;
        }


        /// <summary>
        /// ���´�����		
        /// </summary>
        /// <param name="Cnt"></param>
        private void UpdateRecipeNo(int Cnt)
        {
            this.txtRecipeNo.Text = Convert.ToString(long.Parse(this.txtRecipeNo.Text.Trim()) + Cnt);
        }
        #endregion

        #region ���¿������
        /// <summary>
        /// ����ȫԺ�������
        /// </summary>
        /// <param name="rMgr"></param>
        /// <param name="current"></param>
        /// <param name="seeNo"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int Update(Neusoft.HISFC.Management.Registration.Register rMgr, DateTime current, ref int seeNo,
            ref string Err)
        {
            //���¿������
            //ȫԺ��ȫ����������������Ч��Ĭ�� 1
            //if (rMgr.UpdateSeeNo("4", current, "ALL", "1") == -1)
            //{
            //    Err = rMgr.Err;
            //    return -1;
            //}

            //��ȡȫԺ�������
            if (rMgr.GetSeeNo("4", current, "ALL", "1", ref seeNo) == -1)
            {
                Err = rMgr.Err;
                return -1;
            }

            return 0;
        }

        /// <summary>
        /// ����ҽ������ҵĿ������
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="doctID"></param>
        /// <param name="noonID"></param>
        /// <param name="regDate"></param>
        /// <param name="seeNo"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int UpdateSeeID(string deptID, string doctID, string noonID, DateTime regDate,
            ref int seeNo, ref string Err)
        {
            string Type = "", Subject = "";

            #region ""

            if (doctID != null && doctID != "")
            {
                Type = "1";//ҽ��
                Subject = doctID;
            }
            else
            {
                Type = "2";//����
                Subject = deptID;
            }

            #endregion

            //���¿������
            if (this.regMgr.UpdateSeeNo(Type, regDate, Subject, noonID) == -1)
            {
                Err = this.regMgr.Err;
                return -1;
            }

            //��ȡ�������		
            if (this.regMgr.GetSeeNo(Type, regDate, Subject, noonID, ref seeNo) == -1)
            {
                Err = this.regMgr.Err;
                return -1;
            }

            return 0;
        }

        #endregion

        #region ���¿����޶�
        /// <summary>
        /// ���¿����޶�
        /// </summary>
        /// <param name="SchMgr"></param>
        /// <param name="regType"></param>
        /// <param name="seeNo"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int UpdateSchema(Neusoft.HISFC.Management.Registration.Schema SchMgr,
            Neusoft.HISFC.Object.Base.EnumRegType regType, ref int seeNo, ref string Err)
        {
            int rtn = 1;
            //�Һż���
            Neusoft.HISFC.Object.Registration.RegLevel level =
                                (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;

            if (regType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)//ԤԼ��,����ԤԼ�޶�
            {
                Neusoft.HISFC.Object.Registration.Booking booking =
                                        (Neusoft.HISFC.Object.Registration.Booking)this.txtOrder.Tag;

                rtn = SchMgr.Increase(booking.DoctorInfo.Templet.ID, false, false, true, false);

                //�ж��޶��Ƿ������Һ�

                if (this.IsPermitOverrun(SchMgr, regType, booking.DoctorInfo.Templet.ID, level, ref seeNo, ref Err) == -1)
                {
                    return -1;
                }
            }
            //else if(regType == neusoft.HISFC.Object.Registration.RegTypeNUM.Reg) 
            else if (level.IsFaculty || level.IsExpert)//ר�ҡ�ר��,�۹Һ��޶�
            {
                rtn = SchMgr.Increase(
                    (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.ID,
                    true, false, false, false);

                //�ж��޶��Ƿ������Һ�

                if (this.IsPermitOverrun(SchMgr, regType, (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.ID,
                                            level, ref seeNo, ref Err) == -1)
                {
                    return -1;
                }
            }
            //else if(regType == neusoft.HISFC.Object.Registration.RegTypeNUM.Spe) 
            else if (level.IsSpecial)//����������޶�
            {
                rtn = SchMgr.Increase(
                    (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.ID,
                    false, false, false, true);

                //�ж��޶��Ƿ������Һ�

                if (this.IsPermitOverrun(SchMgr, regType, (this.dtBookingDate.Tag as Neusoft.HISFC.Object.Registration.Schema).Templet.ID,
                                    level, ref seeNo, ref Err) == -1)
                {
                    return -1;
                }
            }

            if (rtn == -1)
            {
                Err = "�����Ű࿴���޶�ʱ����!" + SchMgr.Err;
                return -1;
            }

            if (rtn == 0)
            {
                Err = "ҽ���Ű���Ϣ�Ѿ��ı�,������ѡ����ʱ��!";
                return -1;
            }

            return 0;
        }
        #endregion

        #region �жϳ����Һ��޶��Ƿ������Һ�
        /// <summary>
        /// �жϳ����Һ��޶��Ƿ������Һ�
        /// </summary>
        /// <param name="schMgr"></param>
        /// <param name="regType"></param>
        /// <param name="schemaID"></param>
        /// <param name="level"></param>
        /// <param name="seeNo"></param>
        /// <param name="Err"></param>
        /// <returns></returns>
        private int IsPermitOverrun(Neusoft.HISFC.Management.Registration.Schema schMgr,
                    Neusoft.HISFC.Object.Base.EnumRegType regType,
                    string schemaID, Neusoft.HISFC.Object.Registration.RegLevel level,
                    ref int seeNo, ref string Err)
        {
            bool isOverrun = false;//�Ƿ񳬶�

            Neusoft.HISFC.Object.Registration.Schema schema = schMgr.GetByID(schemaID);
            if (schema == null || schema.Templet.ID == "")
            {
                Err = "��ѯ�Ű���Ϣ����!" + schMgr.Err;
                return -1;
            }

            if (regType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)//ԤԼ��,�����ж��޶�,��ΪԤԼʱ�Ѿ��ж�
            {
                if (this.IsPreFirst)
                {
                    seeNo = int.Parse(schema.TeledQTY.ToString());
                }
                else
                {
                    //seeNo = int.Parse(Convert.ToString(schema.RegedQty + schema.TelReged + schema.SpeReged)) ;//��õ�ǰʱ���ѿ�����,��Ϊ�������к�
                    seeNo = schema.SeeNO;
                }
            }
            else if (level.IsExpert || level.IsFaculty)//ר�ҡ�ר���ж��޶��Ƿ�����ѹҺ�
            {
                if (schema.Templet.RegQuota - schema.RegedQTY < 0)
                {
                    isOverrun = true;
                }

                if (this.IsPreFirst)
                {
                    //seeNo = int.Parse(Convert.ToString(schema.RegedQty + schema.TelReging + schema.SpeReged)) ;//��õ�ǰʱ���ѿ�����,��Ϊ�������к�
                    seeNo = int.Parse(Convert.ToString(schema.SeeNO + schema.TelingQTY - schema.TeledQTY));
                }
                else
                {
                    //seeNo = int.Parse(Convert.ToString(schema.RegedQty + schema.TelReged + schema.SpeReged)) ;//��õ�ǰʱ���ѿ�����,��Ϊ�������к�
                    seeNo = schema.SeeNO;
                }
            }
            else if (level.IsSpecial)//�����ж������޶��Ƿ񳬱�
            {
                if (schema.Templet.SpeQuota - schema.SpedQTY < 0)
                {
                    isOverrun = true;
                }

                if (this.IsPreFirst)
                {
                    //seeNo = int.Parse(Convert.ToString(schema.RegedQty + schema.TelReging + schema.SpeReged)) ;//��õ�ǰʱ���ѿ�����,��Ϊ�������к�
                    seeNo = int.Parse(Convert.ToString(schema.SeeNO + schema.TelingQTY - schema.TeledQTY));
                }
                else
                {
                    //seeNo = int.Parse(Convert.ToString(schema.RegedQty + schema.TelReged + schema.SpeReged)) ;//��õ�ǰʱ���ѿ�����,��Ϊ�������к�
                    seeNo = schema.SeeNO;
                }
            }

            if (isOverrun)
            {
                //�ӺŲ�����ʾ
                if (schema.Templet.IsAppend) return 0;

                if (!this.IsAllowOverrun)
                {
                    Err = "�Ѿ����������Ű��޶�,���ܹҺ�!";
                    return -1;
                }
                else
                {
                    frmWaitingAnswer f = new frmWaitingAnswer();
                    DialogResult dr = f.ShowDialog();//��ֹ������3���ر�
                    f.Dispose();

                    //DialogResult dr = MessageBox.Show("�Һ����Ѿ����������,�Ƿ����?","��ʾ",MessageBoxButtons.YesNo,
                    //	MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ;

                    //ѡ��No
                    if (dr == DialogResult.No)
                    {
                        return -1;
                    }
                }
            }

            return 0;
        }
        #endregion

        #region ��ӡ�Һ�Ʊ
        /// <summary>
        /// ��ӡ
        /// </summary>
        /// <param name="regObj"></param>
        private void Print(Neusoft.HISFC.Object.Registration.Register regObj, Neusoft.HISFC.Management.Registration.Register regmr)
        {
            #region ����
            /*if( this.PrintWhat == "Invoice")//��ӡ��Ʊ
            {
                this.ucInvoice.Registeration = regObj ;
			
                System.Drawing.Printing.PaperSize size ;

                if( PrintCnt % 2 == 0)
                {
                    size = new System.Drawing.Printing.PaperSize("RegInvoice1", 425 ,288);
                }
                else
                {
                    size = new System.Drawing.Printing.PaperSize("RegInvoice2",425,280) ;
                }

                PrintCnt ++ ;

                printer.SetPageSize(size);
                printer.PrintPage(0,0,ucInvoice) ;
            }
            else//��ӡ����
            {
                //fuck
                neusoft.neuFC.Object.neuObject obj = this.conMgr.Get("PrintRecipe",regObj.RegDept.ID) ;

                //�������ģ�����ӡ
                if( obj == null || obj.ID == "")
                {
                    this.ucBill.Register = regObj ;
					
                    System.Drawing.Printing.PaperSize size = new System.Drawing.Printing.PaperSize("Recipe", 670 ,1120);
                    printer.SetPageSize(size);
                    printer.PrintPage(0,0,this.ucBill) ;
                }
            }*/
            #endregion
            #region by niuxy
            /*
            try
            {
                if (IRegPrint != null)
                {
                    this.IRegPrint.RegInfo = regObj;
                    this.IRegPrint.Print();
                }
            }
            catch { }
             */
            #endregion
            Neusoft.HISFC.Integrate.Registration.IRegPrint regprint = null;
            //{662BE165-070B-4700-9973-93B3C52B33EB} ����ӡDLLָ����ͳһĿ¼�� by jizhr
            regprint = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(), typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint), @"\Plugins\InvoicePrint\") as Neusoft.HISFC.Integrate.Registration.IRegPrint;
            //regprint.SetPrintValue(regObj,regmr);
            if (regObj.IsEncrypt)
            {
                regObj.Name = Neusoft.NFC.Interface.Classes.Function.Decrypt3DES(this.regObj.NormalName);
            }

            regprint.SetPrintValue(regObj);
            regprint.Print();
            //regprint.PrintView();



        }
        #endregion

        #region ����
        /// <summary>
        /// �ش�
        /// </summary>
        private void Reprint()
        {
            string Err = "";

            int row = this.fpList.ActiveRowIndex;

            //			if(row <0 || this.fpList.RowCount == 0) return ;

            Neusoft.HISFC.Object.Registration.Register obj;

            frmModifyRegistration f = new frmModifyRegistration();
            DialogResult dr = f.ShowDialog();

            if (dr != DialogResult.OK) return;
            obj = f.Register;
            f.Dispose();

            //���»�ȡ�Һ���Ϣ
            /*obj = this.regMgr.QueryByClinic(obj.ID) ;

            if( obj == null|| obj.ID == null || obj.ID == "")
            {
                MessageBox.Show(this.regMgr.Err,"��ʾ") ;
                return ;
            }
				
            if(obj.IsValid != neusoft.HISFC.Object.Registration.RegisterStatusNUM.Valid||obj.IsBalance)
            {			
                MessageBox.Show("�ùҺ���Ϣ�Ѿ����ϻ����ս�,�����ش�!","��ʾ") ;
                return ;
            }		*/

            Neusoft.HISFC.Management.Registration.EnumUpdateStatus flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Cancel;
            DateTime current = this.regMgr.GetDateTimeFromSysDateTime();

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(regMgr.con);
            //SQLCA.BeginTransaction();

            try
            {
                this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                //this.SIMgr.SetTrans(SQLCA);
                //this.InterfaceMgr.SetTrans(SQLCA.Trans);
                //this.assMgr.SetTrans(SQLCA.Trans);
                this.patientMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);

                if (obj.InputOper.ID == regMgr.Operator.ID && obj.BalanceOperStat.IsCheck == false)
                {
                    #region ����
                    #endregion
                }
                else
                {
                    #region �˺�
                    Neusoft.HISFC.Object.Registration.Register objReturn = obj.Clone();
                    objReturn.RegLvlFee.ChkFee = -obj.RegLvlFee.ChkFee;//����
                    objReturn.RegLvlFee.OwnDigFee = -obj.RegLvlFee.OwnDigFee;//����
                    objReturn.RegLvlFee.OthFee = -obj.RegLvlFee.OthFee;//������
                    objReturn.RegLvlFee.RegFee = -obj.RegLvlFee.RegFee;//�Һŷ�
                    objReturn.BalanceOperStat.IsCheck = false;//�Ƿ����
                    objReturn.BalanceOperStat.ID = "";
                    objReturn.BalanceOperStat.Oper.ID = "";
                    //objReturn.BeginTime = DateTime.MinValue; 
                    objReturn.CheckOperStat.IsCheck = false;//�Ƿ�˲�
                    objReturn.Status = Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back;//�˺�
                    objReturn.InputOper.OperTime = current;//����ʱ��
                    objReturn.InputOper.ID = regMgr.Operator.ID;//������
                    objReturn.CancelOper.ID = regMgr.Operator.ID;//�˺���
                    objReturn.CancelOper.OperTime = current;//�˺�ʱ��
                    objReturn.OwnCost = -obj.OwnCost;//�Է�
                    objReturn.PayCost = -obj.PayCost;
                    objReturn.PubCost = -obj.PubCost;
                    objReturn.TranType = Neusoft.HISFC.Object.Base.TransTypes.Negative;

                    if (this.regMgr.Insert(objReturn) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.regMgr.Err, "��ʾ");
                        return;
                    }

                    flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Return;
                    #endregion
                }

                obj.CancelOper.ID = regMgr.Operator.ID;
                obj.CancelOper.OperTime = current;

                //����ԭ�з�Ʊ
                int rtn = this.regMgr.Update(flag, obj);
                if (rtn == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return;
                }
                if (rtn == 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺ���Ϣ�Ѿ�����,���ܲ���!", "��ʾ");
                    return;
                }
                //��շ�����Ϣ
                //if (this.assMgr.Delete(obj.ID) == -1)
                //{
                //    SQLCA.RollBack();
                //    MessageBox.Show("ɾ�����߷�����Ϣ����!" + this.assMgr.Err, "��ʾ");
                //    return;
                //}
                //��ȡ�µĴ�����
                obj.CancelOper.ID = "";
                obj.CancelOper.OperTime = DateTime.MinValue;
                obj.InvoiceNO = this.txtRecipeNo.Text.Trim();

                obj.ID = this.regMgr.GetSequence("Registration.Register.ClinicID");
                obj.InputOper.ID = regMgr.Operator.ID;
                obj.InputOper.OperTime = current;

                //ҽ�����ߵǼ�ҽ����Ϣ
                if (obj.Pact.PayKind.ID == "02")
                {
                    //if (this.RegSI(obj, this.SIMgr, this.InterfaceMgr, ref Err) == -1)
                    //{
                    //    SQLCA.RollBack();
                    //    MessageBox.Show(Err, "��ʾ");
                    //    return;
                    //}
                }

                //�Ǽ��µĹҺ���Ϣ
                if (this.regMgr.Insert(obj) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return;
                }

                //���»��߻�����Ϣ
                if (this.UpdatePatientinfo(obj, this.patientMgr, this.regMgr, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return;
                }


                Neusoft.NFC.Management.PublicTrans.Commit();

                //���Ӵ�����,��ֹ����
                this.UpdateRecipeNo(1);
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return;
            }

            this.Print(obj, this.regMgr);

            this.Retrieve();
            this.cmbRegLevel.Focus();
        }
        #endregion

        #region �Ҷ��ź�
        /// <summary>
        /// �Ҷ��ź�
        /// </summary>
        private void MultiReg()
        {

            if (this.valid() == -1)
            {

                return;//��֤��������
            }

            int regNum = 0, rtn = 0;
            string Err = "";


            regNum = this.GetRegNum();
            if (regNum == -1)
            {

                return;
            }

            if (this.getValue() == -1)
            {

                return;
            }
            if (this.regObj.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)
            {

                MessageBox.Show("ԤԼ���߲��ܹҶ��ź�", "��ʾ");
                return;
            }

            if (this.regObj.Pact.PayKind.ID == "02")
            {

                MessageBox.Show("ҽ�����߲������Ҷ��ź�!", "��ʾ");
                return;
            }

            ArrayList alRegs = new ArrayList();

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(regMgr.con);
            //SQLCA.BeginTransaction();

            try
            {
                this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.bookingMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.SchemaMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.patientMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.feeMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);

                //��ǰ����
                DateTime current = this.regMgr.GetDateTimeFromSysDateTime();
                //�Һż���
                Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;
                //�Ű�ʵ��
                Neusoft.HISFC.Object.Registration.Schema schema = new Neusoft.HISFC.Object.Registration.Schema();

                //��һ����,Ϊ������,������Ϊ�Ӻ�,�ۼӺ��Ű��޶�,���û�мӺ��Ű�,��������

                for (int i = 1; i <= regNum; i++)
                {
                    //���˺�һ������2��
                    if (i == 2)//�ӵ�2����ʼ,�޸ĹҺ���ϢΪ�Ӻ�,���Ҷ�����ͬ���Ű���Ϣ���޶�
                    {
                        #region ""
                        this.regObj.RegType = Neusoft.HISFC.Object.Base.EnumRegType.Reg;//�ӺŲ���Ϊ��ԤԼ��
                        //						this.regObj.RegDate = this.regObj.RegDate ;
                        //						this.regObj.BeginTime = this.regObj.BeginTime.Date ;
                        //						this.regObj.EndTime = this.regObj.EndTime.Date ;

                        //��ȥ�յ���
                        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                        //if (this.IsKTF)
                        if (this.otherFeeType == "0")
                        {
                            this.regObj.OwnCost = this.regObj.OwnCost - this.regObj.RegLvlFee.OthFee;
                            this.regObj.RegLvlFee.OthFee = 0;
                        }

                        if (this.MultIsAppend)
                        {
                            this.regObj.DoctorInfo.Templet.IsAppend = true;//�Ӻ�						

                            ///����Һż�����Ҫ�����޶���¼���һ���Ӻ��Ű�ʵ��,��1���Ÿ���ԭ���Ű�ʵ�壬
                            ///��2���Ժ󶼸����µļӺ��Ű�ʵ��
                            ///
                            if (level.IsSpecial || level.IsExpert || level.IsFaculty)
                            {
                                string doctID = this.regObj.DoctorInfo.Templet.Doct.ID;

                                if (doctID == null || doctID == "") doctID = "None";

                                ///
                                ///���˺��Ժ���Ϊ�Ӻ�,�����ȼ���һ���Ӻ�,�Ժ�͸��¸��Ű���Ϣ
                                ///							

                                schema = SchemaMgr.QueryAppend(regObj.DoctorInfo.SeeDate.Date, regObj.DoctorInfo.Templet.Dept.ID,
                                    doctID, regObj.DoctorInfo.Templet.Noon.ID);

                                if (schema == null || schema.Templet.ID == "")
                                {
                                    Neusoft.NFC.Management.PublicTrans.RollBack();
                                    MessageBox.Show("�޼Ӻ��Ű���Ϣ!" + this.SchemaMgr.Err, "��ʾ");
                                    return;
                                }

                                this.regObj.DoctorInfo.Templet.ID = schema.Templet.ID;
                                this.regObj.DoctorInfo.Templet.Begin = schema.Templet.Begin;
                                this.regObj.DoctorInfo.Templet.End = schema.Templet.End;

                                this.SetBookingTag(schema);
                            }
                        }
                        #endregion
                    }

                    #region ���¿������
                    int orderNo = 0;

                    //2�������		
                    if (this.UpdateSeeID(regObj.DoctorInfo.Templet.Dept.ID, regObj.DoctorInfo.Templet.Doct.ID,
                        regObj.DoctorInfo.Templet.Noon.ID, regObj.DoctorInfo.SeeDate, ref orderNo, ref Err) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(Err, "��ʾ");
                        return;
                    }

                    regObj.DoctorInfo.SeeNO = orderNo;
                    //ר�ҡ�ר�ơ����ԤԼ�Ÿ����Ű��޶�
                    #region schema
                    if (this.UpdateSchema(SchemaMgr, regObj.RegType, ref orderNo, ref Err) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        if (Err != "") MessageBox.Show(Err, "��ʾ");
                        return;
                    }

                    regObj.DoctorInfo.SeeNO = orderNo;
                    #endregion

                    //1ȫԺ��ˮ��			
                    if (this.Update(this.regMgr, current, ref orderNo, ref Err) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(Err, "��ʾ");
                        return;
                    }

                    regObj.OrderNO = orderNo;
                    #endregion

                    //ԤԼ�Ÿ����ѿ����־
                    #region booking
                    if (this.regObj.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)
                    {
                        //���¿����޶�
                        rtn = this.bookingMgr.Update((this.txtOrder.Tag as Neusoft.HISFC.Object.Registration.Booking).ID,
                            true, regMgr.Operator.ID, current);
                        if (rtn == -1)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            MessageBox.Show("����ԤԼ������Ϣ����!" + this.bookingMgr.Err, "��ʾ");
                            return;
                        }
                        if (rtn == 0)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            MessageBox.Show("ԤԼ�Һ���Ϣ״̬�Ѿ����,�����¼���!", "��ʾ");
                            return;
                        }
                    }
                    #endregion

                    if (i > 1)
                    {
                        //this.regObj.InvoiceNO = Convert.ToString(long.Parse(this.regObj.InvoiceNO) + 1);//������					
                        this.regObj.RecipeNO = Convert.ToString(long.Parse(this.regObj.RecipeNO) + 1);
                    }

                    #region �ǼǹҺ���Ϣ


                    if (this.GetInvoiceType == 1)
                    {
                        //this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO(Neusoft.HISFC.Object.Fee.EnumInvoiceType.R);
                        this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO("R");
                        if (this.regObj.InvoiceNO == null || this.regObj.InvoiceNO == "")
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            MessageBox.Show("�ò���Աû�п���ʹ�õ�����Һŷ�Ʊ������ȡ");
                            return;
                        }
                    }
                    else if (this.GetInvoiceType == 2)
                    {
                        //this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO(Neusoft.HISFC.Object.Fee.EnumInvoiceType.C);
                        this.regObj.InvoiceNO = this.feeMgr.GetNewInvoiceNO("C");
                        if (this.regObj.InvoiceNO == null || this.regObj.InvoiceNO == "")
                        {
                            MessageBox.Show("�ò���Աû�п���ʹ�õ������շѷ�Ʊ������ȡ");
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            return;
                        }
                    }
                    else
                    {
                        this.regObj.InvoiceNO = "";
                    }

                    if (i != 1) this.regObj.ID = this.regMgr.GetSequence("Registration.Register.ClinicID");
                    if (this.regMgr.Insert(this.regObj) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.regMgr.Err, "��ʾ");
                        return;
                    }
                    #endregion

                    #region ���»�����Ϣ,ֻ����һ��
                    if (i == 1)
                    {
                        if (this.UpdatePatientinfo(this.regObj, this.patientMgr, this.regMgr,
                            ref Err) == -1)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            MessageBox.Show(Err, "��ʾ");
                            return;
                        }
                    }
                    #endregion

                    alRegs.Add(this.regObj.Clone());

                }
                Neusoft.NFC.Management.PublicTrans.Commit();

                //���Ӵ�����,��ֹ����
                this.UpdateRecipeNo(regNum);
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return;
            }

            foreach (Neusoft.HISFC.Object.Registration.Register obj in alRegs)
            {
                this.addRegister(obj);
                this.Print(obj, this.regMgr);
            }

            this.clear();
        }
        /// <summary>
        /// ��ȡ�Һ�����
        /// </summary>
        /// <returns></returns>
        private int GetRegNum()
        {
            int regNum = 0;

            frmMultiReg f = new frmMultiReg();
            DialogResult dr = f.ShowDialog();

            if (dr == DialogResult.OK)
            {
                regNum = f.RegNumber;
                f.Dispose();
                return regNum;
            }
            else
            {
                f.Dispose();
                return -1;
            }
        }
        #endregion

        #region ���޶�
        /// <summary>
        /// ���޶�
        /// </summary>
        /// <returns></returns>
        private int Reduce()
        {
            #region ��֤
            if (this.cmbRegLevel.Tag == null || this.cmbRegLevel.Tag.ToString() == "")
            {
                MessageBox.Show("��ѡ��Һż���!", "��ʾ");
                this.cmbRegLevel.Focus();
                return -2;
            }

            Neusoft.HISFC.Object.Registration.RegLevel level = (Neusoft.HISFC.Object.Registration.RegLevel)this.cmbRegLevel.SelectedItem;

            //������ר�ҺŲ��ܿ��޶�
            if (!(level.IsExpert || level.IsFaculty || level.IsSpecial))
            {
                MessageBox.Show("��ר��/ר�ƺŲ��ܿ��޶�!", "��ʾ");
                this.cmbRegLevel.Focus();
                return -2;
            }

            if ((this.cmbDept.Tag == null || this.cmbDept.Tag.ToString() == ""))
            {
                MessageBox.Show("������Һſ���!", "��ʾ");
                this.cmbDept.Focus();
                return -2;
            }

            if ((level.IsExpert || level.IsSpecial) &&
                (this.cmbDoctor.Tag == null || this.cmbDoctor.Tag.ToString() == ""))
            {
                MessageBox.Show("ר�Һű���ָ������ҽ��!", "��ʾ");
                this.cmbDoctor.Focus();
                return -2;
            }

            Neusoft.HISFC.Object.Registration.Schema schema;//�Ű�ʵ��

            //��ѯ�����������Ű���Ϣ
            schema = this.GetValidSchema(level);
            if (schema == null)
            {
                MessageBox.Show("ԤԼʱ��ָ������,û�з����������Ű���Ϣ!", "��ʾ");
                this.dtBookingDate.Focus();
                return -2;
            }
            this.SetBookingTag(schema);

            #endregion

            int seeNo = 0;

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(regMgr.con);
            //SQLCA.BeginTransaction();

            try
            {
                this.SchemaMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);

                string Err = "";

                #region ���¿������

                //��ȡ�������
                string noon = schema.Templet.Noon.ID;//���

                if (this.UpdateSeeID(this.cmbDept.Tag.ToString(), this.cmbDoctor.Tag.ToString(), noon, this.dtBookingDate.Value.Date,
                    ref seeNo, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                #endregion

                Neusoft.HISFC.Object.Base.EnumRegType regType = Neusoft.HISFC.Object.Base.EnumRegType.Reg;
                //��Ϊ��˵����ԤԼ��
                if (this.txtOrder.Tag != null)
                {
                    regType = Neusoft.HISFC.Object.Base.EnumRegType.Pre;
                }
                else if (level.IsSpecial)
                {
                    regType = Neusoft.HISFC.Object.Base.EnumRegType.Spe;
                }

                //�����Ű��޶�
                if (this.UpdateSchema(this.SchemaMgr, regType, ref seeNo, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    if (Err != "") MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                //��ȡȫԺ�������
                int i = 0;

                if (this.Update(this.regMgr, this.regMgr.GetDateTimeFromSysDateTime(), ref i, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                Neusoft.NFC.Management.PublicTrans.Commit();

            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return -1;
            }

            string Msg = "";

            Msg = "[" + seeNo.ToString() + "]";

            MessageBox.Show("���³ɹ�! ��ˮ��Ϊ:" + Msg, "��ʾ");
            this.clear();

            return 0;
        }
        #endregion

        #region �ݴ滼�߻�����Ϣ
        /// <summary>
        /// ���滼����Ϣ
        /// </summary>
        /// <returns></returns>
        private int SavePatient()
        {
            #region ��֤
            if (this.regObj == null)
            {
                MessageBox.Show("��¼��ҺŻ���!", "��ʾ");
                this.txtCardNo.Focus();
                return -1;
            }

            if (this.txtName.Text.Trim() == "")
            {
                MessageBox.Show("�����뻼������!", "��ʾ");
                this.txtName.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtName.Text.Trim(), 40) == false)
            {
                MessageBox.Show("������������¼��20������!", "��ʾ");
                this.txtName.Focus();
                return -1;
            }

            if (this.cmbSex.Tag == null || this.cmbSex.Tag.ToString() == "")
            {
                MessageBox.Show("��ѡ�����Ա�!", "��ʾ");
                this.cmbSex.Focus();
                return -1;
            }

            if (this.cmbPayKind.Tag == null || this.cmbPayKind.Tag.ToString() == "")
            {
                MessageBox.Show("���߽��������Ϊ��!", "��ʾ");
                this.cmbPayKind.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtPhone.Text.Trim(), 20) == false)
            {
                MessageBox.Show("��ϵ�绰����¼��20λ����!", "��ʾ");
                this.txtPhone.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtAddress.Text.Trim(), 60) == false)
            {
                MessageBox.Show("��ϵ�˵�ַ����¼��30������!", "��ʾ");
                this.txtAddress.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtMcardNo.Text.Trim(), 30) == false)
            {
                MessageBox.Show("ҽ��֤������¼��30λ����!", "��ʾ");
                this.txtMcardNo.Focus();
                return -1;
            }

            if (Neusoft.NFC.Public.String.ValidMaxLengh(this.txtAge.Text.Trim(), 3) == false)
            {
                MessageBox.Show("��������¼��3λ����!", "��ʾ");
                this.txtAge.Focus();
                return -1;
            }

            if (this.txtAge.Text.Trim().Length > 0)
            {
                try
                {
                    int age = int.Parse(this.txtAge.Text.Trim());
                    if (age <= 0)
                    {
                        MessageBox.Show("���䲻��Ϊ����!", "��ʾ");
                        this.txtAge.Focus();
                        return -1;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("����¼���ʽ����ȷ!" + e.Message, "��ʾ");
                    this.txtAge.Focus();
                    return -1;
                }
            }
            #endregion

            this.regObj.Name = this.txtName.Text.Trim();//�������� 
            this.regObj.Sex.ID = this.cmbSex.Tag.ToString();//�Ա�
            this.regObj.Birthday = this.dtBirthday.Value;//��������
            this.regObj.Pact.ID = this.cmbPayKind.Tag.ToString();
            this.regObj.Profession.ID = this.cmbProfession.Tag.ToString();//̩����ҽԺ�ֳ��Һ����ӡ�ְҵ��{B51EA52F-ABDF-4aba-B2C8-3A874FB39DBA}
            Neusoft.HISFC.Object.Base.PactInfo pact = conMgr.GetPactUnitInfoByPactCode(this.regObj.Pact.ID);
            if (pact == null || pact.ID == "")
            {
                MessageBox.Show("��ȡ����Ϊ:" + this.regObj.Pact.ID + "�ĺ�ͬ��λ��Ϣ����!" + conMgr.Err, "��ʾ");
                return -1;
            }

            this.regObj.Pact.Name = pact.Name;
            this.regObj.Pact.PayKind = pact.PayKind;
            this.regObj.SSN = this.txtMcardNo.Text.Trim();
            this.regObj.PhoneHome = this.txtPhone.Text.Trim();
            this.regObj.AddressHome = this.txtAddress.Text.Trim();
            //{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}
            this.regObj.IDCard = this.txtIdNO.Text;
            if (this.cmbCardType.Tag != null)
            {
                this.regObj.CardType.ID = this.cmbCardType.Tag.ToString();
            }
            else
            {
                this.regObj.CardType.ID = "";
            }
            if (this.chbEncrpt.Checked)
            {

                this.regObj.NormalName = Neusoft.NFC.Interface.Classes.Function.Encrypt3DES(this.regObj.Name);
                this.regObj.IsEncrypt = true;
                this.regObj.Name = "******";
            }

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(regMgr.con);
            //SQLCA.BeginTransaction();

            string Err = "";
            try
            {
                this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.patientMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);

                if (this.UpdatePatientinfo(regObj, this.patientMgr, this.regMgr, ref Err) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(Err, "��ʾ");
                    return -1;
                }

                Neusoft.NFC.Management.PublicTrans.Commit();
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show(e.Message, "��ʾ");
                return -1;
            }

            MessageBox.Show("�ݴ�ɹ�!", "��ʾ");
            this.clear();

            return 0;
        }
        #endregion

        /// <summary>
        /// �ӿڳ�ʼ�� {E43E0363-0B22-4d2a-A56A-455CFB7CF211}
        /// </summary>
        protected virtual int InitInterface()
        {
            this.iProcessRegiter = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(),
                typeof(Neusoft.HISFC.Management.Interface.Registration.IProcessRegiter)) as Neusoft.HISFC.Management.Interface.Registration.IProcessRegiter;

            return 1;
        }

        /// <summary>
        /// ���㴰��{F0661633-4754-4758-B683-CB0DC983922B}
        /// </summary>
        /// <returns></returns>
        protected virtual int ShowChangeForm(Neusoft.HISFC.Object.Registration.Register regObj)
        {
            frmOpen.RegObj = regObj;//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
            DialogResult r = frmOpen.ShowDialog();

            //{C57BE0DB-CE4C-47dd-8879-17442C1BEA71} ԭ��ֱ�� return 1 ������Ҫ�����㴰��ȡ��ʱҪ���Զ��˺�
            if (r == DialogResult.OK)
            {
               
                return 1;
            }
            else 
            {
                return -1;
            }

            //return 1;
        }

        #region {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        void frmOpen_BackCost(object sender, Neusoft.HISFC.Integrate.FeeInterface.ReturnCostEvent e)
        {
            ShowOperationInformation(this.regObj, e.RealCost);
        }
        #endregion
        #endregion

        #region �¼�
        /// <summary>
        /// ��ݼ�
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessDialogKey(Keys keyData)
        {
            /*if (keyData == Keys.F12)
            {
                if (this.save() == -1)
                {
                    this.cmbRegLevel.Focus();
                }
                return true;
            }
            else if (keyData == Keys.F3)
            {
                if (this.Reduce() == -1)
                {
                    this.cmbRegLevel.Focus();
                }
                return true;
            }
            else if (keyData == Keys.F8)
            {
                this.clear();

                return true;
            }
            else if (keyData.GetHashCode() == Keys.Alt.GetHashCode() + Keys.X.GetHashCode())
            {
                this.FindForm().Close();
                return true;
            }
            if (keyData == Keys.F11)
            {
                this.txtOrder.Focus();
                return true;
            }
            else*/
            if (keyData == Keys.Escape)
            {
                #region ""
                bool IsSelect = false;

                if (this.ucChooseDate.Visible)
                {
                    IsSelect = true;
                    this.ucChooseDate.Visible = false;
                    this.dtBookingDate.Focus();
                }

                if (!IsSelect)//���ʲô��û��ʾ��Esc�رմ���
                {
                    this.FindForm().Close();
                }

                #endregion
                return true;
            }
            /*else if (keyData.GetHashCode() == Keys.Alt.GetHashCode() + Keys.P.GetHashCode())
            {
                this.Reprint();
                return true;
            }
            else if (keyData == Keys.F4)
            {
                this.MultiReg();

                return true;
            }
            else if (keyData == Keys.F5)
            {
                System.Diagnostics.Process.Start("CALC.EXE");
                return true;
            }
            else if (keyData == Keys.F6)
            {
                SavePatient();

                return true;
            }
            else if (keyData == Keys.F10)
            {
                this.cmbRegLevel.Focus();

                return true;
            }
            else if (keyData == Keys.F1)
            {
                this.AutoGetCardNO();
                this.txtCardNo.Focus();
            }*/

            return base.ProcessDialogKey(keyData);
        }
        /// <summary>
        /// ���õ�ǰ��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fpSpread1_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader || this.fpList.RowCount == 0) return;
            this.fpList.ActiveRowIndex = e.Row;
        }
        #endregion

        #region IInterfaceContainer ��Ա

        Type[] Neusoft.NFC.Interface.Forms.IInterfaceContainer.InterfaceTypes
        {
            get
            {
                Type[] type = new Type[3];//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
                type[0] = typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint);
                //{E43E0363-0B22-4d2a-A56A-455CFB7CF211}
                type[1] = typeof(Neusoft.HISFC.Management.Interface.Registration.IProcessRegiter);
                type[2] = typeof(Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
                return type;
            }
        }

        #endregion

        #region �˵�
        private Neusoft.NFC.Interface.Forms.ToolBarService toolBarService = new Neusoft.NFC.Interface.Forms.ToolBarService();

        protected override Neusoft.NFC.Interface.Forms.ToolBarService OnInit(object sender, object neuObject, object param)
        {
            //toolBarService.AddToolButton("����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A����, true, false, null);
            toolBarService.AddToolButton("���ź�", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A����, true, false, null);
            toolBarService.AddToolButton("���޶�", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.N�ֽ�, true, false, null);
            toolBarService.AddToolButton("�Ĵ�����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A�޸�, true, false, null);
            toolBarService.AddToolButton("�ݴ�", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A�ݴ�, true, false, null);
            toolBarService.AddToolButton("����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A���, true, false, null);
            toolBarService.AddToolButton("����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.F�ش�, true, false, null);
            toolBarService.AddToolButton("���ɿ���", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.AȨ��, true, false, null);
            toolBarService.AddToolButton("POS�Һ�", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.Fȷ���շ�, true, false, null);
            toolBarService.AddToolButton("����֤����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A�˿�, true, false, null);

            //�����ӽ����� {076EDB89-7370-45b1-B7AE-3D28BF1A4220} ���ӽ����� jit 2020.07.31
            toolBarService.AddToolButton("���ӽ�����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A��Ա, true, false, null);

            return toolBarService;
        }

        protected override int OnSave(object sender, object neuObject)
        {
            int ret = 0;
            //ret = this.save(false);{D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2} 
            ret = this.SaveByControl(false);
            if (ret == -1)
            {
                this.cmbRegLevel.Focus();
            }
            return ret;
        }

        public override void ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Text)
            {
                //case "����":
                //    if (this.save() == -1)
                //    {
                //        this.cmbRegLevel.Focus();
                //    }
                //    break;
                case "���ź�":
                    this.MultiReg();
                    break;
                case "���޶�":
                    if (this.Reduce() == -1)
                    {
                        this.cmbRegLevel.Focus();
                    }
                    break;
                case "�Ĵ�����":
                    this.ChangeRecipe();
                    break;
                case "�ݴ�":
                    SavePatient();
                    break;
                case "����":
                    clear();
                    break;
                case "����":
                    Reprint();
                    break;
                case "���ɿ���":
                    this.AutoGetCardNO();
                    break;
                case "POS�Һ�":
                    {
                        //this.save(true);{D680D7FA-B0BA-4b6f-A9D1-FCCDF35C0CE2}
                        this.SaveByControl(true);
                        break;
                    }
                case "����֤����":
                    {
                        ReadIDCard();
                        break;
                    }
                //�����ӽ����� {076EDB89-7370-45b1-B7AE-3D28BF1A4220} ���ӽ����� jit 2020.07.31
                case "���ӽ�����":
                    {
                        ReadHealthCard();
                        break;
                    }
            }

            base.ToolStrip_ItemClicked(sender, e);
        }
        #endregion

        #region //ҽ���ӿ�
        #region ISIReadCard ��Ա
        /// <summary>
        /// ͨ��toolBar�Ķ��������ӿ�{CF8F2474-6ECC-4bd7-BAEE-1E67EED39D54} by jizhr
        /// </summary>
        /// <param name="pactCode">��ͬ��λ����</param>
        /// <returns>�ɹ� 1 ʧ�� ��1</returns>
        public int ReadCard(string pactCode)
        {
            this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            return ReadCard(pactCode, null);

        }
        /// <summary>
        /// ͨ��toolBar�Ķ��������ӿ�{CF8F2474-6ECC-4bd7-BAEE-1E67EED39D54} by jizhr
        /// </summary>
        /// <param name="pactCode">��ͬ��λ����</param>
        /// <param name="cardStr">����Ϣ</param>
        /// <returns>�ɹ� 1 ʧ�� ��1</returns>
        public int ReadCard(string pactCode, string cardStr)
        {
            long returnValue = 0;
            Neusoft.HISFC.Integrate.RADT radt = new Neusoft.HISFC.Integrate.RADT();
            regObj = new Neusoft.HISFC.Object.Registration.Register();
            #region �����Ϻ�ҽ�����ͽ϶࣬�ڵ��������ťʱ����ȷ��ҽ�����ͣ�ֻ����д�� add by lcf 2010-03-15
            if (string.IsNullOrEmpty(cardStr))
            {
                if (pactCode == "999999" || pactCode == "999998")
                {
                    if (pactCode == "999999")
                    {
                        regObj.SiCardType = "0";  //�ſ�
                    }
                    else
                    {
                        regObj.SiCardType = "1";   //���Ͽ�
                    }
                    pactCode = "2";   //�������ýӿ�Ĭ��Ϊ��ͨҽ��
                }
            }
            else
            {
                regObj.SiCardType = "0";  //�ſ�
                regObj.Card.User03 = cardStr;
                pactCode = "2";   //�������ýӿ�Ĭ��Ϊ��ͨҽ��
            }
            #endregion
            //{04102034-382D-488e-BC45-F5B8CDBDE70D}
            regObj.Pact.ID = pactCode;


            returnValue = this.MedcareInterfaceProxy.SetPactCode(pactCode);
            if (returnValue != 1)
            {
                MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                // {DBCB798D-2F21-449e-BBE7-8F95E0F08B8A}
                if (this.MedcareInterfaceProxy.Rollback() < 0)
                {
                    MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                    return -1;
                }

                return -1;
            }

            returnValue = this.MedcareInterfaceProxy.Connect();
            if (returnValue != 1)
            {
                MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                // {DBCB798D-2F21-449e-BBE7-8F95E0F08B8A}
                if (this.MedcareInterfaceProxy.Rollback() < 0)
                {
                    MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                return -1;
            }

            returnValue = this.MedcareInterfaceProxy.GetRegInfoOutpatient(this.regObj);
            if (returnValue != 1)
            {
                MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                // {DBCB798D-2F21-449e-BBE7-8F95E0F08B8A}
                if (this.MedcareInterfaceProxy.Rollback() < 0)
                {
                    MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                return -1;
            }

            returnValue = this.MedcareInterfaceProxy.Disconnect();
            if (returnValue != 1)
            {
                MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                // {DBCB798D-2F21-449e-BBE7-8F95E0F08B8A}
                if (this.MedcareInterfaceProxy.Rollback() < 0)
                {
                    MessageBox.Show(this.MedcareInterfaceProxy.ErrMsg);
                    return -1;
                }

                return -1;
            }

            Neusoft.HISFC.Object.RADT.PatientInfo p = null;
            p = radt.QueryOutComPatientInfoByMcardNO(this.regObj.SSN);
            if (p == null)
            {
                p = radt.QueryComPatientInfoByIDNO(this.regObj.IDCard);
            }

            if (p != null)
            {
                this.regObj.PID.CardNO = p.PID.CardNO;
                this.regObj.PhoneHome = p.PhoneHome;
                this.regObj.AddressHome = p.AddressHome;
                //{7D7EFA68-08CD-4005-BACE-8EBD9FEB3481} by ��ΰ  ������Ϣ�����в��˵���Ϣ���ٴ���ˢ�ſ�ʱ�Զ���ʾ�����ź�����֤
                this.regObj.IDCard = p.IDCard;
                this.regObj.Sex = p.Sex;
            }
            this.regObj.User01 = "1";
            // this.regObj = myYBregObj;

            this.SetSIPatientInfo();
            this.SetEnabled(false);
            this.isReadCard = true;
            //this.registerControl.SetRegInfo();
            this.Cursor = System.Windows.Forms.Cursors.Default;
            if (string.IsNullOrEmpty(this.txtCardNo.Text.Trim()))//{77A61D01-A154-42a8-B4D6-78850E94BE23} minqsh 20150929 add��û�������ʱ������ý���
            {
                this.txtCardNo.Focus();
            }
            return 1;
        }

        public void ReadIDCard()
        {
            string errMsg = string.Empty;
            IDCardInfo idCard = new IDCardInfo();
            Neusoft.HISFC.Object.Registration.Register regInfo = new Neusoft.HISFC.Object.Registration.Register();
            regInfo = idCard.GetIDCardInfo(ref errMsg);
            if (string.IsNullOrEmpty(errMsg))
            {
                if (regInfo != null && !string.IsNullOrEmpty(regInfo.IDCard))
                {
                    if (patientMgr.IsHasCardNo(regInfo.IDCard)) //�ж��Ƿ�Ϊ�Է��ϻ��� //{EE98DEFE-0097-4757-84AA-62D96299EB82} add by caokai 2018/11/9
                    {
                        this.SetPatient(patientMgr.GetCardNoByIdNo(regInfo.IDCard)); //���Ϊ�Է��ϻ���,��ȡ������Ϣ����ֵ
                    }
                    else
                    {
                        this.SetPatientInfoByIDCard(regInfo); //���Ϊ�»��߶�ȡ����֤��Ϣ����ֵ
                        this.AutoGetCardNO();//�Զ����ɲ�����
                        this.SetEnabled(false);//���ÿؼ�����
                    }
                }
            }
            else
                MessageBox.Show(errMsg);
        }


        //�����ӽ����� {076EDB89-7370-45b1-B7AE-3D28BF1A4220} ���ӽ����� jit 2020.07.31
        public void ReadHealthCard()
        {
            HealthCard.Process healCardService = new HealthCard.Process();

            HealthCard.Models.UserInfo hearCardInfo = new HealthCard.Models.UserInfo();

            hearCardInfo = healCardService.GetPatientInfoByAnalysisQrCode("", "1");

            if (hearCardInfo == null)
            {
                if (!string.IsNullOrEmpty(healCardService.Err))
                {
                    MessageBox.Show(healCardService.Err);
                }
                return;
            }


            string errMsg = string.Empty;
  
            Neusoft.HISFC.Object.Registration.Register regInfo = new Neusoft.HISFC.Object.Registration.Register();

            regInfo.Name = hearCardInfo.realname;
            regInfo.Sex.ID = hearCardInfo.gender == "0" ? "F" : "M";
            regInfo.IDCard = hearCardInfo.idNumber;

            if (regInfo.IDCard.Length == 18)
            {
                regInfo.Birthday = Convert.ToDateTime(regInfo.IDCard.Substring(6, 4) + "-" + regInfo.IDCard.Substring(10, 2) + "-" + regInfo.IDCard.Substring(12, 2));
            }
            else if (regInfo.IDCard.Length == 15)
            {
                regInfo.Birthday = Convert.ToDateTime("19" + regInfo.IDCard.Substring(6, 2) + "-" + regInfo.IDCard.Substring(8, 2) + "-" + regInfo.IDCard.Substring(10, 2));
            }

            if (regInfo != null && !string.IsNullOrEmpty(regInfo.IDCard))
            {
                if (patientMgr.IsHasCardNo(regInfo.IDCard)) //�ж��Ƿ�Ϊ�Է��ϻ��� //{EE98DEFE-0097-4757-84AA-62D96299EB82} add by caokai 2018/11/9
                {
                    this.SetPatient(patientMgr.GetCardNoByIdNo(regInfo.IDCard)); //���Ϊ�Է��ϻ���,��ȡ������Ϣ����ֵ
                }
                else
                {
                    this.SetPatientInfoByIDCard(regInfo); //���Ϊ�»��߶�ȡ����֤��Ϣ����ֵ
                    this.AutoGetCardNO();//�Զ����ɲ�����
                    this.SetEnabled(false);//���ÿؼ�����
                }
           }
        }

        /// <summary>
        /// ���ý��滼�߻�����Ϣ
        /// </summary>
        /// <returns>�ɹ� 1 ʧ�� ��1</returns>
        public int SetSIPatientInfo()
        {
            this.txtCardNo.Text = (this.regObj.PID.CardNO ?? "").Trim();
            if (this.regObj.Name != null && this.regObj.Name.Trim().IndexOf(' ') > 0)
            {
                this.regObj.Name = this.regObj.Name.Trim().Substring(0, this.regObj.Name.Trim().IndexOf(' '));
            }

            this.txtName.Text = this.regObj.Name.Trim();
            this.cmbSex.Tag = (this.regObj.Sex.ID ?? "").ToString().Trim();
            this.cmbPayKind.Tag = (this.regObj.Pact.ID ?? "").Trim();
            this.txtMcardNo.Text = (this.regObj.SSN ?? "").Trim();
            ////{21D8C03B-9552-4c1f-9B3D-CF5A710972D0} by jizhr //{77A61D01-A154-42a8-B4D6-78850E94BE23} minqsh 20150929 ���Σ���Ĭ��ʹ��ҽ�����ţ�ʹ������
            //if (this.txtCardNo.Text.Length == 0 && this.txtMcardNo.Text.Length > 0)
            //{
            //    if (this.txtMcardNo.Text.Length == 9 && !char.IsNumber(this.txtMcardNo.Text, 0)) //���Ͽ�
            //    {
            //        this.txtCardNo.Text = this.txtMcardNo.Text.PadLeft(10, '0');
            //        this.txtCardNo.Focus();

            //        SendKeys.Send("{ENTER}");               //{6EB5DA57-E8B6-4ccd-A465-262D33FCBD8C}
            //    }
            //}
            this.txtPhone.Text = this.regObj.PhoneHome;
            this.txtAddress.Text = this.regObj.AddressHome;
            //{78137DF2-F953-4d8c-BF9E-670F6B45D0CC}  by jizhr
            if (!string.IsNullOrEmpty(this.regObj.IDCard))
            {
                this.txtIdNO.Text = this.regObj.IDCard;
                string idCard = this.regObj.IDCard;
                if (idCard.Length == 15)
                {
                    idCard = Neusoft.NFC.Interface.Classes.Function.TransIDFrom15To18(idCard);
                }
                try
                {
                    this.regObj.Birthday = new DateTime(int.Parse(idCard.Substring(6, 4)), int.Parse(idCard.Substring(10, 2)), int.Parse(idCard.Substring(12, 2)));
                }
                catch
                {
                    //this.regObj.Birthday = DateTime.MinValue;
                }
            }
            //end {78137DF2-F953-4d8c-BF9E-670F6B45D0CC}

            if (this.regObj.Birthday != DateTime.MinValue)
                this.dtBirthday.Value = this.regObj.Birthday;

            this.cmbCardType.Tag = this.regObj.CardType.ID;

            //{54603DD0-3484-4dba-B88A-B89F2F59EA40}
            if (this.isShowSIBalanceCost == true)
            {
                this.tbSIBalanceCost.Text = this.regObj.SIMainInfo.IndividualBalance.ToString();
            }

            this.setAge(this.regObj.Birthday);
            this.getCost();
            return 1;
        }
        /// <summary>
        /// �Ƿ����
        /// </summary>
        /// <param name="Value"></param>
        /// <returns></returns>
        public int SetEnabled(bool Value)
        {
            //this.txtCardNo.Enabled = Value;
            this.txtName.Enabled = Value;
            //this.cmbSex.Enabled = Value;
            this.txtMcardNo.Enabled = Value;
            //{882709E9-8319-4409-B488-F9F729CD7FAC} ע�͵�
            ////�Ϻ�ҽ���޸ģ���Ϊ�Ϻ�ҽ���еĲ��˿���ѡ��ͬ�ĺ�ͬ��λ����  add by lcf 2010.03.18
            //if (this.cmbPayKind.Tag.ToString().Length > 0)
            //{
            //    this.cmbPayKind.Enabled = Value;
            //}
            //this.dtBirthday.Enabled = Value;
            this.txtAge.Enabled = Value;
            this.cmbUnit.Enabled = Value;
            return 1;
        }

        /// <summary>
        /// �����߸�����Ϣ��ֵ������
        /// </summary>
        /// <param name="MarkNo">��λ�����������</param>
        /// <param name="cardNo">��λ��߲�����</param>
        /// <returns></returns>
        public int SetPatient(string cardNo)
        {
            try
            {
                if (!string.IsNullOrEmpty(cardNo))
                {
                    this.txtCardNo.Text = cardNo;
                    this.txtCardNo_KeyDown(null, new KeyEventArgs(Keys.Enter));
                    if (string.IsNullOrEmpty(this.txtName.Text.Trim()))
                    {
                        return -1;
                    }
                }
                else
                {
                    return -1;
                }
            }
            catch (Exception ex)
            {
                return -1;
            }
            return 1;
        }

        /// <summary>
        /// ����֤���������ý��滼�߻�����Ϣ
        /// </summary>
        /// <param name="regObj"></param>
        /// <returns></returns>
        public int SetPatientInfoByIDCard(Neusoft.HISFC.Object.Registration.Register regObj)
        {
            this.txtName.Text = regObj.Name.Trim();
            this.cmbSex.Tag = regObj.Sex.ID;
            this.cmbPayKind.Tag = regObj.Pact.ID;
            this.txtMcardNo.Text = regObj.SSN;
            this.txtPhone.Text = regObj.PhoneHome;
            this.txtAddress.Text = regObj.AddressHome;
            this.txtIdNO.Text = regObj.IDCard;
            this.dtBirthday.Value = regObj.Birthday;
            this.cmbCardType.Tag = regObj.CardType.ID;
            this.setAge(regObj.Birthday);
            //this.getCost();
            return 1;
        }
        #endregion

        private void cmbRegLevel_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
        #endregion

        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
        private void chbBookFee_CheckedChanged(object sender, EventArgs e)
        {
            //��ϴ�Һŷ�
            this.getCost();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        //{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}����֤��Ϣ
        private void txtIdNO_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            string idNO = txtIdNO.Text.Trim();
            if (!string.IsNullOrEmpty(idNO))
            {
                int returnValue = this.ProcessIDENNO(idNO, EnumCheckIDNOType.BeforeSave);
                if (returnValue < 0)
                {
                    return;
                }

            }
            else
            {
                this.setNextControlFocus();
                //this.cmbSex.Focus();
            }
        }

        private int ProcessIDENNO(string idNO, EnumCheckIDNOType enumType)
        {
            string errText = string.Empty;
            //string idNOTmp = Neusoft.NFC.Interface.Classes.Function.TransIDFrom15To18(idNO);
            //{2FA2A5D4-2796-4bec-AED2-2A7C98A8BFF0}
            //string idNOTmp = Neusoft.NFC.Interface.Classes.Function.TransIDFrom15To18(idNO);
            string idNOTmp = string.Empty;
            if (idNO.Length == 15)
            {
                idNOTmp = Neusoft.NFC.Interface.Classes.Function.TransIDFrom15To18(idNO);
            }
            else
            {
                idNOTmp = idNO;
            }
            //У������֤��
            int returnValue = Neusoft.NFC.Interface.Classes.Function.CheckIDInfo(idNOTmp, ref errText);

            if (returnValue < 0)
            {
                MessageBox.Show(errText);
                this.txtIdNO.Focus();
                return -1;
            }
            string[] reurnString = errText.Split(',');
            if (enumType == EnumCheckIDNOType.BeforeSave)
            {
                this.dtBirthday.Text = reurnString[1];
                this.cmbSex.Text = reurnString[2];
                this.setAge(this.dtBirthday.Value);
                this.cmbPayKind.Focus();
            }
            else
            {
                if (this.dtBirthday.Text != reurnString[1])
                {
                    MessageBox.Show("�������������������֤�кŵ����ղ���");
                    this.dtBirthday.Focus();
                    return -1;
                }

                if (this.cmbSex.Text != reurnString[2])
                {
                    MessageBox.Show("������Ա�������֤�кŵ��Ա𲻷�");
                    this.cmbSex.Focus();
                    return -1;
                }
            }
            return 1;
        }
        #region �Ϻ����ӣ�ҽ������Ϣ¼�� add by feng.ch{2B6167F7-339B-4f09-9af6-C5CD6Agg3AC89}
        /// <summary>
        /// ȡ�󲡵Ǽ���Ϣ
        /// </summary>
        //private int SIBigSickGetInfo()
        //{
        //    if (this.txtMcardNo.Text == "")
        //    {
        //        MessageBox.Show("ֻ��ҽ�����߿���ʹ�ô󲡺ţ�����û�ж�ȡҽ����Ϣ��");
        //        this.clear();
        //        return -1;
        //    }
        //    this.regObj = new Neusoft.HISFC.Object.Registration.Register();
        //    regObj = this.regMgr.SelectSiBigSickInfo(this.txtMcardNo.Text);
        //    this.siBigSickBeginTime = regObj.SiBigSick.MyBeginDate;        //��ʼʱ��
        //    this.siBigSickEndTime = regObj.SiBigSick.MyEndDate;            //����ʱ��
        //    this.siBigSickItem = regObj.SiBigSick.ItemId;                  //ҽ������ĿID
        //    this.siBigSickDignose = regObj.SiBigSick.DignoseId;            //ҽ�������ID
        //    this.siBigSickDignoseName =regObj.SiBigSick.DignoseName;    //ҽ�����������
        //    this.siBigSickItemName = regObj.SiBigSick.ItemName;          //ҽ������Ŀ����
        //    this.priveNo = regObj.SiBigSick.PriveNo;                     //ƾ֤��
        //    //this.lbSiInformation.Visible = true;
        //    //this.lbSiInformation.Text = "ҽ������Ŀ��Ϊ:" + this.siBigSickItem + ",�����Ϊ:" + this.siBigSickDignose +
        //    //    "��Чʱ��:" + this.siBigSickBeginTime + "��" + this.siBigSickEndTime;
        //    if (this.priveNo == "")
        //    {
        //        MessageBox.Show("����ҽ������Ϣû�еǼǣ���Ǽǣ�");
        //        this.clear();
        //        return -1;
        //    }
        //    return 1;

        //}
        #endregion
        ////{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}����֤��Ϣ
        private void dtBirthday_ValueChanged(object sender, EventArgs e)
        {
            //{AE0D67EA-32C9-46e2-8036-2EC797A13B94}
            this.setAge(this.dtBirthday.Value);
        }

        /// <summary>
        /// �ж�����֤//{6B6167F7-3A9B-4f6c-9326-C5CD6AA3AC98}����֤��Ϣ
        /// </summary>
        private enum EnumCheckIDNOType
        {
            /// <summary>
            /// ����֮ǰУ��
            /// </summary>
            BeforeSave = 0,

            /// <summary>
            /// ����ʱУ��
            /// </summary>
            Saveing
        }
        //{F2FB1293-6433-4db5-9BF1-EC855FDF408C}
        /// <summary>
        /// ��ʾ��ǰ����Ա�Һŷ�Ʊ��
        /// </summary>
        /// <returns></returns>
        private int ViewInvoiceNo()
        {
            if (this.IsViewInvoiceNo)
            {
                Neusoft.NFC.Management.PublicTrans.BeginTransaction();
                string invoiceno = string.Empty;
                #region ȡ��Ʊ
                if (this.GetRecipeType == 2)
                {
                    invoiceno = this.feeMgr.GetNewInvoiceNO("R");

                    if (string.IsNullOrEmpty(invoiceno))
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        this.lbinvoiceno.Text = "";
                        this.lbinvoicename.Visible = false;
                        this.lbinvoiceno.Visible = false;
                        return -1;
                    }
                }
                else if (this.GetRecipeType == 3)
                {
                    //ȡ�����վ�
                    invoiceno = this.feeMgr.GetNewInvoiceNO("C");
                    if (string.IsNullOrEmpty(invoiceno))
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        this.lbinvoiceno.Text = "";
                        this.lbinvoicename.Visible = false;
                        this.lbinvoiceno.Visible = false;
                        return -1;
                    }
                }
                this.Parent.Text = "��Ʊ�ţ�" + invoiceno;
                Neusoft.NFC.Management.PublicTrans.RollBack();
                this.lbinvoiceno.Text = invoiceno;
                this.lbinvoicename.Visible = true;
                this.lbinvoiceno.Visible = true;
                #endregion
            }
            else
            {
                this.lbinvoicename.Visible = false;
                this.lbinvoiceno.Visible = false;
            }
            return 1;
        }
        //{F2FB1293-6433-4db5-9BF1-EC855FDF408C}

        #region ��Ϣչʾ��չ�ӿ�
        /// <summary>
        /// ��Ϣչʾ��չ�ӿ� {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        /// </summary>
        /// <param name="register"></param>
        private void ShowOperationInformation(Neusoft.HISFC.Object.Registration.Register register)
        {
            if (this.isInitedIShowOperationInforamtion == false)
            {
                this.isInitedIShowOperationInforamtion = true;
                this.iShowOperationInforamtion = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(typeof(UFC.Registration.ucRegister), typeof(Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion)) as Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion;
            }

            if (this.iShowOperationInforamtion != null)
            {
                this.iShowOperationInforamtion.ReportRealCost(register.Name, register.Pact.Name, register.OwnCost);
            }
        }

        /// <summary>
        /// ��Ϣչʾ��չ�ӿ� {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        /// </summary>
        /// <param name="register"></param>
        private void ShowOperationInformation(Neusoft.HISFC.Object.Registration.Register register, decimal realCost)
        {
            if (this.iShowOperationInforamtion != null)
            {
                this.iShowOperationInforamtion.ReportChangeCost(register.Name, realCost, register.OwnCost);
            }
        }

        #endregion

    }
}
