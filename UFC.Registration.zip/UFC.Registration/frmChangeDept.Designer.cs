﻿namespace Neusoft.UFC.Registration
{
    partial class frmChangeDept
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.neuGroupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.neuGroupBox2 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.neuButton1 = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuButton2 = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtCurrentDept = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbDept = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.cmbDoct = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.txtCurrentDoct = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuGroupBox1.SuspendLayout();
            this.neuGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // neuGroupBox1
            // 
            this.neuGroupBox1.Controls.Add(this.txtCurrentDoct);
            this.neuGroupBox1.Controls.Add(this.neuLabel2);
            this.neuGroupBox1.Controls.Add(this.txtCurrentDept);
            this.neuGroupBox1.Controls.Add(this.neuLabel1);
            this.neuGroupBox1.Location = new System.Drawing.Point(7, 12);
            this.neuGroupBox1.Name = "neuGroupBox1";
            this.neuGroupBox1.Size = new System.Drawing.Size(365, 82);
            this.neuGroupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox1.TabIndex = 0;
            this.neuGroupBox1.TabStop = false;
            this.neuGroupBox1.Text = "当前信息";
            // 
            // neuGroupBox2
            // 
            this.neuGroupBox2.Controls.Add(this.cmbDoct);
            this.neuGroupBox2.Controls.Add(this.cmbDept);
            this.neuGroupBox2.Controls.Add(this.neuLabel3);
            this.neuGroupBox2.Controls.Add(this.neuLabel4);
            this.neuGroupBox2.Location = new System.Drawing.Point(12, 101);
            this.neuGroupBox2.Name = "neuGroupBox2";
            this.neuGroupBox2.Size = new System.Drawing.Size(360, 89);
            this.neuGroupBox2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox2.TabIndex = 1;
            this.neuGroupBox2.TabStop = false;
            this.neuGroupBox2.Text = "选择信息";
            // 
            // neuButton1
            // 
            this.neuButton1.Location = new System.Drawing.Point(189, 218);
            this.neuButton1.Name = "neuButton1";
            this.neuButton1.Size = new System.Drawing.Size(75, 23);
            this.neuButton1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuButton1.TabIndex = 2;
            this.neuButton1.Text = "确定(&O)";
            this.neuButton1.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.neuButton1.UseVisualStyleBackColor = true;
            this.neuButton1.Click += new System.EventHandler(this.neuButton1_Click);
            // 
            // neuButton2
            // 
            this.neuButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.neuButton2.Location = new System.Drawing.Point(270, 218);
            this.neuButton2.Name = "neuButton2";
            this.neuButton2.Size = new System.Drawing.Size(75, 23);
            this.neuButton2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuButton2.TabIndex = 3;
            this.neuButton2.Text = "取消(&C)";
            this.neuButton2.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.neuButton2.UseVisualStyleBackColor = true;
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Location = new System.Drawing.Point(6, 36);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(53, 12);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 0;
            this.neuLabel1.Text = "当前科室";
            // 
            // txtCurrentDept
            // 
            this.txtCurrentDept.Enabled = false;
            this.txtCurrentDept.IsEnter2Tab = false;
            this.txtCurrentDept.Location = new System.Drawing.Point(65, 33);
            this.txtCurrentDept.Name = "txtCurrentDept";
            this.txtCurrentDept.Size = new System.Drawing.Size(112, 21);
            this.txtCurrentDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtCurrentDept.TabIndex = 1;
            // 
            // neuLabel3
            // 
            this.neuLabel3.AutoSize = true;
            this.neuLabel3.Location = new System.Drawing.Point(178, 44);
            this.neuLabel3.Name = "neuLabel3";
            this.neuLabel3.Size = new System.Drawing.Size(53, 12);
            this.neuLabel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel3.TabIndex = 6;
            this.neuLabel3.Text = "待选医生";
            // 
            // neuLabel4
            // 
            this.neuLabel4.AutoSize = true;
            this.neuLabel4.Location = new System.Drawing.Point(1, 44);
            this.neuLabel4.Name = "neuLabel4";
            this.neuLabel4.Size = new System.Drawing.Size(53, 12);
            this.neuLabel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel4.TabIndex = 4;
            this.neuLabel4.Text = "待选科室";
            // 
            // cmbDept
            // 
            this.cmbDept.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDept.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbDept.FormattingEnabled = true;
            this.cmbDept.IsEnter2Tab = false;
            this.cmbDept.IsFlat = true;
            this.cmbDept.IsLike = true;
            this.cmbDept.Location = new System.Drawing.Point(60, 41);
            this.cmbDept.Name = "cmbDept";
            this.cmbDept.PopForm = null;
            this.cmbDept.ShowCustomerList = false;
            this.cmbDept.ShowID = false;
            this.cmbDept.Size = new System.Drawing.Size(112, 22);
            this.cmbDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDept.TabIndex = 7;
            this.cmbDept.Tag = "";
            this.cmbDept.ToolBarUse = false;
            // 
            // cmbDoct
            // 
            this.cmbDoct.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDoct.FormattingEnabled = true;
            this.cmbDoct.IsEnter2Tab = false;
            this.cmbDoct.IsFlat = true;
            this.cmbDoct.IsLike = true;
            this.cmbDoct.Location = new System.Drawing.Point(234, 41);
            this.cmbDoct.Name = "cmbDoct";
            this.cmbDoct.PopForm = null;
            this.cmbDoct.ShowCustomerList = false;
            this.cmbDoct.ShowID = false;
            this.cmbDoct.Size = new System.Drawing.Size(120, 20);
            this.cmbDoct.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDoct.TabIndex = 8;
            this.cmbDoct.Tag = "";
            this.cmbDoct.ToolBarUse = false;
            // 
            // txtCurrentDoct
            // 
            this.txtCurrentDoct.Enabled = false;
            this.txtCurrentDoct.IsEnter2Tab = false;
            this.txtCurrentDoct.Location = new System.Drawing.Point(239, 33);
            this.txtCurrentDoct.Name = "txtCurrentDoct";
            this.txtCurrentDoct.Size = new System.Drawing.Size(121, 21);
            this.txtCurrentDoct.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtCurrentDoct.TabIndex = 3;
            // 
            // neuLabel2
            // 
            this.neuLabel2.AutoSize = true;
            this.neuLabel2.Location = new System.Drawing.Point(183, 36);
            this.neuLabel2.Name = "neuLabel2";
            this.neuLabel2.Size = new System.Drawing.Size(53, 12);
            this.neuLabel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel2.TabIndex = 2;
            this.neuLabel2.Text = "当前医生";
            // 
            // frmChangeDept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 249);
            this.Controls.Add(this.neuButton2);
            this.Controls.Add(this.neuButton1);
            this.Controls.Add(this.neuGroupBox2);
            this.Controls.Add(this.neuGroupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmChangeDept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "换科";
            this.Load += new System.EventHandler(this.frmChangeDept_Load);
            this.neuGroupBox1.ResumeLayout(false);
            this.neuGroupBox1.PerformLayout();
            this.neuGroupBox2.ResumeLayout(false);
            this.neuGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox1;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCurrentDept;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox2;
        private Neusoft.NFC.Interface.Controls.NeuButton neuButton1;
        private Neusoft.NFC.Interface.Controls.NeuButton neuButton2;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDoct;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDept;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel3;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel4;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCurrentDoct;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel2;
    }
}