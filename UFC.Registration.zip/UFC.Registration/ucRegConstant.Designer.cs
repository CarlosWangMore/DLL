﻿namespace Neusoft.UFC.Registration
{
    partial class ucRegConstant
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.plBottom = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.btnCancel = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.btnSave = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuPanel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.neuTabControl1 = new Neusoft.NFC.Interface.Controls.NeuTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.neuGroupBox2 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.cmbPact = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel7 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.ckbMultiAdd = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbDifferentProfLev = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbAddtionFee = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbYYBeforeXC = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbDoctType = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbSaveMessage = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbJumpToYYTime = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbDeptDoctList = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbJumpToYY = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.cmbGetRecipe_Way = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.neuLabel5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuComboBox2 = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.neuLabel4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbInvoiceType = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.ckbICD = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbOverFlowLimit = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbDisplayDeptOnly = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbFirsDept = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.ckbDialogFeePub = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.nudAllow_PubPatient_RegLimitCost = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.neuLabel2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.nudAllow_QuitReg_Days = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.lbl = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuGroupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.lblRegProfCount = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lblRegPactCount = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lblRegDeptCount = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lblRegLevCount = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.nudRegProfCount = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.nudRegPactCount = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.nudRegDeptCount = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.nudRegLevCount = new Neusoft.NFC.Interface.Controls.NeuNumericUpDown();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chkReglevel = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.plBottom.SuspendLayout();
            this.neuPanel1.SuspendLayout();
            this.neuTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.neuGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAllow_PubPatient_RegLimitCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAllow_QuitReg_Days)).BeginInit();
            this.neuGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegProfCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegPactCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegDeptCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegLevCount)).BeginInit();
            this.SuspendLayout();
            // 
            // plBottom
            // 
            this.plBottom.Controls.Add(this.btnCancel);
            this.plBottom.Controls.Add(this.btnSave);
            this.plBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.plBottom.Location = new System.Drawing.Point(0, 518);
            this.plBottom.Name = "plBottom";
            this.plBottom.Size = new System.Drawing.Size(472, 34);
            this.plBottom.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.plBottom.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(383, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "取消(&C)";
            this.btnCancel.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(298, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "保存(&S)";
            this.btnSave.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // neuPanel1
            // 
            this.neuPanel1.Controls.Add(this.neuTabControl1);
            this.neuPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.neuPanel1.Location = new System.Drawing.Point(0, 0);
            this.neuPanel1.Name = "neuPanel1";
            this.neuPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.neuPanel1.Size = new System.Drawing.Size(472, 518);
            this.neuPanel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuPanel1.TabIndex = 1;
            // 
            // neuTabControl1
            // 
            this.neuTabControl1.Controls.Add(this.tabPage1);
            this.neuTabControl1.Controls.Add(this.tabPage2);
            this.neuTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.neuTabControl1.Location = new System.Drawing.Point(10, 10);
            this.neuTabControl1.Name = "neuTabControl1";
            this.neuTabControl1.SelectedIndex = 0;
            this.neuTabControl1.Size = new System.Drawing.Size(452, 498);
            this.neuTabControl1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.neuGroupBox2);
            this.tabPage1.Controls.Add(this.neuGroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(10);
            this.tabPage1.Size = new System.Drawing.Size(444, 473);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "门诊挂号参数";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // neuGroupBox2
            // 
            this.neuGroupBox2.Controls.Add(this.chkReglevel);
            this.neuGroupBox2.Controls.Add(this.cmbPact);
            this.neuGroupBox2.Controls.Add(this.neuLabel1);
            this.neuGroupBox2.Controls.Add(this.neuLabel7);
            this.neuGroupBox2.Controls.Add(this.ckbMultiAdd);
            this.neuGroupBox2.Controls.Add(this.ckbDifferentProfLev);
            this.neuGroupBox2.Controls.Add(this.ckbAddtionFee);
            this.neuGroupBox2.Controls.Add(this.ckbYYBeforeXC);
            this.neuGroupBox2.Controls.Add(this.ckbDoctType);
            this.neuGroupBox2.Controls.Add(this.ckbSaveMessage);
            this.neuGroupBox2.Controls.Add(this.ckbJumpToYYTime);
            this.neuGroupBox2.Controls.Add(this.ckbDeptDoctList);
            this.neuGroupBox2.Controls.Add(this.ckbJumpToYY);
            this.neuGroupBox2.Controls.Add(this.cmbGetRecipe_Way);
            this.neuGroupBox2.Controls.Add(this.neuLabel5);
            this.neuGroupBox2.Controls.Add(this.neuComboBox2);
            this.neuGroupBox2.Controls.Add(this.neuLabel4);
            this.neuGroupBox2.Controls.Add(this.cmbInvoiceType);
            this.neuGroupBox2.Controls.Add(this.ckbICD);
            this.neuGroupBox2.Controls.Add(this.ckbOverFlowLimit);
            this.neuGroupBox2.Controls.Add(this.ckbDisplayDeptOnly);
            this.neuGroupBox2.Controls.Add(this.ckbFirsDept);
            this.neuGroupBox2.Controls.Add(this.ckbDialogFeePub);
            this.neuGroupBox2.Controls.Add(this.nudAllow_PubPatient_RegLimitCost);
            this.neuGroupBox2.Controls.Add(this.neuLabel2);
            this.neuGroupBox2.Controls.Add(this.nudAllow_QuitReg_Days);
            this.neuGroupBox2.Controls.Add(this.lbl);
            this.neuGroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.neuGroupBox2.Location = new System.Drawing.Point(10, 74);
            this.neuGroupBox2.Name = "neuGroupBox2";
            this.neuGroupBox2.Size = new System.Drawing.Size(424, 389);
            this.neuGroupBox2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox2.TabIndex = 1;
            this.neuGroupBox2.TabStop = false;
            this.neuGroupBox2.Text = "操作";
            // 
            // cmbPact
            // 
            this.cmbPact.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbPact.FormattingEnabled = true;
            this.cmbPact.IsEnter2Tab = false;
            this.cmbPact.IsFlat = true;
            this.cmbPact.IsLike = true;
            this.cmbPact.Location = new System.Drawing.Point(115, 15);
            this.cmbPact.Name = "cmbPact";
            this.cmbPact.PopForm = null;
            this.cmbPact.ShowCustomerList = false;
            this.cmbPact.ShowID = false;
            this.cmbPact.Size = new System.Drawing.Size(110, 20);
            this.cmbPact.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbPact.TabIndex = 31;
            this.cmbPact.Tag = "";
            this.cmbPact.ToolBarUse = false;
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Location = new System.Drawing.Point(11, 21);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(101, 12);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 30;
            this.neuLabel1.Text = "合同单位默认代码";
            // 
            // neuLabel7
            // 
            this.neuLabel7.AutoSize = true;
            this.neuLabel7.Location = new System.Drawing.Point(9, 263);
            this.neuLabel7.Name = "neuLabel7";
            this.neuLabel7.Size = new System.Drawing.Size(101, 12);
            this.neuLabel7.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel7.TabIndex = 29;
            this.neuLabel7.Text = "挂号收据取号方式";
            // 
            // ckbMultiAdd
            // 
            this.ckbMultiAdd.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbMultiAdd.Location = new System.Drawing.Point(6, 66);
            this.ckbMultiAdd.Name = "ckbMultiAdd";
            this.ckbMultiAdd.Size = new System.Drawing.Size(204, 22);
            this.ckbMultiAdd.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbMultiAdd.TabIndex = 27;
            this.ckbMultiAdd.Text = "多张号是否作为加号";
            this.ckbMultiAdd.UseVisualStyleBackColor = true;
            // 
            // ckbDifferentProfLev
            // 
            this.ckbDifferentProfLev.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbDifferentProfLev.Location = new System.Drawing.Point(6, 190);
            this.ckbDifferentProfLev.Name = "ckbDifferentProfLev";
            this.ckbDifferentProfLev.Size = new System.Drawing.Size(204, 22);
            this.ckbDifferentProfLev.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbDifferentProfLev.TabIndex = 26;
            this.ckbDifferentProfLev.Text = "专家号是否区分教授级别";
            this.ckbDifferentProfLev.UseVisualStyleBackColor = true;
            // 
            // ckbAddtionFee
            // 
            this.ckbAddtionFee.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbAddtionFee.Location = new System.Drawing.Point(6, 164);
            this.ckbAddtionFee.Name = "ckbAddtionFee";
            this.ckbAddtionFee.Size = new System.Drawing.Size(204, 22);
            this.ckbAddtionFee.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbAddtionFee.TabIndex = 25;
            this.ckbAddtionFee.Text = "是否收取空调费(附加费)";
            this.ckbAddtionFee.UseVisualStyleBackColor = true;
            // 
            // ckbYYBeforeXC
            // 
            this.ckbYYBeforeXC.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbYYBeforeXC.Location = new System.Drawing.Point(231, 159);
            this.ckbYYBeforeXC.Name = "ckbYYBeforeXC";
            this.ckbYYBeforeXC.Size = new System.Drawing.Size(187, 34);
            this.ckbYYBeforeXC.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbYYBeforeXC.TabIndex = 24;
            this.ckbYYBeforeXC.Text = "是否预约号看诊序号排在现场号前面别";
            this.ckbYYBeforeXC.UseVisualStyleBackColor = true;
            // 
            // ckbDoctType
            // 
            this.ckbDoctType.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbDoctType.Location = new System.Drawing.Point(231, 139);
            this.ckbDoctType.Name = "ckbDoctType";
            this.ckbDoctType.Size = new System.Drawing.Size(187, 22);
            this.ckbDoctType.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbDoctType.TabIndex = 23;
            this.ckbDoctType.Text = "排班是否输入医生类别";
            this.ckbDoctType.UseVisualStyleBackColor = true;
            // 
            // ckbSaveMessage
            // 
            this.ckbSaveMessage.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbSaveMessage.Location = new System.Drawing.Point(6, 139);
            this.ckbSaveMessage.Name = "ckbSaveMessage";
            this.ckbSaveMessage.Size = new System.Drawing.Size(204, 22);
            this.ckbSaveMessage.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbSaveMessage.TabIndex = 22;
            this.ckbSaveMessage.Text = "保存时是否提示";
            this.ckbSaveMessage.UseVisualStyleBackColor = true;
            // 
            // ckbJumpToYYTime
            // 
            this.ckbJumpToYYTime.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbJumpToYYTime.Location = new System.Drawing.Point(231, 113);
            this.ckbJumpToYYTime.Name = "ckbJumpToYYTime";
            this.ckbJumpToYYTime.Size = new System.Drawing.Size(187, 22);
            this.ckbJumpToYYTime.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbJumpToYYTime.TabIndex = 21;
            this.ckbJumpToYYTime.Text = "光标是否需跳到预约时间段处";
            this.ckbJumpToYYTime.UseVisualStyleBackColor = true;
            // 
            // ckbDeptDoctList
            // 
            this.ckbDeptDoctList.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbDeptDoctList.Location = new System.Drawing.Point(6, 113);
            this.ckbDeptDoctList.Name = "ckbDeptDoctList";
            this.ckbDeptDoctList.Size = new System.Drawing.Size(204, 22);
            this.ckbDeptDoctList.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbDeptDoctList.TabIndex = 20;
            this.ckbDeptDoctList.Text = "科室,医生下拉列表是否显示全院";
            this.ckbDeptDoctList.UseVisualStyleBackColor = true;
            // 
            // ckbJumpToYY
            // 
            this.ckbJumpToYY.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbJumpToYY.Location = new System.Drawing.Point(231, 89);
            this.ckbJumpToYY.Name = "ckbJumpToYY";
            this.ckbJumpToYY.Size = new System.Drawing.Size(187, 22);
            this.ckbJumpToYY.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbJumpToYY.TabIndex = 19;
            this.ckbJumpToYY.Text = "是否跳到预约流水号处";
            this.ckbJumpToYY.UseVisualStyleBackColor = true;
            // 
            // cmbGetRecipe_Way
            // 
            this.cmbGetRecipe_Way.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbGetRecipe_Way.FormattingEnabled = true;
            this.cmbGetRecipe_Way.IsEnter2Tab = false;
            this.cmbGetRecipe_Way.IsFlat = true;
            this.cmbGetRecipe_Way.IsLike = true;
            this.cmbGetRecipe_Way.Items.AddRange(new object[] {
            "1物理票号",
            "2电脑票号－－挂号收据号",
            "3电脑票号－－门诊收据号"});
            this.cmbGetRecipe_Way.Location = new System.Drawing.Point(116, 262);
            this.cmbGetRecipe_Way.Name = "cmbGetRecipe_Way";
            this.cmbGetRecipe_Way.PopForm = null;
            this.cmbGetRecipe_Way.ShowCustomerList = false;
            this.cmbGetRecipe_Way.ShowID = false;
            this.cmbGetRecipe_Way.Size = new System.Drawing.Size(104, 20);
            this.cmbGetRecipe_Way.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbGetRecipe_Way.TabIndex = 17;
            this.cmbGetRecipe_Way.Tag = "";
            this.cmbGetRecipe_Way.ToolBarUse = false;
            // 
            // neuLabel5
            // 
            this.neuLabel5.AutoSize = true;
            this.neuLabel5.Location = new System.Drawing.Point(6, 352);
            this.neuLabel5.Name = "neuLabel5";
            this.neuLabel5.Size = new System.Drawing.Size(89, 12);
            this.neuLabel5.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel5.TabIndex = 16;
            this.neuLabel5.Text = "排班默认时间段";
            this.neuLabel5.Visible = false;
            // 
            // neuComboBox2
            // 
            this.neuComboBox2.ArrowBackColor = System.Drawing.Color.Silver;
            this.neuComboBox2.FormattingEnabled = true;
            this.neuComboBox2.IsEnter2Tab = false;
            this.neuComboBox2.IsFlat = true;
            this.neuComboBox2.IsLike = true;
            this.neuComboBox2.Items.AddRange(new object[] {
            "0默认为整个午别"});
            this.neuComboBox2.Location = new System.Drawing.Point(175, 349);
            this.neuComboBox2.Name = "neuComboBox2";
            this.neuComboBox2.PopForm = null;
            this.neuComboBox2.ShowCustomerList = false;
            this.neuComboBox2.ShowID = false;
            this.neuComboBox2.Size = new System.Drawing.Size(108, 20);
            this.neuComboBox2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuComboBox2.TabIndex = 15;
            this.neuComboBox2.Tag = "";
            this.neuComboBox2.ToolBarUse = false;
            this.neuComboBox2.Visible = false;
            // 
            // neuLabel4
            // 
            this.neuLabel4.AutoSize = true;
            this.neuLabel4.Enabled = false;
            this.neuLabel4.Location = new System.Drawing.Point(9, 288);
            this.neuLabel4.Name = "neuLabel4";
            this.neuLabel4.Size = new System.Drawing.Size(77, 12);
            this.neuLabel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel4.TabIndex = 14;
            this.neuLabel4.Text = "打印收据方式";
            this.neuLabel4.Visible = false;
            // 
            // cmbInvoiceType
            // 
            this.cmbInvoiceType.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbInvoiceType.Enabled = false;
            this.cmbInvoiceType.FormattingEnabled = true;
            this.cmbInvoiceType.IsEnter2Tab = false;
            this.cmbInvoiceType.IsFlat = true;
            this.cmbInvoiceType.IsLike = true;
            this.cmbInvoiceType.Items.AddRange(new object[] {
            "Invoice",
            "Recipe"});
            this.cmbInvoiceType.Location = new System.Drawing.Point(115, 284);
            this.cmbInvoiceType.Name = "cmbInvoiceType";
            this.cmbInvoiceType.PopForm = null;
            this.cmbInvoiceType.ShowCustomerList = false;
            this.cmbInvoiceType.ShowID = false;
            this.cmbInvoiceType.Size = new System.Drawing.Size(105, 20);
            this.cmbInvoiceType.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbInvoiceType.TabIndex = 13;
            this.cmbInvoiceType.Tag = "";
            this.cmbInvoiceType.ToolBarUse = false;
            this.cmbInvoiceType.Visible = false;
            // 
            // ckbICD
            // 
            this.ckbICD.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbICD.Location = new System.Drawing.Point(6, 89);
            this.ckbICD.Name = "ckbICD";
            this.ckbICD.Size = new System.Drawing.Size(204, 22);
            this.ckbICD.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbICD.TabIndex = 12;
            this.ckbICD.Text = "诊断是否录入ICD码";
            this.ckbICD.UseVisualStyleBackColor = true;
            // 
            // ckbOverFlowLimit
            // 
            this.ckbOverFlowLimit.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbOverFlowLimit.Location = new System.Drawing.Point(231, 66);
            this.ckbOverFlowLimit.Name = "ckbOverFlowLimit";
            this.ckbOverFlowLimit.Size = new System.Drawing.Size(187, 22);
            this.ckbOverFlowLimit.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbOverFlowLimit.TabIndex = 11;
            this.ckbOverFlowLimit.Text = "挂号是否允许超出排班限额";
            this.ckbOverFlowLimit.UseVisualStyleBackColor = true;
            // 
            // ckbDisplayDeptOnly
            // 
            this.ckbDisplayDeptOnly.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbDisplayDeptOnly.Location = new System.Drawing.Point(231, 43);
            this.ckbDisplayDeptOnly.Name = "ckbDisplayDeptOnly";
            this.ckbDisplayDeptOnly.Size = new System.Drawing.Size(187, 22);
            this.ckbDisplayDeptOnly.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbDisplayDeptOnly.TabIndex = 7;
            this.ckbDisplayDeptOnly.Text = "是否只显示出诊科室";
            this.ckbDisplayDeptOnly.UseVisualStyleBackColor = true;
            // 
            // ckbFirsDept
            // 
            this.ckbFirsDept.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbFirsDept.Location = new System.Drawing.Point(231, 20);
            this.ckbFirsDept.Name = "ckbFirsDept";
            this.ckbFirsDept.Size = new System.Drawing.Size(187, 22);
            this.ckbFirsDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbFirsDept.TabIndex = 6;
            this.ckbFirsDept.Text = "专家号是否先输科室";
            this.ckbFirsDept.UseVisualStyleBackColor = true;
            // 
            // ckbDialogFeePub
            // 
            this.ckbDialogFeePub.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ckbDialogFeePub.Location = new System.Drawing.Point(6, 43);
            this.ckbDialogFeePub.Name = "ckbDialogFeePub";
            this.ckbDialogFeePub.Size = new System.Drawing.Size(204, 22);
            this.ckbDialogFeePub.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ckbDialogFeePub.TabIndex = 5;
            this.ckbDialogFeePub.Text = "诊金是否报销";
            this.ckbDialogFeePub.UseVisualStyleBackColor = true;
            // 
            // nudAllow_PubPatient_RegLimitCost
            // 
            this.nudAllow_PubPatient_RegLimitCost.Location = new System.Drawing.Point(365, 221);
            this.nudAllow_PubPatient_RegLimitCost.Name = "nudAllow_PubPatient_RegLimitCost";
            this.nudAllow_PubPatient_RegLimitCost.Size = new System.Drawing.Size(52, 21);
            this.nudAllow_PubPatient_RegLimitCost.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudAllow_PubPatient_RegLimitCost.TabIndex = 4;
            // 
            // neuLabel2
            // 
            this.neuLabel2.AutoSize = true;
            this.neuLabel2.Location = new System.Drawing.Point(230, 225);
            this.neuLabel2.Name = "neuLabel2";
            this.neuLabel2.Size = new System.Drawing.Size(137, 12);
            this.neuLabel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel2.TabIndex = 3;
            this.neuLabel2.Text = "公费患者允许日挂号限额";
            // 
            // nudAllow_QuitReg_Days
            // 
            this.nudAllow_QuitReg_Days.Location = new System.Drawing.Point(156, 221);
            this.nudAllow_QuitReg_Days.Name = "nudAllow_QuitReg_Days";
            this.nudAllow_QuitReg_Days.Size = new System.Drawing.Size(52, 21);
            this.nudAllow_QuitReg_Days.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudAllow_QuitReg_Days.TabIndex = 2;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(6, 225);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(77, 12);
            this.lbl.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbl.TabIndex = 1;
            this.lbl.Text = "允许退号天数";
            // 
            // neuGroupBox1
            // 
            this.neuGroupBox1.Controls.Add(this.lblRegProfCount);
            this.neuGroupBox1.Controls.Add(this.lblRegPactCount);
            this.neuGroupBox1.Controls.Add(this.lblRegDeptCount);
            this.neuGroupBox1.Controls.Add(this.lblRegLevCount);
            this.neuGroupBox1.Controls.Add(this.nudRegProfCount);
            this.neuGroupBox1.Controls.Add(this.nudRegPactCount);
            this.neuGroupBox1.Controls.Add(this.nudRegDeptCount);
            this.neuGroupBox1.Controls.Add(this.nudRegLevCount);
            this.neuGroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.neuGroupBox1.Location = new System.Drawing.Point(10, 10);
            this.neuGroupBox1.Name = "neuGroupBox1";
            this.neuGroupBox1.Size = new System.Drawing.Size(424, 64);
            this.neuGroupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox1.TabIndex = 0;
            this.neuGroupBox1.TabStop = false;
            this.neuGroupBox1.Text = "显示列数";
            // 
            // lblRegProfCount
            // 
            this.lblRegProfCount.AutoSize = true;
            this.lblRegProfCount.Location = new System.Drawing.Point(231, 40);
            this.lblRegProfCount.Name = "lblRegProfCount";
            this.lblRegProfCount.Size = new System.Drawing.Size(101, 12);
            this.lblRegProfCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblRegProfCount.TabIndex = 7;
            this.lblRegProfCount.Text = "出诊教授显示列数";
            // 
            // lblRegPactCount
            // 
            this.lblRegPactCount.AutoSize = true;
            this.lblRegPactCount.Location = new System.Drawing.Point(6, 40);
            this.lblRegPactCount.Name = "lblRegPactCount";
            this.lblRegPactCount.Size = new System.Drawing.Size(101, 12);
            this.lblRegPactCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblRegPactCount.TabIndex = 6;
            this.lblRegPactCount.Text = "合同单位显示列数";
            // 
            // lblRegDeptCount
            // 
            this.lblRegDeptCount.AutoSize = true;
            this.lblRegDeptCount.Location = new System.Drawing.Point(231, 21);
            this.lblRegDeptCount.Name = "lblRegDeptCount";
            this.lblRegDeptCount.Size = new System.Drawing.Size(101, 12);
            this.lblRegDeptCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblRegDeptCount.TabIndex = 5;
            this.lblRegDeptCount.Text = "挂号科室显示列数";
            // 
            // lblRegLevCount
            // 
            this.lblRegLevCount.AutoSize = true;
            this.lblRegLevCount.Location = new System.Drawing.Point(6, 21);
            this.lblRegLevCount.Name = "lblRegLevCount";
            this.lblRegLevCount.Size = new System.Drawing.Size(101, 12);
            this.lblRegLevCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblRegLevCount.TabIndex = 4;
            this.lblRegLevCount.Text = "挂号级别显示列数";
            // 
            // nudRegProfCount
            // 
            this.nudRegProfCount.Location = new System.Drawing.Point(350, 38);
            this.nudRegProfCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRegProfCount.Name = "nudRegProfCount";
            this.nudRegProfCount.Size = new System.Drawing.Size(51, 21);
            this.nudRegProfCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudRegProfCount.TabIndex = 3;
            this.nudRegProfCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudRegPactCount
            // 
            this.nudRegPactCount.Location = new System.Drawing.Point(145, 38);
            this.nudRegPactCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRegPactCount.Name = "nudRegPactCount";
            this.nudRegPactCount.Size = new System.Drawing.Size(51, 21);
            this.nudRegPactCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudRegPactCount.TabIndex = 2;
            this.nudRegPactCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudRegDeptCount
            // 
            this.nudRegDeptCount.Location = new System.Drawing.Point(350, 13);
            this.nudRegDeptCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRegDeptCount.Name = "nudRegDeptCount";
            this.nudRegDeptCount.Size = new System.Drawing.Size(51, 21);
            this.nudRegDeptCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudRegDeptCount.TabIndex = 1;
            this.nudRegDeptCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudRegLevCount
            // 
            this.nudRegLevCount.Location = new System.Drawing.Point(145, 13);
            this.nudRegLevCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRegLevCount.Name = "nudRegLevCount";
            this.nudRegLevCount.Size = new System.Drawing.Size(51, 21);
            this.nudRegLevCount.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.nudRegLevCount.TabIndex = 0;
            this.nudRegLevCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(444, 473);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "门诊挂号参数扩展";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chkReglevel
            // 
            this.chkReglevel.AutoSize = true;
            this.chkReglevel.CheckAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkReglevel.Location = new System.Drawing.Point(231, 195);
            this.chkReglevel.Name = "chkReglevel";
            this.chkReglevel.Size = new System.Drawing.Size(186, 16);
            this.chkReglevel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.chkReglevel.TabIndex = 32;
            this.chkReglevel.Text = "排班是否选择挂号级别       ";
            this.chkReglevel.UseVisualStyleBackColor = true;
            // 
            // ucRegConstant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.neuPanel1);
            this.Controls.Add(this.plBottom);
            this.Name = "ucRegConstant";
            this.Size = new System.Drawing.Size(472, 552);
            this.plBottom.ResumeLayout(false);
            this.neuPanel1.ResumeLayout(false);
            this.neuTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.neuGroupBox2.ResumeLayout(false);
            this.neuGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAllow_PubPatient_RegLimitCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAllow_QuitReg_Days)).EndInit();
            this.neuGroupBox1.ResumeLayout(false);
            this.neuGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegProfCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegPactCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegDeptCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRegLevCount)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuPanel plBottom;
        private Neusoft.NFC.Interface.Controls.NeuPanel neuPanel1;
        private Neusoft.NFC.Interface.Controls.NeuButton btnCancel;
        private Neusoft.NFC.Interface.Controls.NeuButton btnSave;
        private Neusoft.NFC.Interface.Controls.NeuTabControl neuTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox1;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudRegProfCount;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudRegPactCount;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudRegDeptCount;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudRegLevCount;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblRegProfCount;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblRegPactCount;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblRegDeptCount;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblRegLevCount;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox2;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudAllow_QuitReg_Days;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbl;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbDisplayDeptOnly;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbFirsDept;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbDialogFeePub;
        private Neusoft.NFC.Interface.Controls.NeuNumericUpDown nudAllow_PubPatient_RegLimitCost;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel2;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbOverFlowLimit;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbICD;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel4;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbInvoiceType;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel5;
        private Neusoft.NFC.Interface.Controls.NeuComboBox neuComboBox2;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbGetRecipe_Way;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel7;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbMultiAdd;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbDifferentProfLev;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbAddtionFee;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbYYBeforeXC;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbDoctType;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbSaveMessage;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbJumpToYYTime;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbDeptDoctList;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox ckbJumpToYY;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbPact;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox chkReglevel;
    }
}
