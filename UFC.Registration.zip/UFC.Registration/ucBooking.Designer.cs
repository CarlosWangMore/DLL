﻿namespace Neusoft.UFC.Registration
{
    partial class ucBooking
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.TipAppearance tipAppearance1 = new FarPoint.Win.Spread.TipAppearance();
            this.panel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.panel3 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.fpSpread1 = new Neusoft.NFC.Interface.Controls.NeuSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.splitter1 = new Neusoft.NFC.Interface.Controls.NeuSplitter();
            this.panel2 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.lbTelReging = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label12 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTelLmt = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label8 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtIdenNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.txtAdress = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.txtPhone = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.txtName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.txtCardNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label7 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.panel4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label14 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label10 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label9 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.bnQuery = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.lbWeek = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.dtEnd = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.dtBegin = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.label6 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.dtBookingDate = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.cmbDoct = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.cmbDept = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtOrder = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.lbOrder = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label13 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.splitter1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 566);
            this.panel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fpSpread1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(467, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(325, 566);
            this.panel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel3.TabIndex = 2;
            // 
            // fpSpread1
            // 
            this.fpSpread1.About = "2.5.2007.2005";
            this.fpSpread1.AccessibleDescription = "";
            this.fpSpread1.BackColor = System.Drawing.Color.White;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FileName = "";
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.IsAutoSaveGridStatus = false;
            this.fpSpread1.IsCanCustomConfigColumn = false;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(325, 566);
            this.fpSpread1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.fpSpread1.TabIndex = 0;
            tipAppearance1.BackColor = System.Drawing.SystemColors.Info;
            tipAppearance1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            tipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.fpSpread1.TextTipAppearance = tipAppearance1;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 6;
            this.fpSpread1_Sheet1.RowCount = 0;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "流水号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "病历号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "患者姓名";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "预约科室";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "预约专家";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "预约时段";
            this.fpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 22F;
            this.fpSpread1_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "病历号";
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 89F;
            this.fpSpread1_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "患者姓名";
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 59F;
            this.fpSpread1_Sheet1.Columns.Get(3).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.Columns.Get(3).Label = "预约科室";
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 85F;
            this.fpSpread1_Sheet1.Columns.Get(4).Label = "预约专家";
            this.fpSpread1_Sheet1.Columns.Get(4).Width = 84F;
            this.fpSpread1_Sheet1.Columns.Get(5).Font = new System.Drawing.Font("宋体", 9F);
            this.fpSpread1_Sheet1.Columns.Get(5).Label = "预约时段";
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 156F;
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            this.fpSpread1.SetActiveViewport(1, 0);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(464, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 566);
            this.splitter1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.lbTelReging);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.lbTelLmt);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtIdenNo);
            this.panel2.Controls.Add(this.txtAdress);
            this.panel2.Controls.Add(this.txtPhone);
            this.panel2.Controls.Add(this.txtName);
            this.panel2.Controls.Add(this.txtCardNo);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.bnQuery);
            this.panel2.Controls.Add(this.lbWeek);
            this.panel2.Controls.Add(this.dtEnd);
            this.panel2.Controls.Add(this.dtBegin);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.dtBookingDate);
            this.panel2.Controls.Add(this.cmbDoct);
            this.panel2.Controls.Add(this.cmbDept);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtOrder);
            this.panel2.Controls.Add(this.lbOrder);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(464, 566);
            this.panel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel2.TabIndex = 0;
            // 
            // lbTelReging
            // 
            this.lbTelReging.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbTelReging.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbTelReging.Location = new System.Drawing.Point(240, 530);
            this.lbTelReging.Name = "lbTelReging";
            this.lbTelReging.Size = new System.Drawing.Size(40, 23);
            this.lbTelReging.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTelReging.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.Font = new System.Drawing.Font("宋体", 11F);
            this.label12.Location = new System.Drawing.Point(168, 530);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label12.TabIndex = 22;
            this.label12.Text = "预约数：";
            // 
            // lbTelLmt
            // 
            this.lbTelLmt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbTelLmt.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbTelLmt.Location = new System.Drawing.Point(112, 530);
            this.lbTelLmt.Name = "lbTelLmt";
            this.lbTelLmt.Size = new System.Drawing.Size(40, 23);
            this.lbTelLmt.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTelLmt.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.Font = new System.Drawing.Font("宋体", 11F);
            this.label8.Location = new System.Drawing.Point(40, 530);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 23);
            this.label8.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label8.TabIndex = 20;
            this.label8.Text = "设号数：";
            // 
            // txtIdenNo
            // 
            this.txtIdenNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtIdenNo.Font = new System.Drawing.Font("宋体", 11F);
            this.txtIdenNo.Location = new System.Drawing.Point(152, 344);
            this.txtIdenNo.MaxLength = 18;
            this.txtIdenNo.Name = "txtIdenNo";
            this.txtIdenNo.Size = new System.Drawing.Size(264, 24);
            this.txtIdenNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtIdenNo.TabIndex = 8;
            // 
            // txtAdress
            // 
            this.txtAdress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAdress.Font = new System.Drawing.Font("宋体", 11F);
            this.txtAdress.Location = new System.Drawing.Point(152, 384);
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(264, 24);
            this.txtAdress.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtAdress.TabIndex = 9;
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPhone.Font = new System.Drawing.Font("宋体", 11F);
            this.txtPhone.Location = new System.Drawing.Point(152, 304);
            this.txtPhone.MaxLength = 20;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(264, 24);
            this.txtPhone.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtPhone.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.Font = new System.Drawing.Font("宋体", 11F);
            this.txtName.Location = new System.Drawing.Point(152, 264);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(136, 24);
            this.txtName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtName.TabIndex = 6;
            // 
            // txtCardNo
            // 
            this.txtCardNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCardNo.Font = new System.Drawing.Font("宋体", 11F);
            this.txtCardNo.Location = new System.Drawing.Point(152, 224);
            this.txtCardNo.MaxLength = 10;
            this.txtCardNo.Name = "txtCardNo";
            this.txtCardNo.Size = new System.Drawing.Size(136, 24);
            this.txtCardNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtCardNo.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("宋体", 11F);
            this.label7.Location = new System.Drawing.Point(40, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label7.TabIndex = 14;
            this.label7.Text = "身份证号：";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Controls.Add(this.label14);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(464, 37);
            this.panel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel4.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label14.Location = new System.Drawing.Point(136, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(168, 23);
            this.label14.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label14.TabIndex = 0;
            this.label14.Text = "门诊预约挂号";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("宋体", 11F);
            this.label10.Location = new System.Drawing.Point(40, 384);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label10.TabIndex = 15;
            this.label10.Text = "通讯地址：";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("宋体", 11F);
            this.label9.Location = new System.Drawing.Point(40, 304);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 23);
            this.label9.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label9.TabIndex = 13;
            this.label9.Text = "联系电话：";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("宋体", 11F);
            this.label5.Location = new System.Drawing.Point(40, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label5.TabIndex = 12;
            this.label5.Text = "姓    名：";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("宋体", 11F);
            this.label4.Location = new System.Drawing.Point(40, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label4.TabIndex = 11;
            this.label4.Text = "病 历 号：";
            // 
            // bnQuery
            // 
            this.bnQuery.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bnQuery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bnQuery.Location = new System.Drawing.Point(352, 144);
            this.bnQuery.Name = "bnQuery";
            this.bnQuery.Size = new System.Drawing.Size(64, 26);
            this.bnQuery.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.bnQuery.TabIndex = 10;
            this.bnQuery.Text = "(PageDn)";
            this.bnQuery.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            // 
            // lbWeek
            // 
            this.lbWeek.BackColor = System.Drawing.SystemColors.Window;
            this.lbWeek.Font = new System.Drawing.Font("宋体", 10F);
            this.lbWeek.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbWeek.Location = new System.Drawing.Point(264, 145);
            this.lbWeek.Name = "lbWeek";
            this.lbWeek.Size = new System.Drawing.Size(56, 20);
            this.lbWeek.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbWeek.TabIndex = 26;
            this.lbWeek.Text = "星期日";
            this.lbWeek.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // dtEnd
            // 
            this.dtEnd.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtEnd.CustomFormat = "HH:mm";
            this.dtEnd.Font = new System.Drawing.Font("宋体", 11F);
            this.dtEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEnd.Location = new System.Drawing.Point(256, 184);
            this.dtEnd.Name = "dtEnd";
            this.dtEnd.ShowUpDown = true;
            this.dtEnd.Size = new System.Drawing.Size(88, 24);
            this.dtEnd.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtEnd.TabIndex = 4;
            this.dtEnd.Value = new System.DateTime(2006, 2, 28, 20, 40, 47, 546);
            // 
            // dtBegin
            // 
            this.dtBegin.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtBegin.CustomFormat = "HH:mm";
            this.dtBegin.Font = new System.Drawing.Font("宋体", 11F);
            this.dtBegin.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBegin.Location = new System.Drawing.Point(152, 184);
            this.dtBegin.Name = "dtBegin";
            this.dtBegin.ShowUpDown = true;
            this.dtBegin.Size = new System.Drawing.Size(88, 24);
            this.dtBegin.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtBegin.TabIndex = 3;
            this.dtBegin.Value = new System.DateTime(2006, 2, 28, 20, 40, 47, 546);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("宋体", 11F);
            this.label6.Location = new System.Drawing.Point(40, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label6.TabIndex = 19;
            this.label6.Text = "预约时段：";
            // 
            // dtBookingDate
            // 
            this.dtBookingDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtBookingDate.CustomFormat = "yyyy-MM-dd";
            this.dtBookingDate.Font = new System.Drawing.Font("宋体", 11F);
            this.dtBookingDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBookingDate.Location = new System.Drawing.Point(152, 144);
            this.dtBookingDate.Name = "dtBookingDate";
            this.dtBookingDate.ShowUpDown = true;
            this.dtBookingDate.Size = new System.Drawing.Size(192, 24);
            this.dtBookingDate.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtBookingDate.TabIndex = 2;
            this.dtBookingDate.Value = new System.DateTime(2006, 2, 28, 20, 40, 47, 546);
            // 
            // cmbDoct
            // 
            this.cmbDoct.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDoct.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbDoct.IsFlat = true;
            this.cmbDoct.IsLike = true;
            this.cmbDoct.ItemHeight = 15;
            this.cmbDoct.Location = new System.Drawing.Point(152, 104);
            this.cmbDoct.Name = "cmbDoct";
            this.cmbDoct.PopForm = null;
            this.cmbDoct.ShowCustomerList = false;
            this.cmbDoct.ShowID = false;
            this.cmbDoct.Size = new System.Drawing.Size(136, 23);
            this.cmbDoct.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDoct.TabIndex = 1;
            this.cmbDoct.Tag = "";
            this.cmbDoct.ToolBarUse = false;
            // 
            // cmbDept
            // 
            this.cmbDept.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDept.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbDept.IsFlat = true;
            this.cmbDept.IsLike = true;
            this.cmbDept.ItemHeight = 15;
            this.cmbDept.Location = new System.Drawing.Point(152, 64);
            this.cmbDept.Name = "cmbDept";
            this.cmbDept.PopForm = null;
            this.cmbDept.ShowCustomerList = false;
            this.cmbDept.ShowID = false;
            this.cmbDept.Size = new System.Drawing.Size(136, 23);
            this.cmbDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDept.TabIndex = 0;
            this.cmbDept.Tag = "";
            this.cmbDept.ToolBarUse = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("宋体", 11F);
            this.label1.Location = new System.Drawing.Point(40, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label1.TabIndex = 18;
            this.label1.Text = "预约日期：";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 11F);
            this.label3.Location = new System.Drawing.Point(40, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label3.TabIndex = 17;
            this.label3.Text = "教授代码：";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 11F);
            this.label2.Location = new System.Drawing.Point(40, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label2.TabIndex = 16;
            this.label2.Text = "挂号科室：";
            // 
            // txtOrder
            // 
            this.txtOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtOrder.BackColor = System.Drawing.SystemColors.Window;
            this.txtOrder.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.txtOrder.ForeColor = System.Drawing.Color.Red;
            this.txtOrder.Location = new System.Drawing.Point(360, 530);
            this.txtOrder.Name = "txtOrder";
            this.txtOrder.Size = new System.Drawing.Size(88, 24);
            this.txtOrder.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtOrder.TabIndex = 27;
            this.txtOrder.TabStop = false;
            this.txtOrder.Visible = false;
            // 
            // lbOrder
            // 
            this.lbOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbOrder.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbOrder.ForeColor = System.Drawing.Color.Red;
            this.lbOrder.Location = new System.Drawing.Point(360, 530);
            this.lbOrder.Name = "lbOrder";
            this.lbOrder.Size = new System.Drawing.Size(88, 23);
            this.lbOrder.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbOrder.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label13.Font = new System.Drawing.Font("宋体", 11F);
            this.label13.Location = new System.Drawing.Point(296, 530);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 23);
            this.label13.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label13.TabIndex = 24;
            this.label13.Text = "流水号：";
            // 
            // ucBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.panel1);
            this.Name = "ucBooking";
            this.Size = new System.Drawing.Size(792, 566);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        
        private Neusoft.NFC.Interface.Controls.NeuPanel panel1;
        private Neusoft.NFC.Interface.Controls.NeuSplitter splitter1;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel3;        
        private Neusoft.NFC.Interface.Controls.NeuSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label6;
        private Neusoft.NFC.Interface.Controls.NeuLabel label1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label7;
        private Neusoft.NFC.Interface.Controls.NeuLabel panel4;
        private Neusoft.NFC.Interface.Controls.NeuLabel label14;
        private Neusoft.NFC.Interface.Controls.NeuLabel label10;
        private Neusoft.NFC.Interface.Controls.NeuLabel label9;
        private Neusoft.NFC.Interface.Controls.NeuLabel label5;
        private Neusoft.NFC.Interface.Controls.NeuLabel label4;
        private Neusoft.NFC.Interface.Controls.NeuLabel label3;
        private Neusoft.NFC.Interface.Controls.NeuLabel label2;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel2;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtEnd;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBegin;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBookingDate;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDoct;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDept;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtIdenNo;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtAdress;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtPhone;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtName;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCardNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbWeek;
        private Neusoft.NFC.Interface.Controls.NeuLabel label8;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTelLmt;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTelReging;
        private Neusoft.NFC.Interface.Controls.NeuLabel label12;
        private Neusoft.NFC.Interface.Controls.NeuLabel label13;
        private Neusoft.NFC.Interface.Controls.NeuButton bnQuery;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtOrder;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbOrder;
    }
}
