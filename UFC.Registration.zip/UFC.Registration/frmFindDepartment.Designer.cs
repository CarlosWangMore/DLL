﻿namespace Neusoft.UFC.Registration
{
    partial class frmFindDepartment
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.neuCboDeptList = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuPanel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.neuBtnFind = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuBtnCancel = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.groupBox2 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.neuGroupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.neuPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // neuCboDeptList
            // 
            this.neuCboDeptList.ArrowBackColor = System.Drawing.Color.Silver;
            this.neuCboDeptList.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.neuCboDeptList.FormattingEnabled = true;
            this.neuCboDeptList.IsFlat = true;
            this.neuCboDeptList.IsLike = true;
            this.neuCboDeptList.Location = new System.Drawing.Point(109, 76);
            this.neuCboDeptList.Name = "neuCboDeptList";
            this.neuCboDeptList.PopForm = null;
            this.neuCboDeptList.ShowCustomerList = false;
            this.neuCboDeptList.ShowID = false;
            this.neuCboDeptList.Size = new System.Drawing.Size(120, 24);
            this.neuCboDeptList.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuCboDeptList.TabIndex = 0;
            this.neuCboDeptList.Tag = "";
            this.neuCboDeptList.ToolBarUse = false;
            this.neuCboDeptList.SelectedIndexChanged += new System.EventHandler(this.neuCboDeptList_SelectedIndexChanged);
            this.neuCboDeptList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.neuCboDeptList_KeyDown);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(14, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(260, 31);
            this.label2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label2.TabIndex = 4;
            this.label2.Text = "在下拉列表框中选择要查找的科室，然后单击查找按钮";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(46, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 23);
            this.label1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label1.TabIndex = 5;
            this.label1.Text = "查找科室：";
            // 
            // neuPanel1
            // 
            this.neuPanel1.BackColor = System.Drawing.SystemColors.Window;
            this.neuPanel1.Controls.Add(this.label2);
            this.neuPanel1.Location = new System.Drawing.Point(0, 0);
            this.neuPanel1.Name = "neuPanel1";
            this.neuPanel1.Size = new System.Drawing.Size(284, 53);
            this.neuPanel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuPanel1.TabIndex = 6;
            // 
            // neuBtnFind
            // 
            this.neuBtnFind.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.neuBtnFind.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.neuBtnFind.Location = new System.Drawing.Point(93, 142);
            this.neuBtnFind.Name = "neuBtnFind";
            this.neuBtnFind.Size = new System.Drawing.Size(75, 23);
            this.neuBtnFind.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuBtnFind.TabIndex = 7;
            this.neuBtnFind.Text = "查找(&O)";
            this.neuBtnFind.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.neuBtnFind.UseVisualStyleBackColor = true;
            this.neuBtnFind.Click += new System.EventHandler(this.neuBtnFind_Click);
            // 
            // neuBtnCancel
            // 
            this.neuBtnCancel.DialogResult = System.Windows.Forms.DialogResult.No;
            this.neuBtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.neuBtnCancel.Location = new System.Drawing.Point(187, 142);
            this.neuBtnCancel.Name = "neuBtnCancel";
            this.neuBtnCancel.Size = new System.Drawing.Size(75, 23);
            this.neuBtnCancel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuBtnCancel.TabIndex = 8;
            this.neuBtnCancel.Text = "取消(&X)";
            this.neuBtnCancel.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.neuBtnCancel.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(283, 3);
            this.groupBox2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // neuGroupBox1
            // 
            this.neuGroupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.neuGroupBox1.Location = new System.Drawing.Point(-1, 131);
            this.neuGroupBox1.Name = "neuGroupBox1";
            this.neuGroupBox1.Size = new System.Drawing.Size(285, 2);
            this.neuGroupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox1.TabIndex = 10;
            this.neuGroupBox1.TabStop = false;
            // 
            // frmFindDepartment
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(283, 178);
            this.Controls.Add(this.neuGroupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.neuBtnCancel);
            this.Controls.Add(this.neuBtnFind);
            this.Controls.Add(this.neuCboDeptList);
            this.Controls.Add(this.neuPanel1);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFindDepartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "科室查找...";
            this.neuPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuComboBox neuCboDeptList;
        private Neusoft.NFC.Interface.Controls.NeuLabel label2;
        private Neusoft.NFC.Interface.Controls.NeuLabel label1;
        private Neusoft.NFC.Interface.Controls.NeuPanel neuPanel1;
        private Neusoft.NFC.Interface.Controls.NeuButton neuBtnFind;
        private Neusoft.NFC.Interface.Controls.NeuButton neuBtnCancel;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox2;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox1;
    }
}