﻿namespace Neusoft.UFC.Registration
{
	partial class ucRegLevel
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
            FarPoint.Win.Spread.TipAppearance tipAppearance1 = new FarPoint.Win.Spread.TipAppearance();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType1 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType1 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType2 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType3 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType4 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            FarPoint.Win.Spread.CellType.CheckBoxCellType checkBoxCellType5 = new FarPoint.Win.Spread.CellType.CheckBoxCellType();
            this.fpSpread1 = new Neusoft.NFC.Interface.Controls.NeuSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // fpSpread1
            // 
            this.fpSpread1.About = "2.5.2007.2005";
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1";
            this.fpSpread1.BackColor = System.Drawing.SystemColors.Control;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FileName = "";
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.IsAutoSaveGridStatus = false;
            this.fpSpread1.IsCanCustomConfigColumn = false;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(567, 439);
            this.fpSpread1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.fpSpread1.TabIndex = 0;
            tipAppearance1.BackColor = System.Drawing.SystemColors.Info;
            tipAppearance1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            tipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.fpSpread1.TextTipAppearance = tipAppearance1;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.Change += new FarPoint.Win.Spread.ChangeEventHandler(this.fpSpread1_Change);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 9;
            this.fpSpread1_Sheet1.RowCount = 0;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "代码";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "名称";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "1代表普通号，0代表急诊号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "序号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "停用";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "专家号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "专科号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "特诊号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "默认值";
            this.fpSpread1_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.fpSpread1_Sheet1.Columns.Get(0).Label = "代码";
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 48F;
            textCellType2.MaxLength = 20;
            this.fpSpread1_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "名称";
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 114F;
            this.fpSpread1_Sheet1.Columns.Get(2).CellType = textCellType3;
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "1代表普通号，0代表急诊号";
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 174F;
            numberCellType1.FixedPoint = false;
            numberCellType1.MaximumValue = 9999999;
            numberCellType1.MinimumValue = 0;
            this.fpSpread1_Sheet1.Columns.Get(3).CellType = numberCellType1;
            this.fpSpread1_Sheet1.Columns.Get(3).Label = "序号";
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 40F;
            this.fpSpread1_Sheet1.Columns.Get(4).CellType = checkBoxCellType1;
            this.fpSpread1_Sheet1.Columns.Get(4).Label = "停用";
            this.fpSpread1_Sheet1.Columns.Get(4).Width = 35F;
            this.fpSpread1_Sheet1.Columns.Get(5).CellType = checkBoxCellType2;
            this.fpSpread1_Sheet1.Columns.Get(5).Label = "专家号";
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 48F;
            this.fpSpread1_Sheet1.Columns.Get(6).CellType = checkBoxCellType3;
            this.fpSpread1_Sheet1.Columns.Get(6).Label = "专科号";
            this.fpSpread1_Sheet1.Columns.Get(6).Width = 45F;
            this.fpSpread1_Sheet1.Columns.Get(7).CellType = checkBoxCellType4;
            this.fpSpread1_Sheet1.Columns.Get(7).Label = "特诊号";
            this.fpSpread1_Sheet1.Columns.Get(7).Width = 47F;
            this.fpSpread1_Sheet1.Columns.Get(8).CellType = checkBoxCellType5;
            this.fpSpread1_Sheet1.Columns.Get(8).Label = "默认值";
            this.fpSpread1_Sheet1.Columns.Get(8).Width = 47F;
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 37F;
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            this.fpSpread1.SetActiveViewport(1, 0);
            // 
            // ucRegLevel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.fpSpread1);
            this.Name = "ucRegLevel";
            this.Size = new System.Drawing.Size(567, 439);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

        private Neusoft.NFC.Interface.Controls.NeuSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
	}
}
