﻿namespace Neusoft.UFC.Registration
{
    partial class ucModifyRegInfo
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.neuPanel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.neuPanel2 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.ucRegPatientInfo1 = new Neusoft.UFC.Registration.ucRegPatientInfo();
            this.neuGroupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.lblIDNO = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtIDNO = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.tbCardNO = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuPanel1.SuspendLayout();
            this.neuPanel2.SuspendLayout();
            this.neuGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // neuPanel1
            // 
            this.neuPanel1.Controls.Add(this.neuPanel2);
            this.neuPanel1.Controls.Add(this.neuGroupBox1);
            this.neuPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.neuPanel1.Location = new System.Drawing.Point(0, 0);
            this.neuPanel1.Name = "neuPanel1";
            this.neuPanel1.Size = new System.Drawing.Size(695, 502);
            this.neuPanel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuPanel1.TabIndex = 0;
            // 
            // neuPanel2
            // 
            this.neuPanel2.Controls.Add(this.ucRegPatientInfo1);
            this.neuPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.neuPanel2.Location = new System.Drawing.Point(0, 49);
            this.neuPanel2.Name = "neuPanel2";
            this.neuPanel2.Size = new System.Drawing.Size(695, 453);
            this.neuPanel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuPanel2.TabIndex = 1;
            // 
            // ucRegPatientInfo1
            // 
            this.ucRegPatientInfo1.CardNO = "";
            this.ucRegPatientInfo1.CardType = "";
            this.ucRegPatientInfo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucRegPatientInfo1.IsPrint = false;
            this.ucRegPatientInfo1.IsShowButton = true;
            this.ucRegPatientInfo1.Location = new System.Drawing.Point(0, 0);
            this.ucRegPatientInfo1.MarkNO = "";
            this.ucRegPatientInfo1.Name = "ucRegPatientInfo1";
            this.ucRegPatientInfo1.Size = new System.Drawing.Size(695, 453);
            this.ucRegPatientInfo1.TabIndex = 0;
            // 
            // neuGroupBox1
            // 
            this.neuGroupBox1.Controls.Add(this.lblIDNO);
            this.neuGroupBox1.Controls.Add(this.txtIDNO);
            this.neuGroupBox1.Controls.Add(this.neuLabel1);
            this.neuGroupBox1.Controls.Add(this.tbCardNO);
            this.neuGroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.neuGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.neuGroupBox1.Name = "neuGroupBox1";
            this.neuGroupBox1.Size = new System.Drawing.Size(695, 49);
            this.neuGroupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox1.TabIndex = 0;
            this.neuGroupBox1.TabStop = false;
            // 
            // lblIDNO
            // 
            this.lblIDNO.AutoSize = true;
            this.lblIDNO.Location = new System.Drawing.Point(258, 24);
            this.lblIDNO.Name = "lblIDNO";
            this.lblIDNO.Size = new System.Drawing.Size(65, 12);
            this.lblIDNO.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblIDNO.TabIndex = 3;
            this.lblIDNO.Text = "身份证号：";
            // 
            // txtIDNO
            // 
            this.txtIDNO.IsEnter2Tab = false;
            this.txtIDNO.Location = new System.Drawing.Point(328, 20);
            this.txtIDNO.Name = "txtIDNO";
            this.txtIDNO.Size = new System.Drawing.Size(231, 21);
            this.txtIDNO.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtIDNO.TabIndex = 2;
            this.txtIDNO.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtIDNO_KeyDown);
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Location = new System.Drawing.Point(19, 23);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(41, 12);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 1;
            this.neuLabel1.Text = "病历号";
            // 
            // tbCardNO
            // 
            this.tbCardNO.IsEnter2Tab = false;
            this.tbCardNO.Location = new System.Drawing.Point(80, 20);
            this.tbCardNO.Name = "tbCardNO";
            this.tbCardNO.Size = new System.Drawing.Size(102, 21);
            this.tbCardNO.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.tbCardNO.TabIndex = 0;
            this.tbCardNO.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbCardNO_KeyDown);
            // 
            // ucModifyRegInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.neuPanel1);
            this.Name = "ucModifyRegInfo";
            this.Size = new System.Drawing.Size(695, 502);
            this.neuPanel1.ResumeLayout(false);
            this.neuPanel2.ResumeLayout(false);
            this.neuGroupBox1.ResumeLayout(false);
            this.neuGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuPanel neuPanel1;
        private Neusoft.NFC.Interface.Controls.NeuPanel neuPanel2;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox1;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuTextBox tbCardNO;
        private ucRegPatientInfo ucRegPatientInfo1;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblIDNO;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtIDNO;
    }
}
