using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
//{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
using Neusoft.HISFC.Object.Registration;

namespace Neusoft.UFC.Registration
{
    /// <summary>
    /// �˺�/ע��
    /// </summary>
    public partial class ucCancel : Neusoft.NFC.Interface.Controls.ucBaseControl, Neusoft.NFC.Interface.Forms.IInterfaceContainer//{B700292D-50A6-4cdf-8B03-F556F990BB9B}
    {
        public ucCancel()
        {
            InitializeComponent();

            this.fpSpread1.KeyDown += new KeyEventHandler(fpSpread1_KeyDown);
            this.txtInvoice.KeyDown += new KeyEventHandler(txtInvoice_KeyDown);
            this.txtCardNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCardNo_KeyDown);
            this.txtname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtname_KeyDown);
            this.fpSpread1.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(fpSpread1_SelectionChanged);

            this.Init();
        }

        #region ��
        /// <summary>
        /// �ҺŹ�����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Register regMgr = new Neusoft.HISFC.Management.Registration.Register();
        /// <summary>
        /// ���ƹ�����
        /// </summary>
        private Neusoft.NFC.Management.ControlParam ctlMgr = new Neusoft.NFC.Management.ControlParam();

        /// <summary>
        /// �Ű������
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Schema schMgr = new Neusoft.HISFC.Management.Registration.Schema();
        /// <summary>
        /// ����
        /// </summary>
        private Neusoft.HISFC.Integrate.Fee feeMgr = new Neusoft.HISFC.Integrate.Fee();
        /// <summary>
        /// ���������
        /// </summary>
        //private Neusoft.HISFC.Integrate assMgr = new neusoft.HISFC.Management.Nurse.Assign();
        /// <summary>
        /// ���˺�����
        /// </summary>
        private int PermitDays = 0;
        private ArrayList al = new ArrayList();

        //{DA67A335-E85E-46e1-A672-4DB409BCC11B}

        private bool isQuitAccount = false;

        //{C666B232-9973-4e4d-8A89-2F73729B2F28}
        private Neusoft.HISFC.Management.Fee.Account accountMgr = new Neusoft.HISFC.Management.Fee.Account();

        //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
        /// <summary>
        /// �Ƿ��ӡ�˺�Ʊ
        /// </summary>
        private bool isPrintBackBill = false;

        /// <summary>
        /// ���Ʋ���ҵ���
        /// </summary>
        protected Neusoft.HISFC.Integrate.Common.ControlParam controlParamIntegrate = new Neusoft.HISFC.Integrate.Common.ControlParam();

        /// <summary>
        /// ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
        /// </summary>
        private Hashtable hashNHPOS = new Hashtable();

        /// <summary>
        /// �Ƿ�ũ��POS�ӿ��˷�
        /// </summary>
        private bool IsNHPosBack = false;

        /// <summary>
        /// �Ƿ��������շѵ�ũ��POS�ӿ��˷�
        /// </summary>
        private bool IsZZJPosBack = false;

        #endregion
        //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
        #region ����
        [Category("�ؼ�����"), Description("�Ƿ��ӡ�˺�Ʊ"), DefaultValue(false)]
        public bool IsPrintBackBill
        {
            set
            {
                this.isPrintBackBill = value;
            }
            get
            {
                return this.isPrintBackBill;
            }
        }

        /// <summary>
        /// //{DA67A335-E85E-46e1-A672-4DB409BCC11B}
        /// </summary>
        [Category("�ؼ�����"), Description("�ʻ������Ƿ����ʻ�"), DefaultValue(false)]
        public bool IsQuitAccount
        {
            get { return isQuitAccount; }
            set { isQuitAccount = value; }
        }
        #region ��Ϣչʾ��չ�ӿ�

        /// <summary>
        /// ��Ϣչʾ��չ�ӿ� {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        /// </summary>
        private Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion iShowOperationInforamtion = null;

        /// <summary>
        /// ״̬�������Ƿ��ʼ���ɹ������Ϣչʾ��չ�ӿ�
        /// </summary>
        private bool isInitedIShowOperationInforamtion = false;

        #endregion
        #endregion
        #region ҽ���ӿ�
        /// <summary>
        /// ҽ���ӿڴ���������
        /// </summary>
        Neusoft.HISFC.Integrate.FeeInterface.MedcareInterfaceProxy medcareInterfaceProxy = new Neusoft.HISFC.Integrate.FeeInterface.MedcareInterfaceProxy();

        //����������
        string otherFeeType = string.Empty;
        #endregion

        #region ����
        /// <summary>
        /// ��ʼ��
        /// </summary>
        /// <returns></returns>
        private int Init()
        {
            this.IsNHPosBack = this.controlParamIntegrate.GetControlParam<bool>("NHPOS1", false, false);
            this.IsZZJPosBack = this.controlParamIntegrate.GetControlParam<bool>("ZZJ1", false, false);

            string Days = this.ctlMgr.QueryControlerInfo("400006");

            if (Days == null || Days == "" || Days == "-1")
            {
                this.PermitDays = 1;
            }
            else
            {
                this.PermitDays = int.Parse(Days);
            }

            //��ѯ����������
            //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
            Days = this.ctlMgr.QueryControlerInfo("400027");

            if (string.IsNullOrEmpty(Days))
            {
                Days = "2"; //Ĭ��������
            }

            this.otherFeeType = Days;

            if (this.otherFeeType == "1")
            {
                this.chbQuitFeeBookFee.Checked = false;//minqsh 20100603 �޸�Ϊfalse���Ϻ���ұ�������ղ������� {708443C7-3CAE-4ede-B69E-6C9CAFC9AECD}
                this.chbQuitFeeBookFee.Visible = true;
            }
            else
            {
                this.chbQuitFeeBookFee.Visible = false;
                this.chbQuitFeeBookFee.Checked = false;//minqsh 20100603 �޸�Ϊfalse���Ϻ���ұ�������ղ������� {708443C7-3CAE-4ede-B69E-6C9CAFC9AECD}
            }

            this.txtCardNo.Focus();

            return 0;
        }

        /// <summary>
        /// ���ӻ��߹Һ���ϸ
        /// </summary>
        /// <param name="registers"></param>
        private void addRegister(ArrayList registers)
        {
            if (this.fpSpread1_Sheet1.RowCount > 0)
                this.fpSpread1_Sheet1.Rows.Remove(0, this.fpSpread1_Sheet1.RowCount);

            Neusoft.HISFC.Object.Registration.Register obj;

            for (int i = registers.Count - 1; i >= 0; i--)
            {
                obj = (Neusoft.HISFC.Object.Registration.Register)registers[i];
                this.addRegister(obj);
            }
        }
        /// <summary>
        /// ������ʹ��ֱ���շ����ɵĺ��ٽ��йҺ�
        /// </summary>
        /// <param name="CardNO"></param>
        /// <returns></returns>
        private int ValidCardNO(string CardNO)
        {
            Neusoft.HISFC.Integrate.Common.ControlParam controlParams = new Neusoft.HISFC.Integrate.Common.ControlParam();

            string cardRule = controlParams.GetControlParam<string>(Neusoft.HISFC.Integrate.Const.NO_REG_CARD_RULES, false, "9");
            if (CardNO != "" && CardNO != string.Empty)
            {
                if (CardNO.Substring(0, 1) == cardRule)
                {
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�˺Ŷ�Ϊֱ���շ�ʹ�ã��������˺�"), Neusoft.NFC.Management.Language.Msg("��ʾ"));
                    return -1;
                }
            }
            return 1;
        }
        /// <summary>
        /// add a record to farpoint
        /// </summary>
        /// <param name="reg"></param>
        private void addRegister(Neusoft.HISFC.Object.Registration.Register reg)
        {
            this.fpSpread1_Sheet1.Rows.Add(this.fpSpread1_Sheet1.RowCount, 1);

            int cnt = this.fpSpread1_Sheet1.RowCount - 1;

            this.fpSpread1_Sheet1.SetValue(cnt, 0, reg.Name, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 1, reg.Sex.Name, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 2, reg.DoctorInfo.SeeDate.ToString(), false);
            this.fpSpread1_Sheet1.SetValue(cnt, 3, reg.DoctorInfo.Templet.Dept.Name, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 4, reg.DoctorInfo.Templet.RegLevel.Name, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 5, reg.DoctorInfo.Templet.Doct.Name, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 6, reg.RegLvlFee.RegFee, false);
            this.fpSpread1_Sheet1.SetValue(cnt, 7, reg.RegLvlFee.OwnDigFee + reg.RegLvlFee.ChkFee + reg.RegLvlFee.OthFee, false);
            this.fpSpread1_Sheet1.Rows[cnt].Tag = reg;

            if (reg.IsSee)
            {
                this.fpSpread1_Sheet1.Rows[cnt].BackColor = Color.LightCyan;
            }
            if (reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back ||
                reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Cancel)
            {
                this.fpSpread1_Sheet1.Rows[cnt].BackColor = Color.MistyRose;
            }
        }

        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        private int save()
        {
            #region ��֤
            if (this.fpSpread1_Sheet1.RowCount == 0)
            {
                MessageBox.Show("û�п��˹Һż�¼!", "��ʾ");
                return -1;
            }

            int row = this.fpSpread1_Sheet1.ActiveRowIndex;

            if (MessageBox.Show("�Ƿ�Ҫ���ϸùҺ���Ϣ?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.No)
                return -1;

            //ʵ��
            Neusoft.HISFC.Object.Registration.Register reg = (Neusoft.HISFC.Object.Registration.Register)this.fpSpread1_Sheet1.Rows[row].Tag;
            //{6D309EC1-0953-445d-8CD6-C635E739916B}  //�˺�ʱ�жϵ�ǰ�����Ƿ��ڱ�Ժ�ҵĺ�
            if (reg.Hospital.ID != ((Neusoft.HISFC.Object.Base.Employee)Neusoft.NFC.Management.Connection.Operator).Hospital.ID)
            {
                MessageBox.Show("��ǰ���˲����ڱ�Ժ�Һŵ�,�����˺�\r\n ��ǰ����ҽԺ���:" +
                               ((Neusoft.HISFC.Object.Base.Employee)Neusoft.NFC.Management.Connection.Operator).Hospital.ID + "\r\n �Һ�����ҽԺ���:" +
                               reg.Hospital.ID);
                return -1;
            }
            //{6D309EC1-0953-445d-8CD6-C635E739916B}
            #endregion

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction t = new Neusoft.NFC.Management.Transaction(this.regMgr.con);
            //t.BeginTransaction();

            this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.schMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.feeMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            //this.assMgr.SetTrans(t.Trans);

            int rtn;
            Neusoft.HISFC.Management.Registration.EnumUpdateStatus flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Cancel;

            try
            {
                DateTime current = this.regMgr.GetDateTimeFromSysDateTime();


                //���»�ȡ����ʵ��,��ֹ����

                reg = this.regMgr.GetByClinic(reg.ID);
                if (this.ValidCardNO(reg.PID.CardNO) < 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    return -1;
                }
                //����
                if (reg == null || reg.ID == null || reg.ID == "")
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }

                //ʹ��,��������
                //{05E82D53-9B25-44b1-902E-36F8FF4F50F3}
                if (reg.IsSee || reg.IsFee)
                {
                    //minqsh 20100613 ,��ұҪ��û�������û�������ѿ����˺� {41E72252-0F90-4ee5-AC91-13461F981512}
                    //string totCost = "";
                    //totCost = this.regMgr.QueryTotCostByClinicCode(reg.ID);
                    //if (!string.IsNullOrEmpty(totCost))
                    //{
                    //    if (Convert.ToDecimal(totCost) > 0)
                    //    {
                    //        Neusoft.NFC.Management.PublicTrans.RollBack();
                    //        MessageBox.Show("�ú��Ѿ��շ�,�����˷Ѻ�������!", "��ʾ");
                    //        return -1;
                    //    }
                    //}
                    //else
                    //{
                    //    Neusoft.NFC.Management.PublicTrans.RollBack();
                    //    MessageBox.Show("�ú��Ѿ�����,��������!", "��ʾ");
                    //    return -1;
                    //}
                    //{41E72252-0F90-4ee5-AC91-13461F981512}

                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ú��Ѿ�����,��������!", "��ʾ");
                    return -1;
                }

                //�Ƿ��Ѿ��˺�
                if (reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺż�¼�Ѿ��˺ţ������ٴ��˺�!", "��ʾ");
                    return -1;
                }

                //�Ƿ��Ѿ�����
                if (reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Cancel)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺż�¼�Ѿ����ϣ����ܽ����˺�!", "��ʾ");
                    return -1;
                }

                #region �ж��ǲ��������ʻ�����
                decimal vacancy = 0;
                int result = 0;
                reg.TranHospCode = regMgr.ExecSqlReturnOne("select t.tran_hosp_code from fin_opr_register t where t.clinic_code='" + reg.ID + "'");
                if (!string.IsNullOrEmpty(reg.TranHospCode)) // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                {
                    result = this.feeMgr.GetAccountVacancy(reg.TranHospCode, ref vacancy);
                    if (result < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.feeMgr.Err);
                        return -1;
                    }
                }

                //�˷��뻧 {C666B232-9973-4e4d-8A89-2F73729B2F28}
                bool isAccount = false;
                if (string.Equals(reg.IsAccount, "Y"))
                {
                    // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                    string cardNo = reg.PID.CardNO;
                    reg.PID.CardNO = reg.TranHospCode;
                    //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
                    Neusoft.HISFC.Object.Account.AccountRecord accRecord = accountMgr.GetAccountPayRecord(reg.PID.CardNO, reg.InvoiceNO, "R");
                    if (accRecord != null)
                    {
                        result = feeMgr.AccountCancelPay(reg, accRecord.Money, reg.InvoiceNO, reg.DoctorInfo.Templet.Dept.ID, "R");
                        if (result < 0)
                        {
                            MessageBox.Show(this.feeMgr.Err);
                            return -1;
                        }
                        isAccount = true;
                    }
                    // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                    reg.PID.CardNO = cardNo;
                    //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
                }
                #endregion

                #region �����ҺŵĻ����˺� {B42210EB-D925-4c60-A4FD-0E9580F8DAC5} YYTPOS
                bool isYL = false;//�Ƿ������˷ѽɷ�
                TZZYYLocal.HISFC.POS.Classes.EntFinOprPay op = new TZZYYLocal.HISFC.POS.Classes.EntFinOprPay();
                op.ClinicCode = reg.ID;
                if (op.SelectData() > 0 && op.ModeCode == "DB") //ʹ�������Һ� 68097fb1-038d-4aef-bb93-dd7fc744ca8d
                {
                    op.TotCost = reg.OwnCost;
                    if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked)
                    {
                        op.TotCost = reg.OwnCost - reg.RegLvlFee.OthFee;
                    }
                    op.RealCost = op.TotCost;                    
                    if (!TZZYYLocal.HISFC.POS.Classes.SoftPosAPI.CancleUnionpayFee(ref op))
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�����˷ѳ���!", "��ʾ");
                        return -1;
                    }

                    op.TransType = "2";
                    op.TotCost = op.TotCost * -1;
                    op.RealCost = op.RealCost * -1;
                    if (op.InsertData() < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("��������֧����ʽ����!", "��ʾ");
                        return -1;
                    }
                    isYL = true;
                }
                #endregion
                //{5839C7FC-8162-4586-8473-B5F26C018DDE}
                //if (reg.InputOper.ID == regMgr.Operator.ID && reg.BalanceOperStat.IsCheck == false && result == 0  )
                //{
                //    #region ����
                //    #endregion
                //}
                //else
                //{

                this.hashNHPOS = new Hashtable();

                //ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
                if (!string.IsNullOrEmpty(reg.PosPayMethod) && !string.IsNullOrEmpty(reg.PosTransOut) && reg.InputOper.ID != "999888")
                {
                    if (!this.IsNHPosBack)
                    {
                        reg.PosPayMethod = "";
                        reg.PosTransOut = "";
                        MessageBox.Show("��ũ��POS����ȡ�ĹҺŷѣ����ԡ��ֽ𡿵���ʽ�˷����ߣ�");
                    }
                    else
                    {
                        this.hashNHPOS.Add(reg.ID, reg);
                    }
                }

                // ���������ߣ��������������˷�  {F8F88942-90F1-4d7e-BCAB-1E2ED7FEA898}
                if (reg.InputOper.ID == "999888")
                {
                    if (!string.IsNullOrEmpty(reg.PosPayMethod) && !string.IsNullOrEmpty(reg.PosTransOut))
                    {
                        if (!this.IsZZJPosBack)
                        {
                            reg.IsZZJ = "0";
                            reg.PosPayMethod = "";
                            reg.PosTransOut = "";
                            MessageBox.Show("������������ȡ�ĹҺŷѣ����ԡ��ֽ𡿵���ʽ�˷����ߣ�");
                        }
                        else
                        {
                            this.hashNHPOS.Add(reg.ID, reg);
                        }
                    }
                }

                #region �˺�
                Neusoft.HISFC.Object.Registration.Register objReturn = reg.Clone();
                objReturn.RegLvlFee.ChkFee = -reg.RegLvlFee.ChkFee;//����
                objReturn.RegLvlFee.OwnDigFee = -reg.RegLvlFee.OwnDigFee;//����


                objReturn.RegLvlFee.OthFee = -reg.RegLvlFee.OthFee;//������
                objReturn.RegLvlFee.RegFee = -reg.RegLvlFee.RegFee;//�Һŷ�
                //{C666B232-9973-4e4d-8A89-2F73729B2F28}
                //if (result > 0) //���������ʻ��Ļ��ߣ��ʻ�ȫ���˵��Է���
                //{
                //    objReturn.OwnCost = -(reg.OwnCost + reg.PayCost);
                //    objReturn.PayCost = 0;
                //}
                //else
                //{
                objReturn.PayCost = -reg.PayCost;
                objReturn.OwnCost = -reg.OwnCost;
                //}
                objReturn.PubCost = -reg.PubCost;
                objReturn.BalanceOperStat.IsCheck = false;//�Ƿ����
                objReturn.BalanceOperStat.ID = "";
                objReturn.BalanceOperStat.Oper.ID = "";
                //objReturn.BeginTime = DateTime.MinValue; 
                objReturn.CheckOperStat.IsCheck = false;//�Ƿ�˲�
                objReturn.Status = Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back;//�˺�
                objReturn.InputOper.OperTime = current;//����ʱ��
                objReturn.InputOper.ID = regMgr.Operator.ID;//������
                objReturn.CancelOper.ID = regMgr.Operator.ID;//�˺���
                objReturn.CancelOper.OperTime = current;//�˺�ʱ��
                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                //objReturn.OwnCost = -reg.OwnCost;//�Է�
                //objReturn.PayCost = -reg.PayCost;
                objReturn.PubCost = -reg.PubCost;
                //���������Ѵ���
                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked)
                {
                    objReturn.OwnCost = objReturn.OwnCost - objReturn.RegLvlFee.OthFee;
                    objReturn.RegLvlFee.OthFee = 0;
                }
                #region �˷���ʾ 2010-12-11   ����  {F0887CFF-C0C8-4a5f-84A4-7AC331AF16FC}
                if (!isAccount && !isYL)
                {
                    DialogResult result1 = MessageBox.Show("�˸��ò��� " + (-objReturn.OwnCost).ToString() + " ��", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                    if (result1 == DialogResult.No)
                    {
                        MessageBox.Show("ȡ���˺ţ�");
                        return -1;
                    }
                }
                #endregion

                this.ShowOperationInformation(objReturn.Name, objReturn.Pact.Name, -objReturn.OwnCost);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}

                objReturn.TranType = Neusoft.HISFC.Object.Base.TransTypes.Negative;

                if (this.regMgr.Insert(objReturn) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }

                flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Return;
                #endregion
                //}

                reg.CancelOper.ID = regMgr.Operator.ID;
                reg.CancelOper.OperTime = current;

                //����ԭ����ĿΪ����
                rtn = this.regMgr.Update(flag, reg);
                if (rtn == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }
                if (rtn == 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺ���Ϣ״̬�Ѿ����,�����¼�������!", "��ʾ");
                    return -1;
                }

                //ȡ������4.5
                //if (this.assMgr.Delete(reg.ID) == -1)
                //{
                //    t.RollBack();
                //    MessageBox.Show("ɾ��������Ϣ����!" + this.assMgr.Err, "��ʾ");
                //    return -1;
                //}

                #region �ָ��޶�
                //�ָ�ԭ���Ű��޶�
                //���ԭ�������޶�,��ô�ָ��޶�
                if (reg.DoctorInfo.Templet.ID != null && reg.DoctorInfo.Templet.ID != "")
                {
                    //�ֳ��š�ԤԼ�š������

                    bool IsReged = false, IsTeled = false, IsSped = false;

                    if (reg.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)
                    {
                        IsTeled = true; //ԤԼ��
                    }
                    else if (reg.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Reg)
                    {
                        IsReged = true;//�ֳ���
                    }
                    else
                    {
                        IsSped = true;//�����
                    }

                    rtn = this.schMgr.Reduce(reg.DoctorInfo.Templet.ID, IsReged, false, IsTeled, IsSped);
                    if (rtn == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.schMgr.Err, "��ʾ");
                        return -1;
                    }

                    if (rtn == 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�����Ű���Ϣ,�޷��ָ��޶�!", "��ʾ");
                        return -1;
                    }
                }
                #endregion

                //ũ��POS�ӿ�      {F80A944F-B283-48df-B5A5-FAE127B84860}
                //�˴��ȴ��������˷ѡ�����ҽ���˷ѳɹ���Ȼ�������˷�ʧ�ܣ�����ҽ�������ˡ�
                //��������˷ѳɹ�������ҽ���˷�ʧ�ܡ����ں�̨���Ȱ�֧����ʽ�������ĳ��ֽ��˷���ϣ��ٰ�֧����ʽ���ֽ�Ļ�����
                if (this.DoNHPos(ref reg) < 1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    return -1;
                }

                long returnValue = 0;
                //Neusoft.HISFC.Object.Registration.Register myYBregObject = reg.Clone();
                this.medcareInterfaceProxy.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.medcareInterfaceProxy.SetPactCode(reg.Pact.ID);
                //��ʼ��ҽ��dll
                returnValue = this.medcareInterfaceProxy.Connect();
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ʼ��ʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                //����ȡ������Ϣ
                returnValue = this.medcareInterfaceProxy.GetRegInfoOutpatient(reg);
                if (returnValue == -1)
                {

                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ȡ������Ϣʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                //ҽ����Ϣ��ֵ
                //reg.SIMainInfo = myYBregObject.SIMainInfo;
                //�˺�
                reg.User01 = "-1";//�˺Ž���
                //����ĵ����˹Һŷ���{719DEE22-E3E3-4d3c-8711-829391BEA73C} by GengXiaoLei
                //returnValue = this.medcareInterfaceProxy.UploadRegInfoOutpatient(reg);
                returnValue = this.medcareInterfaceProxy.CancelRegInfoOutpatient(reg);
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�����˺�ʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                returnValue = this.medcareInterfaceProxy.Commit();
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�����˺��ύʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                this.medcareInterfaceProxy.Disconnect();

                Neusoft.NFC.Management.PublicTrans.Commit();
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show("�˺ų���!" + e.Message, "��ʾ");
                return -1;
            }

            this.fpSpread1_Sheet1.Rows.Remove(row, 1);
            //����Ѿ���ӡ��Ʊ,��ʾ�ջط�Ʊ
            MessageBox.Show("�˺ųɹ�!", "��ʾ");

            //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
            if (this.IsPrintBackBill)
            {
                //��ӡ���˺�Ʊ
                this.Print(reg);

            }
            this.Clear();

            return 0;
        }
        /// <summary>
        /// �Զ��˺�
        /// </summary>
        /// <param name="regReturn"></param>
        /// <returns></returns>
        public int saveCancel(Neusoft.HISFC.Object.Registration.Register regReturn)
        {
            #region ��֤
            

            //if (MessageBox.Show("�Ƿ�Ҫ���ϸùҺ���Ϣ?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
            //    MessageBoxDefaultButton.Button2) == DialogResult.No)
            //    return -1;

            //ʵ��
            Neusoft.HISFC.Object.Registration.Register reg = new Register();
            //{6D309EC1-0953-445d-8CD6-C635E739916B}  //�˺�ʱ�жϵ�ǰ�����Ƿ��ڱ�Ժ�ҵĺ�
            //if (regReturn.Hospital.ID != ((Neusoft.HISFC.Object.Base.Employee)Neusoft.NFC.Management.Connection.Operator).Hospital.ID)
            //{
            //    MessageBox.Show("��ǰ���˲����ڱ�Ժ�Һŵ�,�����˺�\r\n ��ǰ����ҽԺ���:" +
            //                   ((Neusoft.HISFC.Object.Base.Employee)Neusoft.NFC.Management.Connection.Operator).Hospital.ID + "\r\n �Һ�����ҽԺ���:" +
            //                   reg.Hospital.ID);
            //    return -1;
            //}
            //{6D309EC1-0953-445d-8CD6-C635E739916B}
            #endregion

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction t = new Neusoft.NFC.Management.Transaction(this.regMgr.con);
            //t.BeginTransaction();

            this.regMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.schMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            this.feeMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            //this.assMgr.SetTrans(t.Trans);

            int rtn;
            Neusoft.HISFC.Management.Registration.EnumUpdateStatus flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Cancel;

            try
            {
                DateTime current = this.regMgr.GetDateTimeFromSysDateTime();


                //���»�ȡ����ʵ��,��ֹ����

                reg = this.regMgr.GetByClinic(regReturn.ID);
                if (this.ValidCardNO(reg.PID.CardNO) < 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    return -1;
                }
                //����
                if (reg == null || reg.ID == null || reg.ID == "")
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }

                //ʹ��,��������
                //{05E82D53-9B25-44b1-902E-36F8FF4F50F3}
                if (reg.IsSee || reg.IsFee)
                {
                    //minqsh 20100613 ,��ұҪ��û�������û�������ѿ����˺� {41E72252-0F90-4ee5-AC91-13461F981512}
                    //string totCost = "";
                    //totCost = this.regMgr.QueryTotCostByClinicCode(reg.ID);
                    //if (!string.IsNullOrEmpty(totCost))
                    //{
                    //    if (Convert.ToDecimal(totCost) > 0)
                    //    {
                    //        Neusoft.NFC.Management.PublicTrans.RollBack();
                    //        MessageBox.Show("�ú��Ѿ��շ�,�����˷Ѻ�������!", "��ʾ");
                    //        return -1;
                    //    }
                    //}
                    //else
                    //{
                    //    Neusoft.NFC.Management.PublicTrans.RollBack();
                    //    MessageBox.Show("�ú��Ѿ�����,��������!", "��ʾ");
                    //    return -1;
                    //}
                    //{41E72252-0F90-4ee5-AC91-13461F981512}

                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ú��Ѿ�����,��������!", "��ʾ");
                    return -1;
                }

                //�Ƿ��Ѿ��˺�
                if (reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺż�¼�Ѿ��˺ţ������ٴ��˺�!", "��ʾ");
                    return -1;
                }

                //�Ƿ��Ѿ�����
                if (reg.Status == Neusoft.HISFC.Object.Base.EnumRegisterStatus.Cancel)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺż�¼�Ѿ����ϣ����ܽ����˺�!", "��ʾ");
                    return -1;
                }

                #region �ж��ǲ��������ʻ�����
                decimal vacancy = 0;
                int result = 0;
                reg.TranHospCode = regMgr.ExecSqlReturnOne("select t.tran_hosp_code from fin_opr_register t where t.clinic_code='" + reg.ID + "'");
                if (!string.IsNullOrEmpty(reg.TranHospCode)) // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                {
                    result = this.feeMgr.GetAccountVacancy(reg.TranHospCode, ref vacancy);
                    if (result < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.feeMgr.Err);
                        return -1;
                    }
                }

                //�˷��뻧 {C666B232-9973-4e4d-8A89-2F73729B2F28}
                bool isAccount = false;
                if (string.Equals(reg.IsAccount, "Y"))
                {
                    // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                    string cardNo = reg.PID.CardNO;
                    reg.PID.CardNO = reg.TranHospCode;
                    //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
                    Neusoft.HISFC.Object.Account.AccountRecord accRecord = accountMgr.GetAccountPayRecord(reg.PID.CardNO, reg.InvoiceNO, "R");
                    if (accRecord != null)
                    {
                        result = feeMgr.AccountCancelPay(reg, accRecord.Money, reg.InvoiceNO, reg.DoctorInfo.Templet.Dept.ID, "R");
                        if (result < 0)
                        {
                            MessageBox.Show(this.feeMgr.Err);
                            return -1;
                        }
                        isAccount = true;
                    }
                    // {3641A4A6-AE84-4324-BF42-A7D2F0796233} VIP��
                    reg.PID.CardNO = cardNo;
                    //end {3641A4A6-AE84-4324-BF42-A7D2F0796233}
                }
                #endregion

                #region �����ҺŵĻ����˺� {B42210EB-D925-4c60-A4FD-0E9580F8DAC5} YYTPOS
                bool isYL = false;//�Ƿ������˷ѽɷ�
                TZZYYLocal.HISFC.POS.Classes.EntFinOprPay op = new TZZYYLocal.HISFC.POS.Classes.EntFinOprPay();
                op.ClinicCode = reg.ID;
                if (op.SelectData() > 0 && op.ModeCode == "DB") //ʹ�������Һ� 68097fb1-038d-4aef-bb93-dd7fc744ca8d
                {
                    op.TotCost = reg.OwnCost;
                    if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked)
                    {
                        op.TotCost = reg.OwnCost - reg.RegLvlFee.OthFee;
                    }
                    op.RealCost = op.TotCost;
                    if (!TZZYYLocal.HISFC.POS.Classes.SoftPosAPI.CancleUnionpayFee(ref op))
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�����˷ѳ���!", "��ʾ");
                        return -1;
                    }

                    op.TransType = "2";
                    op.TotCost = op.TotCost * -1;
                    op.RealCost = op.RealCost * -1;
                    if (op.InsertData() < 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("��������֧����ʽ����!", "��ʾ");
                        return -1;
                    }
                    isYL = true;
                }
                #endregion
                //{5839C7FC-8162-4586-8473-B5F26C018DDE}
                //if (reg.InputOper.ID == regMgr.Operator.ID && reg.BalanceOperStat.IsCheck == false && result == 0  )
                //{
                //    #region ����
                //    #endregion
                //}
                //else
                //{

                this.hashNHPOS = new Hashtable();

                //ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
                if (!string.IsNullOrEmpty(reg.PosPayMethod) && !string.IsNullOrEmpty(reg.PosTransOut) && reg.InputOper.ID != "999888")
                {
                    if (!this.IsNHPosBack)
                    {
                        reg.PosPayMethod = "";
                        reg.PosTransOut = "";
                        MessageBox.Show("��ũ��POS����ȡ�ĹҺŷѣ����ԡ��ֽ𡿵���ʽ�˷����ߣ�");
                    }
                    else
                    {
                        this.hashNHPOS.Add(reg.ID, reg);
                    }
                }

                // ���������ߣ��������������˷�  {F8F88942-90F1-4d7e-BCAB-1E2ED7FEA898}
                if (reg.InputOper.ID == "999888")
                {
                    if (!string.IsNullOrEmpty(reg.PosPayMethod) && !string.IsNullOrEmpty(reg.PosTransOut))
                    {
                        if (!this.IsZZJPosBack)
                        {
                            reg.IsZZJ = "0";
                            reg.PosPayMethod = "";
                            reg.PosTransOut = "";
                            MessageBox.Show("������������ȡ�ĹҺŷѣ����ԡ��ֽ𡿵���ʽ�˷����ߣ�");
                        }
                        else
                        {
                            this.hashNHPOS.Add(reg.ID, reg);
                        }
                    }
                }

                #region �˺�
                Neusoft.HISFC.Object.Registration.Register objReturn = reg.Clone();
                objReturn.RegLvlFee.ChkFee = -reg.RegLvlFee.ChkFee;//����
                objReturn.RegLvlFee.OwnDigFee = -reg.RegLvlFee.OwnDigFee;//����


                objReturn.RegLvlFee.OthFee = -reg.RegLvlFee.OthFee;//������
                objReturn.RegLvlFee.RegFee = -reg.RegLvlFee.RegFee;//�Һŷ�
                //{C666B232-9973-4e4d-8A89-2F73729B2F28}
                //if (result > 0) //���������ʻ��Ļ��ߣ��ʻ�ȫ���˵��Է���
                //{
                //    objReturn.OwnCost = -(reg.OwnCost + reg.PayCost);
                //    objReturn.PayCost = 0;
                //}
                //else
                //{
                objReturn.PayCost = -reg.PayCost;
                objReturn.OwnCost = -reg.OwnCost;
                //}
                objReturn.PubCost = -reg.PubCost;
                objReturn.BalanceOperStat.IsCheck = false;//�Ƿ����
                objReturn.BalanceOperStat.ID = "";
                objReturn.BalanceOperStat.Oper.ID = "";
                //objReturn.BeginTime = DateTime.MinValue; 
                objReturn.CheckOperStat.IsCheck = false;//�Ƿ�˲�
                objReturn.Status = Neusoft.HISFC.Object.Base.EnumRegisterStatus.Back;//�˺�
                objReturn.InputOper.OperTime = current;//����ʱ��
                objReturn.InputOper.ID = regMgr.Operator.ID;//������
                objReturn.CancelOper.ID = regMgr.Operator.ID;//�˺���
                objReturn.CancelOper.OperTime = current;//�˺�ʱ��
                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                //objReturn.OwnCost = -reg.OwnCost;//�Է�
                //objReturn.PayCost = -reg.PayCost;
                objReturn.PubCost = -reg.PubCost;
                //���������Ѵ���
                //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
                if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked)
                {
                    objReturn.OwnCost = objReturn.OwnCost - objReturn.RegLvlFee.OthFee;
                    objReturn.RegLvlFee.OthFee = 0;
                }
                #region �˷���ʾ 2010-12-11   ����  {F0887CFF-C0C8-4a5f-84A4-7AC331AF16FC}
                if (!isAccount && !isYL)
                {
                    DialogResult result1 = MessageBox.Show("�˸��ò��� " + (-objReturn.OwnCost).ToString() + " ��", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                    if (result1 == DialogResult.No)
                    {
                        MessageBox.Show("ȡ���˺ţ�");
                        return -1;
                    }
                }
                #endregion

                this.ShowOperationInformation(objReturn.Name, objReturn.Pact.Name, -objReturn.OwnCost);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}

                objReturn.TranType = Neusoft.HISFC.Object.Base.TransTypes.Negative;

                if (this.regMgr.Insert(objReturn) == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }

                flag = Neusoft.HISFC.Management.Registration.EnumUpdateStatus.Return;
                #endregion
                //}

                reg.CancelOper.ID = regMgr.Operator.ID;
                reg.CancelOper.OperTime = current;

                //����ԭ����ĿΪ����
                rtn = this.regMgr.Update(flag, reg);
                if (rtn == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show(this.regMgr.Err, "��ʾ");
                    return -1;
                }
                if (rtn == 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("�ùҺ���Ϣ״̬�Ѿ����,�����¼�������!", "��ʾ");
                    return -1;
                }

                //ȡ������4.5
                //if (this.assMgr.Delete(reg.ID) == -1)
                //{
                //    t.RollBack();
                //    MessageBox.Show("ɾ��������Ϣ����!" + this.assMgr.Err, "��ʾ");
                //    return -1;
                //}

                #region �ָ��޶�
                //�ָ�ԭ���Ű��޶�
                //���ԭ�������޶�,��ô�ָ��޶�
                if (reg.DoctorInfo.Templet.ID != null && reg.DoctorInfo.Templet.ID != "")
                {
                    //�ֳ��š�ԤԼ�š������

                    bool IsReged = false, IsTeled = false, IsSped = false;

                    if (reg.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Pre)
                    {
                        IsTeled = true; //ԤԼ��
                    }
                    else if (reg.RegType == Neusoft.HISFC.Object.Base.EnumRegType.Reg)
                    {
                        IsReged = true;//�ֳ���
                    }
                    else
                    {
                        IsSped = true;//�����
                    }

                    rtn = this.schMgr.Reduce(reg.DoctorInfo.Templet.ID, IsReged, false, IsTeled, IsSped);
                    if (rtn == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show(this.schMgr.Err, "��ʾ");
                        return -1;
                    }

                    if (rtn == 0)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        MessageBox.Show("�����Ű���Ϣ,�޷��ָ��޶�!", "��ʾ");
                        return -1;
                    }
                }
                #endregion

                //ũ��POS�ӿ�      {F80A944F-B283-48df-B5A5-FAE127B84860}
                //�˴��ȴ��������˷ѡ�����ҽ���˷ѳɹ���Ȼ�������˷�ʧ�ܣ�����ҽ�������ˡ�
                //��������˷ѳɹ�������ҽ���˷�ʧ�ܡ����ں�̨���Ȱ�֧����ʽ�������ĳ��ֽ��˷���ϣ��ٰ�֧����ʽ���ֽ�Ļ�����
                if (this.DoNHPos(ref reg) < 1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    return -1;
                }

                long returnValue = 0;
                //Neusoft.HISFC.Object.Registration.Register myYBregObject = reg.Clone();
                this.medcareInterfaceProxy.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
                this.medcareInterfaceProxy.SetPactCode(reg.Pact.ID);
                //��ʼ��ҽ��dll
                returnValue = this.medcareInterfaceProxy.Connect();
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ʼ��ʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                //����ȡ������Ϣ
                returnValue = this.medcareInterfaceProxy.GetRegInfoOutpatient(reg);
                if (returnValue == -1)
                {

                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ȡ������Ϣʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                //ҽ����Ϣ��ֵ
                //reg.SIMainInfo = myYBregObject.SIMainInfo;
                //�˺�
                reg.User01 = "-1";//�˺Ž���
                //����ĵ����˹Һŷ���{719DEE22-E3E3-4d3c-8711-829391BEA73C} by GengXiaoLei
                //returnValue = this.medcareInterfaceProxy.UploadRegInfoOutpatient(reg);
                returnValue = this.medcareInterfaceProxy.CancelRegInfoOutpatient(reg);
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�����˺�ʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                returnValue = this.medcareInterfaceProxy.Commit();
                if (returnValue == -1)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    this.medcareInterfaceProxy.Rollback();
                    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("�����˺��ύʧ��") + this.medcareInterfaceProxy.ErrMsg);
                    return -1;
                }
                this.medcareInterfaceProxy.Disconnect();

                Neusoft.NFC.Management.PublicTrans.Commit();
            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                MessageBox.Show("�˺ų���!" + e.Message, "��ʾ");
                return -1;
            }

            //����Ѿ���ӡ��Ʊ,��ʾ�ջط�Ʊ
            MessageBox.Show("�˺ųɹ�!", "��ʾ");

            //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
            if (this.IsPrintBackBill)
            {
                //��ӡ���˺�Ʊ
                this.Print(reg);

            }
            this.Clear();

            return 0;
        }

        /// <summary>
        /// ũ�������ӿ�  {F80A944F-B283-48df-B5A5-FAE127B84860}
        /// </summary>
        /// <returns></returns>
        private int DoNHPos(ref Neusoft.HISFC.Object.Registration.Register reg)
        {
            if (this.hashNHPOS != null && this.hashNHPOS.Count > 0)
            {
                decimal posCost = reg.OwnCost;
                if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked)
                {
                    posCost = posCost - reg.RegLvlFee.OthFee;
                }

                Neusoft.TaiZhouABCBank.POS.Function posFunction = new Neusoft.TaiZhouABCBank.POS.Function();
                posFunction.InputListInfo.Clear();
                posFunction.InputListInfo.Add(posCost);//���
                posFunction.InputListInfo.Add(reg.PosPayMethod);//����֧����ʽ
                posFunction.InputListInfo.Add(reg.PosTransOut);//ԭ���׳���
                string err = string.Empty;
                if (posFunction.ReDo(ref err) < 1)
                {
                    MessageBox.Show("�����˷ѳ���!" + err, "��ʾ");
                    return -1;
                }

                reg.PosTransOut = posFunction.StrReturn;

                //����ũ��pos֧����Ϣ
                if (this.regMgr.UpdateRegisterForNHPOS(reg) == -1)
                {
                    //����ʧ�ܾ����ˣ������ı���־��
                }
            }

            return 1;
        }

        #region ��Ϣչʾ��չ�ӿ�
        /// <summary>
        /// ��Ϣչʾ��չ�ӿ� {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        /// </summary>
        /// <param name="register">�Һ�ʵ��</param>
        /// <param name="balanceList">�����б�</param>
        /// <param name="realCostInfo">֧����Ϣ�����е�MEMO���Դ�ŷ�ҩ������Ϣ</param>
        /// <param name="operCall">��������ö��</param>
        private void ShowOperationInformation(string patientName, string pactName, decimal money)
        {
            if (this.isInitedIShowOperationInforamtion == false)
            {
                this.isInitedIShowOperationInforamtion = true;
                this.iShowOperationInforamtion = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(), typeof(Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion)) as Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion;
            }

            if (this.iShowOperationInforamtion != null)
            {
                this.iShowOperationInforamtion.ReportBackCost(patientName, pactName, money);
            }
        }

        #endregion
        /// <summary>
        /// ����
        /// </summary>
        private void Clear()
        {
            if (this.fpSpread1_Sheet1.RowCount > 0)
                this.fpSpread1_Sheet1.Rows.Remove(0, this.fpSpread1_Sheet1.RowCount);

            this.txtCardNo.Text = "";
            this.txtInvoice.Text = "";
            this.lbTot.Text = "";
            this.lbReturn.Text = "";
            this.txtname.Text = "";
            this.txtCardNo.Focus();
        }

        /// <summary>
        /// ��ʾӦ�˹ҺŽ��
        /// </summary>
        /// <param name="row"></param>
        private void SetReturnFee(int row)
        {
            if (this.fpSpread1_Sheet1.RowCount <= 0) return;

            Neusoft.HISFC.Object.Registration.Register obj = (Neusoft.HISFC.Object.Registration.Register)this.fpSpread1_Sheet1.Rows[row].Tag;

            if (obj == null) return;

            decimal ownCost = 0;
            //����������
            //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
            if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked) //���˲�����
            {
                ownCost = obj.OwnCost - obj.RegLvlFee.OthFee;//��ȥ������
            }

            //{DA67A335-E85E-46e1-A672-4DB409BCC11B}
            //�ʻ�����
            if (!IsQuitAccount)
            {
                if (this.otherFeeType == "1" && !this.chbQuitFeeBookFee.Checked) //���˲�����
                {
                    ownCost = obj.OwnCost - obj.RegLvlFee.OthFee + obj.PayCost;//��ȥ������
                }
                else
                {
                    ownCost = obj.OwnCost + obj.PayCost;
                }
            }


            this.lbTot.Text = Convert.ToString(ownCost + obj.PayCost + obj.PubCost);
            this.lbReturn.Text = ownCost.ToString();
        }

        //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
        /// <summary>
        /// ��ӡ
        /// </summary>
        /// <param name="regObj"></param>
        private void Print(Neusoft.HISFC.Object.Registration.Register regObj)
        {

            Neusoft.HISFC.Integrate.Registration.IRegPrint regprint = null;
            regprint = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(), typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint)) as Neusoft.HISFC.Integrate.Registration.IRegPrint;

            if (regprint == null)
            {
                MessageBox.Show(Neusoft.NFC.Management.Language.Msg("��ӡƱ��ʧ��,���ڱ���ά����ά���˺�Ʊ"));
            }
            else
            {

                if (regObj.IsEncrypt)
                {
                    regObj.Name = Neusoft.NFC.Interface.Classes.Function.Decrypt3DES(regObj.NormalName);
                }

                regprint.SetPrintValue(regObj);
                regprint.Print();
            }



        }



        #endregion

        #region �¼�
        /// <summary>
        /// ������ݼ�
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessDialogKey(Keys keyData)
        {
            //if (keyData == Keys.F12)
            //{
            //    this.save();

            //    return true;
            //}
            //else if (keyData.GetHashCode() == Keys.Alt.GetHashCode() + Keys.X.GetHashCode())
            //{
            //    this.FindForm().Close();

            //    return true;
            //}
            //else if (keyData == Keys.Escape)
            //{
            //    this.FindForm().Close();

            //    return true;
            //}
            //else if (keyData == Keys.F8)
            //{
            //    this.Clear();

            //    return true;
            //}

            return base.ProcessDialogKey(keyData);
        }

        /// <summary>
        /// fp�س�
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fpSpread1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.save();
            }
        }

        private void fpSpread1_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            this.SetReturnFee(e.Range.Row);
        }

        /// <summary>
        /// ���ݲ����ż������߹Һ���Ϣ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCardNo_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.fpSpread1_Sheet1.RowCount > 0)
                    this.fpSpread1_Sheet1.Rows.Remove(0, this.fpSpread1_Sheet1.RowCount);
                string cardNo = this.txtCardNo.Text.Trim();
                if (cardNo == "")
                {
                    MessageBox.Show("�����Ų���Ϊ��!", "��ʾ");
                    this.txtCardNo.Focus();
                    return;
                }

                cardNo = cardNo.PadLeft(10, '0');

                //minqsh 20100602 {B8CBAC93-4E5B-46d9-82E3-9991279A1340} ��Ϊ�Ϻ�ҽ���������ϲ�������12λ��ϵͳֻ�ܴ�10λ���ĳ�ȡ��10λ
                cardNo = cardNo.Substring(cardNo.Length - 10, 10);

                this.txtCardNo.Text = cardNo;

                DateTime permitDate = this.regMgr.GetDateTimeFromSysDateTime().AddDays(-this.PermitDays).Date;
                //����������Ч��
                this.al = this.regMgr.Query(cardNo, permitDate);
                if (this.al == null)
                {
                    MessageBox.Show("�������߹Һ���Ϣʱ����!" + this.regMgr.Err, "��ʾ");
                    return;
                }

                if (this.al.Count == 0)
                {
                    MessageBox.Show("�û���û�п��˺�!", "��ʾ");
                    this.txtCardNo.Focus();
                    return;
                }
                else
                {
                    this.addRegister(al);

                    this.SetReturnFee(0);

                    this.fpSpread1.Focus();
                    this.fpSpread1_Sheet1.ActiveRowIndex = 0;
                    this.fpSpread1_Sheet1.AddSelection(0, 0, 1, 0);
                }
            }
        }
        /// ���ݼ������߹Һ���Ϣ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtname_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.fpSpread1_Sheet1.RowCount > 0)
                    this.fpSpread1_Sheet1.Rows.Remove(0, this.fpSpread1_Sheet1.RowCount);
                string name = this.txtname.Text.Trim();
                if (name == "")
                {
                    MessageBox.Show("��������Ϊ��!", "��ʾ");
                    this.txtname.Focus();
                    return;
                }

                this.txtname.Text = name;

                DateTime permitDate = this.regMgr.GetDateTimeFromSysDateTime().AddDays(-this.PermitDays).Date;
                //����������Ч��
                this.al = this.regMgr.Queryname(name, permitDate);
                if (this.al == null)
                {
                    MessageBox.Show("�������߹Һ���Ϣʱ����!" + this.regMgr.Err, "��ʾ");
                    return;
                }

                if (this.al.Count == 0)
                {
                    MessageBox.Show("�û���û�п��˺�!", "��ʾ");
                    this.txtname.Focus();
                    return;
                }
                else
                {
                    this.addRegister(al);

                    this.SetReturnFee(0);

                    this.fpSpread1.Focus();
                    this.fpSpread1_Sheet1.ActiveRowIndex = 0;
                    this.fpSpread1_Sheet1.AddSelection(0, 0, 1, 0);
                }
            }
        }

        /// <summary>
        /// ���ݴ����ż����Һ���Ϣ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtInvoice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string recipeNo = this.txtInvoice.Text.Trim();

                if (recipeNo == "")
                {
                    MessageBox.Show("�����Ų���Ϊ��!", "��ʾ");
                    this.txtInvoice.Focus();
                    return;
                }

                DateTime permitDate = this.regMgr.GetDateTimeFromSysDateTime().AddDays(-this.PermitDays).Date;
                //����������Ч��
                //{B6E76F4C-1D79-4fa2-ABAD-4A22DE89A6F7} by ţ��Ԫ
                //this.al = this.regMgr.QueryByRecipe(recipeNo);
                this.al = this.regMgr.QueryByRecipe(recipeNo);
                if (this.al == null)
                {
                    MessageBox.Show("�������߹Һ���Ϣʱ����!" + this.regMgr.Err, "��ʾ");
                    return;
                }

                ArrayList alRegCollection = new ArrayList();

                ///�Ƴ������޶�ʱ��ĹҺ���Ϣ
                ///
                foreach (Neusoft.HISFC.Object.Registration.Register obj in this.al)
                {
                    if (obj.DoctorInfo.SeeDate.Date < permitDate.Date) continue;

                    alRegCollection.Add(obj);
                }

                if (alRegCollection.Count == 0)
                {
                    MessageBox.Show("�޷�Ʊ��Ϊ��" + recipeNo + "�ĹҺ���Ϣ!", "��ʾ");
                    this.txtInvoice.Focus();
                    return;
                }
                else
                {
                    this.addRegister(alRegCollection);

                    this.SetReturnFee(0);

                    this.fpSpread1.Focus();
                    this.fpSpread1_Sheet1.ActiveRowIndex = 0;
                    this.fpSpread1_Sheet1.AddSelection(0, 0, 1, 0);
                }
            }
        }

        #endregion

        private Neusoft.NFC.Interface.Forms.ToolBarService toolbarService = new Neusoft.NFC.Interface.Forms.ToolBarService();

        protected override Neusoft.NFC.Interface.Forms.ToolBarService OnInit(object sender, object neuObject, object param)
        {
            toolbarService.AddToolButton("�˺�", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A����, true, false, null);
            toolbarService.AddToolButton("����", "", (int)Neusoft.NFC.Interface.Classes.EnumImageList.A���, true, false, null);

            return toolbarService;
        }

        public override void ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Text)
            {
                case "�˺�":
                    //if (txtCardNo.Text == null || txtCardNo.Text.Trim() == "")
                    //{
                    //    MessageBox.Show(Neusoft.NFC.Management.Language.Msg("���벡����"), Neusoft.NFC.Management.Language.Msg("��ʾ"));
                    //    return;
                    //}
                    e.ClickedItem.Enabled = false;
                    if (this.save() == -1)
                    {
                        e.ClickedItem.Enabled = true;
                        return;
                    }
                    e.ClickedItem.Enabled = true;

                    break;
                case "����":

                    this.Clear();

                    break;
            }

            base.ToolStrip_ItemClicked(sender, e);
        }

        private void txtCardNo_TextChanged(object sender, EventArgs e)
        {

        }

        #region IInterfaceContainer ��Ա
        //{B700292D-50A6-4cdf-8B03-F556F990BB9B}
        public Type[] InterfaceTypes
        {

            get
            {
                Type[] type = new Type[2];//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
                type[0] = typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint);
                type[1] = typeof(Neusoft.HISFC.Management.Interface.Common.IShowOperationInforamtion);//{0A344A96-E3DD-4a4d-A91E-C3E3714634F6}

                return type;
            }
        }

        #endregion
        //{F3258E87-7BCC-411a-865E-A9843AD2C6DD}
        private void chbQuitFeeBookFee_CheckedChanged(object sender, EventArgs e)
        {
            this.SetReturnFee(this.fpSpread1_Sheet1.ActiveRowIndex);
        }


    }
}
