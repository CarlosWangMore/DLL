﻿namespace Neusoft.UFC.Registration
{
	partial class ucSchema
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
            FarPoint.Win.Spread.TipAppearance tipAppearance1 = new FarPoint.Win.Spread.TipAppearance();
            FarPoint.Win.Spread.CellType.TextCellType textCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType2 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType5 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType6 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType7 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType1 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType2 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.NumberCellType numberCellType3 = new FarPoint.Win.Spread.CellType.NumberCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType8 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType9 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType10 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType11 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType12 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType13 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType14 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType15 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.groupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.label1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.fpSpread1 = new Neusoft.NFC.Interface.Controls.NeuSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.groupBox1.Location = new System.Drawing.Point(64, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 224);
            this.groupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(4, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 197);
            this.label1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label1.TabIndex = 0;
            // 
            // fpSpread1
            // 
            this.fpSpread1.About = "2.5.2007.2005";
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1";
            this.fpSpread1.BackColor = System.Drawing.SystemColors.Window;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.EditModePermanent = true;
            this.fpSpread1.EditModeReplace = true;
            this.fpSpread1.FileName = "";
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.IsAutoSaveGridStatus = false;
            this.fpSpread1.IsCanCustomConfigColumn = false;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(703, 497);
            this.fpSpread1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.fpSpread1.TabIndex = 0;
            tipAppearance1.BackColor = System.Drawing.SystemColors.Info;
            tipAppearance1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            tipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.fpSpread1.TextTipAppearance = tipAppearance1;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 25;
            this.fpSpread1_Sheet1.RowCount = 0;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "ID";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "DeptID";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "出诊科室";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "DoctID";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "出诊医生";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "医生类别";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "RegLevlCode";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "挂号级别";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 8).Value = "午别";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 9).Value = "开始时间";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 10).Value = "结束时间";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 11).Value = "挂号限额";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 12).Value = "预约限额";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 13).Value = "特诊限额";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 14).Value = "是否加号";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 15).Value = "是否有效";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 16).Value = "停诊原因代码";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 17).Value = "停诊原因";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 18).Value = "备注";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 19).Value = "来人已挂";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 20).Value = "预约数量";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 21).Value = "预约已挂";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 22).Value = "特诊已挂";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 23).Value = "StopID";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 24).Value = "StopDate";
            this.fpSpread1_Sheet1.ColumnHeader.Rows.Get(0).Height = 32F;
            this.fpSpread1_Sheet1.Columns.Get(0).CellType = textCellType1;
            this.fpSpread1_Sheet1.Columns.Get(0).Label = "ID";
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 50F;
            this.fpSpread1_Sheet1.Columns.Get(1).CellType = textCellType2;
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "DeptID";
            textCellType3.StringTrim = System.Drawing.StringTrimming.EllipsisCharacter;
            this.fpSpread1_Sheet1.Columns.Get(2).CellType = textCellType3;
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "出诊科室";
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 103F;
            this.fpSpread1_Sheet1.Columns.Get(3).CellType = textCellType4;
            this.fpSpread1_Sheet1.Columns.Get(3).Label = "DoctID";
            this.fpSpread1_Sheet1.Columns.Get(4).CellType = textCellType5;
            this.fpSpread1_Sheet1.Columns.Get(4).Label = "出诊医生";
            this.fpSpread1_Sheet1.Columns.Get(5).CellType = textCellType6;
            this.fpSpread1_Sheet1.Columns.Get(5).Label = "医生类别";
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 39F;
            textCellType7.StringTrim = System.Drawing.StringTrimming.EllipsisCharacter;
            this.fpSpread1_Sheet1.Columns.Get(8).CellType = textCellType7;
            this.fpSpread1_Sheet1.Columns.Get(8).Label = "午别";
            this.fpSpread1_Sheet1.Columns.Get(8).Width = 66F;
            numberCellType1.DecimalPlaces = 0;
            numberCellType1.MaximumValue = 9999;
            numberCellType1.MinimumValue = 0;
            this.fpSpread1_Sheet1.Columns.Get(11).CellType = numberCellType1;
            this.fpSpread1_Sheet1.Columns.Get(11).Label = "挂号限额";
            this.fpSpread1_Sheet1.Columns.Get(11).Width = 64F;
            numberCellType2.DecimalPlaces = 0;
            numberCellType2.MaximumValue = 9999;
            numberCellType2.MinimumValue = 0;
            this.fpSpread1_Sheet1.Columns.Get(12).CellType = numberCellType2;
            this.fpSpread1_Sheet1.Columns.Get(12).Label = "预约限额";
            numberCellType3.DecimalPlaces = 0;
            numberCellType3.MaximumValue = 9999;
            numberCellType3.MinimumValue = 0;
            this.fpSpread1_Sheet1.Columns.Get(13).CellType = numberCellType3;
            this.fpSpread1_Sheet1.Columns.Get(13).Label = "特诊限额";
            this.fpSpread1_Sheet1.Columns.Get(14).CellType = textCellType8;
            this.fpSpread1_Sheet1.Columns.Get(14).Label = "是否加号";
            this.fpSpread1_Sheet1.Columns.Get(14).Width = 36F;
            textCellType9.ReadOnly = true;
            this.fpSpread1_Sheet1.Columns.Get(15).CellType = textCellType9;
            this.fpSpread1_Sheet1.Columns.Get(15).Label = "是否有效";
            this.fpSpread1_Sheet1.Columns.Get(15).Width = 37F;
            this.fpSpread1_Sheet1.Columns.Get(17).CellType = textCellType10;
            this.fpSpread1_Sheet1.Columns.Get(17).Label = "停诊原因";
            this.fpSpread1_Sheet1.Columns.Get(18).CellType = textCellType11;
            this.fpSpread1_Sheet1.Columns.Get(18).Label = "备注";
            this.fpSpread1_Sheet1.Columns.Get(19).CellType = textCellType12;
            this.fpSpread1_Sheet1.Columns.Get(19).Label = "来人已挂";
            this.fpSpread1_Sheet1.Columns.Get(20).CellType = textCellType13;
            this.fpSpread1_Sheet1.Columns.Get(20).Label = "预约数量";
            this.fpSpread1_Sheet1.Columns.Get(21).CellType = textCellType14;
            this.fpSpread1_Sheet1.Columns.Get(21).Label = "预约已挂";
            textCellType15.ReadOnly = true;
            textCellType15.StringTrim = System.Drawing.StringTrimming.EllipsisCharacter;
            this.fpSpread1_Sheet1.Columns.Get(24).CellType = textCellType15;
            this.fpSpread1_Sheet1.Columns.Get(24).Label = "StopDate";
            this.fpSpread1_Sheet1.Columns.Get(24).Width = 129F;
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            this.fpSpread1.SetActiveViewport(1, 0);
            // 
            // ucSchema
            // 
            this.BackColor = System.Drawing.SystemColors.Window;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.fpSpread1);
            this.Name = "ucSchema";
            this.Size = new System.Drawing.Size(703, 497);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label1;
        private Neusoft.NFC.Interface.Controls.NeuSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
	}
}
