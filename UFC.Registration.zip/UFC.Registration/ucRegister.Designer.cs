﻿namespace Neusoft.UFC.Registration
{
    partial class ucRegister
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.TipAppearance tipAppearance2 = new FarPoint.Win.Spread.TipAppearance();
            FarPoint.Win.Spread.CellType.TextCellType textCellType3 = new FarPoint.Win.Spread.CellType.TextCellType();
            FarPoint.Win.Spread.CellType.TextCellType textCellType4 = new FarPoint.Win.Spread.CellType.TextCellType();
            this.panel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.panel3 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.fpSpread1 = new Neusoft.NFC.Interface.Controls.NeuSpread();
            this.neuContextMenuStrip1 = new Neusoft.NFC.Interface.Controls.NeuContextMenuStrip();
            this.fpRegLevel = new FarPoint.Win.Spread.SheetView();
            this.fpDept = new FarPoint.Win.Spread.SheetView();
            this.fpDoctor = new FarPoint.Win.Spread.SheetView();
            this.fpPayKind = new FarPoint.Win.Spread.SheetView();
            this.fpList = new FarPoint.Win.Spread.SheetView();
            this.lblRegInfo = new System.Windows.Forms.Label();
            this.splitter1 = new Neusoft.NFC.Interface.Controls.NeuSplitter();
            this.panel2 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.chbCardFee = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.cmbProfession = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.lblProfession = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtVIPNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbSiInformation = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lblDoctTip = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtIdNO = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.chbBookFee = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.tbSIBalanceCost = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.lblSIBalanceTEXT = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.chbEncrpt = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.lblTip = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTip = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.dtBirthday = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbReceive = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbSpe = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbSpeLmt = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label27 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbRegLmt = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label30 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTelLmt = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label32 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label22 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbReg = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label24 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTel = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label26 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label13 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbSum = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label21 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTot = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label12 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtPhone = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.llPd = new System.Windows.Forms.LinkLabel();
            this.txtOrder = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label20 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.dtEnd = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.dtBegin = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.lbWeek = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbDept = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.dtBookingDate = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.cmbDoctor = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label18 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbDept = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label16 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbUnit = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.txtAge = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label15 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.panel4 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.lbinvoiceno = new System.Windows.Forms.Label();
            this.lbinvoicename = new System.Windows.Forms.Label();
            this.label11 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtRecipeNo = new System.Windows.Forms.TextBox();
            this.label14 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtAddress = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label10 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label9 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtMcardNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label8 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbPayKind = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label7 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbSex = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label6 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtCardNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbDoct = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbRegLevel = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.lbRegLevel = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbCardType = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.label5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtTranHospCode = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label19 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTranHospCode = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtParentName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpRegLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpDept)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpDoctor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpPayKind)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpList)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.splitter1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 566);
            this.panel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fpSpread1);
            this.panel3.Controls.Add(this.lblRegInfo);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(493, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(299, 566);
            this.panel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel3.TabIndex = 2;
            // 
            // fpSpread1
            // 
            this.fpSpread1.About = "2.5.2007.2005";
            this.fpSpread1.AccessibleDescription = "fpSpread1, 已挂患者, Row 0, Column 0, ";
            this.fpSpread1.BackColor = System.Drawing.Color.White;
            this.fpSpread1.ContextMenuStrip = this.neuContextMenuStrip1;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FileName = "";
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.IsAutoSaveGridStatus = false;
            this.fpSpread1.IsCanCustomConfigColumn = false;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpRegLevel,
            this.fpDept,
            this.fpDoctor,
            this.fpPayKind,
            this.fpList});
            this.fpSpread1.Size = new System.Drawing.Size(299, 536);
            this.fpSpread1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.fpSpread1.TabIndex = 0;
            this.fpSpread1.TabStripRatio = 0.783109404990403;
            tipAppearance2.BackColor = System.Drawing.SystemColors.Info;
            tipAppearance2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            tipAppearance2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.fpSpread1.TextTipAppearance = tipAppearance2;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.ActiveSheetIndex = 4;
            // 
            // neuContextMenuStrip1
            // 
            this.neuContextMenuStrip1.Name = "neuContextMenuStrip1";
            this.neuContextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            this.neuContextMenuStrip1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            // 
            // fpRegLevel
            // 
            this.fpRegLevel.Reset();
            this.fpRegLevel.SheetName = "挂号级别";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpRegLevel.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpRegLevel.ColumnCount = 4;
            this.fpRegLevel.RowCount = 0;
            this.fpRegLevel.ColumnHeader.Cells.Get(0, 0).Value = "代码";
            this.fpRegLevel.ColumnHeader.Cells.Get(0, 1).Value = "挂号级别名称";
            this.fpRegLevel.Columns.Get(0).CellType = textCellType3;
            this.fpRegLevel.Columns.Get(0).Label = "代码";
            this.fpRegLevel.Columns.Get(0).Width = 53F;
            this.fpRegLevel.Columns.Get(1).CellType = textCellType4;
            this.fpRegLevel.Columns.Get(1).Label = "挂号级别名称";
            this.fpRegLevel.Columns.Get(1).Width = 118F;
            this.fpRegLevel.DataAutoCellTypes = false;
            this.fpRegLevel.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpRegLevel.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpRegLevel.RowHeader.Columns.Default.Resizable = true;
            this.fpRegLevel.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpRegLevel.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpRegLevel.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            this.fpSpread1.SetActiveViewport(1, 0);
            // 
            // fpDept
            // 
            this.fpDept.Reset();
            this.fpDept.SheetName = "挂号科室";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpDept.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpDept.ActiveColumnIndex = 3;
            this.fpDept.ActiveRowIndex = 17;
            this.fpDept.DataAutoCellTypes = false;
            this.fpDept.RowHeader.Columns.Default.Resizable = false;
            this.fpDept.RowHeader.Columns.Get(0).Width = 37F;
            this.fpDept.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpDoctor
            // 
            this.fpDoctor.Reset();
            this.fpDoctor.SheetName = "出诊教授";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpDoctor.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpDoctor.ActiveColumnIndex = 2;
            this.fpDoctor.ActiveRowIndex = 17;
            this.fpDoctor.DataAutoCellTypes = false;
            this.fpDoctor.RowHeader.Columns.Default.Resizable = true;
            this.fpDoctor.RowHeader.Columns.Get(0).Width = 37F;
            this.fpDoctor.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpPayKind
            // 
            this.fpPayKind.Reset();
            this.fpPayKind.SheetName = "结算类别";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpPayKind.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpPayKind.DataAutoCellTypes = false;
            this.fpPayKind.RowHeader.Columns.Default.Resizable = false;
            this.fpPayKind.RowHeader.Columns.Get(0).Width = 37F;
            this.fpPayKind.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // fpList
            // 
            this.fpList.Reset();
            this.fpList.SheetName = "已挂患者";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpList.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpList.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpList.RowHeader.Columns.Default.Resizable = false;
            this.fpList.RowHeader.Columns.Get(0).Width = 37F;
            this.fpList.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpList.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpList.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // lblRegInfo
            // 
            this.lblRegInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblRegInfo.Location = new System.Drawing.Point(0, 536);
            this.lblRegInfo.Name = "lblRegInfo";
            this.lblRegInfo.Size = new System.Drawing.Size(299, 30);
            this.lblRegInfo.TabIndex = 1;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(490, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 566);
            this.splitter1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.ContextMenuStrip = this.neuContextMenuStrip1;
            this.panel2.Controls.Add(this.txtParentName);
            this.panel2.Controls.Add(this.neuLabel3);
            this.panel2.Controls.Add(this.chbCardFee);
            this.panel2.Controls.Add(this.cmbProfession);
            this.panel2.Controls.Add(this.lblProfession);
            this.panel2.Controls.Add(this.txtVIPNo);
            this.panel2.Controls.Add(this.neuLabel2);
            this.panel2.Controls.Add(this.lbSiInformation);
            this.panel2.Controls.Add(this.lblDoctTip);
            this.panel2.Controls.Add(this.txtIdNO);
            this.panel2.Controls.Add(this.neuLabel1);
            this.panel2.Controls.Add(this.chbBookFee);
            this.panel2.Controls.Add(this.tbSIBalanceCost);
            this.panel2.Controls.Add(this.lblSIBalanceTEXT);
            this.panel2.Controls.Add(this.chbEncrpt);
            this.panel2.Controls.Add(this.lblTip);
            this.panel2.Controls.Add(this.lbTip);
            this.panel2.Controls.Add(this.dtBirthday);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.txtPhone);
            this.panel2.Controls.Add(this.llPd);
            this.panel2.Controls.Add(this.txtOrder);
            this.panel2.Controls.Add(this.linkLabel1);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.txtName);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.dtEnd);
            this.panel2.Controls.Add(this.dtBegin);
            this.panel2.Controls.Add(this.lbWeek);
            this.panel2.Controls.Add(this.cmbDept);
            this.panel2.Controls.Add(this.dtBookingDate);
            this.panel2.Controls.Add(this.cmbDoctor);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.lbDept);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.cmbUnit);
            this.panel2.Controls.Add(this.txtAge);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.txtAddress);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtMcardNo);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbPayKind);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.cmbSex);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtCardNo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lbDoct);
            this.panel2.Controls.Add(this.cmbRegLevel);
            this.panel2.Controls.Add(this.lbRegLevel);
            this.panel2.Controls.Add(this.cmbCardType);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtTranHospCode);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.lbTranHospCode);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(490, 566);
            this.panel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // chbCardFee
            // 
            this.chbCardFee.AutoSize = true;
            this.chbCardFee.ContextMenuStrip = this.neuContextMenuStrip1;
            this.chbCardFee.Font = new System.Drawing.Font("宋体", 10F);
            this.chbCardFee.Location = new System.Drawing.Point(384, 42);
            this.chbCardFee.Name = "chbCardFee";
            this.chbCardFee.Size = new System.Drawing.Size(68, 18);
            this.chbCardFee.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.chbCardFee.TabIndex = 48;
            this.chbCardFee.Text = "就诊卡";
            this.chbCardFee.UseVisualStyleBackColor = true;
            // 
            // cmbProfession
            // 
            this.cmbProfession.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbProfession.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbProfession.FormattingEnabled = true;
            this.cmbProfession.IsEnter2Tab = false;
            this.cmbProfession.IsFlat = true;
            this.cmbProfession.IsLike = true;
            this.cmbProfession.Location = new System.Drawing.Point(343, 392);
            this.cmbProfession.Name = "cmbProfession";
            this.cmbProfession.PopForm = null;
            this.cmbProfession.ShowCustomerList = false;
            this.cmbProfession.ShowID = false;
            this.cmbProfession.Size = new System.Drawing.Size(108, 23);
            this.cmbProfession.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbProfession.TabIndex = 46;
            this.cmbProfession.Tag = "";
            this.cmbProfession.ToolBarUse = false;
            // 
            // lblProfession
            // 
            this.lblProfession.AutoSize = true;
            this.lblProfession.Font = new System.Drawing.Font("宋体", 11F);
            this.lblProfession.Location = new System.Drawing.Point(266, 397);
            this.lblProfession.Name = "lblProfession";
            this.lblProfession.Size = new System.Drawing.Size(77, 15);
            this.lblProfession.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblProfession.TabIndex = 47;
            this.lblProfession.Text = "职    业:";
            // 
            // txtVIPNo
            // 
            this.txtVIPNo.Font = new System.Drawing.Font("宋体", 11F);
            this.txtVIPNo.IsEnter2Tab = false;
            this.txtVIPNo.Location = new System.Drawing.Point(113, 334);
            this.txtVIPNo.Name = "txtVIPNo";
            this.txtVIPNo.Size = new System.Drawing.Size(339, 24);
            this.txtVIPNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtVIPNo.TabIndex = 16;
            // 
            // neuLabel2
            // 
            this.neuLabel2.AutoSize = true;
            this.neuLabel2.Font = new System.Drawing.Font("宋体", 11F);
            this.neuLabel2.Location = new System.Drawing.Point(35, 339);
            this.neuLabel2.Name = "neuLabel2";
            this.neuLabel2.Size = new System.Drawing.Size(84, 15);
            this.neuLabel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel2.TabIndex = 45;
            this.neuLabel2.Text = "VIP 卡号：";
            // 
            // lbSiInformation
            // 
            this.lbSiInformation.AutoSize = true;
            this.lbSiInformation.ForeColor = System.Drawing.Color.Blue;
            this.lbSiInformation.Location = new System.Drawing.Point(23, 122);
            this.lbSiInformation.Name = "lbSiInformation";
            this.lbSiInformation.Size = new System.Drawing.Size(59, 12);
            this.lbSiInformation.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbSiInformation.TabIndex = 42;
            this.lbSiInformation.Text = "neuLabel2";
            this.lbSiInformation.Visible = false;
            // 
            // lblDoctTip
            // 
            this.lblDoctTip.AutoSize = true;
            this.lblDoctTip.ForeColor = System.Drawing.Color.Blue;
            this.lblDoctTip.Location = new System.Drawing.Point(44, 117);
            this.lblDoctTip.Name = "lblDoctTip";
            this.lblDoctTip.Size = new System.Drawing.Size(0, 12);
            this.lblDoctTip.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblDoctTip.TabIndex = 41;
            // 
            // txtIdNO
            // 
            this.txtIdNO.Font = new System.Drawing.Font("宋体", 11F);
            this.txtIdNO.IsEnter2Tab = false;
            this.txtIdNO.Location = new System.Drawing.Point(113, 392);
            this.txtIdNO.Name = "txtIdNO";
            this.txtIdNO.Size = new System.Drawing.Size(152, 24);
            this.txtIdNO.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtIdNO.TabIndex = 18;
            this.txtIdNO.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtIdNO_KeyDown);
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Font = new System.Drawing.Font("宋体", 11F);
            this.neuLabel1.Location = new System.Drawing.Point(35, 397);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(82, 15);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 40;
            this.neuLabel1.Text = "身份证号：";
            // 
            // chbBookFee
            // 
            this.chbBookFee.AutoSize = true;
            this.chbBookFee.ContextMenuStrip = this.neuContextMenuStrip1;
            this.chbBookFee.Font = new System.Drawing.Font("宋体", 10F);
            this.chbBookFee.Location = new System.Drawing.Point(264, 42);
            this.chbBookFee.Name = "chbBookFee";
            this.chbBookFee.Size = new System.Drawing.Size(68, 18);
            this.chbBookFee.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.chbBookFee.TabIndex = 39;
            this.chbBookFee.Text = "病历本";
            this.chbBookFee.UseVisualStyleBackColor = true;
            this.chbBookFee.CheckedChanged += new System.EventHandler(this.chbBookFee_CheckedChanged);
            // 
            // tbSIBalanceCost
            // 
            this.tbSIBalanceCost.Enabled = false;
            this.tbSIBalanceCost.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbSIBalanceCost.IsEnter2Tab = false;
            this.tbSIBalanceCost.Location = new System.Drawing.Point(343, 419);
            this.tbSIBalanceCost.Name = "tbSIBalanceCost";
            this.tbSIBalanceCost.Size = new System.Drawing.Size(108, 26);
            this.tbSIBalanceCost.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.tbSIBalanceCost.TabIndex = 20;
            // 
            // lblSIBalanceTEXT
            // 
            this.lblSIBalanceTEXT.AutoSize = true;
            this.lblSIBalanceTEXT.Font = new System.Drawing.Font("宋体", 11F);
            this.lblSIBalanceTEXT.Location = new System.Drawing.Point(264, 425);
            this.lblSIBalanceTEXT.Name = "lblSIBalanceTEXT";
            this.lblSIBalanceTEXT.Size = new System.Drawing.Size(82, 15);
            this.lblSIBalanceTEXT.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblSIBalanceTEXT.TabIndex = 37;
            this.lblSIBalanceTEXT.Text = "账户余额：";
            // 
            // chbEncrpt
            // 
            this.chbEncrpt.AutoSize = true;
            this.chbEncrpt.Location = new System.Drawing.Point(38, 44);
            this.chbEncrpt.Name = "chbEncrpt";
            this.chbEncrpt.Size = new System.Drawing.Size(48, 16);
            this.chbEncrpt.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.chbEncrpt.TabIndex = 36;
            this.chbEncrpt.Text = "加密";
            this.chbEncrpt.UseVisualStyleBackColor = true;
            // 
            // lblTip
            // 
            this.lblTip.AutoSize = true;
            this.lblTip.ForeColor = System.Drawing.Color.Blue;
            this.lblTip.Location = new System.Drawing.Point(23, 485);
            this.lblTip.Name = "lblTip";
            this.lblTip.Size = new System.Drawing.Size(293, 12);
            this.lblTip.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lblTip.TabIndex = 35;
            this.lblTip.Text = "友情提示：窗口点击鼠标右键可以设置默认汉字输入法";
            // 
            // lbTip
            // 
            this.lbTip.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTip.ForeColor = System.Drawing.Color.Red;
            this.lbTip.Location = new System.Drawing.Point(303, 182);
            this.lbTip.Name = "lbTip";
            this.lbTip.Size = new System.Drawing.Size(149, 23);
            this.lbTip.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTip.TabIndex = 34;
            // 
            // dtBirthday
            // 
            this.dtBirthday.CustomFormat = "yyyy-MM-dd";
            this.dtBirthday.Font = new System.Drawing.Font("宋体", 11F);
            this.dtBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBirthday.IsEnter2Tab = false;
            this.dtBirthday.Location = new System.Drawing.Point(343, 275);
            this.dtBirthday.Name = "dtBirthday";
            this.dtBirthday.Size = new System.Drawing.Size(108, 24);
            this.dtBirthday.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtBirthday.TabIndex = 13;
            this.dtBirthday.Value = new System.DateTime(2006, 6, 12, 10, 52, 27, 812);
            this.dtBirthday.ValueChanged += new System.EventHandler(this.dtBirthday_ValueChanged);
            // 
            // panel5
            // 
            this.panel5.ContextMenuStrip = this.neuContextMenuStrip1;
            this.panel5.Controls.Add(this.lbReceive);
            this.panel5.Controls.Add(this.lbSpe);
            this.panel5.Controls.Add(this.lbSpeLmt);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.lbRegLmt);
            this.panel5.Controls.Add(this.label30);
            this.panel5.Controls.Add(this.lbTelLmt);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.lbReg);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.lbTel);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lbSum);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.lbTot);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 474);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(490, 92);
            this.panel5.TabIndex = 33;
            // 
            // lbReceive
            // 
            this.lbReceive.AutoSize = true;
            this.lbReceive.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbReceive.ForeColor = System.Drawing.Color.Blue;
            this.lbReceive.Location = new System.Drawing.Point(406, 8);
            this.lbReceive.Name = "lbReceive";
            this.lbReceive.Size = new System.Drawing.Size(0, 15);
            this.lbReceive.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbReceive.TabIndex = 0;
            this.lbReceive.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbSpe
            // 
            this.lbSpe.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbSpe.Location = new System.Drawing.Point(405, 65);
            this.lbSpe.Name = "lbSpe";
            this.lbSpe.Size = new System.Drawing.Size(43, 22);
            this.lbSpe.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbSpe.TabIndex = 32;
            this.lbSpe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbSpeLmt
            // 
            this.lbSpeLmt.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbSpeLmt.Location = new System.Drawing.Point(405, 34);
            this.lbSpeLmt.Name = "lbSpeLmt";
            this.lbSpeLmt.Size = new System.Drawing.Size(43, 25);
            this.lbSpeLmt.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbSpeLmt.TabIndex = 38;
            this.lbSpeLmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("宋体", 11F);
            this.label27.Location = new System.Drawing.Point(325, 38);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 27);
            this.label27.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label27.TabIndex = 37;
            this.label27.Text = "特诊限额：";
            // 
            // lbRegLmt
            // 
            this.lbRegLmt.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbRegLmt.Location = new System.Drawing.Point(113, 34);
            this.lbRegLmt.Name = "lbRegLmt";
            this.lbRegLmt.Size = new System.Drawing.Size(46, 25);
            this.lbRegLmt.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbRegLmt.TabIndex = 40;
            this.lbRegLmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("宋体", 11F);
            this.label30.Location = new System.Drawing.Point(35, 38);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(100, 27);
            this.label30.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label30.TabIndex = 39;
            this.label30.Text = "挂号限额：";
            // 
            // lbTelLmt
            // 
            this.lbTelLmt.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbTelLmt.Location = new System.Drawing.Point(261, 34);
            this.lbTelLmt.Name = "lbTelLmt";
            this.lbTelLmt.Size = new System.Drawing.Size(47, 25);
            this.lbTelLmt.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTelLmt.TabIndex = 36;
            this.lbTelLmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("宋体", 11F);
            this.label32.Location = new System.Drawing.Point(183, 38);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 27);
            this.label32.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label32.TabIndex = 35;
            this.label32.Text = "预约限额：";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("宋体", 11F);
            this.label22.Location = new System.Drawing.Point(325, 69);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 24);
            this.label22.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label22.TabIndex = 31;
            this.label22.Text = "特诊已挂：";
            // 
            // lbReg
            // 
            this.lbReg.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbReg.Location = new System.Drawing.Point(113, 65);
            this.lbReg.Name = "lbReg";
            this.lbReg.Size = new System.Drawing.Size(46, 22);
            this.lbReg.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbReg.TabIndex = 34;
            this.lbReg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("宋体", 11F);
            this.label24.Location = new System.Drawing.Point(35, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 24);
            this.label24.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label24.TabIndex = 33;
            this.label24.Text = "现场已挂：";
            // 
            // lbTel
            // 
            this.lbTel.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbTel.Location = new System.Drawing.Point(261, 65);
            this.lbTel.Name = "lbTel";
            this.lbTel.Size = new System.Drawing.Size(47, 22);
            this.lbTel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTel.TabIndex = 30;
            this.lbTel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("宋体", 11F);
            this.label26.Location = new System.Drawing.Point(183, 69);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(100, 24);
            this.label26.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label26.TabIndex = 29;
            this.label26.Text = "预约已挂：";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("宋体", 11F);
            this.label13.Location = new System.Drawing.Point(324, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 32);
            this.label13.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label13.TabIndex = 0;
            this.label13.Text = "应    收：";
            // 
            // lbSum
            // 
            this.lbSum.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbSum.ForeColor = System.Drawing.Color.Blue;
            this.lbSum.Location = new System.Drawing.Point(113, 2);
            this.lbSum.Name = "lbSum";
            this.lbSum.Size = new System.Drawing.Size(46, 25);
            this.lbSum.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbSum.TabIndex = 28;
            this.lbSum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 11F);
            this.label21.Location = new System.Drawing.Point(3, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 22);
            this.label21.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label21.TabIndex = 27;
            this.label21.Text = "有效挂号总数：";
            this.label21.UseCompatibleTextRendering = true;
            // 
            // lbTot
            // 
            this.lbTot.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.lbTot.ForeColor = System.Drawing.Color.Blue;
            this.lbTot.Location = new System.Drawing.Point(283, 2);
            this.lbTot.Name = "lbTot";
            this.lbTot.Size = new System.Drawing.Size(47, 25);
            this.lbTot.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTot.TabIndex = 0;
            this.lbTot.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("宋体", 11F);
            this.label12.Location = new System.Drawing.Point(183, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 27);
            this.label12.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label12.TabIndex = 0;
            this.label12.Text = "自付比例：";
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPhone.Font = new System.Drawing.Font("宋体", 11F);
            this.txtPhone.IsEnter2Tab = false;
            this.txtPhone.Location = new System.Drawing.Point(343, 304);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(108, 24);
            this.txtPhone.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtPhone.TabIndex = 15;
            // 
            // llPd
            // 
            this.llPd.Location = new System.Drawing.Point(303, 148);
            this.llPd.Name = "llPd";
            this.llPd.Size = new System.Drawing.Size(72, 15);
            this.llPd.TabIndex = 30;
            this.llPd.TabStop = true;
            this.llPd.Text = "(PageDown)";
            // 
            // txtOrder
            // 
            this.txtOrder.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtOrder.Font = new System.Drawing.Font("宋体", 11F);
            this.txtOrder.IsEnter2Tab = false;
            this.txtOrder.Location = new System.Drawing.Point(343, 89);
            this.txtOrder.Name = "txtOrder";
            this.txtOrder.Size = new System.Drawing.Size(108, 24);
            this.txtOrder.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtOrder.TabIndex = 4;
            // 
            // linkLabel1
            // 
            this.linkLabel1.Font = new System.Drawing.Font("宋体", 9F);
            this.linkLabel1.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.Location = new System.Drawing.Point(459, 98);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(25, 15);
            this.linkLabel1.TabIndex = 29;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "F11";
            this.linkLabel1.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Location = new System.Drawing.Point(8, 209);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(464, 2);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "患者信息";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.Font = new System.Drawing.Font("宋体", 11F);
            this.txtName.IsEnter2Tab = false;
            this.txtName.Location = new System.Drawing.Point(343, 218);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(108, 24);
            this.txtName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtName.TabIndex = 8;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 11F);
            this.label20.Location = new System.Drawing.Point(264, 223);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 15);
            this.label20.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label20.TabIndex = 24;
            this.label20.Text = "姓    名：";
            // 
            // dtEnd
            // 
            this.dtEnd.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtEnd.CalendarFont = new System.Drawing.Font("宋体", 9F);
            this.dtEnd.CustomFormat = "HH:mm";
            this.dtEnd.Font = new System.Drawing.Font("宋体", 11F);
            this.dtEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtEnd.IsEnter2Tab = false;
            this.dtEnd.Location = new System.Drawing.Point(213, 179);
            this.dtEnd.Name = "dtEnd";
            this.dtEnd.ShowUpDown = true;
            this.dtEnd.Size = new System.Drawing.Size(78, 24);
            this.dtEnd.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtEnd.TabIndex = 6;
            // 
            // dtBegin
            // 
            this.dtBegin.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtBegin.CalendarFont = new System.Drawing.Font("宋体", 9F);
            this.dtBegin.CustomFormat = "HH:mm";
            this.dtBegin.Font = new System.Drawing.Font("宋体", 11F);
            this.dtBegin.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBegin.IsEnter2Tab = false;
            this.dtBegin.Location = new System.Drawing.Point(113, 179);
            this.dtBegin.Name = "dtBegin";
            this.dtBegin.ShowUpDown = true;
            this.dtBegin.Size = new System.Drawing.Size(78, 24);
            this.dtBegin.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtBegin.TabIndex = 5;
            // 
            // lbWeek
            // 
            this.lbWeek.BackColor = System.Drawing.SystemColors.Window;
            this.lbWeek.Location = new System.Drawing.Point(220, 149);
            this.lbWeek.Name = "lbWeek";
            this.lbWeek.Size = new System.Drawing.Size(43, 15);
            this.lbWeek.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbWeek.TabIndex = 21;
            this.lbWeek.Text = "星期一";
            // 
            // cmbDept
            // 
            this.cmbDept.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDept.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbDept.IsEnter2Tab = false;
            this.cmbDept.IsFlat = false;
            this.cmbDept.IsLike = true;
            this.cmbDept.Location = new System.Drawing.Point(343, 63);
            this.cmbDept.Name = "cmbDept";
            this.cmbDept.PopForm = null;
            this.cmbDept.ShowCustomerList = false;
            this.cmbDept.ShowID = false;
            this.cmbDept.Size = new System.Drawing.Size(108, 23);
            this.cmbDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDept.TabIndex = 1;
            this.cmbDept.Tag = "";
            this.cmbDept.ToolBarUse = false;
            // 
            // dtBookingDate
            // 
            this.dtBookingDate.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dtBookingDate.CustomFormat = "yyyy-MM-dd";
            this.dtBookingDate.Font = new System.Drawing.Font("宋体", 11F);
            this.dtBookingDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtBookingDate.IsEnter2Tab = false;
            this.dtBookingDate.Location = new System.Drawing.Point(113, 143);
            this.dtBookingDate.Name = "dtBookingDate";
            this.dtBookingDate.ShowUpDown = true;
            this.dtBookingDate.Size = new System.Drawing.Size(178, 24);
            this.dtBookingDate.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtBookingDate.TabIndex = 4;
            // 
            // cmbDoctor
            // 
            this.cmbDoctor.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbDoctor.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbDoctor.IsEnter2Tab = false;
            this.cmbDoctor.IsFlat = false;
            this.cmbDoctor.IsLike = true;
            this.cmbDoctor.Location = new System.Drawing.Point(113, 90);
            this.cmbDoctor.Name = "cmbDoctor";
            this.cmbDoctor.PopForm = null;
            this.cmbDoctor.ShowCustomerList = false;
            this.cmbDoctor.ShowID = false;
            this.cmbDoctor.Size = new System.Drawing.Size(108, 23);
            this.cmbDoctor.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbDoctor.TabIndex = 2;
            this.cmbDoctor.Tag = "";
            this.cmbDoctor.ToolBarUse = false;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("宋体", 11F);
            this.label18.Location = new System.Drawing.Point(35, 182);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 23);
            this.label18.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label18.TabIndex = 18;
            this.label18.Text = "预约时段：";
            // 
            // lbDept
            // 
            this.lbDept.Font = new System.Drawing.Font("宋体", 11F);
            this.lbDept.Location = new System.Drawing.Point(260, 66);
            this.lbDept.Name = "lbDept";
            this.lbDept.Size = new System.Drawing.Size(83, 23);
            this.lbDept.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbDept.TabIndex = 16;
            this.lbDept.Text = "挂号科室：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 11F);
            this.label16.Location = new System.Drawing.Point(264, 309);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 15);
            this.label16.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label16.TabIndex = 13;
            this.label16.Text = "联系电话：";
            // 
            // cmbUnit
            // 
            this.cmbUnit.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUnit.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbUnit.IsEnter2Tab = false;
            this.cmbUnit.IsFlat = false;
            this.cmbUnit.IsLike = true;
            this.cmbUnit.Items.AddRange(new object[] {
            "岁",
            "月",
            "天"});
            this.cmbUnit.Location = new System.Drawing.Point(165, 276);
            this.cmbUnit.Name = "cmbUnit";
            this.cmbUnit.PopForm = null;
            this.cmbUnit.ShowCustomerList = false;
            this.cmbUnit.ShowID = false;
            this.cmbUnit.Size = new System.Drawing.Size(56, 23);
            this.cmbUnit.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbUnit.TabIndex = 12;
            this.cmbUnit.Tag = "";
            this.cmbUnit.ToolBarUse = false;
            // 
            // txtAge
            // 
            this.txtAge.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAge.Font = new System.Drawing.Font("宋体", 11F);
            this.txtAge.IsEnter2Tab = false;
            this.txtAge.Location = new System.Drawing.Point(113, 275);
            this.txtAge.MaxLength = 3;
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(49, 24);
            this.txtAge.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtAge.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 11F);
            this.label15.Location = new System.Drawing.Point(264, 280);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 15);
            this.label15.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label15.TabIndex = 0;
            this.label15.Text = "出生日期：";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Controls.Add(this.lbinvoiceno);
            this.panel4.Controls.Add(this.lbinvoicename);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.txtRecipeNo);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(490, 37);
            this.panel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel4.TabIndex = 0;
            // 
            // lbinvoiceno
            // 
            this.lbinvoiceno.AutoSize = true;
            this.lbinvoiceno.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbinvoiceno.ForeColor = System.Drawing.Color.Red;
            this.lbinvoiceno.Location = new System.Drawing.Point(52, 14);
            this.lbinvoiceno.Name = "lbinvoiceno";
            this.lbinvoiceno.Size = new System.Drawing.Size(0, 16);
            this.lbinvoiceno.TabIndex = 4;
            // 
            // lbinvoicename
            // 
            this.lbinvoicename.AutoSize = true;
            this.lbinvoicename.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbinvoicename.Location = new System.Drawing.Point(3, 15);
            this.lbinvoicename.Name = "lbinvoicename";
            this.lbinvoicename.Size = new System.Drawing.Size(49, 14);
            this.lbinvoicename.TabIndex = 3;
            this.lbinvoicename.Text = "发票号";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(349, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 19);
            this.label11.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label11.TabIndex = 2;
            this.label11.Text = "N&o";
            // 
            // txtRecipeNo
            // 
            this.txtRecipeNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRecipeNo.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.txtRecipeNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRecipeNo.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold);
            this.txtRecipeNo.ForeColor = System.Drawing.Color.Yellow;
            this.txtRecipeNo.Location = new System.Drawing.Point(381, 14);
            this.txtRecipeNo.MaxLength = 10;
            this.txtRecipeNo.Name = "txtRecipeNo";
            this.txtRecipeNo.ReadOnly = true;
            this.txtRecipeNo.Size = new System.Drawing.Size(89, 17);
            this.txtRecipeNo.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label14.Location = new System.Drawing.Point(168, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 23);
            this.label14.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label14.TabIndex = 0;
            this.label14.Text = "门诊挂号";
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAddress.Font = new System.Drawing.Font("宋体", 11F);
            this.txtAddress.IsEnter2Tab = false;
            this.txtAddress.Location = new System.Drawing.Point(113, 363);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(339, 24);
            this.txtAddress.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtAddress.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 11F);
            this.label10.Location = new System.Drawing.Point(35, 368);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 15);
            this.label10.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label10.TabIndex = 0;
            this.label10.Text = "地    址：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 11F);
            this.label9.Location = new System.Drawing.Point(35, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 15);
            this.label9.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label9.TabIndex = 0;
            this.label9.Text = "年    龄：";
            // 
            // txtMcardNo
            // 
            this.txtMcardNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtMcardNo.Font = new System.Drawing.Font("宋体", 11F);
            this.txtMcardNo.IsEnter2Tab = false;
            this.txtMcardNo.Location = new System.Drawing.Point(113, 304);
            this.txtMcardNo.Name = "txtMcardNo";
            this.txtMcardNo.Size = new System.Drawing.Size(108, 24);
            this.txtMcardNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtMcardNo.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 11F);
            this.label8.Location = new System.Drawing.Point(35, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 15);
            this.label8.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label8.TabIndex = 0;
            this.label8.Text = "医疗证号：";
            // 
            // cmbPayKind
            // 
            this.cmbPayKind.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbPayKind.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbPayKind.FormattingEnabled = true;
            this.cmbPayKind.IsEnter2Tab = false;
            this.cmbPayKind.IsFlat = true;
            this.cmbPayKind.IsLike = true;
            this.cmbPayKind.Location = new System.Drawing.Point(343, 247);
            this.cmbPayKind.Name = "cmbPayKind";
            this.cmbPayKind.PopForm = null;
            this.cmbPayKind.ShowCustomerList = false;
            this.cmbPayKind.ShowID = false;
            this.cmbPayKind.Size = new System.Drawing.Size(108, 23);
            this.cmbPayKind.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbPayKind.TabIndex = 10;
            this.cmbPayKind.Tag = "";
            this.cmbPayKind.ToolBarUse = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 11F);
            this.label7.Location = new System.Drawing.Point(264, 251);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label7.TabIndex = 0;
            this.label7.Text = "人员类别：";
            // 
            // cmbSex
            // 
            this.cmbSex.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbSex.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbSex.IsEnter2Tab = false;
            this.cmbSex.IsFlat = false;
            this.cmbSex.IsLike = true;
            this.cmbSex.Location = new System.Drawing.Point(113, 247);
            this.cmbSex.Name = "cmbSex";
            this.cmbSex.PopForm = null;
            this.cmbSex.ShowCustomerList = false;
            this.cmbSex.ShowID = false;
            this.cmbSex.Size = new System.Drawing.Size(108, 23);
            this.cmbSex.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbSex.TabIndex = 9;
            this.cmbSex.Tag = "";
            this.cmbSex.ToolBarUse = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 11F);
            this.label6.Location = new System.Drawing.Point(35, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 15);
            this.label6.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label6.TabIndex = 0;
            this.label6.Text = "性    别：";
            // 
            // txtCardNo
            // 
            this.txtCardNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCardNo.Font = new System.Drawing.Font("宋体", 11F);
            this.txtCardNo.IsEnter2Tab = false;
            this.txtCardNo.Location = new System.Drawing.Point(113, 218);
            this.txtCardNo.MaxLength = 1000;
            this.txtCardNo.Name = "txtCardNo";
            this.txtCardNo.Size = new System.Drawing.Size(108, 24);
            this.txtCardNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtCardNo.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 11F);
            this.label4.Location = new System.Drawing.Point(35, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 15);
            this.label4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label4.TabIndex = 0;
            this.label4.Text = "病 历 号：";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("宋体", 11F);
            this.label3.Location = new System.Drawing.Point(34, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label3.TabIndex = 0;
            this.label3.Text = "预约日期：";
            // 
            // lbDoct
            // 
            this.lbDoct.Font = new System.Drawing.Font("宋体", 11F);
            this.lbDoct.Location = new System.Drawing.Point(34, 91);
            this.lbDoct.Name = "lbDoct";
            this.lbDoct.Size = new System.Drawing.Size(83, 23);
            this.lbDoct.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbDoct.TabIndex = 0;
            this.lbDoct.Text = "教授代码：";
            // 
            // cmbRegLevel
            // 
            this.cmbRegLevel.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbRegLevel.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbRegLevel.IsEnter2Tab = false;
            this.cmbRegLevel.IsFlat = false;
            this.cmbRegLevel.IsLike = true;
            this.cmbRegLevel.Location = new System.Drawing.Point(113, 63);
            this.cmbRegLevel.Name = "cmbRegLevel";
            this.cmbRegLevel.PopForm = null;
            this.cmbRegLevel.ShowCustomerList = false;
            this.cmbRegLevel.ShowID = false;
            this.cmbRegLevel.Size = new System.Drawing.Size(108, 23);
            this.cmbRegLevel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbRegLevel.TabIndex = 0;
            this.cmbRegLevel.Tag = "";
            this.cmbRegLevel.ToolBarUse = false;
            this.cmbRegLevel.SelectedIndexChanged += new System.EventHandler(this.cmbRegLevel_SelectedIndexChanged_1);
            // 
            // lbRegLevel
            // 
            this.lbRegLevel.Font = new System.Drawing.Font("宋体", 11F);
            this.lbRegLevel.Location = new System.Drawing.Point(34, 66);
            this.lbRegLevel.Name = "lbRegLevel";
            this.lbRegLevel.Size = new System.Drawing.Size(83, 23);
            this.lbRegLevel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbRegLevel.TabIndex = 0;
            this.lbRegLevel.Text = "挂号类别：";
            // 
            // cmbCardType
            // 
            this.cmbCardType.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbCardType.Font = new System.Drawing.Font("宋体", 11F);
            this.cmbCardType.IsEnter2Tab = false;
            this.cmbCardType.IsFlat = false;
            this.cmbCardType.IsLike = true;
            this.cmbCardType.ItemHeight = 15;
            this.cmbCardType.Location = new System.Drawing.Point(113, 421);
            this.cmbCardType.Name = "cmbCardType";
            this.cmbCardType.PopForm = null;
            this.cmbCardType.ShowCustomerList = false;
            this.cmbCardType.ShowID = false;
            this.cmbCardType.Size = new System.Drawing.Size(108, 23);
            this.cmbCardType.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbCardType.TabIndex = 19;
            this.cmbCardType.Tag = "";
            this.cmbCardType.ToolBarUse = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 11F);
            this.label5.Location = new System.Drawing.Point(35, 425);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 15);
            this.label5.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label5.TabIndex = 32;
            this.label5.Text = "证件类别：";
            // 
            // txtTranHospCode
            // 
            this.txtTranHospCode.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtTranHospCode.Font = new System.Drawing.Font("宋体", 11F);
            this.txtTranHospCode.IsEnter2Tab = false;
            this.txtTranHospCode.Location = new System.Drawing.Point(343, 89);
            this.txtTranHospCode.Name = "txtTranHospCode";
            this.txtTranHospCode.Size = new System.Drawing.Size(108, 24);
            this.txtTranHospCode.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtTranHospCode.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 11F);
            this.label19.Location = new System.Drawing.Point(260, 94);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 15);
            this.label19.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label19.TabIndex = 19;
            this.label19.Text = "流 水 号：";
            // 
            // lbTranHospCode
            // 
            this.lbTranHospCode.AutoSize = true;
            this.lbTranHospCode.Font = new System.Drawing.Font("宋体", 11F);
            this.lbTranHospCode.Location = new System.Drawing.Point(260, 94);
            this.lbTranHospCode.Name = "lbTranHospCode";
            this.lbTranHospCode.Size = new System.Drawing.Size(82, 15);
            this.lbTranHospCode.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTranHospCode.TabIndex = 43;
            this.lbTranHospCode.Text = "转诊单号：";
            // 
            // neuLabel3
            // 
            this.neuLabel3.AutoSize = true;
            this.neuLabel3.Font = new System.Drawing.Font("宋体", 11F);
            this.neuLabel3.Location = new System.Drawing.Point(35, 456);
            this.neuLabel3.Name = "neuLabel3";
            this.neuLabel3.Size = new System.Drawing.Size(82, 15);
            this.neuLabel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel3.TabIndex = 49;
            this.neuLabel3.Text = "家长姓名：";
            // 
            // txtParentName
            // 
            this.txtParentName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtParentName.Font = new System.Drawing.Font("宋体", 11F);
            this.txtParentName.IsEnter2Tab = false;
            this.txtParentName.Location = new System.Drawing.Point(113, 453);
            this.txtParentName.Name = "txtParentName";
            this.txtParentName.Size = new System.Drawing.Size(108, 24);
            this.txtParentName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtParentName.TabIndex = 50;
            // 
            // ucRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.panel1);
            this.Name = "ucRegister";
            this.Size = new System.Drawing.Size(792, 566);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpRegLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpDept)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpDoctor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpPayKind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpList)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
                
        private Neusoft.NFC.Interface.Controls.NeuPanel panel1;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel2;
        private Neusoft.NFC.Interface.Controls.NeuSplitter splitter1;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel3;
        private Neusoft.NFC.Interface.Controls.NeuSpread fpSpread1;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbRegLevel;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDept;
        private Neusoft.NFC.Interface.Controls.NeuLabel label3;
        private Neusoft.NFC.Interface.Controls.NeuLabel label4;
        private Neusoft.NFC.Interface.Controls.NeuLabel label6;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbSex;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtName;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCardNo;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbDoctor;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbPayKind;
        private Neusoft.NFC.Interface.Controls.NeuLabel label7;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtMcardNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel label8;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtPhone;
        private Neusoft.NFC.Interface.Controls.NeuLabel label9;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtAddress;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel4;
        private Neusoft.NFC.Interface.Controls.NeuLabel label12;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTot;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbReceive;
        private Neusoft.NFC.Interface.Controls.NeuLabel label13;
        private FarPoint.Win.Spread.SheetView fpRegLevel;
        private FarPoint.Win.Spread.SheetView fpDept;
        private Neusoft.NFC.Interface.Controls.NeuLabel label14;
        private FarPoint.Win.Spread.SheetView fpPayKind;
        private FarPoint.Win.Spread.SheetView fpDoctor;
        private Neusoft.NFC.Interface.Controls.NeuLabel label15;
        private FarPoint.Win.Spread.SheetView fpList;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbUnit;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtAge;
        private Neusoft.NFC.Interface.Controls.NeuLabel label10;
        private Neusoft.NFC.Interface.Controls.NeuLabel label16;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbCardType;
        private Neusoft.NFC.Interface.Controls.NeuLabel label18;
        private Neusoft.NFC.Interface.Controls.NeuLabel label19;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBookingDate;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbWeek;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBegin;
        private Neusoft.NFC.Interface.Controls.NeuLabel label20;
        private System.Windows.Forms.GroupBox groupBox1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label21;        
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtEnd;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbSum;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtOrder;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label5;
        private System.Windows.Forms.Panel panel5;
        private Neusoft.NFC.Interface.Controls.NeuLabel label24;
        private Neusoft.NFC.Interface.Controls.NeuLabel label26;
        private Neusoft.NFC.Interface.Controls.NeuLabel label27;
        private Neusoft.NFC.Interface.Controls.NeuLabel label30;
        private Neusoft.NFC.Interface.Controls.NeuLabel label32;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbSpeLmt;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbRegLmt;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTelLmt;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbReg;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTel;
        private System.Windows.Forms.LinkLabel llPd;
        private Neusoft.NFC.Interface.Controls.NeuLabel label22;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbSpe;
        private System.Windows.Forms.TextBox txtRecipeNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel label11;        
        private Neusoft.NFC.Interface.Controls.NeuLabel lbDept;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbDoct;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbRegLevel;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtBirthday;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTip;
        private Neusoft.NFC.Interface.Controls.NeuContextMenuStrip neuContextMenuStrip1;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblTip;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox chbEncrpt;
        private Neusoft.NFC.Interface.Controls.NeuTextBox tbSIBalanceCost;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblSIBalanceTEXT;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox chbBookFee;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtIdNO;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblDoctTip;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbSiInformation;
        private System.Windows.Forms.Label lbinvoicename;
        private System.Windows.Forms.Label lbinvoiceno;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTranHospCode;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtTranHospCode;
        private System.Windows.Forms.Label lblRegInfo;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtVIPNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel2;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbProfession;
        private Neusoft.NFC.Interface.Controls.NeuLabel lblProfession;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox chbCardFee;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtParentName;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel3;
    }
}
