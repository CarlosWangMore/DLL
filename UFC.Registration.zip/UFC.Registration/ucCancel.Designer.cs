﻿namespace Neusoft.UFC.Registration
{
    partial class ucCancel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.TipAppearance tipAppearance1 = new FarPoint.Win.Spread.TipAppearance();
            this.panel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.panel3 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.fpSpread1 = new Neusoft.NFC.Interface.Controls.NeuSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.splitter2 = new Neusoft.NFC.Interface.Controls.NeuSplitter();
            this.panel4 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.chbQuitFeeBookFee = new Neusoft.NFC.Interface.Controls.NeuCheckBox();
            this.groupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.txtCardNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtInvoice = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.splitter1 = new Neusoft.NFC.Interface.Controls.NeuSplitter();
            this.panel2 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.lbReturn = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label7 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.lbTot = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.label4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtname = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.splitter2);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.splitter1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 516);
            this.panel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fpSpread1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(710, 426);
            this.panel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel3.TabIndex = 6;
            // 
            // fpSpread1
            // 
            this.fpSpread1.About = "2.5.2007.2005";
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1";
            this.fpSpread1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FileName = "";
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.IsAutoSaveGridStatus = false;
            this.fpSpread1.IsCanCustomConfigColumn = false;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(710, 426);
            this.fpSpread1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.fpSpread1.TabIndex = 0;
            tipAppearance1.BackColor = System.Drawing.SystemColors.Info;
            tipAppearance1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            tipAppearance1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.fpSpread1.TextTipAppearance = tipAppearance1;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 8;
            this.fpSpread1_Sheet1.RowCount = 0;
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "姓名";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "性别";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 2).Value = "挂号日期";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 3).Value = "挂号科室";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 4).Value = "挂号级别";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 5).Value = "看诊医生";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 6).Value = "挂号费";
            this.fpSpread1_Sheet1.ColumnHeader.Cells.Get(0, 7).Value = "诊金";
            this.fpSpread1_Sheet1.Columns.Get(0).Label = "姓名";
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 79F;
            this.fpSpread1_Sheet1.Columns.Get(1).Label = "性别";
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 45F;
            this.fpSpread1_Sheet1.Columns.Get(2).Label = "挂号日期";
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 152F;
            this.fpSpread1_Sheet1.Columns.Get(3).Label = "挂号科室";
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 82F;
            this.fpSpread1_Sheet1.Columns.Get(4).Label = "挂号级别";
            this.fpSpread1_Sheet1.Columns.Get(4).Width = 74F;
            this.fpSpread1_Sheet1.Columns.Get(5).Label = "看诊医生";
            this.fpSpread1_Sheet1.Columns.Get(5).Width = 92F;
            this.fpSpread1_Sheet1.Columns.Get(6).Label = "挂号费";
            this.fpSpread1_Sheet1.Columns.Get(6).Width = 67F;
            this.fpSpread1_Sheet1.Columns.Get(7).Label = "诊金";
            this.fpSpread1_Sheet1.Columns.Get(7).Width = 71F;
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.SystemColors.Window;
            this.fpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            this.fpSpread1.SetActiveViewport(1, 0);
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter2.Location = new System.Drawing.Point(0, 37);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(710, 3);
            this.splitter2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.splitter2.TabIndex = 5;
            this.splitter2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtname);
            this.panel4.Controls.Add(this.neuLabel1);
            this.panel4.Controls.Add(this.chbQuitFeeBookFee);
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Controls.Add(this.txtCardNo);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.txtInvoice);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(710, 37);
            this.panel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel4.TabIndex = 4;
            // 
            // chbQuitFeeBookFee
            // 
            this.chbQuitFeeBookFee.AutoSize = true;
            this.chbQuitFeeBookFee.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chbQuitFeeBookFee.ForeColor = System.Drawing.Color.Red;
            this.chbQuitFeeBookFee.Location = new System.Drawing.Point(663, 13);
            this.chbQuitFeeBookFee.Name = "chbQuitFeeBookFee";
            this.chbQuitFeeBookFee.Size = new System.Drawing.Size(89, 16);
            this.chbQuitFeeBookFee.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.chbQuitFeeBookFee.TabIndex = 5;
            this.chbQuitFeeBookFee.Text = "退病历本费";
            this.chbQuitFeeBookFee.UseVisualStyleBackColor = true;
            this.chbQuitFeeBookFee.CheckedChanged += new System.EventHandler(this.chbQuitFeeBookFee_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("宋体", 1F);
            this.groupBox1.Location = new System.Drawing.Point(0, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(710, 2);
            this.groupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // txtCardNo
            // 
            this.txtCardNo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCardNo.IsEnter2Tab = false;
            this.txtCardNo.Location = new System.Drawing.Point(97, 8);
            this.txtCardNo.Name = "txtCardNo";
            this.txtCardNo.Size = new System.Drawing.Size(100, 21);
            this.txtCardNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtCardNo.TabIndex = 0;
            this.txtCardNo.TextChanged += new System.EventHandler(this.txtCardNo_TextChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(41, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label1.TabIndex = 4;
            this.label1.Text = "病历号";
            // 
            // txtInvoice
            // 
            this.txtInvoice.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtInvoice.IsEnter2Tab = false;
            this.txtInvoice.Location = new System.Drawing.Point(320, 8);
            this.txtInvoice.Name = "txtInvoice";
            this.txtInvoice.Size = new System.Drawing.Size(100, 21);
            this.txtInvoice.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtInvoice.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(251, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label3.TabIndex = 3;
            this.label3.Text = "发票号";
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(710, 37);
            this.label2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label2.TabIndex = 2;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 466);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(710, 3);
            this.splitter1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbReturn);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.lbTot);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 469);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(710, 47);
            this.panel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.panel2.TabIndex = 0;
            // 
            // lbReturn
            // 
            this.lbReturn.BackColor = System.Drawing.SystemColors.Info;
            this.lbReturn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbReturn.Font = new System.Drawing.Font("宋体", 12F);
            this.lbReturn.ForeColor = System.Drawing.Color.Red;
            this.lbReturn.Location = new System.Drawing.Point(320, 12);
            this.lbReturn.Name = "lbReturn";
            this.lbReturn.Size = new System.Drawing.Size(100, 23);
            this.lbReturn.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbReturn.TabIndex = 0;
            this.lbReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(248, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 20);
            this.label7.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label7.TabIndex = 0;
            this.label7.Text = "应退金额";
            // 
            // lbTot
            // 
            this.lbTot.BackColor = System.Drawing.SystemColors.Info;
            this.lbTot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbTot.Font = new System.Drawing.Font("宋体", 12F);
            this.lbTot.Location = new System.Drawing.Point(97, 12);
            this.lbTot.Name = "lbTot";
            this.lbTot.Size = new System.Drawing.Size(100, 23);
            this.lbTot.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.lbTot.TabIndex = 0;
            this.lbTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(25, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label5.TabIndex = 0;
            this.label5.Text = "合计金额";
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(710, 47);
            this.label4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.label4.TabIndex = 0;
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Location = new System.Drawing.Point(443, 11);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(29, 12);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 6;
            this.neuLabel1.Text = "姓名";
            // 
            // txtname
            // 
            this.txtname.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtname.IsEnter2Tab = false;
            this.txtname.Location = new System.Drawing.Point(490, 8);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(118, 21);
            this.txtname.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtname.TabIndex = 7;
            // 
            // ucCancel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.Controls.Add(this.panel1);
            this.Name = "ucCancel";
            this.Size = new System.Drawing.Size(710, 516);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
                
        private Neusoft.NFC.Interface.Controls.NeuPanel panel1;        
        private Neusoft.NFC.Interface.Controls.NeuPanel panel2;
        private Neusoft.NFC.Interface.Controls.NeuSplitter splitter1;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel4;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtCardNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel label1;        
        private Neusoft.NFC.Interface.Controls.NeuLabel label2;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtInvoice;
        private Neusoft.NFC.Interface.Controls.NeuLabel label3;
        private Neusoft.NFC.Interface.Controls.NeuSplitter splitter2;
        private Neusoft.NFC.Interface.Controls.NeuPanel panel3;
        private Neusoft.NFC.Interface.Controls.NeuSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox groupBox1;
        private Neusoft.NFC.Interface.Controls.NeuLabel label4;        
        private Neusoft.NFC.Interface.Controls.NeuLabel label5;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbTot;
        private Neusoft.NFC.Interface.Controls.NeuLabel lbReturn;
        private Neusoft.NFC.Interface.Controls.NeuLabel label7;
        private Neusoft.NFC.Interface.Controls.NeuCheckBox chbQuitFeeBookFee;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtname;        
    }
}
