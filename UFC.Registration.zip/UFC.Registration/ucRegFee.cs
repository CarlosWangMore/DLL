using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Neusoft.UFC.Registration
{
    /// <summary>
    /// �Һŷ�ά��
    /// </summary>
    public partial class ucRegFee : Neusoft.NFC.Interface.Controls.ucBaseControl
    {
        public ucRegFee()
        {
            InitializeComponent();

            this.Load += new EventHandler(ucRegFee_Load);
            this.treeView1.AfterSelect += new TreeViewEventHandler(treeView1_AfterSelect);
            this.treeView1.BeforeSelect += new TreeViewCancelEventHandler(treeView1_BeforeSelect);
        }

        #region ������
        /// <summary>
        /// �Һŷѹ�����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.RegLvlFee regFeeMgr = new Neusoft.HISFC.Management.Registration.RegLvlFee();
        private Neusoft.HISFC.Management.Registration.RegLevel regMgr = new Neusoft.HISFC.Management.Registration.RegLevel();

        private ArrayList al;
        private ArrayList alLevel;
        private DataTable dtRegFee = new DataTable();
        private string levelName;
        private List<Neusoft.HISFC.Object.Fee.Item.Undrug> alItem; //modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
        #endregion

        #region ��ʼ��
        /// <summary>
        /// Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ucRegFee_Load(object sender, EventArgs e)
        {
            this.InitTree();
            this.InitRegLevl();
            this.InitDataTable();
            using (Neusoft.HISFC.Management.Fee.Item itemMgr = new Neusoft.HISFC.Management.Fee.Item())
            {//modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
                alItem = itemMgr.QueryValidItemsList();
                foreach (Neusoft.HISFC.Object.Fee.Item.Undrug ud in alItem)
                {
                    ud.Memo = ud.Price.ToString("0.00");
                }
                ArrayList altem = new ArrayList(alItem);
                fpSpread1.SetWidthAndHeight(400, 200);
                fpSpread1.SetColumnList(fpSpread1.Sheets[0], 1, altem);
                fpSpread1.SetColumnList(fpSpread1.Sheets[0], 3, altem);
                fpSpread1.SetColumnList(fpSpread1.Sheets[0], 5, altem);
                fpSpread1.SetColumnList(fpSpread1.Sheets[0], 7, altem);
                fpSpread1.SetColumnList(fpSpread1.Sheets[0], 9, altem);
                fpSpread1.SetItem += new Neusoft.NFC.Interface.Controls.NeuFpEnter.setItem(fpSpread1_SetItem);
                fpSpread1.KeyEnter += new Neusoft.NFC.Interface.Controls.NeuFpEnter.keyDown(fpSpread1_KeyEnter);
            }
        }

        /// <summary>
        /// ���ɹҺ�Ա�б�
        /// </summary>
        private void InitTree()
        {
            this.treeView1.Nodes.Clear();

            TreeNode root = new TreeNode("��ͬ��λ", 22, 22);
            this.treeView1.Nodes.Add(root);

            Neusoft.HISFC.Integrate.Manager pactMgr = new Neusoft.HISFC.Integrate.Manager();
            //��ú�ͬ��λ�б�
            this.al = pactMgr.QueryPactUnitAll();
            if (al == null)
            {
                MessageBox.Show("��ȡ��ͬ��λ��Ϣʱ����!" + pactMgr.Err, "��ʾ");
                return;
            }

            foreach (Neusoft.HISFC.Object.Base.PactInfo obj in al)
            {
                TreeNode node = new TreeNode(obj.Name, 11, 35);
                node.Tag = obj.ID;
                root.Nodes.Add(node);
            }
            root.Expand();
        }
        /// <summary>
        /// ��ȡ�Һż���
        /// </summary>
        private void InitRegLevl()
        {
            Neusoft.HISFC.Management.Registration.RegLevel regMgr = new Neusoft.HISFC.Management.Registration.RegLevel();

            alLevel = regMgr.Query(true);
            if (alLevel == null)
            {
                MessageBox.Show("��ȡ�Һż���ʱ����!" + regMgr.Err, "��ʾ");
                return;
            }
        }
        /// <summary>
        /// ��ʼ�����ݴ���ʽ
        /// </summary>
        private void InitDataTable()
        {
            //modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
            //this.dtRegFee.Columns.AddRange(new DataColumn[]{
            //                                                   new DataColumn("�Һż���",System.Type.GetType("System.String")),
            //                                                   new DataColumn("�Һŷ�",System.Type.GetType("System.Decimal")),
            //                                                   new DataColumn("����",Type.GetType("System.Decimal")),
            //                                                   new DataColumn("�Է����Ʒ�",Type.GetType("System.Decimal")),
            //                                                   new DataColumn("�������Ʒ�",Type.GetType("System.Decimal")),
            //                                                   new DataColumn("���ӷ�",Type.GetType("System.Decimal")),
            //                                                   new DataColumn("��ˮ��",Type.GetType("System.String")),
            //                                                   new DataColumn("�������",Type.GetType("System.String"))
            //});
            this.dtRegFee.Columns.AddRange(new DataColumn[]{
															   new DataColumn("�Һż���",System.Type.GetType("System.String")),
															   new DataColumn("�Һŷѱ���",System.Type.GetType("System.String")),
															   new DataColumn("�Һŷѽ��",System.Type.GetType("System.Decimal")),
															   new DataColumn("���ѱ���",Type.GetType("System.String")),
															   new DataColumn("���ѽ��",Type.GetType("System.Decimal")),
															   new DataColumn("�Է����Ʒѱ���",Type.GetType("System.String")),
															   new DataColumn("�Է����Ʒѽ��",Type.GetType("System.Decimal")),
															   new DataColumn("�������Ʒѱ���",Type.GetType("System.String")),
															   new DataColumn("�������Ʒѽ��",Type.GetType("System.Decimal")),
															   new DataColumn("���ӷѱ���",Type.GetType("System.String")),
															   new DataColumn("���ӷѽ��",Type.GetType("System.Decimal")),
															   new DataColumn("��ˮ��",Type.GetType("System.String")),
															   new DataColumn("�������",Type.GetType("System.String"))
														   });
            //end modify
        }
        #endregion

        #region ����

        #region ��֤�Ƿ���Ҫ����
        private void MakeAll(string pactCode)
        {
            al = regFeeMgr.Query(pactCode, true);
            //			if(al.Count != alLevel.Count)
            //			{
            bool IsFound = false;
            foreach (Neusoft.HISFC.Object.Registration.RegLevel level in alLevel)
            {
                IsFound = false;

                foreach (Neusoft.HISFC.Object.Registration.RegLvlFee obj in al)
                {
                    if (level.ID == obj.RegLevel.ID)
                    {
                        IsFound = true;
                        break;
                    }
                }

                if (!IsFound)
                {
                    //����������У����Ǹú�ͬ��λû��ά����
                    Neusoft.HISFC.Object.Registration.RegLvlFee regFee = this.Insert(pactCode, level.ID);
                    //ֱ�����ӵ������У���ֹ�ٴμ������ݿ⡣
                    al.Add(regFee);
                }
            }
            //			}
        }
        #endregion

        #region ��ѯ
        /// <summary>
        /// ����ͬ��λ��ѯ�Һż���
        /// </summary>
        private void Query(string PactID)
        {
            //			al = this.regFeeMgr.Query(PactID ) ;
            if (al == null)
            {
                MessageBox.Show("��ѯ�Һŷ���Ϣʱ����!" + this.regFeeMgr.Err, "��ʾ");
                return;
            }

            this.dtRegFee.Rows.Clear();

            foreach (Neusoft.HISFC.Object.Registration.RegLvlFee info in al)
            {
                this.getNamebyId(info.RegLevel.ID);
                if (levelName == "" || levelName == null)
                {
                    MessageBox.Show("��ȡ�������Ƴ�����");
                    return;
                }
                //modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
                //this.dtRegFee.Rows.Add(new object[]{
                //                                       levelName,
                //                                       info.RegFee,
                //                                       info.ChkFee,
                //                                       info.OwnDigFee,
                //                                       info.PubDigFee,
                //                                       info.OthFee,
                //                                       info.ID,
                //                                       info.RegLevel.ID
                //                                   });
                this.dtRegFee.Rows.Add(new object[]{
													   levelName,
                    info.RegFeeCode,
													   info.RegFee,
                    info.ChkFeeCode,
													   info.ChkFee,
                    info.OwnDigFeeCode,
													   info.OwnDigFee,
                    info.PubDigFeeCode,
													   info.PubDigFee,
                    info.OthFeeCode,
													   info.OthFee,
													   info.ID,
													   info.RegLevel.ID
												   });
                //end modify
            }
            this.dtRegFee.AcceptChanges();
            this.fpSpread1_Sheet1.DataSource = this.dtRegFee;


            this.SetFpFormat();
            this.fpSpread1.ActiveSheet.SetActiveCell(0, 0);
            this.fpSpread1.ShowColumn(0, 0, FarPoint.Win.Spread.HorizontalPosition.Left);
        }
        #endregion

        /// <summary>
        /// ��ѯ��ť�ã���ʵûɶ����
        /// </summary>
        private void Query()
        {
            int i = 0;
            string pactCode = string.Empty;
            TreeNode root = this.treeView1.Nodes[0];
            foreach (TreeNode node in root.Nodes)
            {
                if (node.Checked)
                {
                    i++;
                    pactCode = node.Tag.ToString();
                }
            }
            if (i > 1)
            {
                MessageBox.Show("��ѡ��һ����¼���в�ѯ����");
                pactCode = string.Empty;
                return;
            }
            if (!(pactCode == "" && pactCode == string.Empty))
            {
                this.MakeAll(pactCode);
                this.Query(pactCode);
            }
        }

        #region ����
        /// <summary>
        /// ����һ���µļ�¼
        /// </summary>
        /// <param name="pactCode"></param>
        /// <param name="levelCode"></param>
        /// <returns></returns>
        private Neusoft.HISFC.Object.Registration.RegLvlFee Insert(string pactCode, string levelCode)
        {
            Neusoft.HISFC.Object.Registration.RegLvlFee info = new Neusoft.HISFC.Object.Registration.RegLvlFee();

            info.ID = regFeeMgr.GetSequence("Registration.RegLevel.GetSeqNo");
            info.Pact.ID = pactCode;
            info.RegLevel.ID = levelCode;
            info.RegFee = 0;
            info.ChkFee = 0;
            info.OwnDigFee = 0;
            info.PubDigFee = 0;
            info.OthFee = 0;
            info.Oper.ID = this.regFeeMgr.Operator.ID;
            info.Oper.OperTime = regFeeMgr.GetDateTimeFromSysDateTime();

            if (regFeeMgr.Insert(info) == -1)
            {
                MessageBox.Show("���Ӻ�ͬ��λ�Һŷѷ�����Ϣʧ�ܣ�[Registration.RegFee.Insert.1]" + regFeeMgr.Err);
            }

            return info;
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private int Valid()
        {
            ///�жϽ���Ϊ��
            for (int i = 0; i < this.fpSpread1_Sheet1.RowCount; i++)
            {
                for (int j = 0; j < this.fpSpread1_Sheet1.Columns.Count; j++)
                {
                    if (j == 2 || j == 4 || j == 6 || j == 8 || j == 10)
                    {
                        if (this.fpSpread1_Sheet1.Cells[i, j].Text == string.Empty)
                        {
                            MessageBox.Show("��" + (i + 1).ToString() + "�н���Ϊ��");
                            this.fpSpread1_Sheet1.Cells[i, j].Text = "0.00";
                            return -1;
                        }
                    }
                }
            }

            return 1;
        }

        #region ����
        /// <summary>
        /// ����
        /// </summary>
        private void Save()
        {
            this.fpSpread1.StopCellEditing();

            if (this.Valid() == -1)
            {
                return;
            }
            if (this.treeView1.SelectedNode == null || this.treeView1.SelectedNode.Parent == null)
            {
                MessageBox.Show("�޺�ͬ��λ!", "��ʾ");
                return;
            }

            //��ǰ��ͬ��λ����
            string pactID = this.treeView1.SelectedNode.Tag.ToString();

            if (fpSpread1_Sheet1.RowCount > 0)
                dtRegFee.Rows[fpSpread1_Sheet1.ActiveRowIndex].EndEdit();

            //�޸�            
            DataTable dtModify = dtRegFee.GetChanges(DataRowState.Modified);
            ArrayList alModify = this.GetChanges(dtModify);

            Neusoft.NFC.Interface.Classes.Function.ShowWaitForm("���ڱ���,���Ժ�...");
            Application.DoEvents();

            Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //Neusoft.NFC.Management.Transaction SQLCA = new Neusoft.NFC.Management.Transaction(regFeeMgr.con);
            //SQLCA.BeginTransaction();

            this.regFeeMgr.SetTrans(Neusoft.NFC.Management.PublicTrans.Trans);
            try
            {
                foreach (Neusoft.HISFC.Object.Registration.RegLvlFee info in alModify)
                {
                    if (regFeeMgr.Update(info) == -1)
                    {
                        Neusoft.NFC.Management.PublicTrans.RollBack();
                        Neusoft.NFC.Interface.Classes.Function.HideWaitForm();
                        MessageBox.Show("���¹Һŷѷ��䷽��������" + regFeeMgr.Err, "��ʾ");
                        return;
                    }
                }

                // ��������ѡ�еĽڵ�
                foreach (TreeNode pact in this.treeView1.Nodes[0].Nodes)
                {
                    if (pact.Checked && pact != this.treeView1.SelectedNode)
                    {
                        //ɾ��ԭ���ĹҺŷ�

                        if (this.regFeeMgr.DeleteByPact(pact.Tag.ToString()) == -1)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            Neusoft.NFC.Interface.Classes.Function.HideWaitForm();
                            MessageBox.Show("ɾ���Һŷѳ�����" + regFeeMgr.Err, "��ʾ");
                            return;
                        }

                        //Copy �Һŷ�
                        if (this.regFeeMgr.CopyByPact(pact.Tag.ToString(), pactID) == -1)
                        {
                            Neusoft.NFC.Management.PublicTrans.RollBack();
                            Neusoft.NFC.Interface.Classes.Function.HideWaitForm();
                            MessageBox.Show("���ƹҺŷѳ�����" + regFeeMgr.Err, "��ʾ");
                            return;
                        }
                    }
                    //ȡ��ѡ��
                    if (pact.Checked)
                    {
                        pact.Checked = false;
                    }
                }
                this.treeView1.Nodes[0].Checked = false;

            }
            catch (Exception e)
            {
                Neusoft.NFC.Management.PublicTrans.RollBack();
                Neusoft.NFC.Interface.Classes.Function.HideWaitForm();
                MessageBox.Show(e.Message, "��ʾ");
                return;
            }

            Neusoft.NFC.Management.PublicTrans.Commit();
            Neusoft.NFC.Interface.Classes.Function.HideWaitForm();

            MessageBox.Show("����ɹ���");
            dtRegFee.AcceptChanges();
        }
        #endregion

        #region ��������
        /// <summary>
        /// ��ȡ�ı����Ϣ��ת��Ϊʵ��
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private ArrayList GetChanges(DataTable dt)
        {
            this.al = new ArrayList();
            if (dt != null)
            {
                try
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        Neusoft.HISFC.Object.Registration.RegLvlFee info = new Neusoft.HISFC.Object.Registration.RegLvlFee();
                        info.ID = row["��ˮ��"].ToString();
                        //modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
                        info.RegFeeCode = row["�Һŷѱ���"].ToString();
                        info.ChkFeeCode = row["���ѱ���"].ToString();
                        info.OwnDigFeeCode = row["�Է����Ʒѱ���"].ToString();
                        info.PubDigFeeCode = row["�������Ʒѱ���"].ToString();
                        info.OthFeeCode = row["���ӷѱ���"].ToString();
                        if (row["�Һŷѱ���"].ToString().Length == 0) row["�Һŷѽ��"] = 0;
                        if (row["���ѱ���"].ToString().Length == 0) row["���ѽ��"] = 0;
                        if (row["�Է����Ʒѱ���"].ToString().Length == 0) row["�Է����Ʒѽ��"] = 0;
                        if (row["�������Ʒѱ���"].ToString().Length == 0) row["�������Ʒѽ��"] = 0;
                        if (row["���ӷѱ���"].ToString().Length == 0) row["���ӷѽ��"] = 0;
                        //end modify
                        info.RegFee = Neusoft.NFC.Function.NConvert.ToDecimal(row["�Һŷѽ��"].ToString());
                        info.ChkFee = Neusoft.NFC.Function.NConvert.ToDecimal(row["���ѽ��"].ToString());
                        info.OwnDigFee = Neusoft.NFC.Function.NConvert.ToDecimal(row["�Է����Ʒѽ��"].ToString());
                        info.PubDigFee = Neusoft.NFC.Function.NConvert.ToDecimal(row["�������Ʒѽ��"].ToString());
                        info.OthFee = Neusoft.NFC.Function.NConvert.ToDecimal(row["���ӷѽ��"].ToString());
                        this.al.Add(info);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("����ʵ�弯��ʱ����!" + e.Message, "��ʾ");
                    return null;
                }
            }
            return al;

        }
        /// <summary>
        /// �趨��ʾ��ʽ
        /// </summary>
        private void SetFpFormat()
        {
            FarPoint.Win.Spread.CellType.NumberCellType numbCellType = new FarPoint.Win.Spread.CellType.NumberCellType();
            numbCellType.MaximumValue = 2499.99;
            numbCellType.MinimumValue = 0;

            FarPoint.Win.Spread.CellType.TextCellType txtCellType = new FarPoint.Win.Spread.CellType.TextCellType();
            txtCellType.ReadOnly = true;
            FarPoint.Win.Spread.CellType.TextCellType txtCellType1 = new FarPoint.Win.Spread.CellType.TextCellType();
            txtCellType.ReadOnly = false;

            this.fpSpread1_Sheet1.Columns[0].CellType = txtCellType;
            this.fpSpread1_Sheet1.Columns[0].Locked = true;
            //modify by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
            //this.fpSpread1_Sheet1.Columns[1].CellType = numbCellType;
            //this.fpSpread1_Sheet1.Columns[2].CellType = numbCellType;
            //this.fpSpread1_Sheet1.Columns[3].CellType = numbCellType;
            //this.fpSpread1_Sheet1.Columns[4].CellType = numbCellType;
            //this.fpSpread1_Sheet1.Columns[5].CellType = numbCellType;
            this.fpSpread1_Sheet1.Columns[1].CellType = txtCellType1;
            this.fpSpread1_Sheet1.Columns[2].CellType = numbCellType;
            this.fpSpread1_Sheet1.Columns[3].CellType = txtCellType1;
            this.fpSpread1_Sheet1.Columns[4].CellType = numbCellType;
            this.fpSpread1_Sheet1.Columns[5].CellType = txtCellType1;
            this.fpSpread1_Sheet1.Columns[6].CellType = numbCellType;
            this.fpSpread1_Sheet1.Columns[7].CellType = txtCellType1;
            this.fpSpread1_Sheet1.Columns[8].CellType = numbCellType;
            this.fpSpread1_Sheet1.Columns[9].CellType = txtCellType1;
            this.fpSpread1_Sheet1.Columns[10].CellType = numbCellType;
            //end modify
            this.fpSpread1_Sheet1.Columns[11].Visible = false;
            this.fpSpread1_Sheet1.Columns[12].Visible = false;
            this.fpSpread1_Sheet1.Columns[2].Locked = true;
            this.fpSpread1_Sheet1.Columns[4].Locked = true;
            this.fpSpread1_Sheet1.Columns[6].Locked = true;
            this.fpSpread1_Sheet1.Columns[8].Locked = true;
            this.fpSpread1_Sheet1.Columns[10].Locked = true;
            this.fpSpread1_Sheet1.Columns[1].Width = 90;
            this.fpSpread1_Sheet1.Columns[2].Width = 70;
            this.fpSpread1_Sheet1.Columns[3].Width = 90;
            this.fpSpread1_Sheet1.Columns[4].Width = 70;
            this.fpSpread1_Sheet1.Columns[5].Width = 92;
            this.fpSpread1_Sheet1.Columns[6].Width = 92;
            this.fpSpread1_Sheet1.Columns[7].Width = 92;
            this.fpSpread1_Sheet1.Columns[8].Width = 92;
            this.fpSpread1_Sheet1.Columns[9].Width = 90;
            this.fpSpread1_Sheet1.Columns[10].Width = 70;
        }

        private void getNamebyId(string levelCode)
        {
            foreach (Neusoft.HISFC.Object.Registration.RegLevel level in alLevel)
            {
                if (levelCode == level.ID)
                {
                    levelName = level.Name.ToString();
                    break;
                }
            }
        }
        #endregion

        #endregion

        #region �¼�

        /// <summary>
        /// ��ѯ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Parent != null)//���Ǹ��ڵ�
            {
                this.MakeAll(e.Node.Tag.ToString());
                this.Query(e.Node.Tag.ToString());
            }
            else
            {
                this.al = new ArrayList();
                this.Query("NULL");
            }
        }

        /// <summary>
        /// �Ƿ��޸����ݣ�
        /// </summary>
        /// <returns></returns>
        public bool IsChange()
        {
            this.fpSpread1.StopCellEditing();

            DataTable dt = dtRegFee.GetChanges();

            if (dt == null || dt.Rows.Count == 0)
            {
                return false;
            }
            else
            {
                if (MessageBox.Show("�����Ѿ��޸�,�Ƿ񱣴�䶯?", "��ʾ", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    this.Save();
                    return true;
                }
            }
            return true;
        }


        private void treeView1_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            this.IsChange();
        }

        protected override int OnSave(object sender, object neuObject)
        {
            Save();

            return base.OnSave(sender, neuObject);
        }
        protected override int OnQuery(object sender, object neuObject)
        {
            this.Query();
            return base.OnQuery(sender, neuObject);
        }
        #endregion

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            bool selectedFlag = e.Node.Checked;

            if (e.Node.Parent == null)
            {
                foreach (TreeNode node in e.Node.Nodes)
                {
                    node.Checked = selectedFlag;
                }
            }
        }

        private void treeView1_Click(object sender, EventArgs e)
        {
            TreeNode node = this.treeView1.SelectedNode;
            if (node.Parent == null)
                node.ExpandAll();
        }

        private void treeView1_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            e.Node.ExpandAll();
        }

        //add by jizhr {57C6363D-F921-4657-ACE2-E45F36AE1627}
        private int fpSpread1_SetItem(Neusoft.NFC.Object.NeuObject obj)
        {
            int row = fpSpread1_Sheet1.ActiveRowIndex;
            int col = fpSpread1_Sheet1.ActiveColumnIndex;

            if (obj == null)
            {
                this.fpSpread1_Sheet1.SetText(row, col, "");
                this.fpSpread1_Sheet1.SetText(row, col + 1, "0");
                return -1;
            };

            this.fpSpread1_Sheet1.SetText(row, col, obj.ID);
            this.fpSpread1_Sheet1.SetText(row, col + 1, obj.Memo);

            this.fpSpread1.Focus();
            if (col < 9)
            {
                fpSpread1_Sheet1.SetActiveCell(row, col + 2);
            }
            else if (row < fpSpread1_Sheet1.RowCount - 1)
            {
                fpSpread1_Sheet1.SetActiveCell(row + 1, 1);
            }
            else
            {
                fpSpread1_Sheet1.SetActiveCell(0, 1);
            }
            return 0;
        }

        int fpSpread1_KeyEnter(Keys key)
        {
            if (key == Keys.Enter)
            {
                int row = fpSpread1_Sheet1.ActiveRowIndex;
                int col = fpSpread1_Sheet1.ActiveColumnIndex;
                if (col == 1 || col == 3 || col == 5 || col == 7 || col == 9)
                {
                    Neusoft.NFC.Interface.Controls.PopUpListBox list = this.fpSpread1.getCurrentList(this.fpSpread1_Sheet1, col);
                    if (list == null) return -1;

                    Neusoft.NFC.Object.NeuObject obj = null;
                    if (list.GetSelectedItem(out obj) == -1)
                    {
                        this.fpSpread1_Sheet1.SetText(row, col, "");
                        this.fpSpread1_Sheet1.SetText(row, col + 1, "0");
                        return -1;
                    }

                    if (obj == null) return -1;

                    this.fpSpread1_Sheet1.SetText(row, col, obj.ID);
                    this.fpSpread1_Sheet1.SetText(row, col + 1, obj.Memo);

                    list.Visible = false;
                    //this.fpSpread1.Focus();
                    if (col < 9)
                    {
                        fpSpread1_Sheet1.SetActiveCell(row, col + 2);
                    }
                    else if (row < fpSpread1_Sheet1.RowCount - 1)
                    {
                        fpSpread1_Sheet1.SetActiveCell(row + 1, 1);
                    }
                    else
                    {
                        fpSpread1_Sheet1.SetActiveCell(0, 1);
                    }
                }
            }
            return 0;
        }
    }
}
