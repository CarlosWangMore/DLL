﻿namespace Neusoft.UFC.Registration.Forms
{
    partial class frmRegisterInfo
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.neuPanel1 = new Neusoft.NFC.Interface.Controls.NeuPanel();
            this.btnCancel = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.btnOk = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuGroupBox1 = new Neusoft.NFC.Interface.Controls.NeuGroupBox();
            this.txtSSN = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel6 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.txtPriveNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.neuLabel5 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel8 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel4 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.dtpEndTime = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.dtpBeginTime = new Neusoft.NFC.Interface.Controls.NeuDateTimePicker();
            this.neuLabel3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbYbDignose = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.neuLabel2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.cmbYbItem = new Neusoft.NFC.Interface.Controls.NeuComboBox(this.components);
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.btnReadCard = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.neuPanel1.SuspendLayout();
            this.neuGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // neuPanel1
            // 
            this.neuPanel1.Controls.Add(this.btnCancel);
            this.neuPanel1.Controls.Add(this.btnOk);
            this.neuPanel1.Controls.Add(this.neuGroupBox1);
            this.neuPanel1.Location = new System.Drawing.Point(4, 7);
            this.neuPanel1.Name = "neuPanel1";
            this.neuPanel1.Size = new System.Drawing.Size(639, 344);
            this.neuPanel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuPanel1.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(367, 303);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "取消";
            this.btnCancel.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(194, 303);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btnOk.TabIndex = 7;
            this.btnOk.Text = "确定";
            this.btnOk.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // neuGroupBox1
            // 
            this.neuGroupBox1.Controls.Add(this.btnReadCard);
            this.neuGroupBox1.Controls.Add(this.txtSSN);
            this.neuGroupBox1.Controls.Add(this.neuLabel6);
            this.neuGroupBox1.Controls.Add(this.txtPriveNo);
            this.neuGroupBox1.Controls.Add(this.neuLabel5);
            this.neuGroupBox1.Controls.Add(this.neuLabel8);
            this.neuGroupBox1.Controls.Add(this.neuLabel4);
            this.neuGroupBox1.Controls.Add(this.dtpEndTime);
            this.neuGroupBox1.Controls.Add(this.dtpBeginTime);
            this.neuGroupBox1.Controls.Add(this.neuLabel3);
            this.neuGroupBox1.Controls.Add(this.cmbYbDignose);
            this.neuGroupBox1.Controls.Add(this.neuLabel2);
            this.neuGroupBox1.Controls.Add(this.cmbYbItem);
            this.neuGroupBox1.Controls.Add(this.neuLabel1);
            this.neuGroupBox1.Location = new System.Drawing.Point(3, 3);
            this.neuGroupBox1.Name = "neuGroupBox1";
            this.neuGroupBox1.Size = new System.Drawing.Size(633, 294);
            this.neuGroupBox1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuGroupBox1.TabIndex = 0;
            this.neuGroupBox1.TabStop = false;
            this.neuGroupBox1.Text = "信息登记";
            // 
            // txtSSN
            // 
            this.txtSSN.IsEnter2Tab = false;
            this.txtSSN.Location = new System.Drawing.Point(110, 27);
            this.txtSSN.MaxLength = 28;
            this.txtSSN.Name = "txtSSN";
            this.txtSSN.Size = new System.Drawing.Size(172, 21);
            this.txtSSN.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtSSN.TabIndex = 1;
            this.txtSSN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSSN_KeyDown);
            // 
            // neuLabel6
            // 
            this.neuLabel6.AutoSize = true;
            this.neuLabel6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel6.Location = new System.Drawing.Point(15, 30);
            this.neuLabel6.Name = "neuLabel6";
            this.neuLabel6.Size = new System.Drawing.Size(65, 12);
            this.neuLabel6.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel6.TabIndex = 17;
            this.neuLabel6.Text = "医疗证号：";
            // 
            // txtPriveNo
            // 
            this.txtPriveNo.IsEnter2Tab = false;
            this.txtPriveNo.Location = new System.Drawing.Point(110, 67);
            this.txtPriveNo.MaxLength = 20;
            this.txtPriveNo.Name = "txtPriveNo";
            this.txtPriveNo.Size = new System.Drawing.Size(172, 21);
            this.txtPriveNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtPriveNo.TabIndex = 2;
            this.txtPriveNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPriveNo_KeyDown);
            // 
            // neuLabel5
            // 
            this.neuLabel5.AutoSize = true;
            this.neuLabel5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel5.Location = new System.Drawing.Point(15, 70);
            this.neuLabel5.Name = "neuLabel5";
            this.neuLabel5.Size = new System.Drawing.Size(53, 12);
            this.neuLabel5.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel5.TabIndex = 15;
            this.neuLabel5.Text = "凭证号：";
            // 
            // neuLabel8
            // 
            this.neuLabel8.AutoSize = true;
            this.neuLabel8.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel8.Location = new System.Drawing.Point(490, 269);
            this.neuLabel8.Name = "neuLabel8";
            this.neuLabel8.Size = new System.Drawing.Size(137, 12);
            this.neuLabel8.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel8.TabIndex = 14;
            this.neuLabel8.Text = "注意：蓝色字体为必输项";
            // 
            // neuLabel4
            // 
            this.neuLabel4.AutoSize = true;
            this.neuLabel4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel4.Location = new System.Drawing.Point(15, 245);
            this.neuLabel4.Name = "neuLabel4";
            this.neuLabel4.Size = new System.Drawing.Size(65, 12);
            this.neuLabel4.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel4.TabIndex = 7;
            this.neuLabel4.Text = "截止时间：";
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.IsEnter2Tab = false;
            this.dtpEndTime.Location = new System.Drawing.Point(110, 241);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.Size = new System.Drawing.Size(172, 21);
            this.dtpEndTime.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtpEndTime.TabIndex = 6;
            this.dtpEndTime.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpEndTime_KeyDown);
            // 
            // dtpBeginTime
            // 
            this.dtpBeginTime.IsEnter2Tab = false;
            this.dtpBeginTime.Location = new System.Drawing.Point(110, 198);
            this.dtpBeginTime.Name = "dtpBeginTime";
            this.dtpBeginTime.Size = new System.Drawing.Size(172, 21);
            this.dtpBeginTime.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.dtpBeginTime.TabIndex = 5;
            this.dtpBeginTime.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dtpBeginTime_KeyDown);
            // 
            // neuLabel3
            // 
            this.neuLabel3.AutoSize = true;
            this.neuLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel3.Location = new System.Drawing.Point(15, 202);
            this.neuLabel3.Name = "neuLabel3";
            this.neuLabel3.Size = new System.Drawing.Size(65, 12);
            this.neuLabel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel3.TabIndex = 4;
            this.neuLabel3.Text = "开始时间：";
            // 
            // cmbYbDignose
            // 
            this.cmbYbDignose.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbYbDignose.FormattingEnabled = true;
            this.cmbYbDignose.IsEnter2Tab = false;
            this.cmbYbDignose.IsFlat = true;
            this.cmbYbDignose.IsLike = true;
            this.cmbYbDignose.Location = new System.Drawing.Point(110, 151);
            this.cmbYbDignose.Name = "cmbYbDignose";
            this.cmbYbDignose.PopForm = null;
            this.cmbYbDignose.ShowCustomerList = false;
            this.cmbYbDignose.ShowID = false;
            this.cmbYbDignose.Size = new System.Drawing.Size(172, 20);
            this.cmbYbDignose.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbYbDignose.TabIndex = 4;
            this.cmbYbDignose.Tag = "";
            this.cmbYbDignose.ToolBarUse = false;
            this.cmbYbDignose.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbYbDignose_KeyDown);
            // 
            // neuLabel2
            // 
            this.neuLabel2.AutoSize = true;
            this.neuLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel2.Location = new System.Drawing.Point(15, 154);
            this.neuLabel2.Name = "neuLabel2";
            this.neuLabel2.Size = new System.Drawing.Size(89, 12);
            this.neuLabel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel2.TabIndex = 2;
            this.neuLabel2.Text = "医保大病诊断：";
            // 
            // cmbYbItem
            // 
            this.cmbYbItem.ArrowBackColor = System.Drawing.Color.Silver;
            this.cmbYbItem.FormattingEnabled = true;
            this.cmbYbItem.IsEnter2Tab = false;
            this.cmbYbItem.IsFlat = true;
            this.cmbYbItem.IsLike = true;
            this.cmbYbItem.Location = new System.Drawing.Point(110, 108);
            this.cmbYbItem.Name = "cmbYbItem";
            this.cmbYbItem.PopForm = null;
            this.cmbYbItem.ShowCustomerList = false;
            this.cmbYbItem.ShowID = false;
            this.cmbYbItem.Size = new System.Drawing.Size(172, 20);
            this.cmbYbItem.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.cmbYbItem.TabIndex = 3;
            this.cmbYbItem.Tag = "";
            this.cmbYbItem.ToolBarUse = false;
            this.cmbYbItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbYbItem_KeyDown);
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.neuLabel1.Location = new System.Drawing.Point(15, 112);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(89, 12);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 0;
            this.neuLabel1.Text = "医保大病项目：";
            // 
            // btnReadCard
            // 
            this.btnReadCard.Location = new System.Drawing.Point(327, 25);
            this.btnReadCard.Name = "btnReadCard";
            this.btnReadCard.Size = new System.Drawing.Size(75, 23);
            this.btnReadCard.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btnReadCard.TabIndex = 18;
            this.btnReadCard.Text = "读取卡号";
            this.btnReadCard.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btnReadCard.UseVisualStyleBackColor = true;
            this.btnReadCard.Click += new System.EventHandler(this.btnReadCard_Click);
            // 
            // frmRegisterInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 363);
            this.ControlBox = false;
            this.Controls.Add(this.neuPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRegisterInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "医保大病信息登记";
            this.Load += new System.EventHandler(this.frmRegisterInfo_Load);
            this.neuPanel1.ResumeLayout(false);
            this.neuGroupBox1.ResumeLayout(false);
            this.neuGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuPanel neuPanel1;
        private Neusoft.NFC.Interface.Controls.NeuButton btnCancel;
        private Neusoft.NFC.Interface.Controls.NeuButton btnOk;
        private Neusoft.NFC.Interface.Controls.NeuGroupBox neuGroupBox1;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel4;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtpEndTime;
        private Neusoft.NFC.Interface.Controls.NeuDateTimePicker dtpBeginTime;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel3;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbYbDignose;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel2;
        private Neusoft.NFC.Interface.Controls.NeuComboBox cmbYbItem;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel8;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtPriveNo;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel5;
        private Neusoft.NFC.Interface.Controls.NeuTextBox txtSSN;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel6;
        private Neusoft.NFC.Interface.Controls.NeuButton btnReadCard;
    }
}