﻿namespace Neusoft.UFC.Registration.Forms
{
    partial class frmReprintZZJ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtInvoiceNo = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.btExit = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.btOk = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.txtName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSex = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBirthDay = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRegDeptName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtRegDoctName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRegLevelName = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtRegDate = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPact = new Neusoft.NFC.Interface.Controls.NeuTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(28, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "发票号：";
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.Font = new System.Drawing.Font("宋体", 10F);
            this.txtInvoiceNo.IsEnter2Tab = false;
            this.txtInvoiceNo.Location = new System.Drawing.Point(98, 9);
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.Size = new System.Drawing.Size(100, 23);
            this.txtInvoiceNo.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtInvoiceNo.TabIndex = 2;
            this.txtInvoiceNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtInvoiceNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInvoiceNo_KeyDown);
            // 
            // btExit
            // 
            this.btExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btExit.Location = new System.Drawing.Point(329, 163);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btExit.TabIndex = 4;
            this.btExit.Text = "退出(&X)";
            this.btExit.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btOk
            // 
            this.btOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btOk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btOk.Location = new System.Drawing.Point(242, 163);
            this.btOk.Name = "btOk";
            this.btOk.Size = new System.Drawing.Size(75, 23);
            this.btOk.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.btOk.TabIndex = 3;
            this.btOk.Text = "打印(&P)";
            this.btOk.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.btOk.UseVisualStyleBackColor = true;
            this.btOk.Click += new System.EventHandler(this.btOk_Click);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("宋体", 10F);
            this.txtName.IsEnter2Tab = false;
            this.txtName.Location = new System.Drawing.Point(304, 9);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 23);
            this.txtName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtName.TabIndex = 6;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(249, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "姓名：";
            // 
            // txtSex
            // 
            this.txtSex.Font = new System.Drawing.Font("宋体", 10F);
            this.txtSex.IsEnter2Tab = false;
            this.txtSex.Location = new System.Drawing.Point(98, 38);
            this.txtSex.Name = "txtSex";
            this.txtSex.Size = new System.Drawing.Size(100, 23);
            this.txtSex.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtSex.TabIndex = 8;
            this.txtSex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(42, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "性别：";
            // 
            // txtBirthDay
            // 
            this.txtBirthDay.Font = new System.Drawing.Font("宋体", 10F);
            this.txtBirthDay.IsEnter2Tab = false;
            this.txtBirthDay.Location = new System.Drawing.Point(304, 38);
            this.txtBirthDay.Name = "txtBirthDay";
            this.txtBirthDay.Size = new System.Drawing.Size(100, 23);
            this.txtBirthDay.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtBirthDay.TabIndex = 10;
            this.txtBirthDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(218, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "出生日期：";
            // 
            // txtRegDeptName
            // 
            this.txtRegDeptName.Font = new System.Drawing.Font("宋体", 10F);
            this.txtRegDeptName.IsEnter2Tab = false;
            this.txtRegDeptName.Location = new System.Drawing.Point(98, 67);
            this.txtRegDeptName.Name = "txtRegDeptName";
            this.txtRegDeptName.Size = new System.Drawing.Size(100, 23);
            this.txtRegDeptName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtRegDeptName.TabIndex = 12;
            this.txtRegDeptName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(10, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "看诊科室：";
            // 
            // txtRegDoctName
            // 
            this.txtRegDoctName.Font = new System.Drawing.Font("宋体", 10F);
            this.txtRegDoctName.IsEnter2Tab = false;
            this.txtRegDoctName.Location = new System.Drawing.Point(304, 67);
            this.txtRegDoctName.Name = "txtRegDoctName";
            this.txtRegDoctName.Size = new System.Drawing.Size(100, 23);
            this.txtRegDoctName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtRegDoctName.TabIndex = 14;
            this.txtRegDoctName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(218, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "看诊医生：";
            // 
            // txtRegLevelName
            // 
            this.txtRegLevelName.Font = new System.Drawing.Font("宋体", 10F);
            this.txtRegLevelName.IsEnter2Tab = false;
            this.txtRegLevelName.Location = new System.Drawing.Point(98, 96);
            this.txtRegLevelName.Name = "txtRegLevelName";
            this.txtRegLevelName.Size = new System.Drawing.Size(100, 23);
            this.txtRegLevelName.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtRegLevelName.TabIndex = 16;
            this.txtRegLevelName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(10, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "挂号级别：";
            // 
            // txtRegDate
            // 
            this.txtRegDate.Font = new System.Drawing.Font("宋体", 10F);
            this.txtRegDate.IsEnter2Tab = false;
            this.txtRegDate.Location = new System.Drawing.Point(304, 96);
            this.txtRegDate.Name = "txtRegDate";
            this.txtRegDate.Size = new System.Drawing.Size(100, 23);
            this.txtRegDate.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtRegDate.TabIndex = 18;
            this.txtRegDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(216, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "挂号时间：";
            // 
            // txtPact
            // 
            this.txtPact.Font = new System.Drawing.Font("宋体", 10F);
            this.txtPact.IsEnter2Tab = false;
            this.txtPact.Location = new System.Drawing.Point(98, 130);
            this.txtPact.Name = "txtPact";
            this.txtPact.Size = new System.Drawing.Size(100, 23);
            this.txtPact.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.txtPact.TabIndex = 20;
            this.txtPact.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(10, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "合同单位：";
            // 
            // frmReprintZZJ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 198);
            this.Controls.Add(this.txtPact);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtRegDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtRegLevelName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtRegDoctName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtRegDeptName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBirthDay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSex);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.btOk);
            this.Controls.Add(this.txtInvoiceNo);
            this.Controls.Add(this.label1);
            this.Name = "frmReprintZZJ";
            this.Text = "自助机挂号发票补打（此功能补打不走发票号）";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtInvoiceNo;
        public Neusoft.NFC.Interface.Controls.NeuButton btExit;
        public Neusoft.NFC.Interface.Controls.NeuButton btOk;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtName;
        private System.Windows.Forms.Label label2;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtSex;
        private System.Windows.Forms.Label label3;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtBirthDay;
        private System.Windows.Forms.Label label4;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtRegDeptName;
        private System.Windows.Forms.Label label5;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtRegDoctName;
        private System.Windows.Forms.Label label6;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtRegLevelName;
        private System.Windows.Forms.Label label7;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtRegDate;
        private System.Windows.Forms.Label label8;
        public Neusoft.NFC.Interface.Controls.NeuTextBox txtPact;
        private System.Windows.Forms.Label label9;
    }
}