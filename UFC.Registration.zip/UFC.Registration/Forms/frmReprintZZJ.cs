﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Neusoft.UFC.Registration.Forms
{
    public partial class frmReprintZZJ : Form
    {
        public frmReprintZZJ()
        {
            InitializeComponent();
        }

        private Neusoft.HISFC.Object.Registration.Register regObj = new Neusoft.HISFC.Object.Registration.Register();

        private Neusoft.HISFC.Management.Registration.Register reg = new Neusoft.HISFC.Management.Registration.Register();

        private void txtInvoiceNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                QueryReg();
            }
        }

        private void Clear()
        {
            this.regObj = new Neusoft.HISFC.Object.Registration.Register();
            this.txtName.Text = "";
            this.txtSex.Text = "";
            this.txtBirthDay.Text = "";
            this.txtRegDeptName.Text = "";
            this.txtRegDoctName.Text = "";
            this.txtRegLevelName.Text = "";
            this.txtRegDate.Text = "";
            this.txtPact.Text = "";

            this.txtInvoiceNo.Text = "";
            this.txtInvoiceNo.Focus();
            this.txtInvoiceNo.SelectAll();
        }

        private void QueryReg()
        {
            string invoiceNo = this.txtInvoiceNo.Text.Trim();
            if (string.IsNullOrEmpty(invoiceNo))
            {
                MessageBox.Show("请输入挂号发票号！");
                this.txtInvoiceNo.Focus();
                this.txtInvoiceNo.SelectAll();
                return;
            }

            ArrayList al = this.reg.QueryByRegInvoice(invoiceNo);
            if (al == null || al.Count < 1)
            {
                MessageBox.Show("根据输入的发票号未能获取到有效的挂号记录！\r\n请确认发票号是否有效或已退费！");
                this.txtInvoiceNo.Focus();
                this.txtInvoiceNo.SelectAll();
                return;
            }

            this.regObj = al[0] as Neusoft.HISFC.Object.Registration.Register;

            //{0398E6E7-7A26-49ff-9093-46AA65681BD6} 2020.08.14 增加泰州APP
            if (this.regObj.InputOper.ID != "999888" && this.regObj.InputOper.ID != "999666")
            {
                MessageBox.Show("此页面只能补打操作员：自助机或泰州APP 的挂号发票！");
                this.txtInvoiceNo.Focus();
                this.txtInvoiceNo.SelectAll();
                this.regObj = null;
                return;
            }

            this.txtName.Text = this.regObj.Name;
            this.txtSex.Text = this.regObj.Sex.ID.Equals("F") ? "女" : "男";
            this.txtBirthDay.Text = this.regObj.Birthday.ToString("yyyy-MM-dd");
            this.txtRegDeptName.Text = this.regObj.DoctorInfo.Templet.Dept.Name;
            this.txtRegDoctName.Text = this.regObj.DoctorInfo.Templet.Doct.Name;
            this.txtRegLevelName.Text = this.regObj.DoctorInfo.Templet.RegLevel.Name;
            this.txtRegDate.Text = this.regObj.InputOper.OperTime.ToString("yyyy-MM-dd HH:mm:ss");
            this.txtPact.Text = this.regObj.Pact.Name;

            this.btOk.Focus();
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否要补打自助机发票?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.Yes)
            {
                this.Print();
            }
        }

        private void Print()
        {
            if (this.regObj == null || string.IsNullOrEmpty(this.regObj.ID))
            {
                MessageBox.Show("未获取需要打印的挂号记录！\r\n请重新输入发票号并回车！");
                return;
            }

            Neusoft.HISFC.Integrate.Registration.IRegPrint regprint = null;
            //{662BE165-070B-4700-9973-93B3C52B33EB} 将打印DLL指定到统一目录下 by jizhr
            regprint = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(), typeof(Neusoft.HISFC.Integrate.Registration.IRegPrint), @"\Plugins\InvoicePrint\") as Neusoft.HISFC.Integrate.Registration.IRegPrint;
            //regprint.SetPrintValue(regObj,regmr);
            if (regObj.IsEncrypt)
            {
                regObj.Name = Neusoft.NFC.Interface.Classes.Function.Decrypt3DES(this.regObj.NormalName);
            }

            if (regprint.SetPrintValue(this.regObj) < 0)
            {
                return;
            }
            if (regprint.Print() < 0)
            {
                return;
            }

            //Neusoft.NFC.Management.PublicTrans.BeginTransaction();

            //if (this.reg.UpdateRegPrintFlagForZZJ(this.regObj) < 1)
            //{
            //    Neusoft.NFC.Management.PublicTrans.RollBack();
            //    MessageBox.Show("更新发票打印标记失败！");
            //}

            //Neusoft.NFC.Management.PublicTrans.Commit();

            MessageBox.Show("补打成功!");
            this.Clear();
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
