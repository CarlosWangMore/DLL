using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
namespace Neusoft.UFC.Registration.Forms
{
    /// <summary>
    /// ҽ������Ϣ¼��
    /// �����ߣ��볬
    /// ����ʱ�䣺2010.3.8
    /// <˵��>
    /// 
    /// </summary>
    public partial class frmRegisterInfo : Form, Neusoft.NFC.Interface.Forms.IInterfaceContainer
    {
        public frmRegisterInfo()
        {
            InitializeComponent();
        }

        #region ������
        /// <summary>
        /// Managerҵ���
        /// </summary>
        private Neusoft.HISFC.Integrate.Manager managerIntegrate = new Neusoft.HISFC.Integrate.Manager();
        /// <summary>
        /// �ҺŹ�����
        /// </summary>
        private Neusoft.HISFC.Management.Registration.Register regMgr = new Neusoft.HISFC.Management.Registration.Register();
        /// <summary>
        /// �Һ�ʵ��
        /// </summary>
        private Neusoft.HISFC.Object.Registration.Register regObj=new Neusoft.HISFC.Object.Registration.Register();
        #endregion

        #region ��������
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        private string siBigSickItem = string.Empty;
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        private string siBigSickItemName = string.Empty;
        /// <summary>
        /// ҽ�������
        /// </summary>
        private string siBigSickDignose = string.Empty;
        /// <summary>
        /// ҽ�����������
        /// </summary>
        private string siBigSickDignoseName = string.Empty;
        /// <summary>
        /// ��ʼʱ��
        /// </summary>
        private DateTime siBigSickBeginTime = new DateTime();
        /// <summary>
        /// ����ʱ��
        /// </summary>
        private DateTime siBigSickEndTime = new DateTime();
        /// <summary>
        /// ���
        /// </summary>
        private DialogResult rs = DialogResult.Cancel;
        /// <summary>
        /// ��ᱣ�պ�
        /// </summary>
        private string ssn ="";
        /// <summary>
        /// ƾ֤��
        /// </summary>
        private string priveNo = "";
        #endregion

        #region ����
        /// <summary>
        /// ��� 
        /// </summary>
        public DialogResult Result
        {
            set
            {
                this.rs = value;
            }
            get
            {
                return this.rs;
            }
        }
        /// <summary>
        /// ҽ������Ŀ
        /// </summary>
        public string SIBigSickItem
        {
            set
            {
                this.siBigSickItem = value;
            }
            get
            {
                return this.siBigSickItem;
            }
        }
        /// <summary>
        /// ҽ�������
        /// </summary>
        public string SIBigSickDignose
        {
            set
            {
                this.siBigSickDignose = value;
            }
            get
            {
                return this.siBigSickDignose;
            }
        }
        /// <summary>
        /// ��ʼʱ��
        /// </summary>
        public DateTime SIBigSickBeginTime
        {
            set
            {
                this.siBigSickBeginTime = value;
            }
            get
            {
                return this.siBigSickBeginTime;
            }
        }
        /// <summary>
        /// ��ֹʱ��
        /// </summary>
        public DateTime SIBigSickEndTime
        {
            set
            {
                this.siBigSickEndTime = value;
            }
            get
            {
                return this.siBigSickEndTime;
            }
        }
        /// <summary>
        /// ҽ������Ŀ����
        /// </summary>
        public string SIBigSickItemName
        {
            set
            {
                this.siBigSickItemName = value;
            }
            get
            {
                return this.siBigSickItemName;
            }
        }
        /// <summary>
        /// ҽ�����������
        /// </summary>
        public string SIBigSickDignoseName
        {
            set
            {
                this.siBigSickDignoseName = value;
            }
            get
            {
                return this.siBigSickDignoseName;
            }
        }
        /// <summary>
        /// ��ᱣ�պ�
        /// </summary>
        public string SSN
        {
            set
            {
                this.ssn = value;
            }
            get
            {
                return this.ssn;
            }
        }
        /// <summary>
        /// ƾ֤��
        /// </summary>
        public string PriveNo
        {
            set
            {
                this.priveNo = value;
            }
            get
            {
                return this.priveNo;
            }
        }
        #endregion

        #region �¼�
        private void cmbYbItem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.cmbYbDignose.Focus();
            }
        }

        private void cmbYbDignose_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.dtpBeginTime.Focus();
            }
        }

        private void dtpBeginTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.dtpEndTime.Focus();
            }
        }

        private void dtpEndTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.btnOk.Focus();
            }
        }
        private void txtSSN_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.txtPriveNo.Focus();
            }
        }

        private void txtPriveNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.cmbYbItem.Focus();
            }
        }



        /// <summary>
        /// ȡ��
        /// </summary>

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            this.rs = DialogResult.Cancel;
        }
        
        private void frmRegisterInfo_Load(object sender, EventArgs e)
        {
            this.txtSSN.Focus();
            this.Init();
        }
        /// <summary>
        /// ȷ��
        /// </summary>
        private void btnOk_Click(object sender, EventArgs e)
        {
            #region Ԥ������������ά��ʱʹ��
            this.siBigSickBeginTime = this.dtpBeginTime.Value;                        //��ʼʱ��
            this.siBigSickEndTime = this.dtpEndTime.Value;                            //��ֹʱ��
            this.siBigSickDignose = this.cmbYbDignose.Tag.ToString();                 //����ϴ���
            this.siBigSickItem = this.cmbYbItem.Tag.ToString();                       //����Ŀ����
            this.siBigSickDignoseName = this.cmbYbDignose.Text;                       //���������
            this.siBigSickItemName = this.cmbYbItem.Text;                             //����Ŀ����
            this.ssn = this.txtSSN.Text;                                              //ҽ����
            this.priveNo = this.txtPriveNo.Text;                                      //ƾ֤��
            #endregion
            if (this.siBigSickDignose == "" || this.siBigSickItem == "" ||this.ssn=="" ||this.priveNo=="")
            {
                MessageBox.Show("��Ϣ��д����ȫ��");
                this.CheckInfo();
                this.ClearSource();
                return;
            }
            if (this.siBigSickBeginTime.Date < this.regMgr.GetDateTimeFromSysDateTime().Date)
            {
                MessageBox.Show("��ʼʱ�䲻��С�ڵ�ǰϵͳʱ�䣡");
                this.dtpBeginTime.Focus();
                return;
            }
            if (this.siBigSickBeginTime > this.siBigSickEndTime)
            {
                MessageBox.Show("��ʼʱ�䲻�ܴ��ڽ�ֹʱ�䣡");
                this.dtpEndTime.Focus();
                return;
            }
            //ʵ�帳ֵ �������Ϣ
            SIBigSickSetInfo();
           // this.Close();
            this.rs = DialogResult.OK;
        }
        /// <summary>
        /// ��ȡҽ����
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReadCard_Click(object sender, EventArgs e)
        {
            SHSI.IShSiInterface read = Neusoft.NFC.Interface.Classes.UtilInterface.CreateObject(this.GetType(), typeof(SHSI.IShSiInterface)) as SHSI.IShSiInterface;
            SHSI.Classes.SafeGuardCardInfo info= new SHSI.Classes.SafeGuardCardInfo();      //ҽ��ʵ��
            //ҽ����Ϣ��ֵ
            if(read.ReadSafeCard(info) ==1)
            {
                this.txtSSN.Text = info.Cardno;
            }
            else
            {
                MessageBox.Show("����ʧ�ܣ�");
                return;
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// ��ʼ��
        /// </summary>
        private void Init()
        {
            //���ݳ���ά����ʼ�������б�
            this.cmbYbItem.AddItems(managerIntegrate.GetConstantList("SIDBXM"));      //ҽ������Ŀ
            this.cmbYbDignose.AddItems(managerIntegrate.GetConstantList("SIDBZD"));   //ҽ�������
            this.dtpBeginTime.Value = this.regMgr.GetDateTimeFromSysDateTime();
            this.dtpEndTime.Value = this.regMgr.GetDateTimeFromSysDateTime();
        }
        /// <summary>
        /// ���
        /// </summary>
        private int ClearSource()
        {
            this.siBigSickDignose = string.Empty;
            this.siBigSickItem = string.Empty;
            this.priveNo = string.Empty;
            this.ssn = string.Empty;
            this.txtPriveNo.Text = "";
            this.txtSSN.Text = "";
            this.cmbYbDignose.Text = "";
            this.cmbYbItem.Text = "";
            return 1;
        }
        /// <summary>
        /// �жϹ��
        /// </summary>
        private int CheckInfo()
        {
            if (this.txtSSN.Text == "")
            {
                this.txtSSN.Focus();
                return -1;
            }
            if (this.txtPriveNo.Text == "")
            {
                this.txtPriveNo.Focus();
                return -1;
            }
            if (this.cmbYbItem.Text == "")
            {
                this.cmbYbItem.Focus();
                return -1;
            }
            if (this.cmbYbDignose.Text == "")
            {
                this.cmbYbDignose.Focus();
                return -1;
            }         
            return 1;
        }
        /// <summary>
        /// ҽ������Ϣʵ�帳ֵ����
        /// </summary>
        /// <returns>�ɹ�1������-1</returns>
        private int SIBigSickSetInfo()
        {
            if (this.siBigSickDignose == "" || this.siBigSickItem == "")
            {
                MessageBox.Show("�󲡺ű�������ҽ������Ϣ��");
                return -1;
            }
            this.regObj.SiBigSick.ItemId = this.siBigSickItem;
            this.regObj.SiBigSick.ItemName = this.siBigSickItemName;
            this.regObj.SiBigSick.DignoseId = this.siBigSickDignose;
            this.regObj.SiBigSick.DignoseName = this.siBigSickDignoseName;
            this.regObj.SiBigSick.MyBeginDate = this.siBigSickBeginTime;
            this.regObj.SiBigSick.MyEndDate = this.siBigSickEndTime;
            this.regObj.SSN = this.ssn;
            this.regObj.SiBigSick.PriveNo = this.priveNo;
            Neusoft.NFC.Management.PublicTrans.BeginTransaction();
            if (this.regMgr.InsertSiBigSickInfo(this.regObj) == -1)
            {
                if (this.regMgr.UpdateSiBigSickInfo(this.regObj) < 0)
                {
                    Neusoft.NFC.Management.PublicTrans.RollBack();
                    MessageBox.Show("����ҽ������Ϣ����");                
                    return -1;
                }
                else
                {
                    Neusoft.NFC.Management.PublicTrans.Commit();
                    MessageBox.Show("���³ɹ���");                   
                    this.ClearSource();
                    return 1;
                }
            }
           
            Neusoft.NFC.Management.PublicTrans.Commit();
            MessageBox.Show("����ɹ���");
            this.ClearSource();
            return 1;
        }
        #endregion

        #region IInterfaceContainer ��Ա

        public Type[] InterfaceTypes
        {
            get
            {
                Type[] type = new Type[1];
                type[0] = typeof(SHSI.IShSiInterface);
                return type;
            }
        }

        #endregion
    }
}