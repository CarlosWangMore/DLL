﻿namespace Neusoft.UFC.Registration.Forms
{
    partial class frmReturnCost
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.neuLabel1 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel2 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.neuLabel3 = new Neusoft.NFC.Interface.Controls.NeuLabel();
            this.ntxtWillCost = new Neusoft.NFC.Interface.Controls.NeuNumericTextBox();
            this.ntxtRealCost = new Neusoft.NFC.Interface.Controls.NeuNumericTextBox();
            this.ntxtChangeCost = new Neusoft.NFC.Interface.Controls.NeuNumericTextBox();
            this.tbOK = new Neusoft.NFC.Interface.Controls.NeuButton();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // neuLabel1
            // 
            this.neuLabel1.AutoSize = true;
            this.neuLabel1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.neuLabel1.Location = new System.Drawing.Point(19, 42);
            this.neuLabel1.Name = "neuLabel1";
            this.neuLabel1.Size = new System.Drawing.Size(93, 16);
            this.neuLabel1.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel1.TabIndex = 0;
            this.neuLabel1.Text = "应收金额：";
            // 
            // neuLabel2
            // 
            this.neuLabel2.AutoSize = true;
            this.neuLabel2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.neuLabel2.ForeColor = System.Drawing.Color.Blue;
            this.neuLabel2.Location = new System.Drawing.Point(18, 100);
            this.neuLabel2.Name = "neuLabel2";
            this.neuLabel2.Size = new System.Drawing.Size(93, 16);
            this.neuLabel2.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel2.TabIndex = 2;
            this.neuLabel2.Text = "实收金额：";
            // 
            // neuLabel3
            // 
            this.neuLabel3.AutoSize = true;
            this.neuLabel3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.neuLabel3.ForeColor = System.Drawing.Color.Red;
            this.neuLabel3.Location = new System.Drawing.Point(229, 100);
            this.neuLabel3.Name = "neuLabel3";
            this.neuLabel3.Size = new System.Drawing.Size(59, 16);
            this.neuLabel3.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.neuLabel3.TabIndex = 3;
            this.neuLabel3.Text = "找零：";
            // 
            // ntxtWillCost
            // 
            this.ntxtWillCost.AllowNegative = false;
            this.ntxtWillCost.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ntxtWillCost.IsAutoRemoveDecimalZero = false;
            this.ntxtWillCost.IsEnter2Tab = false;
            this.ntxtWillCost.Location = new System.Drawing.Point(117, 39);
            this.ntxtWillCost.Name = "ntxtWillCost";
            this.ntxtWillCost.NumericPrecision = 10;
            this.ntxtWillCost.NumericScaleOnFocus = 2;
            this.ntxtWillCost.NumericScaleOnLostFocus = 2;
            this.ntxtWillCost.NumericValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ntxtWillCost.SetRange = new System.Drawing.Size(-1, -1);
            this.ntxtWillCost.Size = new System.Drawing.Size(105, 26);
            this.ntxtWillCost.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ntxtWillCost.TabIndex = 5;
            this.ntxtWillCost.Text = "0.00";
            this.ntxtWillCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ntxtWillCost.UseGroupSeperator = true;
            this.ntxtWillCost.ZeroIsValid = true;
            // 
            // ntxtRealCost
            // 
            this.ntxtRealCost.AllowNegative = false;
            this.ntxtRealCost.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ntxtRealCost.ForeColor = System.Drawing.Color.Blue;
            this.ntxtRealCost.IsAutoRemoveDecimalZero = false;
            this.ntxtRealCost.IsEnter2Tab = false;
            this.ntxtRealCost.Location = new System.Drawing.Point(117, 97);
            this.ntxtRealCost.Name = "ntxtRealCost";
            this.ntxtRealCost.NumericPrecision = 10;
            this.ntxtRealCost.NumericScaleOnFocus = 2;
            this.ntxtRealCost.NumericScaleOnLostFocus = 2;
            this.ntxtRealCost.NumericValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ntxtRealCost.SetRange = new System.Drawing.Size(-1, -1);
            this.ntxtRealCost.Size = new System.Drawing.Size(105, 26);
            this.ntxtRealCost.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ntxtRealCost.TabIndex = 4;
            this.ntxtRealCost.Text = "0.00";
            this.ntxtRealCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ntxtRealCost.UseGroupSeperator = true;
            this.ntxtRealCost.ZeroIsValid = true;
            this.ntxtRealCost.TextChanged += new System.EventHandler(this.ntxtRealCost_TextChanged);
            this.ntxtRealCost.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ntxtRealCost_KeyDown);
            // 
            // ntxtChangeCost
            // 
            this.ntxtChangeCost.AllowNegative = false;
            this.ntxtChangeCost.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ntxtChangeCost.ForeColor = System.Drawing.Color.Red;
            this.ntxtChangeCost.IsAutoRemoveDecimalZero = false;
            this.ntxtChangeCost.IsEnter2Tab = false;
            this.ntxtChangeCost.Location = new System.Drawing.Point(285, 97);
            this.ntxtChangeCost.Name = "ntxtChangeCost";
            this.ntxtChangeCost.NumericPrecision = 10;
            this.ntxtChangeCost.NumericScaleOnFocus = 2;
            this.ntxtChangeCost.NumericScaleOnLostFocus = 2;
            this.ntxtChangeCost.NumericValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ntxtChangeCost.SetRange = new System.Drawing.Size(-1, -1);
            this.ntxtChangeCost.Size = new System.Drawing.Size(113, 26);
            this.ntxtChangeCost.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.ntxtChangeCost.TabIndex = 6;
            this.ntxtChangeCost.Text = "0.00";
            this.ntxtChangeCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ntxtChangeCost.UseGroupSeperator = true;
            this.ntxtChangeCost.ZeroIsValid = true;
            // 
            // tbOK
            // 
            this.tbOK.Location = new System.Drawing.Point(213, 152);
            this.tbOK.Name = "tbOK";
            this.tbOK.Size = new System.Drawing.Size(75, 23);
            this.tbOK.Style = Neusoft.NFC.Interface.Controls.StyleType.Fixed3D;
            this.tbOK.TabIndex = 7;
            this.tbOK.Text = "确定(&O)";
            this.tbOK.Type = Neusoft.NFC.Interface.Controls.General.ButtonType.None;
            this.tbOK.UseVisualStyleBackColor = true;
            this.tbOK.Click += new System.EventHandler(this.btOK_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(310, 152);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "取消号(&C)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmReturnCost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 191);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ntxtWillCost);
            this.Controls.Add(this.neuLabel1);
            this.Controls.Add(this.tbOK);
            this.Controls.Add(this.ntxtChangeCost);
            this.Controls.Add(this.neuLabel2);
            this.Controls.Add(this.neuLabel3);
            this.Controls.Add(this.ntxtRealCost);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmReturnCost";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "挂号已经成功，找零窗口";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel1;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel2;
        private Neusoft.NFC.Interface.Controls.NeuLabel neuLabel3;
        private Neusoft.NFC.Interface.Controls.NeuNumericTextBox ntxtWillCost;
        private Neusoft.NFC.Interface.Controls.NeuNumericTextBox ntxtRealCost;
        private Neusoft.NFC.Interface.Controls.NeuNumericTextBox ntxtChangeCost;
        private Neusoft.NFC.Interface.Controls.NeuButton tbOK;
        private System.Windows.Forms.Button button1;
    }
}