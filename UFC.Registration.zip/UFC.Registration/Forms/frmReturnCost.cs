using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Neusoft.HISFC.Integrate.FeeInterface;

namespace Neusoft.UFC.Registration.Forms
{
    /// <summary>
    /// �Һ����㴰��{F0661633-4754-4758-B683-CB0DC983922B}
    /// </summary>
    public partial class frmReturnCost : Form
    {
        #region {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
        public delegate void BackCostHandle(object sender, ReturnCostEvent e);
        public event BackCostHandle BackCost;
        #endregion

        public frmReturnCost()
        {
            InitializeComponent();
        }

        #region ����
        /// <summary>
        /// �Һ�ʵ��
        /// </summary>
        private Neusoft.HISFC.Object.Registration.Register regObj;
        #endregion

        #region ����
        /// <summary>
        /// �Һ�ʵ��
        /// </summary>
        public Neusoft.HISFC.Object.Registration.Register RegObj
        {
            get
            {
                return regObj;
            }
            set
            {
                regObj = value;
                this.SetCost();
            }
        }
        #endregion

        #region ����
        /// <summary>
        /// У����
        /// </summary>
        /// <returns></returns>
        protected virtual int ValidValue()
        {
            //Ӧ�ս��
            decimal willCost = Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtWillCost.Text);

            //ʵ�ս��
            decimal realCost = Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtRealCost.Text);

            //������
            decimal changeCost = Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtChangeCost.Text);

            //ʵ�ս��С��Ӧ�ս��
            if (realCost < willCost)
            {
                MessageBox.Show("ʵ�ս���С��Ӧ�ս��");
                return -1;

            }

            return 1;


        }

        /// <summary>
        /// ��ֵ
        /// </summary>
        private void SetCost()
        {

            if (!this.ntxtRealCost.Focused)
            {
                this.ntxtRealCost.Focus();
            }
            this.ntxtWillCost.Text = this.RegObj.OwnCost.ToString();
            //minqsh 20100602 add��ʵ���Զ���ֵ {B8CBAC93-4E5B-46d9-82E3-9991279A1340}
            this.ntxtRealCost.Text = this.RegObj.OwnCost.ToString();

        }
        #endregion

        #region �¼�
        private void btOK_Click(object sender, EventArgs e)
        {
            //У������
            int retureValue = this.ValidValue();

            if (retureValue < 0)
            {
                return;
            }

            this.DialogResult = DialogResult.OK;

            #region {0A344A96-E3DD-4a4d-A91E-C3E3714634F6}
            if (BackCost != null)
            {
                ReturnCostEvent re = new ReturnCostEvent(Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtWillCost.Text),
                                                         Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtRealCost.Text),
                                                         Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtChangeCost.Text));
                BackCost(this, re);
            }
            #endregion

            this.Close();
        }

        private void ntxtRealCost_TextChanged(object sender, EventArgs e)
        {

            decimal willCost = Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtWillCost.Text);
            decimal realCost = Neusoft.NFC.Function.NConvert.ToDecimal(this.ntxtRealCost.Text);
            this.ntxtChangeCost.Text = (realCost - willCost).ToString();
        }

        private void ntxtRealCost_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.btOK_Click(sender, new EventArgs());
            }
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            //{C57BE0DB-CE4C-47dd-8879-17442C1BEA71}
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

    }
}